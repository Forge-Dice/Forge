from pathlib import Path
import zipfile,hashlib,json
root=Path(__file__).resolve().parent
out=root/'deliverables/MYSTERY-INFOFLOW-EVIDENCE.zip'
source_names=['MYST-0002.contract.FINAL-CANDIDATE.md','MYST-0003-EVIDENCE-ACCESS-V1.contract.DRAFT.md','MYST-0004-EVIDENCE-PRESENTATION-V1.contract.DRAFT.md','MYST-0005A-INTERROGATION-AUTHORING-V1.contract.DRAFT.md','MYST-0005B-INTERROGATION-RELEASE-V1.contract.DRAFT.md','MYST-CHALLENGE-0001.contract.DRAFT.md','MYST-SOLVABILITY-0001.contract.DRAFT.md','MYST-0004-EVIDENCE-PRESENTATION-PACKAGE.md','MYST-0005-INTERROGATION-PACKAGE.md','DIE-LEERE-VITRINE-HEADLESS-SPEC.html','DIE-LEERE-VITRINE-CASE-PACK.zip','MYST-0002-REPAIR-EVIDENCE.zip']
items=[]
for f in (root/'lab').rglob('*'):
 if f.is_file() and not f.is_symlink() and 'node_modules' not in f.parts and '__pycache__' not in f.parts:
  items.append((f,str(f.relative_to(root))))
for n in source_names:items.append((root/'inputs'/n,'source-artifacts/'+n))
for n in ['setup_sources.py','build_report.py','package_evidence.py']:items.append((root/n,n))
for f in (root/'deliverables').glob('*.html'):items.append((f,'reports/'+f.name))
hashes=[{'path':p,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size} for f,p in items]
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f,p in items:z.write(f,p)
 z.writestr('MANIFEST.json',json.dumps(hashes,indent=2)+'\n')
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(set(z.namelist()))
print(json.dumps({'file':str(out),'files':len(items)+1,'zipBytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()}))
