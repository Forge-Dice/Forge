// PROPOSED MINIMAL HOST, not reconstructed VS-5 (full draft unavailable).
import {hashCaseTruth} from '../vendor/case-truth.identity.ts';
import {hashCaseSolution} from '../vendor/case-solution.identity.ts';
import {parseAccusation} from './case-accusation.ts';
import {investigate,releaseEvidence,interrogate,availableQuestions,challenge,key,cmp,clone} from './boundaries.mjs';
import {digest} from './playerref.mjs';
export const fail=()=>({success:false,code:'ACTION_NOT_AVAILABLE'});
export function fresh(b){return {known:new Map(b.initial.map(e=>[key(e),e])),found:new Set(),journal:[],events:[],phase:'running'};}
export function publicView(b,s){return {phase:s.phase,entities:[...s.known.values()].map(e=>({kind:e.kind,ref:b.refs.refFor(e.kind,e.id)})).sort((a,b)=>cmp(a.ref,b.ref)),evidence:[...s.found].map(id=>b.refs.refFor('evidence',id)).sort(cmp),journal:s.journal};}
export function questionView(b,s){return availableQuestions(b.catalogue,b.profile,[...s.known.values()]);}
export function reduce(b,s,cmd){
 if(s.phase==='solved')return {success:false,code:'SESSION_COMPLETED'};
 if(!cmd||typeof cmd!=='object'||Array.isArray(cmd))return fail();
 const exact=names=>Object.keys(cmd).sort().join('|')===names.sort().join('|');
 const available=(r,k)=>{const e=b.refs.resolve(r,k);return e&&s.known.has(key(e))?e:null;};
 let out;
 if(cmd.type==='investigate'){
 if(!exact(['type','target','kind']))return fail();
 const k=({search_location:'location',examine_item:'item',examine_person:'person'})[cmd.kind];if(!k)return fail();
 const e=available(cmd.target,k);if(!e)return fail();
 const a={kind:cmd.kind,[{location:'locationId',item:'itemId',person:'personId'}[k]]:e.id},r=investigate(b.access,[...s.known.values()],a);if(!r.success)return fail();
 const observations=[];for(const id of r.found.filter(id=>!s.found.has(id))){const r=releaseEvidence(b.presentation,id,b.refs);if(!r.success)return {success:false,code:'HOST_UNAVAILABLE'};observations.push(r.observation);}
 observations.sort((a,b)=>cmp(a.evidence,b.evidence));
 for(const o of observations){const e=b.refs.resolve(o.evidence,'evidence');s.found.add(e.id);s.known.set(key(e),e);for(const m of o.mentions){const e=b.refs.resolve(m.ref,m.kind);s.known.set(key(e),e);}s.journal.push(o);}
 out={success:true,observations};
 }else if(cmd.type==='interrogate'){
 if(!exact(['type','npc','questionId']))return fail();const e=available(cmd.npc,'person');if(!e||e.id!==b.profile.npcId)return fail();
 const r=interrogate({truth:b.truth,solution:b.solution,snapshot:b.snapshot,catalogue:b.catalogue,profile:b.profile,refs:b.refs,known:[...s.known.values()],questionId:cmd.questionId});
 if(!r.success)return r.code==='QUESTION_NOT_AVAILABLE'?fail():{success:false,code:'HOST_UNAVAILABLE'};
 out=r;for(const m of r.observation.mentions??[]){const e=b.refs.resolve(m.ref,m.kind);s.known.set(key(e),e);}s.journal.push(r.observation);
 }else if(cmd.type==='accuse'){
 if(!exact(['type','literals'])||!Array.isArray(cmd.literals)||cmd.literals.length>256)return fail();
 const fields={person:'personId',location:'locationId',item:'itemId',event:'eventId',causeEvent:'causeEventId'},lits=[];
 for(const l of cmd.literals){if(!l||typeof l!=='object'||Object.keys(l).sort().join('|')!=='claim|value'||!l.claim||typeof l.value!=='boolean')return fail();
 const c={};for(const [f,v] of Object.entries(l.claim)){if(f in fields){const k=f==='causeEvent'?'event':f,e=available(v,k);if(!e)return fail();c[fields[f]]=e.id;}else c[f]=v;}lits.push({claim:c,value:l.value});}
 let a;try{a=parseAccusation({schemaVersion:1,caseId:b.truth.caseId,truthHash:hashCaseTruth(b.truth),literals:lits},b.truth);}catch{return fail();}
 const r=challenge(b.truth,b.solution,b.challenge,a);if(!r.success)return {success:false,code:'HOST_UNAVAILABLE'};out=r;if(r.verdict==='solved')s.phase='solved';
 }else return fail();
 s.events.push(clone(cmd));return out;
}
export function identity(b){return digest(JSON.stringify({version:'lab-session-v1',truth:hashCaseTruth(b.truth),solution:hashCaseSolution(b.solution),access:b.access,presentation:b.presentation,catalogue:b.catalogue,profile:b.profile,snapshot:b.snapshot,proof:b.proof,challenge:b.challenge,refConfiguration:b.refs.privateConfigurationHash}));}
export function save(b,s){const body={schemaVersion:1,packageIdentity:identity(b),rulesetVersion:'lab-session-v1',events:s.events};return {...body,checksum:digest(JSON.stringify(body))};}
export function replay(b,x){try{if(!x||Object.keys(x).sort().join('|')!=='checksum|events|packageIdentity|rulesetVersion|schemaVersion')return fail();const {checksum,...body}=x;if(checksum!==digest(JSON.stringify(body))||body.packageIdentity!==identity(b)||body.rulesetVersion!=='lab-session-v1'||body.schemaVersion!==1||!Array.isArray(body.events))return fail();const s=fresh(b);for(const e of body.events)if(!reduce(b,s,e).success)return fail();return {success:true,state:publicView(b,s)};}catch{return fail();}}
