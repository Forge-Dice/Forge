import { z } from "zod";
import { CaseIdSchema, type CaseTruth, type DeepReadonly } from "./case-truth.ts";
import { hashCaseTruth } from "./case-truth.identity.ts";
import {
  ConclusionClaimSchema,
  claimKey,
  evaluateConclusionClaim,
  type CaseSolution,
  type ConclusionClaim,
  type ConclusionEvaluation,
} from "./case-solution.ts";

// Player accusation and core verdict (MYST-0002). Core solved is canonical consistency plus
// required coverage; it is NOT a player challenge completion check.

const AccusationLiteralSchema = z.strictObject({ claim: ConclusionClaimSchema, value: z.boolean() });

const AccusationShapeSchema = z.strictObject({
  schemaVersion: z.literal(1),
  caseId: CaseIdSchema,
  truthHash: z.string().regex(/^[0-9a-f]{64}$/, "Expected a lowercase SHA-256 hex digest"),
  literals: z.array(AccusationLiteralSchema),
});

type AccusationShape = z.output<typeof AccusationShapeSchema>;

function checkAccusation(doc: AccusationShape, truth: CaseTruth, truthHash: string, ctx: z.RefinementCtx<AccusationShape>): void {
  const issue = (message: string, path: (string | number)[]) => ctx.addIssue({ code: "custom", message, path });
  let bound = true;
  if (doc.caseId !== truth.caseId) {
    issue(`Accusation is for ${doc.caseId}, not ${truth.caseId}`, ["caseId"]);
    bound = false;
  }
  if (doc.truthHash !== truthHash) {
    issue("truthHash does not match the given CaseTruth snapshot", ["truthHash"]);
    bound = false;
  }
  if (!bound) return;

  const events = new Set<string>(truth.events.map((e) => e.id));
  const persons = new Set<string>(truth.persons.map((p) => p.id));
  const seen = new Set<string>();
  doc.literals.forEach((literal, i) => {
    const claim: ConclusionClaim = literal.claim;
    const path = ["literals", i, "claim"];
    if (!events.has(claim.eventId)) issue(`Unknown event "${claim.eventId}"`, [...path, "eventId"]);
    if ("personId" in claim && !persons.has(claim.personId)) issue(`Unknown person "${claim.personId}"`, [...path, "personId"]);
    if (claim.kind === "eventCausedEvent" && !events.has(claim.causeEventId)) {
      issue(`Unknown event "${claim.causeEventId}"`, [...path, "causeEventId"]);
    }
    const key = claimKey(literal.claim);
    if (seen.has(key)) issue("Claim is asserted more than once", path);
    seen.add(key);
  });
}

function deepFreeze<T>(value: T): T {
  if (typeof value === "object" && value !== null) {
    for (const child of Object.values(value)) deepFreeze(child);
    Object.freeze(value);
  }
  return value;
}

export function createAccusationSchema(truth: CaseTruth) {
  const truthHash = hashCaseTruth(truth);
  return AccusationShapeSchema.superRefine((doc, ctx) => checkAccusation(doc, truth, truthHash, ctx))
    .transform((doc) => deepFreeze(structuredClone(doc)) as DeepReadonly<AccusationShape>)
    .brand<"Accusation">();
}

export type AccusationInput = z.input<ReturnType<typeof createAccusationSchema>>;
export type Accusation = z.output<ReturnType<typeof createAccusationSchema>>;

export function parseAccusation(input: unknown, truth: CaseTruth): Accusation {
  return createAccusationSchema(truth).parse(input);
}

export type Verdict = "solved" | "not_solved";
export type AccusationResult =
  | { readonly success: true; readonly verdict: Verdict }
  | { readonly success: false; readonly code: "ACCUSATION_BINDING_MISMATCH" | Extract<ConclusionEvaluation, { success: false }>["code"] };

function failure(code: Extract<AccusationResult, { success: false }>["code"]): AccusationResult {
  return Object.freeze({ success: false, code });
}

export function evaluateAccusation(truth: CaseTruth, solution: CaseSolution, accusation: Accusation): AccusationResult {
  const truthHash = hashCaseTruth(truth);
  if (accusation.caseId !== truth.caseId || accusation.truthHash !== truthHash) return failure("ACCUSATION_BINDING_MISMATCH");
  if (solution.caseId !== truth.caseId || solution.truthHash !== truthHash) return failure("SOLUTION_BINDING_MISMATCH");

  let contradicted = false;
  const asserted = new Map<string, boolean>();
  for (const literal of accusation.literals) {
    const evaluation = evaluateConclusionClaim(truth, solution, literal.claim);
    if (!evaluation.success) return failure(evaluation.code);
    if (evaluation.status !== "undetermined" && evaluation.status !== literal.value) contradicted = true;
    asserted.set(claimKey(literal.claim), literal.value);
  }
  const catalog = new Map(solution.conclusions.map((conclusion) => [conclusion.id, conclusion.claim]));
  const covered = solution.requiredConclusions.every(
    (literal) => asserted.get(claimKey(catalog.get(literal.conclusionId)!)) === literal.value,
  );
  return Object.freeze({ success: true, verdict: covered && !contradicted ? "solved" : "not_solved" });
}
