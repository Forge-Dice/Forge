// HYPOTHESIS ONLY: full MYST-0001 unavailable. Not its protocol/golden vectors.
import {createHash} from 'node:crypto';
export const ALPHABET='0123456789abcdefghjkmnpqrstvwxyz';
export const REF_PATTERN=/^pr1_[0-9a-hjkmnp-tv-z]{16}$/;
export const kinds=['person','location','item','event','evidence'];
export const cols=['persons','locations','items','events','evidence'];
export const digest=s=>createHash('sha256').update(s).digest('hex');
export function encode(bytes) {
 let n=BigInt('0x'+Buffer.from(bytes).subarray(0,10).toString('hex')), s='';
 for(let i=0;i<16;i++){s=ALPHABET[Number(n&31n)]+s;n>>=5n;} return 'pr1_'+s;
}
export function buildIndex(truth,truthHash,{salt='00112233445566778899aabbccddeeff',namespace=truthHash,hash=s=>createHash('sha256').update(s).digest()}={}) {
 if(!/^[0-9a-f]{32}$/.test(salt))throw new Error('INVALID_SALT');
 const forward=new Map(),reverse=new Map();
 for(let i=0;i<kinds.length;i++)for(const e of truth[cols[i]]){
  const kind=kinds[i],key=kind+'|'+e.id;
  const r=encode(hash(JSON.stringify(['infoflow-lab-ref-v1',namespace,salt,kind,e.id])));
  if(reverse.has(r)&&reverse.get(r).id!==e.id)throw new Error('REF_COLLISION');
  forward.set(key,r);reverse.set(r,Object.freeze({kind,id:e.id}));
 }
 const privateConfigurationHash=digest(JSON.stringify(['infoflow-lab-ref-v1',namespace,salt]));
 return Object.freeze({caseId:truth.caseId,truthHash,namespace,privateConfigurationHash,refFor:(kind,id)=>forward.get(kind+'|'+id)??null,
 resolve:(r,kind)=>typeof r==='string'&&REF_PATTERN.test(r)&&reverse.has(r)&&(!kind||reverse.get(r).kind===kind)?reverse.get(r):null});
}
