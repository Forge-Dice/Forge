// TEMPORARY IMPLEMENTATION MODELS. Main projection is imported without changes.
import {z} from 'zod';
import * as T from '../vendor/case-truth.ts';
import {ConclusionClaimSchema} from '../vendor/case-solution.ts';
import {AwarenessSubjectSchema} from '../vendor/npc-knowledge.ts';
import {projectNpcKnowledge} from '../vendor/npc-knowledge.projection.ts';
import {hashCaseTruth} from '../vendor/case-truth.identity.ts';
import {hashCaseSolution} from '../vendor/case-solution.identity.ts';
import {evaluateConclusionClaim,claimKey} from './case-solution.ts';
import {evaluateAccusation} from './case-accusation.ts';
import {REF_PATTERN,digest} from './playerref.mjs';
export const clone=structuredClone;
export const cmp=(a,b)=>a<b?-1:a>b?1:0;
export const key=e=>e.kind+'|'+e.id;
export function freeze(x){if(x&&typeof x==='object'){Object.values(x).forEach(freeze);Object.freeze(x);}return x;}
export function canonical(x){if(Array.isArray(x))return '['+x.map(canonical).sort(cmp).join(',')+']';if(x&&typeof x==='object')return '{'+Object.keys(x).sort(cmp).map(k=>JSON.stringify(k)+':'+canonical(x[k])).join(',')+'}';return JSON.stringify(x);}
export const catalogueHash=c=>digest('forge-interrogation-catalogue-c14n-v1\n'+canonical(c));
const error=code=>freeze({success:false,code});
const sha=z.string().regex(/^[0-9a-f]{64}$/);
const idsets=t=>new Map(['person','location','item','event','evidence'].map((k,i)=>[k,new Set(t[['persons','locations','items','events','evidence'][i]].map(e=>e.id))]));
const exists=(sets,e)=>sets.get(e.kind)?.has(e.id);
export function claimRefs(c){
 const fields={personId:'person',locationId:'location',itemId:'item',eventId:'event',causeEventId:'event'};
 const r=[];for(const [f,k] of Object.entries(fields))if(f in c)r.push({kind:k,id:c[f]});
 return [...new Map(r.map(e=>[key(e),e])).values()];
}
export function playerClaim(c,ref){
 switch(c.kind){
 case 'personAt':return {kind:c.kind,person:ref('person',c.personId),location:ref('location',c.locationId),at:c.at};
 case 'eventHasParticipant':return {kind:c.kind,event:ref('event',c.eventId),person:ref('person',c.personId)};
 case 'eventHasItem':return {kind:c.kind,event:ref('event',c.eventId),item:ref('item',c.itemId)};
 case 'personResponsibleForEvent':return {kind:c.kind,person:ref('person',c.personId),event:ref('event',c.eventId)};
 case 'personRoleForEvent':return {kind:c.kind,person:ref('person',c.personId),event:ref('event',c.eventId),role:c.role};
 case 'noPersonResponsibleForEvent':return {kind:c.kind,event:ref('event',c.eventId)};
 case 'eventCausedEvent':return {kind:c.kind,causeEvent:ref('event',c.causeEventId),event:ref('event',c.eventId)};
 case 'eventIntent':case 'eventMechanism':return {kind:c.kind,event:ref('event',c.eventId),value:c.value};
 default:throw new Error('INVALID_CLAIM');
 }
}
export const actionSchema=z.discriminatedUnion('kind',[
 z.strictObject({kind:z.literal('search_location'),locationId:T.LocationIdSchema}),
 z.strictObject({kind:z.literal('examine_item'),itemId:T.ItemIdSchema}),
 z.strictObject({kind:z.literal('examine_person'),personId:T.PersonIdSchema})]);
export const targetOf=a=>a.kind==='search_location'?{kind:'location',id:a.locationId}:a.kind==='examine_item'?{kind:'item',id:a.itemId}:{kind:'person',id:a.personId};
const accessSchema=z.strictObject({schemaVersion:z.literal(1),caseId:T.CaseIdSchema,truthHash:sha,entries:z.array(z.strictObject({evidenceId:T.EvidenceIdSchema,access:z.discriminatedUnion('kind',[
 z.strictObject({kind:z.literal('inaccessible')}),z.strictObject({kind:z.literal('discoverable'),paths:z.array(actionSchema).min(1)})])}))});
export function parseAccess(raw,t){
 const s=accessSchema.superRefine((m,ctx)=>{
 const issue=(message,path)=>ctx.addIssue({code:'custom',message,path});
 if(m.caseId!==t.caseId||m.truthHash!==hashCaseTruth(t)){issue('BINDING_MISMATCH',[]);return;}
 const ids=new Set(t.evidence.map(e=>e.id)),seen=new Set(),sets=idsets(t);
 m.entries.forEach((e,i)=>{if(!ids.has(e.evidenceId)||seen.has(e.evidenceId))issue('EVIDENCE_REFERENCE',['entries',i]);seen.add(e.evidenceId);
 if(e.access.kind==='discoverable'){const paths=new Set();e.access.paths.forEach((p,j)=>{const target=targetOf(p),k=key(target);if(!exists(sets,target)||paths.has(k))issue('TARGET_REFERENCE',['entries',i,'access','paths',j]);paths.add(k);});}});
 for(const id of ids)if(!seen.has(id))issue('MISSING '+id,['entries']);
 });return freeze(clone(s.parse(raw)));
}
export function investigate(m,known,action){
 const a=actionSchema.safeParse(action);if(!a.success)return error('INVALID_ACTION');
 const k=z.array(AwarenessSubjectSchema).safeParse(known);if(!k.success)return error('INVALID_KNOWN_REFS');
 const keys=new Set(k.data.map(key));if(!keys.has(key(targetOf(a.data))))return error('TARGET_NOT_KNOWN');
 return freeze({success:true,found:m.entries.filter(e=>e.access.kind==='discoverable'&&e.access.paths.some(p=>key(targetOf(p))===key(targetOf(a.data)))).map(e=>e.evidenceId).sort(cmp)});
}
export const FORBIDDEN=/[\u0000-\u0009\u000b-\u001f\u007f-\u009f\u061c\u200b\u200e\u200f\u2028\u2029\u202a-\u202e\u2060\u2066-\u2069\ufeff]/;
export const ID_TEXT=/(?:case|person|location|item|relationship|event|motive|proposition|evidence|secret|red-herring|conclusion):[a-z0-9]/;
export const REF_TEXT=/pr1_[0-9a-z]{16}/;
export const playerText=z.string().max(1000).superRefine((s,ctx)=>{for(const [condition,message] of [[!/\S/.test(s),'EMPTY'],[!s.isWellFormed(),'UNICODE'],[FORBIDDEN.test(s),'CONTROL'],[ID_TEXT.test(s),'CANONICAL_ID'],[REF_TEXT.test(s),'PLAYER_REF']])if(condition)ctx.addIssue({code:'custom',message});});
const mention=z.discriminatedUnion('kind',[
 z.strictObject({kind:z.literal('person'),id:T.PersonIdSchema}),z.strictObject({kind:z.literal('location'),id:T.LocationIdSchema}),
 z.strictObject({kind:z.literal('item'),id:T.ItemIdSchema}),z.strictObject({kind:z.literal('event'),id:T.EventIdSchema})]);
const report=z.strictObject({claim:T.ClaimSchema,stance:z.enum(['affirms','denies']),source:z.discriminatedUnion('kind',[
 z.strictObject({kind:z.literal('observation')}),z.strictObject({kind:z.literal('testimony'),personId:T.PersonIdSchema})])});
const presentationSchema=z.strictObject({schemaVersion:z.literal(1),caseId:T.CaseIdSchema,truthHash:sha,entries:z.array(z.strictObject({evidenceId:T.EvidenceIdSchema,text:playerText,mentions:z.array(mention).max(16),reports:z.array(report).max(8)}))});
export function parsePresentation(raw,t){
 const s=presentationSchema.superRefine((p,ctx)=>{
 const issue=(message,path)=>ctx.addIssue({code:'custom',message,path});
 if(p.caseId!==t.caseId||p.truthHash!==hashCaseTruth(t)){issue('BINDING_MISMATCH',[]);return;}
 const ids=new Set(t.evidence.map(e=>e.id)),seen=new Set(),sets=idsets(t);
 p.entries.forEach((e,i)=>{if(!ids.has(e.evidenceId)||seen.has(e.evidenceId))issue('EVIDENCE_REFERENCE',['entries',i]);seen.add(e.evidenceId);
 const mk=new Set();e.mentions.forEach((m,j)=>{if(!exists(sets,m)||mk.has(key(m)))issue('MENTION',['entries',i,'mentions',j]);mk.add(key(m));});
 const rk=new Set();e.reports.forEach((r,j)=>{const refs=claimRefs(r.claim);if(r.source.kind==='testimony')refs.push({kind:'person',id:r.source.personId});
 if(refs.some(x=>!mk.has(key(x))))issue('UNCLOSED_REPORT',['entries',i,'reports',j]);
 const k=canonical([r.claim,r.source]);if(rk.has(k))issue('DUPLICATE_REPORT',['entries',i,'reports',j]);rk.add(k);});});
 for(const id of ids)if(!seen.has(id))issue('MISSING '+id,['entries']);
 });return freeze(clone(s.parse(raw)));
}
export function releaseEvidence(p,id,refs){
 if(refs.caseId!==p.caseId||refs.truthHash!==p.truthHash)return error('BINDING_MISMATCH');
 const e=p.entries.find(e=>e.evidenceId===id);if(!e)return error('UNKNOWN_EVIDENCE');
 const mapping=new Map(),used=new Set();for(const entity of [{kind:'evidence',id:e.evidenceId},...e.mentions]){
 const r=refs.refFor(entity.kind,entity.id);if(typeof r!=='string'||!REF_PATTERN.test(r)||used.has(r))return error('REF_UNAVAILABLE');used.add(r);mapping.set(key(entity),r);}
 const ref=(kind,id)=>mapping.get(key({kind,id}));
 const reports=e.reports.map(r=>({claim:playerClaim(r.claim,ref),stance:r.stance,source:r.source.kind==='observation'?{kind:'observation'}:{kind:'testimony',person:ref('person',r.source.personId)}})).sort((a,b)=>cmp(JSON.stringify(a),JSON.stringify(b)));
 return freeze({success:true,observation:{schemaVersion:1,evidence:ref('evidence',e.evidenceId),text:e.text,mentions:e.mentions.map(m=>({kind:m.kind,ref:ref(m.kind,m.id)})).sort((a,b)=>cmp(a.ref,b.ref)),reports}});
}
export const questionIdSchema=z.string().regex(/^question:[a-z0-9][a-z0-9_-]{0,63}$/);
const catalogSchema=z.strictObject({schemaVersion:z.literal(1),caseId:T.CaseIdSchema,truthHash:sha,revision:z.int().positive(),questions:z.array(z.strictObject({id:questionIdSchema,mentions:z.array(AwarenessSubjectSchema).min(1)})).min(1)});
const profileSchema=z.strictObject({schemaVersion:z.literal(1),caseId:T.CaseIdSchema,truthHash:sha,catalogueHash:sha,npcId:T.PersonIdSchema,revision:z.int().positive(),rules:z.array(z.discriminatedUnion('act',[
 z.strictObject({questionId:questionIdSchema,act:z.literal('decline')}),z.strictObject({questionId:questionIdSchema,act:z.literal('answer'),claim:z.union([T.ClaimSchema,ConclusionClaimSchema]),reveal:z.array(AwarenessSubjectSchema)})]))});
export function parseCatalogue(raw,t){const c=catalogSchema.parse(raw),sets=idsets(t);if(c.caseId!==t.caseId||c.truthHash!==hashCaseTruth(t))throw new Error('BINDING');
 const seen=new Set();for(const q of c.questions){if(seen.has(q.id))throw new Error('DUPLICATE');seen.add(q.id);const ms=new Set();for(const m of q.mentions){if(!exists(sets,m)||ms.has(key(m)))throw new Error('MENTION');ms.add(key(m));}}return freeze(clone(c));}
export function parseProfile(raw,t,c){const p=profileSchema.parse(raw),sets=idsets(t);if(p.caseId!==t.caseId||p.truthHash!==hashCaseTruth(t)||c.truthHash!==p.truthHash||p.catalogueHash!==catalogueHash(c))throw new Error('BINDING');
 if(!sets.get('person').has(p.npcId))throw new Error('NPC');const seen=new Set();for(const r of p.rules){const q=c.questions.find(q=>q.id===r.questionId);if(!q||seen.has(r.questionId))throw new Error('QUESTION');seen.add(r.questionId);if(r.act==='decline')continue;
 const refs=claimRefs(r.claim),M=new Set([...q.mentions.map(key),'person|'+p.npcId]),C=new Set(refs.map(key)),R=new Set(r.reveal.map(key));
 if(refs.some(e=>!exists(sets,e))||r.reveal.some(e=>!exists(sets,e)))throw new Error('REFERENCE');
 if(refs.some(e=>!M.has(key(e))&&!R.has(key(e)))||r.reveal.some(e=>!C.has(key(e))||M.has(key(e)))||R.size!==r.reveal.length)throw new Error('RELEASE');}return freeze(clone(p));}
export function bridgeProjection(snapshot,truth,solution){
 const p=projectNpcKnowledge(snapshot,truth,solution);if(!p.success)return p;
 const claims=new Map([...truth.propositions,...(solution?.conclusions??[])].map(x=>[x.id,x.claim]));
 const v=new Map(['person','location','item','event','evidence','proposition','conclusion'].map(k=>[k,new Set()]));
 v.get('person').add(snapshot.npcId);for(const a of snapshot.awareness)v.get(a.subject.kind).add(a.subject.id);
 for(const a of snapshot.attitudes){v.get(a.subject.kind).add(a.subject.id);for(const r of claimRefs(claims.get(a.subject.id)))v.get(r.kind).add(r.id);}
 const forward=new Map(),reverse=new Map();for(const [kind,ids] of v)[...ids].sort(cmp).forEach((id,i)=>{forward.set(kind+'|'+id,i+1);reverse.set(kind+'|'+(i+1),{kind,id});});
 const emitted=new Map();function walk(x){if(!x||typeof x!=='object')return;if('index'in x&&['person','location','item','event','evidence'].includes(x.kind))emitted.set(x,reverse.get(x.kind+'|'+x.index));for(const child of Object.values(x))walk(child);}walk(p.context);
 const bridge=Object.freeze({entityOf:r=>emitted.has(r)?freeze(clone(emitted.get(r))):null,visibleClaimOf:c=>claimRefs(c).every(e=>forward.has(key(e)))?freeze(playerClaim(c,(kind,id)=>({kind,index:forward.get(kind+'|'+id)}))):null,toJSON(){throw new TypeError('PRIVATE_CAPABILITY');}});
 return Object.freeze({success:true,context:p.context,bridge});
}
export function decideResponse(c,target){if(target===null)return freeze({stance:'does_not_know',claim:null});const a=c.attitudes.find(a=>canonical(a.claim)===canonical(target));if(!a)return freeze({stance:'does_not_know',claim:null});
 const s=a.stance,stance=s.kind==='uncertain'?(s.leaning===null?'uncertain':s.leaning?'leans_affirms':'leans_denies'):(s.value?'affirms':'denies');return freeze({stance,claim:a.claim});}
export function createTranslator(bridge,refs,authorized){const allowed=new Set(authorized.map(key));return Object.freeze({translate:r=>{const e=bridge.entityOf(r);if(!e||!allowed.has(key(e)))return null;const p=refs.refFor(e.kind,e.id);return typeof p==='string'&&REF_PATTERN.test(p)?p:null;},toJSON(){throw new TypeError('PRIVATE_CAPABILITY');}});}
export function availableQuestions(c,p,known){const k=new Set(known.map(key));return p.rules.filter(r=>k.has('person|'+p.npcId)&&c.questions.find(q=>q.id===r.questionId).mentions.every(m=>k.has(key(m)))).map(r=>r.questionId).sort(cmp);}
export function interrogate({truth:t,solution:s,snapshot:n,catalogue:c,profile:p,refs,known,questionId}){
 const h=hashCaseTruth(t),proj=bridgeProjection(n,t,s);
 if(!proj.success||[c,p,refs].some(x=>x.caseId!==t.caseId||x.truthHash!==h)||p.catalogueHash!==catalogueHash(c)||p.npcId!==n.npcId)return error('BINDING_MISMATCH');
 const r=typeof questionId==='string'?p.rules.find(r=>r.questionId===questionId):null,q=r?c.questions.find(q=>q.id===questionId):null,k=new Set(known.map(key));
 if(!r||!q||![...q.mentions,{kind:'person',id:n.npcId}].every(e=>k.has(key(e))))return error('QUESTION_NOT_AVAILABLE');
 const npc=refs.refFor('person',n.npcId);if(typeof npc!=='string'||!REF_PATTERN.test(npc))return error('REF_UNAVAILABLE');
 const base={schemaVersion:1,npc,questionId,act:r.act};if(r.act==='decline')return freeze({success:true,observation:base});
 const d=decideResponse(proj.context,proj.bridge.visibleClaimOf(r.claim));if(d.stance==='does_not_know')return freeze({success:true,observation:{...base,stance:d.stance}});
 const tr=createTranslator(proj.bridge,refs,[...q.mentions,{kind:'person',id:n.npcId},...r.reveal]),used=new Map([[npc,'person|'+n.npcId]]),mentions=new Map();let fail=false;
 const statement={};for(const [f,v] of Object.entries(d.claim)){if(v&&typeof v==='object'&&'index'in v){const e=proj.bridge.entityOf(v),pr=tr.translate(v);if(!pr||!e||used.has(pr)&&used.get(pr)!==key(e)){fail=true;break;}used.set(pr,key(e));mentions.set(key(e),{kind:e.kind,ref:pr});statement[f]=pr;}else statement[f]=v;}
 if(fail)return error('REF_UNAVAILABLE');return freeze({success:true,observation:{...base,stance:d.stance,statement,mentions:[...mentions.values()].sort((a,b)=>cmp(a.ref,b.ref))}});
}
export function challenge(t,s,ch,a){
 const h=hashCaseTruth(t);if(s.caseId!==t.caseId||s.truthHash!==h)return error('SOLUTION_BINDING_MISMATCH');
 if(ch.caseId!==t.caseId||ch.truthHash!==h||ch.solutionHash!==hashCaseSolution(s))return error('CHALLENGE_BINDING_MISMATCH');
 if(a.caseId!==t.caseId||a.truthHash!==h)return error('ACCUSATION_BINDING_MISMATCH');
 const no=()=>freeze({success:true,verdict:'not_solved'}),scope=new Set(ch.allowedClaims.map(claimKey));
 if(a.literals.length>scope.size||a.literals.some(l=>!scope.has(claimKey(l.claim))))return no();
 for(const l of a.literals){const e=evaluateConclusionClaim(t,s,l.claim);if(!e.success)return e;if(e.status==='undetermined'||e.status!==l.value)return no();}
 return evaluateAccusation(t,s,a);
}
