import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {parseCaseTruth} from './vendor/case-truth.ts';
import {hashCaseTruth} from './vendor/case-truth.identity.ts';
import {parseCaseSolution,createCaseSolutionSchema} from './vendor/case-solution.ts';
import {hashCaseSolution} from './vendor/case-solution.identity.ts';
import {parseNpcKnowledge} from './vendor/npc-knowledge.ts';
import {projectNpcKnowledge} from './vendor/npc-knowledge.projection.ts';
import {evaluateConclusionClaim,claimKey} from './model/case-solution.ts';
import {parseAccusation} from './model/case-accusation.ts';
import * as M from './model/boundaries.mjs';
import {buildIndex,REF_PATTERN,digest} from './model/playerref.mjs';
import * as H from './model/session.mjs';
const OUT=new URL('./results/',import.meta.url);fs.mkdirSync(OUT,{recursive:true});
const write=(n,v)=>fs.writeFileSync(new URL(n,OUT),JSON.stringify(v,null,2)+'\n');
let checks=0;const check=(v,msg)=>{checks++;assert.ok(v,msg);},eq=(a,b,msg)=>{checks++;assert.deepEqual(a,b,msg);};
const plain=x=>JSON.parse(JSON.stringify(x));
const stmt=(kind,id)=>({kind,id});
const families=['truth_value','knowledge_true_vs_belief_true','knowledge_false_vs_belief_false','winning_polarity','hidden_entity_added','hidden_entity_deleted','required_conclusions','evidence_links_source','hidden_npc_awareness','provenance','acquisition_time','secret_membership','red_herring_membership','proof_edge','raw_description','responsibility_completeness'];
const publicIds=['person:bravo','person:charlie','person:npc','location:lab','item:tool','event:public'];
function raw(i){
 const time=100+i,truth={schemaVersion:1,caseId:'case:twin-'+i,revision:1,title:'Labor '+i,timeline:{unit:'second',originLabel:'Start'},
 persons:[{id:'person:bravo',name:'B'},{id:'person:charlie',name:'C'},{id:'person:npc',name:'N'},{id:'person:aaa-hidden',name:'PRIVATE_NAME_'+i}],
 locations:[{id:'location:lab',name:'Raum'},{id:'location:hidden',name:'PRIVATE_LOCATION'}],items:[{id:'item:tool',name:'Werkzeug'}],relationships:[],motives:[],
 events:[{id:'event:public',description:'PRIVATE_EVENT_'+i,time:{kind:'instant',at:time},locationId:'location:lab',participantIds:[],itemIds:[],causedByEventIds:[]}],
 propositions:[{id:'proposition:shown',claim:{kind:'personAt',personId:'person:bravo',locationId:'location:lab',at:time},truth:true},
 {id:'proposition:negative',claim:{kind:'personAt',personId:'person:charlie',locationId:'location:lab',at:time},truth:false},
 {id:'proposition:hidden',claim:{kind:'personAt',personId:'person:aaa-hidden',locationId:'location:hidden',at:time+7},truth:true}],
 evidence:[{id:'evidence:shown',description:'PRIVATE_RAW_'+i,source:{kind:'location',id:'location:hidden'},links:[{propositionId:'proposition:hidden',direction:'supports'}]},
 {id:'evidence:inaccessible',description:'PRIVATE_INACCESSIBLE_'+i,source:{kind:'person',id:'person:aaa-hidden'},links:[{propositionId:'proposition:hidden',direction:'supports'}]}],secrets:[{id:'secret:hidden',propositionIds:['proposition:hidden']}],redHerrings:[{id:'red-herring:hidden',evidenceIds:['evidence:inaccessible'],misleadingPropositionId:'proposition:hidden'}]};
 const claims=[{kind:'personResponsibleForEvent',personId:'person:bravo',eventId:'event:public'},
 {kind:'personResponsibleForEvent',personId:'person:charlie',eventId:'event:public'},
 {kind:'noPersonResponsibleForEvent',eventId:'event:public'},
 {kind:'personRoleForEvent',personId:'person:bravo',eventId:'event:public',role:'direct_actor'},
 {kind:'eventIntent',eventId:'event:public',value:'intended'},
 {kind:'eventMechanism',eventId:'event:public',value:'ordinary'}];
 const solution={schemaVersion:1,caseId:truth.caseId,truthHash:'',revision:1,resolutions:[{eventId:'event:public',targets:[],responsibility:{completeness:'complete',assignments:[{personId:'person:bravo',roles:['direct_actor']}]},intent:'intended',mechanism:'ordinary',causesComplete:true}],conclusions:claims.map((claim,j)=>({id:'conclusion:c'+j,claim})),requiredConclusions:[{conclusionId:'conclusion:c0',value:true}]};
 const snapshot={schemaVersion:1,caseId:truth.caseId,truthHash:'',solutionHash:'',npcId:'person:npc',revision:1,asOf:500+i,awareness:publicIds.map(id=>({subject:stmt(id.split(':')[0],id),acquiredAt:0,provenance:{kind:'prior_knowledge'}})),attitudes:[
 {subject:stmt('proposition','proposition:shown'),stance:{kind:'knowledge',value:true},acquiredAt:0,provenance:{kind:'prior_knowledge'}},
 {subject:stmt('proposition','proposition:negative'),stance:{kind:'knowledge',value:false},acquiredAt:0,provenance:{kind:'prior_knowledge'}},
 {subject:stmt('conclusion','conclusion:c0'),stance:{kind:'belief',value:Boolean(i&1)},acquiredAt:0,provenance:{kind:'prior_knowledge'}}]};
 const catalogue={schemaVersion:1,caseId:truth.caseId,truthHash:'',revision:1,questions:[
 {id:'question:q1',mentions:[stmt('person','person:bravo'),stmt('location','location:lab')]},
 {id:'question:q2',mentions:[stmt('person','person:charlie'),stmt('location','location:lab')]},
 {id:'question:q3',mentions:[stmt('person','person:bravo'),stmt('event','event:public')]},
 {id:'question:q4',mentions:[stmt('person','person:bravo')]},
 {id:'question:q5',mentions:[stmt('location','location:hidden')]},
 {id:'question:q6',mentions:[stmt('person','person:charlie')]}]};
 const profile={schemaVersion:1,caseId:truth.caseId,truthHash:'',catalogueHash:'',npcId:'person:npc',revision:1,rules:[
 {questionId:'question:q1',act:'answer',claim:truth.propositions[0].claim,reveal:[]},
 {questionId:'question:q2',act:'answer',claim:truth.propositions[1].claim,reveal:[]},
 {questionId:'question:q3',act:'answer',claim:claims[0],reveal:[]},
 {questionId:'question:q4',act:'answer',claim:{kind:'eventHasParticipant',eventId:'event:public',personId:'person:bravo'},reveal:[stmt('event','event:public')]},
 {questionId:'question:q5',act:'decline'},
 {questionId:'question:q6',act:'decline'}]};
 const access={schemaVersion:1,caseId:truth.caseId,truthHash:'',entries:[{evidenceId:'evidence:shown',access:{kind:'discoverable',paths:[{kind:'search_location',locationId:'location:lab'},{kind:'examine_item',itemId:'item:tool'},{kind:'examine_person',personId:'person:bravo'}]}},{evidenceId:'evidence:inaccessible',access:{kind:'inaccessible'}}]};
 const presentation={schemaVersion:1,caseId:truth.caseId,truthHash:'',entries:[{evidenceId:'evidence:shown',text:'Freigegebene Karte '+i,mentions:catalogue.questions[0].mentions,reports:[{claim:truth.propositions[0].claim,stance:'affirms',source:{kind:'observation'}}]},{evidenceId:'evidence:inaccessible',text:'Noch nicht freigegebene Karte',mentions:[],reports:[]}]};
 return {truth,solution,snapshot,catalogue,profile,access,presentation,proof:{privateEdges:[{id:'edge:private',premises:['secret:hidden'],yields:'conclusion:c0'}]},initial:publicIds.map(id=>stmt(id.split(':')[0],id))};
}
function bind(r,i,mode='fixed'){
 const truth=parseCaseTruth(r.truth),th=hashCaseTruth(truth);const solution=parseCaseSolution({...r.solution,truthHash:th},truth),sh=hashCaseSolution(solution);
 const snapshot=parseNpcKnowledge({...r.snapshot,truthHash:th,solutionHash:sh},truth,solution);
 const catalogue=M.parseCatalogue({...r.catalogue,truthHash:th},truth),profile=M.parseProfile({...r.profile,truthHash:th,catalogueHash:M.catalogueHash(catalogue)},truth,catalogue);
 const access=M.parseAccess({...r.access,truthHash:th},truth),presentation=M.parsePresentation({...r.presentation,truthHash:th},truth);
 const refs=buildIndex(truth,th,{namespace:mode==='fixed'?'isolated-public-port-'+i:th});
 const challenge={schemaVersion:1,caseId:truth.caseId,truthHash:th,solutionHash:sh,allowedClaims:solution.conclusions.map(c=>c.claim)};
 return {...r,truth,solution,snapshot,catalogue,profile,access,presentation,refs,challenge};
}
function mutate(r,f,i){const b=M.clone(r);
 switch(f){
 case 'truth_value':b.truth.propositions[2].truth=false;break;
 case 'knowledge_true_vs_belief_true':b.snapshot.attitudes[0].stance.kind='belief';break;
 case 'knowledge_false_vs_belief_false':b.snapshot.attitudes[1].stance.kind='belief';break;
 case 'winning_polarity':b.solution.resolutions[0].responsibility.assignments=[{personId:'person:charlie',roles:['direct_actor']}];b.solution.requiredConclusions[0].value=false;break;
 case 'hidden_entity_added':for(let k=0;k<1+(i%4);k++)b.truth.persons.push({id:'person:added-'+k,name:'PRIVATE_ADDED'});break;
 case 'hidden_entity_deleted':b.truth.evidence.pop();b.truth.redHerrings=[];b.access.entries.pop();b.presentation.entries.pop();break;
 case 'required_conclusions':b.solution.requiredConclusions.push({conclusionId:'conclusion:c'+(i%3+3),value:true});break;
 case 'evidence_links_source':b.truth.evidence[0].source={kind:'person',id:'person:bravo'};b.truth.evidence[0].links=[{propositionId:'proposition:negative',direction:'refutes'}];break;
 case 'hidden_npc_awareness':b.snapshot.awareness.push({subject:stmt('person','person:aaa-hidden'),acquiredAt:0,provenance:{kind:'prior_knowledge'}});break;
 case 'provenance':b.snapshot.attitudes[0].provenance={kind:'told_by_person',personId:'person:aaa-hidden'};break;
 case 'acquisition_time':b.snapshot.attitudes[0].provenance={kind:'author_modeled_inference'};r.snapshot.attitudes[0].provenance={kind:'author_modeled_inference'};b.snapshot.attitudes[0].acquiredAt=1+i;break;
 case 'secret_membership':b.truth.secrets[0].propositionIds=['proposition:negative'];break;
 case 'red_herring_membership':b.truth.redHerrings[0].evidenceIds=['evidence:shown'];b.truth.redHerrings[0].misleadingPropositionId='proposition:negative';break;
 case 'proof_edge':b.proof.privateEdges[0].premises=['secret:hidden','private:extra-'+i];break;
 case 'raw_description':b.truth.evidence[0].description='PRIVATE_DIFFERENT_'+i;break;
 case 'responsibility_completeness':b.solution.resolutions[0].responsibility.completeness='partial';break;
 }return b;}
function commands(b){const pr=(k,id)=>b.refs.refFor(k,id);return [
 {type:'investigate',kind:'search_location',target:pr('location','location:lab')},
 {type:'investigate',kind:'search_location',target:pr('location','location:lab')},
 {type:'investigate',kind:'examine_item',target:pr('item','item:tool')},
 {type:'investigate',kind:'examine_person',target:pr('person','person:charlie')},
 ...['question:q1','question:q2','question:q3','question:q4','question:q5','question:q6','question:unknown',null,{},'question:q1\n'].map(questionId=>({type:'interrogate',npc:pr('person','person:npc'),questionId})),
 ...[null,'pr1_0000000000000000','person:bravo',pr('person','person:aaa-hidden'),pr('item','item:tool')].map(target=>({type:'investigate',kind:'search_location',target})),
 {type:'invalid'},{type:'interrogate',npc:pr('person','person:aaa-hidden'),questionId:'question:q1'}];}
function observe(b){const s=H.fresh(b),initial=H.publicView(b,s),availability=[H.questionView(b,s)],outputs=[];
 for(const c of commands(b)){outputs.push(H.reduce(b,s,c));availability.push(H.questionView(b,s));}
 const saved=H.save(b,s),replay=H.replay(b,saved);eq(replay,{success:true,state:H.publicView(b,s)},'save replay');
 const savePublic={...saved,packageIdentity:'<permitted-package-identity>',checksum:'<checksum>'};
 return {initial,availability,outputs,view:H.publicView(b,s),save:savePublic,replay:replay.state,byteSize:Buffer.byteLength(JSON.stringify(saved))};}
const corpus=[],rows=[],counters={pairs:0,operationComparisons:0,preRevealMismatches:0,rawProjectionChanges:0,verdictQueryChanges:0,rebindingRawDifferences:0,rebindingAlphaDifferences:0};
const forbidden=/PRIVATE_|"(?:knowledge|belief|provenance|acquiredAt|index|requiredConclusions|proofProfile|links|truthHash|solutionHash)"|(?:person|location|item|event|evidence|proposition|conclusion|secret):/;
function alpha(value,b){const names=new Map();for(const [ki,col] of ['persons','locations','items','events','evidence'].entries())for(const e of b.truth[col])names.set(b.refs.refFor(['person','location','item','event','evidence'][ki],e.id),'<'+e.id+'>');
 function w(x){if(typeof x==='string')return names.get(x)??x;if(Array.isArray(x)){const a=x.map(w);if(a.every(x=>typeof x==='string'))return a.sort(M.cmp);if(a.every(x=>x&&typeof x==='object'&&'ref'in x))return a.sort((a,b)=>M.cmp(a.ref,b.ref));return a;}if(x&&typeof x==='object')return Object.fromEntries(Object.entries(x).map(([k,v])=>[k,w(v)]));return x;}return w(value);}
for(let i=0;i<64;i++)for(const f of families){
 const a=raw(i),b=mutate(a,f,i),A=bind(a,i),B=bind(b,i),oa=observe(A),ob=observe(B);
 const same=JSON.stringify(oa)===JSON.stringify(ob);counters.pairs++;counters.operationComparisons+=commands(A).length;
 if(!same)counters.preRevealMismatches++;eq(oa,ob,'PRE_REVEAL '+f+' '+i);check(!forbidden.test(JSON.stringify(oa)),'OUTPUT SECRET TOKEN '+f);
 const pa=projectNpcKnowledge(A.snapshot,A.truth,A.solution),pb=projectNpcKnowledge(B.snapshot,B.truth,B.solution);if(JSON.stringify(pa)!==JSON.stringify(pb))counters.rawProjectionChanges++;
 const lits=[{claim:A.solution.conclusions[0].claim,value:true}],aa=parseAccusation({schemaVersion:1,caseId:A.truth.caseId,truthHash:hashCaseTruth(A.truth),literals:lits},A.truth),ab=parseAccusation({schemaVersion:1,caseId:B.truth.caseId,truthHash:hashCaseTruth(B.truth),literals:lits},B.truth);
 const va=M.challenge(A.truth,A.solution,A.challenge,aa),vb=M.challenge(B.truth,B.solution,B.challenge,ab);if(JSON.stringify(va)!==JSON.stringify(vb))counters.verdictQueryChanges++;
 const IA=bind(a,i,'truth'),IB=bind(b,i,'truth'),ia=observe(IA),ib=observe(IB);if(JSON.stringify(ia)!==JSON.stringify(ib))counters.rebindingRawDifferences++;
 const ap=alpha(ia,IA),bp=alpha(ib,IB);if(JSON.stringify(ap)!==JSON.stringify(bp))counters.rebindingAlphaDifferences++;eq(ap,bp,'ALPHA '+f);
 corpus.push({id:f+'-'+i,family:f,base:a,twin:b});rows.push({id:f+'-'+i,family:f,operations:commands(A).length,preRevealEqual:same,projectionEqual:JSON.stringify(pa)===JSON.stringify(pb),verdictA:va,verdictB:vb,saveBytesA:oa.byteSize,saveBytesB:ob.byteSize});
}
fs.writeFileSync(new URL('twin-corpus.jsonl',OUT),corpus.map(x=>JSON.stringify(x)).join('\n')+'\n');write('differential-results.json',rows);write('differential-summary.json',counters);
// Actual main black-box truth table validates the imported repaired draft evaluator.
const oracleRows=[];for(const cp of corpus.filter(x=>['winning_polarity','responsibility_completeness','required_conclusions'].includes(x.family)).slice(0,36))for(const rawCase of [cp.base,cp.twin]){
 const b=bind(rawCase,0);for(const c of b.solution.conclusions){const e=evaluateConclusionClaim(b.truth,b.solution,c.claim),tests=[true,false].map(value=>createCaseSolutionSchema(b.truth).safeParse({...plain(b.solution),requiredConclusions:[{conclusionId:c.id,value}]}).success),status=tests[0]?true:tests[1]?false:'undetermined';eq(e,{success:true,status},'native oracle');oracleRows.push({case:cp.id,claim:c.claim,status});}}
write('native-oracle-crosscheck.json',oracleRows);
// Bridge identity and release refusal, including every one of nine claim variants.
const br=bind(raw(0),0),projection=M.bridgeProjection(br.snapshot,br.truth,br.solution),original=projectNpcKnowledge(br.snapshot,br.truth,br.solution);
eq(projection.context,original.context,'bridge output');check(projection.bridge.entityOf(projection.context.self)?.id==='person:npc','original self');
eq(projection.bridge.entityOf(plain(projection.context.self)),null,'copied VisibleRef');eq(projection.bridge.entityOf(M.bridgeProjection(br.snapshot,br.truth,br.solution).context.self),null,'foreign VisibleRef');eq(projection.bridge.entityOf(projection.context.attitudes[0].subject),null,'subject ref');
let jsonThrows=false;try{JSON.stringify(projection);}catch{jsonThrows=true;}check(jsonThrows,'bridge toJSON');
let cloneThrows=false;try{structuredClone(projection);}catch{cloneThrows=true;}check(cloneThrows,'bridge clone');
const translator=M.createTranslator(projection.bridge,br.refs,[]);eq(translator.translate(projection.context.self),null,'unauthorized');
const cloneToJSON=x=>({...x,toJSON:undefined});check(!JSON.stringify(cloneToJSON(projection.bridge)).includes('person:'),'naive function serialization loses bridge methods but context still unsafe');
const variantClaims=[...br.truth.propositions.slice(0,2).map(p=>p.claim),{kind:'eventHasParticipant',eventId:'event:public',personId:'person:bravo'},{kind:'eventHasItem',eventId:'event:public',itemId:'item:tool'},...br.solution.conclusions.map(c=>c.claim),{kind:'eventCausedEvent',causeEventId:'event:public',eventId:'event:public'}];
const variantRows=variantClaims.map(c=>{const translated=M.playerClaim(c,(k,id)=>br.refs.refFor(k,id));check(!/"index"|person:|event:|location:|item:/.test(JSON.stringify(translated)),'all variants no indices');return {kind:c.kind,translated};});write('bridge-results.json',{jsonThrows,cloneThrows,variants:variantRows,unsafeProjection:original});
// PlayerRef structure/invariance and forced collision; no false birthday experiment claims.
const refRows=[],th=hashCaseTruth(br.truth),ix=br.refs;
const salt2=buildIndex(br.truth,th,{salt:'ffeeddccbbaa99887766554433221100',namespace:ix.namespace});
const tests={differentSalt:ix.refFor('person','person:bravo')!==salt2.refFor('person','person:bravo'),differentCanonical:ix.refFor('person','person:bravo')!==ix.refFor('person','person:charlie'),sameKindNoPrefix:!ix.refFor('person','person:bravo').includes('person'),fixedLength:[...publicIds].every(id=>ix.refFor(id.split(':')[0],id).length===20),pattern:publicIds.every(id=>REF_PATTERN.test(ix.refFor(id.split(':')[0],id)))};
for(const [k,v] of Object.entries(tests))check(v,k);
let collision=false;try{buildIndex(br.truth,th,{hash:()=>Buffer.alloc(32)});}catch(e){collision=e.message==='REF_COLLISION';}check(collision,'hard collision');
for(const f of ['hidden_entity_added','hidden_entity_deleted','raw_description']){const r=raw(0),b=mutate(r,f,0),x=bind(r,0),y=bind(b,0);refRows.push({mutation:f,isolatedSame:x.refs.refFor('person','person:bravo')===y.refs.refFor('person','person:bravo'),truthBoundSame:bind(r,0,'truth').refs.refFor('person','person:bravo')===bind(b,0,'truth').refs.refFor('person','person:bravo')});}
write('playerref-results.json',{hypothesis:true,...tests,collision,rows:refRows});
// Error-oracle classes: errors are inputs, never raw parse diagnostics at the public facade.
const errors=[];const errorTargets={foreign:'pr1_zzzzzzzzzzzzzzzz',malformed:'person:bravo',well_shaped_unknown:'pr1_0000000000000000',known_unauthorized:br.refs.refFor('person','person:aaa-hidden'),known_authorized:br.refs.refFor('location','location:lab'),stale:buildIndex(br.truth,th,{namespace:'old'}).refFor('location','location:lab'),wrong_kind:br.refs.refFor('item','item:tool')};
for(const [cls,target] of Object.entries(errorTargets)){const s=H.fresh(br),out=H.reduce(br,s,{type:'investigate',kind:'search_location',target});if(cls!=='known_authorized')eq(out,H.fail(),'error equivalent '+cls);errors.push({operation:'investigate',class:cls,result:out});}
for(const q of [null,{},'question:unknown','question:q5','question:q1']){const out=M.interrogate({truth:br.truth,solution:br.solution,snapshot:br.snapshot,catalogue:br.catalogue,profile:br.profile,refs:br.refs,known:br.initial,questionId:q});errors.push({operation:'interrogate_internal',input:q,result:out});}
for(const id of [null,{},'evidence:unknown','evidence:inaccessible','evidence:shown'])errors.push({operation:'releaseEvidence_private',input:id,result:M.releaseEvidence(br.presentation,id,br.refs)});
for(const c of [null,{kind:'personResponsibleForEvent',eventId:'event:public',personId:'person:unknown'},{kind:'personResponsibleForEvent',eventId:'event:public',personId:'person:aaa-hidden'}])errors.push({operation:'evaluateConclusionClaim_private',input:c,result:evaluateConclusionClaim(br.truth,br.solution,c)});
write('error-oracle-experiments.json',errors);
// Authored text: enumerate every prohibited control and selected deliberate allowed bypasses.
const chars=[];for(let n=0;n<=0x9f;n++)if(M.FORBIDDEN.test(String.fromCodePoint(n)))chars.push(n);chars.push(0x61c,0x200b,0x200e,0x200f,0x2028,0x2029,...Array.from({length:5},(_,i)=>0x202a+i),0x2060,...Array.from({length:4},(_,i)=>0x2066+i),0xfeff);
const textCases=[...chars.map(n=>({label:'control-'+n.toString(16),text:'a'+String.fromCodePoint(n)+'b',expected:false})),...['person:killer','event:hidden','conclusion:answer','pr1_0000000000000000','abcperson:killer','\ud800'].map(text=>({label:'ID-or-surrogate',text,expected:false})),
 ...['person:Killer','Person:killer','person：killer','persоn:killer','per\u200dson:killer','p\u200cerson:killer','pr1_000000000000000O','Ben ist der Täter.','a\nb','Schrödinger'].map(text=>({label:'allowed-by-draft',text,expected:true}))];
let seed=0x51f10;const rnd=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed;};
for(let n=0;n<512;n++){const stem=['person:killer','event:hidden','pr1_0000000000000000'][rnd()%3],mode=rnd()%4,pos=rnd()%(stem.length+1),ch=['\u202e','\u200b','\u0000','\u2066'][mode];textCases.push({label:'seeded-control-'+n,text:stem.slice(0,pos)+ch+stem.slice(pos),expected:false});}
const textResults=textCases.map(c=>{const r=M.playerText.safeParse(c.text);eq(r.success,c.expected,'text '+c.label);return {...c,accepted:r.success,issues:r.success?[]:r.error.issues.map(i=>i.message)};});write('text-fuzz.json',textResults);
// AnswerScope leakage: all nonempty subsets of an eight-person answer space.
const scopeRows=[];for(let mask=1;mask<256;mask++){const requiredKeys=Array.from({length:8},(_,i)=>i).filter(i=>mask&(1<<i));scopeRows.push({secretAssignment:requiredKeys,requiredOnlyScope:requiredKeys,publicCompleteScope:Array.from({length:8},(_,i)=>i)});}
write('scope-enumeration.json',{worlds:scopeRows.length,requiredOnlyDistinctScopes:new Set(scopeRows.map(x=>JSON.stringify(x.requiredOnlyScope))).size,completeDistinctScopes:1,identityBits:Math.log2(255),countBits:3,rows:scopeRows});
// Expected leak mutants demonstrate sensitivity, not production bugs.
const A=bind(raw(3),3),mutants=[];
function kill(name,family,leaky){const r=raw(3),b=mutate(r,family,3),X=bind(r,3),Y=bind(b,3);const differs=JSON.stringify(leaky(X))!==JSON.stringify(leaky(Y));check(differs,'surviving mutant '+name);mutants.push({name,family,killed:differs});}
kill('export_objective_truth','truth_value',b=>b.truth.propositions[2].truth);
kill('export_stance_kind','knowledge_true_vs_belief_true',b=>b.snapshot.attitudes[0].stance.kind);
kill('export_awareness_count','hidden_npc_awareness',b=>b.snapshot.awareness.length);
kill('export_hidden_entity_count','hidden_entity_added',b=>b.truth.persons.length);
kill('export_required_count','required_conclusions',b=>b.solution.requiredConclusions.length);
kill('export_evidence_metadata','evidence_links_source',b=>({source:b.truth.evidence[0].source,links:b.truth.evidence[0].links}));
kill('export_provenance','provenance',b=>b.snapshot.attitudes[0].provenance);
kill('export_acquisition','acquisition_time',b=>b.snapshot.attitudes[0].acquiredAt);
kill('export_proof_trace','proof_edge',b=>b.proof);
kill('export_solution','winning_polarity',b=>b.solution.resolutions);
write('mutation-detector-results.json',mutants);
// Question ID is a public authored string, unaffected by entity obfuscation.
const leak=raw(2);leak.catalogue.questions[0].id='question:bravo-is-the-killer';leak.profile.rules[0].questionId=leak.catalogue.questions[0].id;
const lb=bind(leak,2),lo=M.interrogate({truth:lb.truth,solution:lb.solution,snapshot:lb.snapshot,catalogue:lb.catalogue,profile:lb.profile,refs:lb.refs,known:lb.initial,questionId:leak.catalogue.questions[0].id});check(lo.success&&lo.observation.questionId.includes('killer'),'question slug leak');write('question-id-reproduction.json',lo);
write('summary.json',{...counters,assertions:checks,nativeOracleCases:oracleRows.length,textFuzzCases:textResults.length,leakMutants:mutants.length,leakMutantsKilled:mutants.filter(x=>x.killed).length,seed:'0x51f10',timing:'not measured; conceptual analysis only'});
console.log(JSON.stringify({checks,...counters,textFuzzCases:textResults.length,mutants:mutants.length}));
export {raw,bind,mutate,observe};
