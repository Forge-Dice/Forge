import assert from 'node:assert/strict';
import fs from 'node:fs';
import {raw,bind,mutate,observe} from './run.mjs';
import * as M from './model/boundaries.mjs';
import * as H from './model/session.mjs';
import {buildIndex,digest} from './model/playerref.mjs';
import {parseCaseTruth} from './vendor/case-truth.ts';
import {hashCaseTruth} from './vendor/case-truth.identity.ts';
import {parseCaseSolution} from './vendor/case-solution.ts';
import {hashCaseSolution} from './vendor/case-solution.identity.ts';
import {parseNpcKnowledge} from './vendor/npc-knowledge.ts';
import {projectNpcKnowledge} from './vendor/npc-knowledge.projection.ts';
const OUT=new URL('./results/',import.meta.url);const write=(n,x)=>fs.writeFileSync(new URL(n,OUT),JSON.stringify(x,null,2)+'\n');
let checks=0;const eq=(a,b,msg)=>{checks++;assert.deepEqual(a,b,msg);},ok=(x,msg)=>{checks++;assert.ok(x,msg);};
// All nine claims through actual parsed snapshots -> real projection -> model bridge -> release.
const r=raw(7);r.truth.events.push({...M.clone(r.truth.events[0]),id:'event:cause',time:{kind:'instant',at:1}});r.truth.events[0].causedByEventIds=['event:cause'];
const c=[r.truth.propositions[0].claim,{kind:'eventHasParticipant',eventId:'event:public',personId:'person:bravo'},{kind:'eventHasItem',eventId:'event:public',itemId:'item:tool'},...r.solution.conclusions.map(c=>c.claim),{kind:'eventCausedEvent',causeEventId:'event:cause',eventId:'event:public'}];
r.truth.propositions.push(...c.slice(1,3).map((claim,i)=>({id:'proposition:variant-'+i,claim,truth:true})));
r.solution.conclusions.push({id:'conclusion:cause',claim:c.at(-1)});
r.initial.push({kind:'event',id:'event:cause'});
const claims=[r.truth.propositions[0],...r.truth.propositions.slice(-2),...r.solution.conclusions];
r.snapshot.attitudes=claims.map(x=>({subject:{kind:x.id.split(':')[0],id:x.id},stance:{kind:'belief',value:true},acquiredAt:0,provenance:{kind:'prior_knowledge'}}));
r.catalogue.questions=claims.map((x,i)=>({id:'question:v'+i,mentions:M.claimRefs(x.claim)}));r.profile.rules=claims.map((x,i)=>({questionId:'question:v'+i,act:'answer',claim:x.claim,reveal:[]}));
const b=bind(r,7),variantResults=[];
for(const q of b.catalogue.questions){const result=M.interrogate({truth:b.truth,solution:b.solution,snapshot:b.snapshot,catalogue:b.catalogue,profile:b.profile,refs:b.refs,known:b.initial,questionId:q.id});ok(result.success,'9-kind release');ok(!/"index"|(?:person|event|location|item):/.test(JSON.stringify(result)),'9-kind scan');variantResults.push(result);}
eq(new Set(variantResults.map(r=>r.observation.statement.kind)).size,9,'exactly nine kinds');write('nine-kind-release-results.json',variantResults);
// Uncertainty and absent attitude disclose only selected answer state; same question availability.
const uncertainty=[];for(const stance of [{kind:'uncertain',leaning:true},{kind:'uncertain',leaning:false},{kind:'uncertain',leaning:null},null]){
 const r=raw(9);if(stance)r.snapshot.attitudes[0].stance=stance;else r.snapshot.attitudes.shift();const x=bind(r,9),out=M.interrogate({truth:x.truth,solution:x.solution,snapshot:x.snapshot,catalogue:x.catalogue,profile:x.profile,refs:x.refs,known:x.initial,questionId:'question:q1'});
 ok(out.success,'uncertainty');uncertainty.push({stance,available:H.questionView(x,H.fresh(x)),out});}
for(const x of uncertainty)eq(x.available,uncertainty[0].available,'attitude-independent availability');write('uncertainty-results.json',uncertainty);
// A hidden attitude can change local indices/shape but not selected player answer.
const ra=raw(4),rb=M.clone(ra);rb.snapshot.attitudes.push({subject:{kind:'proposition',id:'proposition:hidden'},stance:{kind:'belief',value:false},acquiredAt:0,provenance:{kind:'prior_knowledge'}});
eq(observe(bind(ra,4)),observe(bind(rb,4)),'hidden attitude');
// Full host error matrix over investigate, interrogate, accuse, view/save/load, ref resolution.
const x=bind(raw(5),5),pr=(k,id)=>x.refs.refFor(k,id),inputs={foreign:'pr1_zzzzzzzzzzzzzzzz',malformed:'person:bravo',well_shaped_unknown:'pr1_0000000000000000',known_unauthorized:pr('person','person:aaa-hidden'),known_authorized:pr('person','person:bravo'),stale:buildIndex(x.truth,hashCaseTruth(x.truth),{namespace:'old'}).refFor('person','person:bravo'),wrong_kind:pr('item','item:tool')},matrix=[];
for(const [cls,value] of Object.entries(inputs)){
 const operations={investigate:{type:'investigate',kind:'examine_person',target:value},interrogate:{type:'interrogate',npc:value,questionId:'question:q1'},accuse:{type:'accuse',literals:[{claim:{kind:'personResponsibleForEvent',person:value,event:pr('event','event:public')},value:true}]}};
 for(const [operation,cmd] of Object.entries(operations)){
  if(cls==='known_authorized'&&operation==='interrogate')cmd.npc=pr('person','person:npc');
  const result=H.reduce(x,H.fresh(x),cmd);if(cls!=='known_authorized')eq(result,H.fail(),operation+' '+cls);else ok(result.success,operation+' authorized');matrix.push({operation,class:cls,result});}
 matrix.push({operation:'resolve_private',class:cls,result:x.refs.resolve(value,'person')});
}
const s=H.fresh(x),save=H.save(x,s),loads=[];for(const field of ['known','proofProfile','solution','provenance','derived']){const mutant={...M.clone(save),[field]:[]};eq(H.replay(x,mutant),H.fail(),'save field reject');loads.push({mutation:'add-'+field,result:H.replay(x,mutant)});}
for(const identity of ['0'.repeat(64),'foreign',null]){const m={...M.clone(save),packageIdentity:identity};const {checksum,...body}=m;m.checksum=digest(JSON.stringify(body));eq(H.replay(x,m),H.fail(),'identity reject');loads.push({mutation:'package-'+identity,result:H.replay(x,m)});}
const forged=M.clone(save);forged.events=[{type:'investigate',kind:'examine_person',target:pr('person','person:aaa-hidden')}];const {checksum,...body}=forged;forged.checksum=digest(JSON.stringify(body));eq(H.replay(x,forged),H.fail(),'hidden accepted-event forgery');
const otherSalt={...x,refs:buildIndex(x.truth,hashCaseTruth(x.truth),{namespace:x.refs.namespace,salt:'ffeeddccbbaa99887766554433221100'})};
ok(H.identity(x)!==H.identity(otherSalt),'salt binding identity');eq(H.replay(otherSalt,save),H.fail(),'cross-salt empty save rejected');
const otherScope={...x,challenge:{...x.challenge,allowedClaims:x.challenge.allowedClaims.slice(0,1)}};
ok(H.identity(x)!==H.identity(otherScope),'scope binding identity');eq(H.replay(otherScope,save),H.fail(),'cross-scope empty save rejected');
write('model-binding-after-repair.json',{saltConfigBound:true,challengeScopeBound:true,crossSaltReplayAccepted:false,crossScopeReplayAccepted:false,classification:'repaired only in disposable MODEL; no production claim'});
write('full-public-error-matrix.json',{matrix,loads,viewAndSave:'no caller-supplied canonical target; view projects only derived known; save fixed schema'});
// Public exact scope vs solution-conditioned scope; quantity is Shannon entropy under uniform subsets.
const entropy=counts=>{const n=counts.reduce((a,b)=>a+b,0);return -counts.map(c=>c?c/n*Math.log2(c/n):0).reduce((a,b)=>a+b,0);},bins=Array(9).fill(0);for(let n=1;n<256;n++)bins[n.toString(2).replace(/0/g,'').length]++;
write('scope-information.json',{uniformNonemptySubsets:255,requiredOnlyScopeBits:Math.log2(255),scopeLengthBits:entropy(bins),fixedRosterScopeBits:0,singleActor8CandidateBits:3,trueOnlyRole3CandidateBits:Math.log2(3),bounds:'experiment-specific priors; not universal MI claim'});
// Sorting by package-bound refs can reorder multiple identical public cards on secret rebinding.
const ordering=[];for(let i=0;i<64;i++){
 const a=raw(i);a.access.entries[1].access={kind:'discoverable',paths:[{kind:'search_location',locationId:'location:lab'}]};a.presentation.entries[1].text='Zweite öffentliche Karte';const t=mutate(a,'truth_value',i);
 const A=bind(a,i,'truth'),B=bind(t,i,'truth'),sa=H.fresh(A),sb=H.fresh(B),oa=H.reduce(A,sa,{type:'investigate',kind:'search_location',target:A.refs.refFor('location','location:lab')}),ob=H.reduce(B,sb,{type:'investigate',kind:'search_location',target:B.refs.refFor('location','location:lab')});
 const orderA=oa.observations.map(x=>x.text),orderB=ob.observations.map(x=>x.text);ordering.push({i,orderA,orderB,changed:JSON.stringify(orderA)!==JSON.stringify(orderB)});
}write('hash-ordering-results.json',{cases:ordering.length,reordered:ordering.filter(x=>x.changed).length,rows:ordering,classification:'permitted different package identity; stable within one immutable package'});
// Hash commitments are an offline oracle only with an enumerable, known remaining preimage.
const dictRaw=raw(0),trueT=parseCaseTruth(dictRaw.truth),target=hashCaseTruth(trueT),dictionary=[];
for(const value of [false,true]){const candidate=M.clone(dictRaw.truth);candidate.propositions[2].truth=value;dictionary.push({candidate:value,matches:hashCaseTruth(parseCaseTruth(candidate))===target});}
eq(dictionary.filter(x=>x.matches).length,1,'hash dictionary');write('hash-dictionary-reproduction.json',{assumption:'all other private input bytes known; public unsalted truthHash supplied',dictionary});
// Validate reference case and all local mutation worlds using actual main parsers after exact rebinding.
const root=new URL('../extracted/DIE-LEERE-VITRINE-CASE-PACK/DIE-LEERE-VITRINE-CASE-PACK/case-pack/',import.meta.url),load=n=>JSON.parse(fs.readFileSync(new URL(n,root),'utf8'));
const vt=parseCaseTruth(load('truth.json')),vs=parseCaseSolution(load('solution.json'),vt),projRows=[];
for(const n of ['max','lina','nora','oskar']){const sn=parseNpcKnowledge(load('npc-'+n+'.json'),vt,vs),proj=projectNpcKnowledge(sn,vt,vs);eq(proj.context,load('projection-'+n+'.PRIVATE.json').context??load('projection-'+n+'.PRIVATE.json'),'archived projection '+n);projRows.push({npc:n,projectionMatches:true});}
const nativeInputs=JSON.parse(fs.readFileSync(new URL('vitrine-native-inputs.json',OUT))),validation=[];
for(const item of nativeInputs){const t=parseCaseTruth(item.truth),s=parseCaseSolution({...item.solution,truthHash:hashCaseTruth(t)},t);for(const sn of Object.values(item.npcs))parseNpcKnowledge({...sn,truthHash:hashCaseTruth(t),solutionHash:hashCaseSolution(s)},t,s);validation.push({mutation:item.mutation,domainParse:'pass',semanticWorldCertification:'not asserted'});}
write('vitrine-native-validation.json',{referenceMainParsers:'passed',snapshots:4,projections:projRows,mutations:validation});
// Adapt archived released card intents to CURRENT MYST-0004 report DTOs. Not authored production data.
const host=load('case-host.design.json'),entries=vt.evidence.map(e=>{const old=host.presentation[e.id],reports=old.observed.map(id=>({claim:vt.propositions.find(p=>p.id===id).claim,stance:'affirms',source:{kind:'observation'}})),mentions=[...new Map(reports.flatMap(r=>M.claimRefs(r.claim)).map(x=>[M.key(x),x])).values()];return {evidenceId:e.id,text:old.text,mentions,reports};}),pres=M.parsePresentation({schemaVersion:1,caseId:vt.caseId,truthHash:hashCaseTruth(vt),entries},vt),refs=buildIndex(vt,hashCaseTruth(vt));
const released=pres.entries.map(e=>M.releaseEvidence(pres,e.evidenceId,refs));ok(released.every(x=>x.success),'current presentation adapter');ok(!/proposition:|"truth"|"links"|"proof"/.test(JSON.stringify(released)),'presentation adapter no proof');
write('vitrine-current-presentation-adapter.json',{status:'MODELED migration fixture, reports are not automatic objective proof roots',released});
// Shape validation and deterministic shape ordering; host faults stay technical.
const badPort={...x.refs,refFor:()=> 'person:spoiler'},collisionPort={...x.refs,refFor:()=> 'pr1_0000000000000000'};
eq(M.releaseEvidence(x.presentation,'evidence:shown',badPort),{success:false,code:'REF_UNAVAILABLE'},'invalid ref output');eq(M.releaseEvidence(x.presentation,'evidence:shown',collisionPort),{success:false,code:'REF_UNAVAILABLE'},'collision output');
const bad=M.clone(raw(11));bad.presentation.entries[0].mentions=[];let closed=false;try{bind(bad,11);}catch{closed=true;}ok(closed,'hidden report closure');
write('supplemental-summary.json',{assertions:checks,nineClaimKinds:9,uncertaintyVariants:4,publicErrorMatrixCells:matrix.length,saveRejectCases:loads.length+3,vitrineNativeMutationParses:validation.length,hashOrderingPairs:ordering.length,hashOrderingChanged:ordering.filter(x=>x.changed).length});console.log(JSON.stringify({supplementalChecks:checks,vitrineValidated:validation.length,hashReorders:ordering.filter(x=>x.changed).length}));
