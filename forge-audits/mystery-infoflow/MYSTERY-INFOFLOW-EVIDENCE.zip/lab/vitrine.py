"""Original archived host experiments. No changes to its files or canonical repository.
PRIVATE evidence contains authored case truth. The final report's case table is spoiler-free.
"""
from pathlib import Path
import json,copy,hashlib,collections
P=Path(__file__).resolve().parent.parent/'extracted/DIE-LEERE-VITRINE-CASE-PACK/DIE-LEERE-VITRINE-CASE-PACK'
SRC=(P/'simulate.py').read_text(); PREFIX=SRC.split('scenarios=[]')[0]
OUT=Path(__file__).resolve().parent/'results'
def context():
 e={'__file__':str(P/'simulate.py')};exec(compile(PREFIX,str(P/'simulate.py'),'exec'),e);return e
def stable(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def observations(e):
 s=e['fresh']();initial=e['public_initial']();trace=[]
 # All investigations and all authored questions, including gated empty/invalid paths.
 commands=[e['S'](n) for n in ['galerie','hof','archiv','werkstatt','foyer']]
 commands += [e['Q'](e['host']['questionText']['question:q'+str(i).zfill(2)]['npc'].split(':')[1],i) for i in range(1,21)]
 commands += [e['R']('kamera'),e['R']('terminal'),e['S']('galerie')]
 for cmd in commands:trace.append({'command':cmd,'result':e['step'](s,cmd)})
 return {'initial':initial,'trace':trace,'view':e['public_state'](s),'save':{'schemaVersion':1,'packageHash':e['packagehash'],'commands':s['log']}},s
BASE=context();base,state=observations(BASE)
forbidden=['"provenance"','"acquiredAt"','"knowledge"','"belief"','"index"','"requiredConclusions"','"proofProfile"','"links"','person:','location:','item:','event:','evidence:','proposition:','conclusion:']
assert not any(t in stable(base) for t in forbidden)
mutations=['hidden_proposition_truth','hidden_npc_awareness','provenance','acquired_at','secret_membership','red_herring_membership','evidence_metadata','required_conclusions','proof_edge','hidden_item','hidden_person','hidden_location','canonical_evidence_order']
rows=[];detail={}
native_inputs=[]
for name in mutations:
 e=context()
 if name=='hidden_proposition_truth':e['truth']['propositions'][12]['truth']=False
 elif name=='hidden_npc_awareness':e['npcs']['nora']['awareness'].append({'subject':{'kind':'item','id':'item:kassette'},'acquiredAt':0,'provenance':{'kind':'prior_knowledge'}})
 elif name=='provenance':e['npcs']['nora']['attitudes'][0]['provenance']={'kind':'author_modeled_inference'}
 elif name=='acquired_at':
  # Change only time in a provenance form that allows both times.
  e['npcs']['nora']['attitudes'][0]['provenance']={'kind':'author_modeled_inference'}
  e['npcs']['nora']['attitudes'][0]['acquiredAt']=241
 elif name=='secret_membership':e['truth']['secrets'][0]['propositionIds']=['proposition:p02']
 elif name=='red_herring_membership':e['truth']['redHerrings'][0]['evidenceIds']=['evidence:d02']
 elif name=='evidence_metadata':e['truth']['evidence'][0]['source']={'kind':'location','id':'location:hof'};e['truth']['evidence'][0]['links'][0]['direction']='refutes'
 elif name=='required_conclusions':e['solution']['requiredConclusions']=e['solution']['requiredConclusions'][:-1]
 elif name=='proof_edge':
  # Original player host does not consume the private proof-profile document at runtime.
  e['privateProofMutation']={'edge':'PRIVATE_EDGE_CHANGED'}
 elif name=='hidden_item':
  cid='item:private-added';e['truth']['items'].append({'id':cid,'name':'PRIVATE_ITEM'});e['entities'][cid]='item';e['refs'][cid]='pr1_0000000000000001';e['reverse'][e['refs'][cid]]=cid
 elif name=='hidden_person':
  cid='person:private-added';e['truth']['persons'].append({'id':cid,'name':'PRIVATE_PERSON'});e['entities'][cid]='person';e['refs'][cid]='pr1_0000000000000002';e['reverse'][e['refs'][cid]]=cid;e['host']['personRoles'][cid]='PRIVATE_ROLE'
 elif name=='hidden_location':
  cid='location:private-added';e['truth']['locations'].append({'id':cid,'name':'PRIVATE_LOCATION'});e['entities'][cid]='location';e['refs'][cid]='pr1_0000000000000003';e['reverse'][e['refs'][cid]]=cid
 elif name=='canonical_evidence_order':
  # Rename two internal evidence IDs while preserving released cards and opaque handles.
  ren={'evidence:d01':'evidence:z99','evidence:d02':'evidence:a00'}
  def rename(x):
   if isinstance(x,str):return ren.get(x,x)
   if isinstance(x,list):return [rename(y) for y in x]
   if isinstance(x,dict):return {ren.get(k,k):rename(v) for k,v in x.items()}
   return x
  for k in ['truth','host']:e[k]=rename(e[k])
  e['refs']={ren.get(k,k):v for k,v in e['refs'].items()};e['reverse']={v:k for k,v in e['refs'].items()};e['entities']={ren.get(k,k):v for k,v in e['entities'].items()};e['propmap']={p['id']:p for p in e['truth']['propositions']}
 # Isolation mode: retain old refs/package token to identify payload dependence alone.
 actual,_=observations(e);equal=stable(base)==stable(actual)
 native_inputs.append({'mutation':name,'truth':e['truth'],'solution':e['solution'],'npcs':e['npcs']})
 rows.append({'mutation':name,'preRevealEqual':equal,'initialEqual':stable(base['initial'])==stable(actual['initial']),'traceEqual':stable(base['trace'])==stable(actual['trace']),'saveEqual':stable(base['save'])==stable(actual['save']),'baselineBytes':len(stable(base).encode()),'twinBytes':len(stable(actual).encode())})
 if not equal:detail[name]={'baseline':base,'twin':actual}
 if name not in ['hidden_person','hidden_location','canonical_evidence_order']:assert equal,name
 else:assert not equal,name
# Genuine original error oracles, same public payload across invalid refs.
err={}
for name,r in [('malformed','person:max'),('foreign','pr1_zzzzzzzzzzzzzzzz'),('unknown','pr1_0000000000000000'),('known_unauthorized',BASE['refs']['item:kamera']),('wrong_kind',BASE['refs']['person:max']),('stale',BASE['ref']('item:kamera','0'*64))]:
 out=BASE['step'](BASE['fresh'](),{'type':'read_record','target':r});assert out=={'success':False,'code':'ACTION_NOT_AVAILABLE'};err[name]=out
# Original packageHash and public refs rebind for ANY hidden payload mutation.
rebind=[]
for name in ['truth','proof']:
 e=context();old=e['packagehash'];payload={'profile':'case-lab-package-v1','truth':e['truth'],'solution':e['solution'],'host':e['host'],'catalogue':e['catalogue'],'npcs':e['npcs'],'profiles':e['profiles'],'proofProfile':e['load']('proof-profile.PRIVATE.design.json'),'releaseManifest':e['load']('release-manifest.PRIVATE.design.json')}
 if name=='truth':payload['truth']['propositions'][12]['truth']=False
 else:payload['proofProfile']['edges'][0]['id']+='-changed'
 new=hashlib.sha256(stable(payload).encode()).hexdigest();assert new!=old
 rebind.append({'secret':name,'packageChanged':True,'sameLength':len(new)==len(old),'examplePublicRefChanged':e['ref']('person:max',new)!=e['ref']('person:max',old)})
summary={'artifact':'original archived Vitrine Scratch host; NOT main','commandsPerCase':28,'secretMutationPairs':len(rows),'preRevealEqual':sum(r['preRevealEqual'] for r in rows),'differences':sum(not r['preRevealEqual'] for r in rows),'originalPlayerPayloadForbiddenTokens':0,'errorClassesEqual':len(err),'findings':['hidden persons/locations included in public_initial collections','evidence cards ordered by canonical evidence ID'], 'rebind':rebind}
(OUT/'vitrine-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(OUT/'vitrine-mutations.json').write_text(json.dumps(rows,indent=2)+'\n')
(OUT/'vitrine-private-reproductions.json').write_text(json.dumps(detail,ensure_ascii=False,indent=2)+'\n')
(OUT/'vitrine-error-oracles.json').write_text(json.dumps(err,indent=2)+'\n')
(OUT/'vitrine-native-inputs.json').write_text(json.dumps(native_inputs,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary))
