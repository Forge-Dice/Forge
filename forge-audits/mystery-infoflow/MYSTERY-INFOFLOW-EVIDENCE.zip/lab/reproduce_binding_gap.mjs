// Retained original MODEL identity function, not canonical/main code.
import {raw,bind} from './run.mjs';
import {hashCaseTruth} from './vendor/case-truth.identity.ts';
import {hashCaseSolution} from './vendor/case-solution.identity.ts';
import {buildIndex,digest} from './model/playerref.mjs';
import * as H from './model/session.mjs';
function legacyIdentity(b){return digest(JSON.stringify({version:'lab-session-v1',truth:hashCaseTruth(b.truth),solution:hashCaseSolution(b.solution),access:b.access,presentation:b.presentation,catalogue:b.catalogue,profile:b.profile,snapshot:b.snapshot,proof:b.proof,namespace:b.refs.namespace}));}
const b=bind(raw(0),0),differentSalt={...b,refs:buildIndex(b.truth,b.refs.truthHash,{namespace:b.refs.namespace,salt:'ffeeddccbbaa99887766554433221100'})};
const beforeEqual=legacyIdentity(b)===legacyIdentity(differentSalt),afterEqual=H.identity(b)===H.identity(differentSalt);
if(!beforeEqual||afterEqual)throw new Error('Unexpected binding-counterexample result');
console.log(JSON.stringify({beforeSaltChangeUndetected:beforeEqual,afterSaltChangeUndetected:afterEqual,finalEmptySaveAccepted:H.replay(differentSalt,H.save(b,H.fresh(b))).success}));
