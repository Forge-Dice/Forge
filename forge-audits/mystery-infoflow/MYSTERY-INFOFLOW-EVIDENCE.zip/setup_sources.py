from pathlib import Path
import zipfile
root=Path(__file__).resolve().parent
if not (root/'inputs').exists():
    (root/'inputs').symlink_to('source-artifacts',target_is_directory=True)
archive=root/'source-artifacts/DIE-LEERE-VITRINE-CASE-PACK.zip'
destination=root/'extracted/DIE-LEERE-VITRINE-CASE-PACK'
with zipfile.ZipFile(archive) as z:
    for info in z.infolist():
        target=(destination/info.filename).resolve()
        if not target.is_relative_to(destination.resolve()):
            raise ValueError('Archive path escape')
    z.extractall(destination)
print('Reference Scratch casepack prepared.')
