from pathlib import Path
import json,html,hashlib,zipfile,datetime
B=Path(__file__).resolve().parents[1];D=B/'deliverables';D.mkdir(exist_ok=True)
SHA='3d7545d843883418348004e68717399a64da7a7d'
E=html.escape
sections=[]
def p(s):return '<p>'+E(s)+'</p>'
def code(s):return '<pre><code>'+E(s.strip())+'</code></pre>'
def table(headers,rows):return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+E(str(x))+'</th>' for x in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+E(str(x))+'</td>' for x in row)+'</tr>' for row in rows)+'</tbody></table></div>'
def ul(items):return '<ul>'+''.join('<li>'+E(s)+'</li>' for s in items)+'</ul>'
def add(n,title,body):sections.append((n,title,body))
errors=[
('GIT_FETCH','Fetch, Transport, Ref-Abgleich fehlgeschlagen'),('GIT_LAYOUT','Replace, Alternates, Graft, Shallow, Promisor, Config oder Hooks unzulässig'),('GIT_OBJECT','Objekttyp, Hash, Framing, Rohstruktur oder Vollständigkeit ungültig'),('GIT_LIMIT','Objekt-, Byte-, Baum- oder History-Budget überschritten'),('GIT_PATH','Byte-Pfad unzulässig'),('GIT_COLLISION','Doppelter Name, Case- oder Prefix-Kollision'),('GIT_HISTORY','BASE nicht erreichbar; Merge/Root/zu viele neue Commits; leerer End-Diff'),
('PR_INPUT','Event/PR/Repository-Datensatz ungültig oder widersprüchlich'),('PR_STATE','Geschlossen, Draft, falsches Base-Repository oder Ziel'),('PR_STALE','Main, BASE oder HEAD verändert'),('IDENTITY_ACTOR','Numerische Identität oder Head-Repository falsch'),('IDENTITY_NAMESPACE','Branchname passt nicht zum zugelassenen Actor/Task'),('IDENTITY_RECHECK','Owner-Recheck oder aktueller Gate-Receipt fehlt'),
('CONTRACT_PARSE','Aktueller Format-1-Parser lehnt Dokument ab'),('CONTRACT_BINDING','Task, Dokumenthash, Baseline oder Planbindung falsch'),('CONTRACT_DEPENDENCY','Abhängigkeit unaufgelöst, unbekannt oder nicht in BASE'),('SCOPE_PATH','Änderung nicht exakt genehmigt oder Create/Modify falsch'),('SCOPE_PROTECTED','Geschützter Pfad verändert'),('SCOPE_MODE','Symlink, Gitlink, unbekannter Mode oder Mode-Änderung'),
('TEST_BASELINE','BASE-Compiler/Suite/Inventar nicht grün'),('TEST_COMPILE','HEAD-Typecheck fehlgeschlagen'),('TEST_INVENTORY','Datei oder Testidentität fehlt, unbekannter/inkonsistenter Report'),('TEST_STATUS','HEAD-Test fehlgeschlagen, skipped, todo oder nur teilweise gelaufen'),
('MUTANT_NOT_APPLIED','Anker/Mutation/Diff nicht exakt anwendbar'),('MUTANT_SURVIVED','Mutation anwendbar, alle verlangten Tests bestehen'),('MUTANT_INFRA','Compiler, Hook, Collection, Timeout, Prozess- oder Reportfehler bei Mutation'),
('REVIEW_MISSING','Keine maßgebliche Owner-Attestation'),('REVIEW_FORMAT','Maßgeblicher Review-Body nicht im strikten Format'),('REVIEW_BINDING','Attestation oder externer Bericht bindet falsche Eingaben'),('REVIEW_BLOCKED','Widerruf, Findings, falscher Review-State oder nicht freigegebener Blocker'),('REVIEW_CHANGED','Review-Snapshot zwischen Start und Ende geändert/gelöscht'),
('EXECUTION_TIMEOUT','Deadline außerhalb Mutationsklassifikation überschritten'),('EXECUTION_SANDBOX','Sandbox-/Image-/Ressourcen-Voraussetzung nicht erfüllt'),('EXECUTION_IO','Materialisierung, Report-I/O oder Cleanup fehlgeschlagen'),('EXECUTION_API','API nicht vollständig/frisch/authentisch lesbar, Rate-Limit oder Größenlimit'),('EXECUTION_INTERNAL','Unerwartete interne Invariante verletzt'),
('POLICY_INVALID','Versionierte Policy oder Taskplan ungültig/nicht unterstützt'),('POLICY_CHANGED','Versionierte Policy/Manifestbindung verändert'),('POLICY_DEPLOYMENT','Deployment-Nachweis fehlt, abgelaufen oder nicht zum Policy-Digest passend'),('POLICY_CHECKS','Falscher Workflow/Attempt oder doppelte/verwechselbare Checks')]
CODES={x[0] for x in errors}
matrix=[]
def cases(group,lines,kind='SPECIFIED — noch kein Integrationstest'):
 for s in lines.strip().splitlines():
  desc,expected=s.rsplit('|',1);expected=expected.strip();assert expected in CODES or expected=='PASS',expected
  matrix.append({'id':f'AV-{len(matrix)+1:03}','group':group,'input':desc.strip(),'expected':expected,'evidence':kind})
cases('Bootstrap / Prozess', '''Gültiger öffentlicher Repo-Input, exakte BASE-/HEAD-Refs|PASS
GITHUB_SHA mit 39 Hexzeichen|PR_INPUT
SHA mit Großbuchstaben oder :path Suffix|PR_INPUT
PR-Nummer 0, negativ oder Exponentialnotation|PR_INPUT
Eventdatei > 1 MiB|PR_INPUT
JSON mit doppeltem repository.id|PR_INPUT
Event ist push statt pull_request_target|PR_INPUT
Event-Aktion edited|PR_INPUT
Remote-URL aus PR wird angeboten|GIT_FETCH
HTTP-Redirect vom festen Git-Remote|GIT_FETCH
Fetch liefert anderen Head als Live-PR|PR_STALE
main bewegt sich zwischen GET und Fetch|PR_STALE
Git-Fetch hängt > 90 Sekunden|EXECUTION_TIMEOUT
ODB überschreitet 512 MiB|GIT_LIMIT
Objektzahl 150001|GIT_LIMIT
Ein Blob hat 8 MiB + 1 Byte|GIT_LIMIT
Summe deklarierter entpackter Objektgrößen > 512 MiB|GIT_LIMIT
GIT_CONFIG_COUNT mit Credential-Helfer im Elternprozess|PASS
NODE_OPTIONS mit require-Angriff im Elternprozess|PASS
npm_config_userconfig verweist auf Angreiferdatei|PASS
HTTPS_PROXY/SSH_ASKPASS im Elternprozess|PASS
Versteckter Git-Config-Include nach Fetch|GIT_LAYOUT
Hookdatei im neuen ODB|GIT_LAYOUT
Promisor-/Partial-Clone-Markierung|GIT_LAYOUT''')
cases('Echte Git-/Dateisystem-Probe', '''Replace-Ref verändert ungeschützten Objektread; Schutz liest Original, Layout lehnt Ref ab|GIT_LAYOUT
objects/info/alternates trotz leerer Umgebung|GIT_LAYOUT
info/grafts im Repository|GIT_LAYOUT
shallow-Datei im Repository|GIT_LAYOUT
HEAD-Commit mit zwei echten parent-Headern|GIT_HISTORY
Doppelter Rohname in demselben Tree|GIT_COLLISION
A.ts und a.ts im selben Snapshot|GIT_COLLISION
Dir/a und dir/b als verschiedene Directory-Schreibweisen|GIT_COLLISION
a als Datei und a/b als Pfad|GIT_COLLISION
A als Datei und a/b als Pfad|GIT_COLLISION
x/a und x/b ohne Kollision|PASS
Parent-Directory wird durch Symlink ersetzt|EXECUTION_IO
Zieldatei existiert bereits|EXECUTION_IO
Binärblob mit NUL wird bytegenau geschrieben|PASS''','EXPERIMENTALLY VERIFIED — git-lab; künftiger Code muss dieselbe Entscheidung umsetzen')
cases('Pfad und Modes', '''Ungültiges UTF-8 im Namen|GIT_PATH
Newline im Dateinamen|GIT_PATH
Tab oder DEL im Dateinamen|GIT_PATH
Absoluter Pfad|GIT_PATH
Leeres Segment a//b|GIT_PATH
Traversal a/../b|GIT_PATH
.git/config|GIT_PATH
.GiT/config|GIT_PATH
git~1/config|GIT_PATH
CON.ts|GIT_PATH
LPT9.log|GIT_PATH
Trailing-Dot x.|GIT_PATH
Backslash a\\b|GIT_PATH
Colon/ADS a:b|GIT_PATH
Leading-Dash-Segment -option|GIT_PATH
NFC é.ts|GIT_PATH
NFD e + combining accent .ts|GIT_PATH
NFC und NFD nebeneinander werden vor Normalisierung abgelehnt|GIT_PATH
Pfadtiefe 17|GIT_PATH
Segmentlänge 101 Byte|GIT_PATH
Normale Datei 100644 unverändert|PASS
Bestehende BASE-Datei 100755 unverändert|PASS
Neu hinzugefügte Datei 100755|SCOPE_MODE
Mode 120000 Symlink|SCOPE_MODE
Mode 160000 Gitlink|SCOPE_MODE
Unbekannter Mode 100600|SCOPE_MODE
100644 nach 100755 bei gleichem Blob|SCOPE_MODE
Content und Mode zugleich verändert|SCOPE_MODE''')
cases('History / Scope', '''Linearer HEAD ist ein Commit nach aktuellem BASE|PASS
Trusted BASE hat zwei Parents, HEAD genau einen|PASS
HEAD hat keinen BASE-Vorfahren|GIT_HISTORY
HEAD ist identisch BASE|GIT_HISTORY
129 neue lineare Commits|GIT_LIMIT
HEAD hat Parent auf nicht vorhandenes Objekt|GIT_OBJECT
Commit mit zwei tree-Headern|GIT_OBJECT
Temporärer Workflow-Edit im Zwischencommit, später revertiert|SCOPE_PROTECTED
Erlaubter MODIFY-Pfad existiert in BASE nicht|SCOPE_PATH
Erlaubter ADD-Pfad existiert schon in BASE|SCOPE_PATH
Umbenennung erlaubter Datei nach anderem Namen|SCOPE_PATH
Extra-Datei außerhalb exaktem Scope|SCOPE_PATH
Scope src/a.ts wird als Prefix für src/a.ts/escape missbraucht|SCOPE_PATH
Änderung forge/coordination/CODEX.md ohne Scope|SCOPE_PATH
Änderung aktiven Contracts in HEAD|SCOPE_PROTECTED
Änderung package.json script|SCOPE_PROTECTED
Änderung package-lock.json|SCOPE_PROTECTED
Vitest-Config in HEAD hinzugefügt|SCOPE_PROTECTED
Tsconfig include geschrumpft|SCOPE_PROTECTED
Änderung bestehender Tests/Fixtures|SCOPE_PROTECTED
Testdatei gelöscht|SCOPE_PATH
Testdatei umbenannt|SCOPE_PATH
Genehmigte neue Testdatei mit korrektem Scope|PASS
DEV verändert Verifier oder Workflow|SCOPE_PROTECTED
OWNER_OPS mit explizitem Plan verändert exakt genehmigte TCB-Datei|PASS
OWNER_OPS versucht bestehende Tests oder Lockfile zu ändern|SCOPE_PROTECTED
Falsche numerische Autor-ID bei gleichem Login|IDENTITY_ACTOR
Fork mit identischem Branch-Namen|IDENTITY_ACTOR
Falscher Codex-Namespace|IDENTITY_NAMESPACE
Task im Branch ungleich Contract-Task|CONTRACT_BINDING
Contract nicht canonical JSON|CONTRACT_PARSE
Unaufgelöste dependency acceptedCommit null|CONTRACT_DEPENDENCY
Dependency-Commit kein Vorfahre von BASE|CONTRACT_DEPENDENCY
Doppelter requiredCheck-Name|CONTRACT_PARSE
Nicht registrierter Shell-Befehl im Contract|POLICY_INVALID''')
cases('Echtes Testinventar', '''Aktueller main: 1087 Tests in 22 Dateien bestehen|PASS
Parameterized tests mit mehrfach gleichem formatierten Namen|PASS
Zwei identische Titel erhalten occurrence 0 und 1|PASS
it.skip bei ansonsten Exit 0|TEST_STATUS
it.todo bei ansonsten Exit 0|TEST_STATUS
Leere Testdatei|TEST_INVENTORY
Collection-Fehler|TEST_INVENTORY
it.only bei allowOnly false|TEST_STATUS
Assertion-Failure im HEAD|TEST_STATUS
Titel geändert bei gleicher Gesamtzahl|TEST_INVENTORY
Neue genehmigte Datei mit zusätzlichem Test|PASS
Eine Datei gelöscht, verbleibende Suite Exit 0|TEST_INVENTORY''','EXPERIMENTALLY VERIFIED — runtime-lab; isolierte Inventory-Proben umgehen absichtlich früheren Freeze')
cases('Inventory / Infrastruktur', '''Unbekannter Projektname im Report|TEST_INVENTORY
Gleiche flache fullName-Zeichenfolge bei anderer ancestor-Struktur|TEST_INVENTORY
Abschlussreihenfolge der Paralleltests verändert, Identitäten gleich|PASS
Hooks/Unhandled-Error neben bestandenen Tests|TEST_INVENTORY
Ein BASE-Test fehlt, zehn neue Tests kompensieren die Anzahl|TEST_INVENTORY
Timeout liefert nur partielles Inventar|EXECUTION_TIMEOUT
Compiler-Crash vor HEAD-Tests|TEST_COMPILE
Gefälschter oder übergroßer Report|TEST_INVENTORY
Fehlgeschlagene Installation|EXECUTION_SANDBOX
Worker versucht Docker-Socket zu öffnen|EXECUTION_SANDBOX
Worker versucht Netzwerk oder Actions-Dateikommandos|EXECUTION_SANDBOX
Worker überschreibt schreibgeschützte Tests/Tools|EXECUTION_SANDBOX''')
cases('Echte Mutationsprobe', '''clampAtZero gibt n zurück, negativer Test wirft AssertionError|PASS
Semantisch gleichwertige if-Form überlebt|MUTANT_SURVIVED
Anker fehlt|MUTANT_NOT_APPLIED
Mutation erzeugt ungültige Syntax|MUTANT_INFRA
Mutation wirft Fehler beim Import|MUTANT_INFRA
Mutation blockiert bis Prozess-Deadline|MUTANT_INFRA''','EXPERIMENTALLY VERIFIED — runtime-lab; PASS bedeutet Mutant KILLED')
cases('Mutation / Zusatzangriffe', '''Anker erscheint zweimal einschließlich überlappender Treffer|MUTANT_NOT_APPLIED
Replacement entspricht Anchor bytegenau|MUTANT_NOT_APPLIED
Patch verändert eine zweite Datei|MUTANT_NOT_APPLIED
Mutation auf Testdatei statt genehmigtem Source-Pfad|POLICY_INVALID
Ein benannter Test fehlt in Mutationsergebnis|MUTANT_INFRA
AssertionError im Hook statt im benannten Test|MUTANT_INFRA
Timeout plus bereits eingetretener AssertionError|MUTANT_INFRA
Signal/OOM neben Testfehler|MUTANT_INFRA
Exit 1 ohne Assertion-Report|MUTANT_INFRA
Developer meldet detected ohne unabhängigen Mutantenlauf|MUTANT_INFRA
Equivalent-Rationale soll SURVIVED freistellen|MUTANT_SURVIVED''')
cases('Review / Final', '''Owner COMMENTED mit allen richtigen Bindungen|PASS
APPROVED statt vorgeschriebenem COMMENTED|REVIEW_BLOCKED
Owner-Login stimmt, numeric ID nicht|REVIEW_MISSING
commit_id ist alter HEAD|REVIEW_BINDING
Selbe Truth/Quellen, anderer Contracthash in Review|REVIEW_BINDING
Review auf falsche PR oder Repository-ID|REVIEW_BINDING
External-Review-Hash passt nicht zu eingebetteten Bytes|REVIEW_BINDING
External-Review result reject|REVIEW_BLOCKED
Externer Reviewer nur als Chat-Anzeigename angegeben|REVIEW_FORMAT
PENDING Review|REVIEW_MISSING
Maßgebliche Review DISMISSED|REVIEW_BLOCKED
Review-Body zwischen Gate und Final editiert|REVIEW_CHANGED
Review vor erster Beobachtung editiert und jetzt korrekt gebunden|PASS
Maßgebliche Review zwischen Gate und Final gelöscht|REVIEW_CHANGED
Neuere malformed Owner-Attestation, ältere korrekt|REVIEW_FORMAT
Neuere stale Owner-Attestation, ältere korrekt|REVIEW_BINDING
Neuer Widerruf|REVIEW_BLOCKED
Neue Freigabe ohne explizites supersedes der Blocker|REVIEW_BLOCKED
Neue Freigabe supersedes alle bekannten Blocker|PASS
Neue widersprechende autorisierte Findings nach Freigabe|REVIEW_BLOCKED
Unbeteiligter öffentlicher Kommentar ohne Autorisierung|PASS
PR wird während Tests geschlossen|PR_STATE
Head bewegt sich während Tests|PR_STALE
main bewegt sich während Tests|PR_STALE
Policyhash bewegt sich im geprüften Snapshot|POLICY_CHANGED
Original actor Codex, triggering_actor numerisch Owner, Attempt 2 komplett|PASS
triggering_actor Codex bei Attempt 2|IDENTITY_RECHECK
Re-run failed jobs verwendet Gate-Receipt von Attempt 1|IDENTITY_RECHECK
Doppelter forge-verify-Job im selben Attempt|POLICY_CHECKS
Fremder Workflow liefert gleichnamigen Check|POLICY_CHECKS
Alte grüne Checks sollen neue SHA freigeben|POLICY_CHECKS
Native PR-target-Checkzuordnung nicht durch Live-Drill belegt|POLICY_DEPLOYMENT
Plattformpolicy nicht administrativ geprüft/attestiert|POLICY_DEPLOYMENT
API-Lesefehler oder unvollständige Pagination|EXECUTION_API
Cleanup schlägt nach ansonsten grünen Tests fehl|EXECUTION_IO''')
(D/'adversarial-matrix.json').write_text(json.dumps(matrix,indent=2,ensure_ascii=False))
core=[
('contract-document.ts',145,'parseContractDocument, contractPathFor, ContractMetadataSchema','REUSE: exakt aus BASE importieren; vorher 256-KiB-Limit und striktes UTF-8. Format/Hash unverändert. Befehle sind Daten, niemals Shell.'),
('primitives.ts',46,'CommitShaSchema, RepoPathSchema, TaskIdSchema, compareCodeUnits','REUSE für Domain-Schema; RepoPath ist KEIN Filesystem-Sicherheitsvalidator. .git/config, CON.ts, AUX/x und a./b werden dort akzeptiert.'),
('freeze.ts',8,'deepFreeze','REUSE für eigene JSON-Daten. Bereits gefrorene fremde Objekte sind kein Authentizitätsbeweis.'),
('node-sha256.ts',7,'nodeSha256Utf8','REUSE des SHA-256-Adapters für Contractparser.'),
('ancestry.ts',26,'isAncestorOrSelf, isReachableFromRefs','NICHT sicherheitskritisch: glaubt dem gelieferten Graphen. Verifier liest echte Commitobjekte, stoppt an BASE, prüft Parents selbst.'),
('identity.ts',40,'sameIdentity, isIndependentReviewer','NICHT GitHub-Authentifizierung: Identitäten/Labels selbst deklariert. Numeric server IDs und Owner-Attestation separat.'),
('runs.ts',88,'Run-/Evidence-/Mutation-Schemas','NICHT neue Sicherheitsgrenze: fresh_clone ist Behauptung; Rename-Schema kennt keine Mode-Änderung; kein INFRA_FAILURE.'),
('verification.ts',129,'evaluateVerification und interne Scope-/Check-/Mutation-Auswertung','NICHT als PASS-Entscheider: globale Coordination-Ausnahme, Developer-Mutationsfallback, historische Remote-Beobachtung; .includes im Scope quadratisch.'),
('events.ts',153,'ForgeEventSchema und Eventtypen','REUSE nur als optionale spätere Domain-Projektion. Rollenprüfung authentifiziert weder Actor noch GitHub-Review.'),
('state.ts',452,'applyEvent, replay, Zustandsprojektion','NICHT als aktuelle Remote-Wahrheit: Input-State bzw. Log nicht authentifiziert, keine editierbare GitHub-Review-Lifecycle-Bindung. replay prüft innere Konsistenz.'),
('start-gate.ts',101,'canStartDeveloperRun','NICHT Static Gate: prüft gelieferte State-/Repo-Beobachtungen; Namespace, tatsächliches Git und Live-API fehlen.'),
('kernel.ts',30,'createForgeKernel','Kein IO-Verifier. Nicht importieren, um indirekt alte Freigabesemantik zu übernehmen.'),
('tests/forge-red-team/*', 'test-only','model.ts, findings.test.ts, differential.test.ts','Testideen und Gegenbeispiele wiederverwenden; langsames Array-Referenzmodell nicht in Produktion kopieren.')]
add(1,'Current Code Map',p('VERIFIED FROM CODE — Main wurde über die GitHub-API gelesen und als unveränderlicher Snapshot untersucht: '+SHA+'; Tree 67103229baccaefd68ce5047d8503eca9883f1d3. Alle zwölf aktuellen src/forge-Module wurden vollständig gelesen, außerdem die Red-Team-Helfer und zugehörigen relevanten Tests. Der Snapshot enthält 71 versionierte Dateien, noch keinen produktiven Workflow und keinen IO-Verifier. Der Hash-Manifest im Evidence-Paket bindet jede gelesene Quelldatei.')+table(['Modul','LOC','API / Aufgabe','Entscheidung'],core)+p('EXPERIMENTALLY VERIFIED — Der reale Core akzeptiert die untersuchte Coordination-Ausnahme zusammen mit Developer-Mutationsevidence; eine erfundene Ancestry-Tabelle wird als Fakt behandelt. Das ist eine Vertrauensgrenze des neutralen Domain-Cores, keine behauptete Remote-Authentifizierung. Die neue Spezifikation ändert keine bestehende Domain-Funktion. Sie ersetzt sicherheitskritische Verwendung durch einen separaten IO-Verifier.')+p('DESIGN INPUT — Der vorhandene FORGE-V0.1-BOOTSTRAP-EXPERIMENTAL-REPORT wurde vollständig gelesen; SHA-256 d3ed7f74b84282de75e3c77da2e43f91845bf4c112699e82b63fcd8ea24a2a3c. H1/H2/H3, zwei Jobs, Inventar, ignore-scripts, kein Rename-Vertrauen, kein merge-tree, frische Stage 2 und clampAtZero bleiben verbindlich. Neue Festlegungen unten konkretisieren diese Vorgaben; sie behaupten keine vorhandene Implementierung.')+p('PRODUCT JUDGMENT — V0.1 ist ein kontrollierter PR-Verifikationsprozess für dieses öffentliche Repository. GitHub, die frisch gestartete Runner-VM, der Linux-Kernel, Docker, TLS/CA, das digest-gepinnte Bootstrap-Image und BASE-Code sind TCB. HEAD-Inhalt, Autortexte, Artefakte, Git-Config, Developer-Berichte und Worker-Ausgaben sind untrusted. Kein Schutzversprechen gegen kompromittierte Owner/GitHub/TCB; kein Beweis semantischer Programmkorrektheit.'))
limits=[('Event / API-Seite / Reviewbody','1 MiB / 4 MiB / 64 KiB'),('Contract / Taskplan / Policy','je 256 KiB, JSON-Tiefe höchstens 32'),('Fetch / API / gesamter Job','90 s / 10 s pro Request / 20 min'),('ODB auf Disk / entpackte Objekte','512 MiB / 512 MiB, harte Mount-/cgroup-Grenze plus Zähler'),('Objekte / Commits HEAD..BASE','150.000 / 128'),('Commit / Tree / Blob','1 MiB / 16 MiB / 8 MiB'),('Dateien / Tree-Entries gesamt','20.000 / 40.000 je Snapshot'),('Materialisierte Bytes / Tiefe / Segment / Pfad','128 MiB / 16 / 100 Byte / 255 Byte'),('API Pagination','höchstens 20 Seiten à 100; Überschreitung FAIL'),('Inventar / Tests / Titel','8 MiB / 50.000 Identitäten / 4 KiB je Titel; Tiefe 32'),('Mutation / Anzahl / benannte Tests','30 s Laufzeit / höchstens 8 / höchstens 500 Testidentitäten pro Mutant'),('Worker','2 CPUs, 2 GiB RAM, 128 PIDs, 64 MiB /tmp, 16 MiB /out'),('Install / Typecheck / BASE- oder HEAD-Suite','180 s / 60 s / 120 s'),('stdout + stderr','je Prozess zusammen höchstens 8 MiB; Überlauf ist Infrastrukturfehler')]
add(2,'Trusted Bootstrap',p('NORMATIVE / PRODUCT JUDGMENT — Produktionssprache: Python 3.12 für Prozess-, Git-, API- und dir_fd-Dateisystemgrenzen; kleine JavaScript-Adapter für den existierenden Contractparser und Vitest. Keine neue Paket-Dependency. Die Python-Stdlib stellt die benötigten openat-artigen Operationen bereit. Ein TypeScript-Native-Addon oder ein produktiver Shell-Verifier wird nicht eingeführt.')+p('Der trusted Start benötigt ein separates, unveränderliches Werkzeug-Image. Festgelegte Kompatibilitätsversionen: Linux/amd64, Python 3.12.14, Git 2.51.1, Node 24.19.0, npm 11.9.0, Zod 4.6.5; TypeScript 7.0.2 und Vitest 5.0.3 stammen später aus BASE-lock. Die Versionen sind keine Sicherheitszertifizierung. Task C baut und prüft das Image, dokumentiert Build-/Paket-Hashes und pinnt seinen realen OCI-Digest. Hier wird kein erfundener Digest eingesetzt. Eine ungeprüfte neuere Version oder mutable Tag ist unzulässig. Python-Patchlevel/Image/Containerpfad sind im Lab noch nicht gemeinsam verifiziert.')+p('Stage 0 liegt im gepinnten Werkzeug-Image: stage0.py plus die kleinen Prozess-/Object-/Path-/Materialize-Primitiven aus akzeptiertem Task A. Dieser Bootstrap-Kernel hat eine eigene Image-Identität. Der eigentliche Verifier wird danach ausschließlich aus BASE geladen; verifierSha ist BASE, nicht der Image-Digest. So entsteht kein zirkulärer Commit, der den Digest eines Images mit sich selbst enthalten müsste. Die Workflowdatei aus dem trusted Base-Kontext pinnt das Image literal. Ein Image-Tag aus HEAD oder einem PR-Text darf nicht ausgewertet werden.')+code('''bootstrapTrustedObjects(eventBytes, runnerFacts, expectedRepo) -> TrustedBootstrap
runnerFacts = {eventName, githubSha, runId, runAttempt, actorId, triggeringActorLogin}
TrustedBootstrap = {repoId, pr, base, head, verifierSha, objectStore,
                    policyHash, manifestHash, sourceRoot, imageDigest}
Alle Datensätze frozen; keine vom Aufrufer frei konstruierbare "verified"-Flag.
''')+ul([
'0. Frische ubuntu-24.04-VM pro Job; kein self-hosted Runner, kein Checkout-/Cache-/Download-Artefakt-Schritt. Host-Schritt startet nur den fest gepinnten Container und übergibt Eventdatei read-only sowie explizit erlaubte Runner-Fakten als Daten. Keine PR-Ausdrücke in Shellcode. Host erzeugt zufälligen 0700-Arbeitsordner unter RUNNER_TEMP; nur dieser Host-Pfad darf als Bind-Mount verwendet werden.',
'1. Stage 0 läuft vor jeder HEAD-Ausführung. Event maximal 1 MiB; UTF-8 strikt; doppelte JSON-Keys, nichtendliche Zahlen, falsche Typen und übertiefe Daten ablehnen. PR/run/actor IDs positive dezimale Integer ≤ 2^53−1. SHA exakt [0-9a-f]{40}. Repository-ID muss 1401864629 sein; Name Forge-Dice/Forge ist zusätzlicher Pfadanker, kein Identitätsersatz.',
'2. Live GET /repos/Forge-Dice/Forge, /pulls/<pr>, /branches/main und /actions/runs/<runId>/attempts/<attempt>; feste api.github.com-URLs, keine Redirects, API-Version 2026-03-10, Accept application/vnd.github+json, TLS-Prüfung an, kein Authorization-Header. Event und Live-Daten abgleichen. GITHUB_SHA = PR.base.sha = aktuelles main = B; HEAD = PR.head.sha = H. HEAD-Repo muss dieselbe numerische Repo-ID haben. Bei fehlender öffentlicher API-Fähigkeit fail closed; kein Token-Fallback.',
'3. Neues leeres bare Repository, leeres template, eigenes HOME/XDG_CONFIG_HOME/TMPDIR, umask 077. Nicht klonen, nicht alternates/cache/reuse. Git vor und nach jedem Fetch auf Local-Layout und erlaubte Config prüfen.',
'4. Zuerst nur main fetchen und Ref exakt B prüfen. Echten Commit B lesen, BASE-Tree sicher traversieren. Aus B das feste forge/verifier/bootstrap-manifest.json lesen. Manifest hat nur format=1 und eine eindeutige Liste {path,sha256}; höchstens 100 Dateien. Nur tools/forge_v01/* sowie genau src/forge/{contract-document,primitives,freeze,node-sha256}.ts zulässig. Manifestpfade werden durch dieselbe Byte-Pathprüfung und sichere Materialisierung geschickt. Code darf nur diese BASE-Dateien und Image-Stdlib/-Zod importieren.',
'5. SHA-256 jedes geladenen BASE-Blobs mit Manifest abgleichen; Manifest selbst ist über B gebunden. Danach exec des materialisierten BASE main.py im selben vertrauenswürdigen Supervisor, nie aus cwd eines HEAD-Baums. Stage 0 und BASE-Verifier prüfen miteinander übereinstimmende Schema-/Bootstrap-Version. HEAD wird erst durch BASE bootstrapTrustedObjects im frischen ODB gefetcht und untersucht.',
'6. Exakte HEAD-Ref fetchen, Typ/Hash/Objektbudgets und Layout prüfen, Live-PR/main nochmals lesen. Weder refs/pull/N/merge noch HEAD-Repository-URLs noch beliebige SHA-Revspecs fetchen. Nur der feste Remote ist zugelassen. Ref-Fetch mit + betrifft ausschließlich die wegwerfbaren lokalen refs/forge/*; es ist kein Remote-Force-Push.',
'7. Keine Credentialdateien, SSH-Agenten, GitHub-Token, .netrc, globalen Git-Configs oder npmrc aus dem Host mounten. Supervisor hat für Stage 2 allein den Docker-Socket als privilegierte TCB-Schnittstelle; dieser Socket und das Supervisor-Verzeichnis werden niemals in einen Worker gemountet. Stage 1 benötigt ihn nicht. Worker startet erst nach vollständigem Static Gate.'
])+code('''/usr/bin/git init --bare --object-format=sha1 --template=<empty-dir> <private-odb>
/usr/bin/git -C <private-odb> <fixed-config-argv> fetch --no-tags --no-recurse-submodules \
  --no-write-fetch-head https://github.com/Forge-Dice/Forge.git \
  +refs/heads/main:refs/forge/main
/usr/bin/git -C <private-odb> <fixed-config-argv> fetch --no-tags --no-recurse-submodules \
  --no-write-fetch-head https://github.com/Forge-Dice/Forge.git \
  +refs/pull/<validated-decimal-pr>/head:refs/forge/head
Kein --depth; keine revspecs aus Text; alle Aufrufe argv, shell=False.
''')+p('Erlaubte Git-Prozessumgebung, aus leerem Mapping aufgebaut: PATH=/usr/bin:/bin; HOME, XDG_CONFIG_HOME und TMPDIR auf private Verzeichnisse; LANG=C, LC_ALL=C, TZ=UTC; GIT_CONFIG_NOSYSTEM=1; GIT_CONFIG_SYSTEM=/dev/null; GIT_CONFIG_GLOBAL=/dev/null; GIT_NO_REPLACE_OBJECTS=1; GIT_NO_LAZY_FETCH=1; GIT_TERMINAL_PROMPT=0; GIT_ASKPASS=/bin/false; GIT_OPTIONAL_LOCKS=0. Keine andere geerbte Variable. Insbesondere alle übrigen GIT_*, NODE_*, NPM_*/npm_*, COREPACK_*, SSH_*, LD_*, DYLD_*, HTTP(S)_PROXY/ALL_PROXY/NO_PROXY, GITHUB_*, ACTIONS_*, BASH_ENV, ENV, CDPATH fehlen. Python startet mit -I; keine PYTHONPATH/PYTHONHOME-Injektion. Stage 0 fügt vor eigenen Imports ausschließlich /opt/forge/bootstrap aus dem Image zu sys.path hinzu; der materialisierte main.py ausschließlich seinen geprüften absoluten BASE-Modulordner. Cwd und HEAD-Pfade bleiben ausgeschlossen. Der Wert 0 bei GIT_NO_REPLACE_OBJECTS ist keine sichere „Aus“-Kontrolle: die Labor-Kontrolle musste die Variable vollständig entfernen.')+code('''fixed-config-argv (jede Option als eigenes argv-Paar -c, key=value):
core.hooksPath=/dev/null
core.fsmonitor=false
credential.helper=
credential.interactive=false
http.extraHeader=
http.followRedirects=false
protocol.allow=never
protocol.https.allow=always
fetch.fsckObjects=true
transfer.fsckObjects=true
fetch.writeCommitGraph=false
gc.auto=0
maintenance.auto=false
submodule.recurse=false
''')+p('Zugelassene lokale Config sind ausschließlich die von git init erzeugten core.repositoryformatversion=0, core.filemode=true, core.bare=true und ausschließlich intern erforderliche dokumentierte Standardwerte; keine include/includeIf, remote, credential, filter, diff, merge, extensions oder zusätzliche Keys. Vorhandene refs/replace (auch packed), info/grafts, shallow, objects/info/{alternates,http-alternates}, *.promisor, extensions.partialClone und unerwartete Hooks führen zu GIT_LAYOUT; „ignorieren“ genügt nicht. Kein replace-, textconv-, filter-, submodule- oder merge-tree-Aufruf. fsck --strict --no-dangling muss unter denselben Grenzen bestehen; Warnungen über unzulässige Struktur werden nicht weggelassen. BASE kann normale historische Merge-Commits besitzen.')+table(['Grenze','Fester V0.1-Wert'],limits)+p('Prozesse starten mit eigener Prozessgruppe; Deadline mit monotonic clock. Bei Frist/Outputbudget: SIGTERM, höchstens 1 s Grace, SIGKILL, wait auf alle Kinder; Worker zusätzlich docker kill/rm. Fetch/Indexpack laufen in begrenztem cgroup und auf quota-begrenztem Workspace. Ein nachträgliches Zählen schützt nicht vor Pack-/Delta-Bomben während Fetch; deshalb sind Mount- und Memory-Grenzen Aktivierungsvoraussetzung. ODB-Metadaten in einem Batch lesen; deklarierte Größen summieren, dann Inhalte bounded konsumieren. Unerwartete Exitcodes, Signale und fehlende Daten sind FAIL. Kein Retry mit weniger Schutz; API-GET höchstens ein identischer Transport-Retry, niemals alte erfolgreiche Antworten verwenden.'))
add(3,'Git Object Model',p('NORMATIVE — Git ist Transport und geprüfter Objektspeicher, nicht Semantik-Orakel für Scope. Objektidentitäten sind 20 rohe Bytes / 40 Lowercase-Hex; Dateipfade bleiben vom Roh-Tree bis zum Change-Set bytes. Ausgabe darf erst nach vollständiger Pfadprüfung in ASCII erfolgen. OIDs sind Identitäten in der SHA-1-Repositorywelt; Git-SHA-1 ist hier kein Ersatz für den zusätzlichen SHA-256-Manifest oder gegen kompromittiertes GitHub gerichteter Integritätsbeweis.')+table(['API','Exakte Semantik'],[
('readCommit(oid) -> Commit','Ein cat-file --batch Prozess; Header <oid> <type> <size> LF, danach genau size Bytes + LF lesen. Größe vor Allokation prüfen. type muss commit sein; SHA1("commit "+decimal(size)+NUL+raw) nachrechnen. Genau ein tree-Header mit 40 lowercase hex. parent-Header geordnet als OIDs. Leere Zeile trennt Header/Message. Fortsetzungszeilen nur zu nichtstrukturellen Headern (z.B. gpgsig); keine Fortsetzung von tree/parent. Fehlende/falsche/mehrfache Strukturdaten FAIL. Autor-/Committertexte geben keine Actor-Berechtigung.'),
('readTree(oid) -> tuple[Entry]','Typ tree und eigener Objekthash prüfen. Wiederholt: mode ASCII-octal, SP, ein nichtleerer Rohname ohne / und NUL, NUL, genau 20 OID-Bytes. Keine dict-Konvertierung vor Duplicate-Prüfung. Git-Tree-Sortierung inklusive Directory-/ Terminator prüfen; kein trailing garbage. Rawname und Mode erhalten.'),
('collectTree(root) -> Snapshot','Iterativer Stack statt rekursiver Callstack; Entry-/Depth-/Bytebudgets. Mode 40000 rekursiver Tree; OID-Typ jeweils prüfen. Alle Directories und Leaves in Path-Trie aufnehmen; Filename-Mapping byteweise. OID-Lese-Cache bounded und unveränderlich; gleicher Subtree an verschiedenen Prefixen muss je Prefix auf Pfade geprüft werden.'),
('collectChanges(base,head) -> tuple[Change]','Union der byteweisen Leafpfade sortieren. Nur HEAD: ADD; nur BASE: DELETE; beidseitig andere OID: MODIFY; anderer Mode: MODE_CHANGE. Bei Content+Mode beide Flags in dieser Reihenfolge. Kein Rename-Score; DELETE+ADD auch bei identischen Blobs. Bei file→directory entstehen DELETE und ADDs und werden von V0.1-Scope abgelehnt.'),
('validateHistory(B,H) -> ordered commits','Von H raw parent-Kette bis exakt B. Jeder neue Commit hat exakt einen Parent; kein Root, keine Wiederholung, höchstens 128. B selbst darf mehrere Parents haben. Fehlende Objekte FAIL, nicht „kein Ancestor“. Jeder Zwischen-Snapshot muss denselben Schutzregeln genügen. End-Diff H gegen B muss nichtleer sein. Verträge können einen älteren baseCommit haben, dieser muss in authentisch gelesener BASE-Ancestry liegen.')])+table(['Mode / Pfadfall','V0.1-Verhalten'],[
('100644','Regulärer Blob. Neue Dateien nur dieser Mode.'),('100755','Nur unverändert aus BASE übernehmbar; Execute-Bit allein veranlasst keine Ausführung.'),('120000 / 160000 / unknown','SCOPE_MODE. Gitlink nicht als Blob lesen. Unbekannte Schreibweise/Struktur zuerst GIT_OBJECT, wohlgeformter unzulässiger Mode SCOPE_MODE.'),('Invalid UTF-8 / C0 / DEL','GIT_PATH; niemals Ersatzzeichen normalisieren.'),('Valid Unicode / NFC-NFD-Kollision','V0.1 weist jedes Nicht-ASCII-Byte ab. Kein stilles NFC. Die beiden Unicodeformen werden beide ausgeschlossen; volle Unicode-Pfadunterstützung bleibt außerhalb V0.1.'),('ASCII portable grammar','Segment [A-Za-z0-9._-]+; nicht . oder .., nicht mit - beginnen, nicht mit . enden. Keine leeren Segmente. Grenzen aus §2.'),('Case-Collision','ASCII-lowercase Schlüssel auf jedem Directory-/Leaf-Prefix; unterschiedliche Originalbytes mit gleichem Schlüssel verboten. Nicht nur finale Dateinamen vergleichen.'),('File/Directory Prefix','Trie-Knoten kann nicht gleichzeitig Leaf und Directory sein; ebenso unter casefold. Roh-Doubletten immer verboten.'),('.git / Windows','Segment case-insensitive .git verboten; git~1 bereits außerhalb Grammatik. CON/PRN/AUX/NUL/COM1..9/LPT1..9 auch vor Extension verboten. Colon, Backslash, Laufwerk/UNC, trailing space/dot, Steuerzeichen und Nicht-ASCII-NTFS-Aliase unzulässig.'),('.gitattributes / .gitmodules','Als ASCII-Pfad lesbar, aber geschützt; keine Attribute/Submodule werden angewendet. Keine Git-Smudges/Filters.')])+p('EXPERIMENTALLY VERIFIED — Echte Rawtrees zeigen Rename als DELETE+ADD, Mode+Content als zwei Flags, Symlink/Gitlink als andere Modes und den zweiten Parent im Commit. Replace-, Alternate-, Graft-/Shallow- und dir_fd-Angriffe sind im Scratch-Lab dokumentiert. Das ist keine Behauptung, dass GitHub all diese Rohobjekte für einen realen Push annimmt. Lokale Angriffsfixtures testen die Verifier-Grenze unabhängig von Server-Vorfiltern.'))
add(4,'Static Gate',p('NORMATIVE — Gleicher Algorithmus in beiden Jobs, in Stage 2 vollständig neu ausgeführt. Keine von Stage 1 materialisierten Quellen/Artefakte übernehmen. Lediglich ein kleines, vom trusted Job gesetztes Receipt darf als Attempt-Korrelation dienen; es ersetzt keine erneute Prüfung. Gate führt weder npm noch Compiler, Testcollection, tsconfig, PR-Python, PR-JavaScript oder Hooks aus.')+table(['Priorität','Prüfung / Ergebnis'],[
(1,'Prozess-/Bootstrap-Invarianten, bounded Event, Repository-ID/öffentliche Sichtbarkeit, Workflow-Event und feste Remote-Identität.'),
(2,'PR offen, nicht draft, base.repo.id korrekt, base.ref main; B/H gültig; GITHUB_SHA, base.sha, Live-main gleich. Head-Repo exakt kanonisches Repo; keine Forks.'),
(3,'PR.user.id aus Live-API; erlaubter Actor und Namespace. Nicht author association, Commit-Email, Login oder PR-Body verwenden.'),
(4,'ODB-Layout, Typen/Hashes, vollständige Rohstruktur; Limits bei jedem Read. HEAD-Ancestry und exakt ein Parent je neuem Commit.'),
(5,'BASE-Policy/Manifest und Taskindex; existierender BASE-Contractpfad, exact contentHash mit aktuellem Parser, Planbindung, baseCommit-Ancestry, akzeptierte Dependencies.'),
(6,'Gesamtsnapshots: Pfadvalidität/Kollisionen; Modes. Changes über Zwischencommits UND Netto-Diff. Keine Normalisierung vor diesem Schritt.'),
(7,'Exact scope: create nur B-absent, modify nur B-present. Jedes Zwischen- und Endergebnis darf nur diese Pfade betreffen. DELETE und MODE_CHANGE generell nicht erlaubt; keine Coordination-Ausnahme.'),
(8,'Protected files und Freeze. DEV darf keine TCB-, Config-, Toolchain- oder bestehenden Test-/Fixturepfade ändern. OWNER_OPS nur enge BASE-genehmigte TCB-Pfade, keine Test-/Toolchain-Freeze-Ausnahme.'),
(9,'Verbleibende Collection-/Change-/Bytebudgets und registrierte requiredChecks/Mutanten. Keine impliziten Shellbefehle oder dynamischen Testfilter.'),
(10,'Reviewliste vollständig laden; vorhandene Attestationen parsen und binden. Fehlende Attestation markiert reviewPending=true und verhindert Stage-1-Technical-PASS nicht; malformed/stale/revoked maßgebliche Owner-Attestation führt dagegen zu FAIL. Final-PASS braucht immer gültige Attestation.')])+p('Deterministische Priorität gilt innerhalb vollständig verfügbarer Snapshots: kleinste Phase gewinnt; darin feste Code-Reihenfolge aus §11, dann raw path bytes, dann Objekt-ID/Review-ID/Testidentität. Strukturfehler oder Ressourcenabbruch werden sofort ausgegeben, wenn keine spätere sichere Prüfung möglich ist; es wird nicht auf unlesbare Daten gewartet, um einen früheren semantischen Fehler zu erraten. Parallel ausgeführte unabhängige Requests verändern die Auswahl nicht. Das maschinenlesbare Ergebnis enthält primary failure plus sortierte, bounded Zusatzcodes; kein fortlaufendes Echo untrusted Textes.')+p('Zwei Profile, keine allgemeine Bypass-Rolle: DEV autorisiert numeric 337272506, Namespace ^forge/run/codex/<TASK>/[a-z0-9][a-z0-9-]{0,31}$. OWNER_OPS autorisiert numeric 315180734, Namespace ^forge/owner/<TASK>/[a-z0-9][a-z0-9-]{0,31}$. TASK ist genau ein registrierter TaskId. Beide verlangen gleiche Repo-ID, Ancestry, Scope, Tests, Mutationen und externe Owner-Attestation. OWNER_OPS darf nur die im BASE-Plan ausdrücklich aufgeführten TCB-Pfade ändern. Der Kandidaten-Verifier wird niemals zur Kontrolle seines eigenen PR benutzt. Alle anderen Namespaces/Profile sind FAIL.')+p('Policy v1 in forge/verifier/policy.json: strikte Felder format, repoId, ownerId, developers [{id,provider,namespacePrefix}], imageDigest, bootstrapVersion, deploymentPolicyDigest, limitsProfile="v01", taskIndex [{taskId,contractPath,contractHash,planPath,planHash}]. Keine optionalen unbekannten Felder. Taskplan v1: format, taskId, contractHash, profile, approvedTcbPaths, addedTestFiles, checks, mutants. PlanHash ist SHA256("forge-plan-v1\\n" + exakte UTF-8-Bytes); policyHash analog forge-policy-v1. Doppelte Keys/IDs/Pfade und unordered-duplicate Bedeutungen ablehnen. JSON ist LF, ohne BOM/CR, kanonisch mit zwei Leerzeichen und abschließendem LF; Encoder-Reihenfolge im Schema festgelegt. Kein frei interpretierbares Freitext-Programm.')+p('Es gibt auf aktuellem main keinen nachweisbar autoritativen persistenten ForgeLog als neue IO-Freigabequelle. Der Owner veröffentlicht Contracts/Taskpläne auf trusted main; der Taskindex genehmigt exakte Hashes. Dependencies müssen im Contract mit acceptedCommit != null vorliegen und authentische BASE-Vorfahren sein. Contract.baseCommit ist der Authoring-Snapshot, darf vor dem Publikationscommit liegen; PR-BASE ist stets aktuelles main. Das vermeidet die Selbstreferenz „Contract muss im eigenen baseCommit enthalten sein“.'))
sections[-1]=(sections[-1][0],sections[-1][1],sections[-1][2]+p('Exakte Pfadklassen: DEV darf nur im Contract benannte .ts-Dateien unter src/ außerhalb src/forge/ und genehmigte neue *.test.ts-Dateien unter tests/ ändern/anlegen. Bestehende tests/**, ganz src/forge/**, tools/forge_v01/**, .github/**, forge/{contracts,approvals,verifier}/**, root package/lock/tsconfig sowie jede .npmrc/.gitattributes/.gitmodules/.env und jede Toolconfig sind geschützt. OWNER_OPS darf genau seine approvedTcbPaths aus den TCB-Klassen ändern/anlegen, einschließlich anderer neu veröffentlichter Contracts/Pläne; niemals den gerade aktiven Contract, bestehende Tests/Fixtures oder package/lock/tsconfig. Sonstige Root-/Fremdpfade sind ausgeschlossen. Bereits vorhandene unveränderte Repo-Dateien werden lesbar mitgeführt, erhalten dadurch aber keine Änderungsberechtigung. addedTestFiles und approvedTcbPaths müssen Teil von contract.scope sein, schaffen selbst keine neue Scope-Erlaubnis.'))
add(5,'Materialization',p('NORMATIVE — Ausschließlich Blob-Materialisierung; niemals git checkout, worktree, archive-Entpacken, cp -a aus HEAD, npm-prepack oder Merge. Zielroot neu mit zufälligem Namen im privaten quota-begrenzten Workspace erzeugen, Mode 0700. Keine Wiederverwendung früherer BASE-/HEAD-/Mutantenverzeichnisse und keine Hardlinks zwischen ihnen.')+code('''rootfd = os.open(root, O_RDONLY|O_DIRECTORY|O_NOFOLLOW|O_CLOEXEC)
Für jeden bereits geprüften Pfad, Byte-sortiert:
  für jeden Parent: os.mkdir(name, 0o700, dir_fd=parentfd) falls neu;
                   os.open(name, O_RDONLY|O_DIRECTORY|O_NOFOLLOW|O_CLOEXEC,
                           dir_fd=parentfd); fstat -> Directory
  fd = os.open(leaf, O_WRONLY|O_CREAT|O_EXCL|O_NOFOLLOW|O_CLOEXEC,
               0o600, dir_fd=parentfd)
  fstat -> regular file AND st_nlink == 1
  exakt bounded Blob-Bytes streamen; eigene Git-OID und SHA256 gegen Erwartung prüfen
  fchmod(fd, 0o444 oder 0o555 bei zugelassenem BASE-100755); fsync; close
Alle fd über finally schließen; Symlink/EEXIST/unerwartete Stat -> EXECUTION_IO.
''')+p('Pfadvalidierung erfolgt vor der ersten Anlage und erneut als API-Vorbedingung; einzelne Komponenten öffnen, keine zusammengesetzten untrusted OS-Pfade nach rootfd. O_NOFOLLOW nur am Leaf reicht nicht, deshalb jeder Parent via dir_fd. Keine UID-/mtime-/xattr-Information aus Git anwenden. Worker-/out-tmpfs gehört uid/gid 10001 mit Mode 0700; /tmp Mode 1777. Ein Image-Selbsttest muss die Schreib-/Read-only-Grenzen vor HEAD-Start prüfen. Binary und leere Blobs unverändert schreiben. Bloblimit 8 MiB und Gesamtlauf 128 MiB zusätzlich beim Streaming zählen. Read-only-Mount für Worker schützt auch gegen chmod des Dateieigentümers. Über den Supervisor kontrollierte node_modules-/Config-Mounts sind keine aus HEAD übernommenen Symlinks.')+p('Bei Fehler komplette private Materialisierung verwerfen, laufende Gruppen/Container beenden, erst danach fd-sichere Entfernung unter dem bekannten Root. Worker kann Cleanup-Pfade nicht wählen. Bei Cleanupfehler kein PASS; Runner-VM wird entsorgt. Für Diagnose nur normalisierte Zähler, Hashes und feste Reason-Codes behalten, keine PR-Ausgaben oder Credentials. Erfolgreiche Jobs entsorgen ODB, Toolchain und Workspaces ebenso; keine Cross-Run-Caches. Die Laborproben haben binäre Bytegleichheit, EEXIST und Parent-Symlink-Abweisung geprüft; vollständige Docker-/Quota-Isolation ist noch ein Abnahmetest.'))
add(6,'Toolchain',p('NORMATIVE — Stage 1 benutzt ausschließlich das Image und BASE-Verifiercode. Zod 4.6.5 ist im digest-gepinnten Image für den bestehenden Parser vorhanden; Stage 1 installiert nichts. Stage 2 läuft auf einer anderen frischen VM und wiederholt Bootstrap/Gate. Danach wird die BASE-Toolchain in einem neuen Installationscontainer hergestellt, bevor irgendein HEAD-Code sichtbar ist.')+table(['Dateien / Daten','Herkunft und Regel'],[
('package.json, package-lock.json','Exakte BASE-Blobs. Keine HEAD-Nachinstallation. Lock muss die gepinnten Node-kompatiblen Tools liefern; npm ci prüft Lock-/Manifestkonsistenz und Integrities.'),
('tsconfig.json, Vitest-Konfiguration, Reporter, Setup','BASE bzw. generierter trusted V0.1-Config aus BASE-Code. Vite-/Vitest-Config-Autodiscovery aus HEAD deaktiviert durch explizites --config. Keine HEAD-Plugins/Setup-/Environment-/Workspace-Dateien.'),
('Bestehende tests/** inklusive Fixtures/typecheck-Dateien','Byte- und Mode-identisch BASE; Head-Dateien dürfen sie nicht ersetzen. Neue Tests nur exakte BASE-Planpfade, ebenfalls untrusted Sandboxcode.'),
('Genehmigte Source-Dateien','HEAD nach Gate. Alle sonstigen Dateipfade identisch BASE. Supervisor liest sie als Daten und importiert sie nie.'),
('node_modules und native optionale Toolpakete','Neu per BASE-lock installiert, nur während Install Netzwerk, danach read-only in Worker. Keine npm-Scripts, kein node_modules aus Git, keine weggelassenen optionalen TypeScript-Native-Pakete.'),
('Tool-Image, Dockerflags, CLI-Argumente, Env, Arbeitsroot','Trusted Workflow/Image/BASE-Code; niemals HEAD oder Contract.command als argv verwenden.')])+code('''# Exakte Aufrufe; Arrays, kein Shell-eval und kein npm test:
/opt/node/bin/npm ci --ignore-scripts --no-audit --no-fund
/opt/node/bin/node /case/node_modules/typescript/bin/tsc \
  --project /case/tsconfig.json --noEmit
/opt/node/bin/node /case/node_modules/vitest/vitest.mjs run \
  --config /trusted/vitest.config.mjs
''')+p('Install-Umgebung aus leerem Mapping: PATH=/opt/node/bin:/usr/bin:/bin, HOME=/tmp/install-home, TMPDIR=/tmp, LANG/LC_ALL=C.UTF-8, TZ=UTC, CI=true, NO_COLOR=1, npm_config_userconfig=/dev/null, npm_config_globalconfig=/dev/null, npm_config_cache=/tmp/npm-cache, npm_config_registry=https://registry.npmjs.org/. Install nur BASE package/lock, keine Repo-.npmrc. Keine --omit=optional. npm ci --ignore-scripts verhindert Lifecycle-Scripts; ein explizites npm test würde den ausgewählten Script trotzdem ausführen und ist deshalb nicht der vorgeschriebene Aufruf.')+p('Trusted Vitest-Config: project name forge-v01; root=/case; include wird aus den zugelassenen *.test.ts-Pfaden des Git-Snapshots exakt aufgebaut, keine frei gelieferten Globs; allowOnly=false; passWithNoTests=false; retry=0; sequence.shuffle=false; pool=forks; maxWorkers=2; fileParallelism=true; testTimeout=5000 ms; hookTimeout=10000 ms. Ausschließlich trusted Inventarreporter; kein Snapshot-Update; keine Coverage-/Watch-/UI-/Browsermode-Aktivierung. Aktuelle BASE-tsconfig bleibt vollständig erhalten. Nicht geplante TypeScript-Pfade außerhalb der BASE-Includes sind POLICY_INVALID. OWNER_OPS-Verifierdateien unter tools/forge_v01 werden zusätzlich im Worker mit Python compile(..., mode="exec") für alle .py und Node --check für alle .mjs syntaxgeprüft, ohne sie dabei auszuführen. Feste argv, kein Code aus HEAD in einem -c-Argument. Ihre fachliche Prüfung erfolgt durch die inventarisierten Vitest-Integrationstests.')+p('Worker: separater Container pro BASE, HEAD und Mutant; --network=none --read-only --cap-drop=ALL --security-opt=no-new-privileges --pids-limit=128 --cpus=2 --memory=2g --memory-swap=2g --user=10001:10001; Docker-Default-seccomp/AppArmor dürfen nicht ausgeschaltet sein. /case, /case/node_modules, /trusted read-only; nur bounded tmpfs /tmp und /out beschreibbar. Kein Docker-Socket, Host-Workspace, ODB, Event, API-Token oder Actions-Commandfile. Worker-Env nur PATH/HOME=/tmp/home/TMPDIR/LANG/LC_ALL/TZ/CI/NO_COLOR und feste Reportposition. Supervisor bleibt außerhalb dieses Containers; kein späterer trusted Schritt im durch HEAD veränderten Worker.')+p('Transport: trusted Worker-Entrypoint fängt Teststdout/stderr bounded ab und gibt nach Ende genau einen längengeframten JSON-Report an den Supervisor. Supervisor parst strikt, echoet keinen Output und vertraut ausschließlich dem selbst beobachteten Containerexit/Timeout plus geprüftem Reportschema. Keine Shell-/GitHub-Workflowcommands aus Tests in Runnerlogs. Report ist Beobachtung, kein signierter Beweis: absichtliches Monkeypatching durch beliebigen ausgeführten JavaScript-Code kann Prozess-internen Testerfolg vortäuschen. Scope, geschützte Tests, isolierte Umgebung und externe Codeprüfung begrenzen dieses Risiko, eliminieren es nicht. Eine stärkere Beweisgrenze wäre ein anderes Produkt und gehört nicht in V0.1.'))
add(7,'Test Inventory',p('NORMATIVE — Inventar wird aus realer Runtime-Collection und endgültigen Testresultaten erzeugt, nicht aus Source-RegEx, vitest list, JSON-Gesamtzahlen oder grep nach it(. Der Reporter nutzt die gepinnte öffentliche Vitest-5.0.3-API onTestRunEnd(TestModule[], unhandledErrors, reason). Ein Testmodul wird im geordneten children-Baum depth-first durchlaufen; Callback-/Abschlussreihenfolge darf keine Identität erzeugen.')+code('''TestIdentity = [file, project, ancestorTitles[], testTitle, occurrence]
file: validierter ASCII-Repo-Pfad, kein absoluter Workerpfad
project: exakt "forge-v01"
ancestorTitles/testTitle: unveränderte wohlgeformte Unicode-Strings
occurrence: 0-basierter Zähler unter gleichem [file,project,ancestors,title]
IdentityKey = JSON.stringify(TestIdentity)  # kein zusammengesetzter fullName
Status = passed | failed | skipped | todo
Inventory = {format:1, files:[{file,project,collection}], tests:[{id,status}],
             errors:[{kind, testIdentity|null}], reason}
''')+p('Parameterized cases werden nach tatsächlicher Expansion erfasst. Doppelte Namen sind erlaubt; jede occurrence muss zusammenhängend 0..n−1 sein, ohne Duplikat. Gleiche Titel unter unterschiedlichen ancestor-Arrays bleiben verschieden, auch wenn ein gedruckter fullName gleich aussieht. Unicode wird in Titeln nicht normalisiert; NFC/NFD sind unterschiedliche Identitäten, nicht automatisch semantisch gleiche Tests. Wohlgeformte Escape-/Delimiter-Zeichen werden als JSON strukturiert kodiert, nicht „bereinigt“. Grenzen stehen in §2.')+ul([
'BASE: Typecheck und vollständige Suite aus dem unveränderten Snapshot müssen bestehen. Ein vorhandenes skipped/todo/empty/collection error ist TEST_BASELINE, kein Ausgangszustand, den HEAD nur erhalten muss.',
'HEAD: erwartete Testdateiliste entspricht exakt dem Git-Snapshot und approved addedTestFiles. Alle BASE-Identitäten müssen vorhanden und passed sein. Jede zusätzliche Identität muss aus einer genehmigten neuen Datei stammen und ebenfalls passed sein. Neue Tests in geänderten bestehenden Dateien sind schon wegen Freeze unzulässig.',
'Leere Testdatei, fehlendes Modul, Collection-/Suite-/Hook-/Unhandled-Error, unbekannter Status, pending, aborted oder partieller Report: keine vollständige Verifikation. Ein absent/todo/skipped-Test kann nicht durch zusätzliche Tests kompensiert werden.',
'it.only/describe.only sind verboten; allowOnly=false. skipIf/runIf/dynamisches context.skip resultieren in skipped und somit FAIL, selbst wenn Prozess-Exit 0 ist. Retries bleiben 0, damit ein früher Fehlversuch nicht als bloß passed verschwindet.',
'Deleted/renamed/changed Testdateien werden im Static Gate gesperrt. Die Inventory-Schicht erkennt dieselben Verluste unabhängig nochmals, damit ein fehlerhafter Gate-Adapter nicht durch reine Testzahlkontrolle grün wird.',
'Outputreihenfolge wird kanonisch nach strukturierten UTF-8-JSON-Identitätsbytes sortiert. Eindeutigkeit und occurrence werden vor Sortierung im geordneten Collection-Baum bestimmt. Test-Titel aus Produktionsdaten können dynamisch wechseln: dann ist Inventory-Änderung bewusst ein Review-/Fehlerfall, keine automatische Aliasbildung.'
])+p('EXPERIMENTALLY VERIFIED — Auf echtem main liefen 1.087 Tests in 22 Dateien (17,63 s in diesem Lauf), TypeScript war grün (0,69 s). Eine kleine Fixture expandierte auf fünf Tests und lieferte duplicate occurrences 0/1. Skip und Todo ergaben Exit 0, wurden vom Inventar trotzdem abgelehnt; Löschen einer Datei ebenso. Leere Datei, Collection-Fehler, only, Assertion-Fehler und Titeländerung wurden getrennt sichtbar. Ein genehmigter neuer Test wurde akzeptiert. Der Lab-Reporter ist ein Testinstrument, kein fertiger sicherer Worker-Transport.'))
add(8,'Mutation Runner',p('NORMATIVE — Contract.mutationSmoke="required" verlangt 1..8 gebundene Mutanten. "optional" bedeutet: jede vorhandene Mutante muss ebenfalls KILLED sein; leer ist erlaubt. "none" verlangt leere Mutantenliste. Keine equivalence-Rationale und kein Developer-Fallback kann eine erforderliche überlebende Mutation entschuldigen. Die Mutation-Daten stehen im BASE-Taskplan, dessen Hash in der Policy steht; Format-1-Frontmatter wird nicht erweitert.')+code('''Mutant = {id, path, anchorBase64, replacementBase64,
          testFiles:[RepoPath], namedTests:[TestIdentity]}
id: [a-z][a-z0-9-]{0,31}, eindeutig, Reihenfolge im Plan normativ
anchor/replacement: canonical Base64; 1..65536 / 0..65536 Bytes
path: genau eine genehmigte Source-Datei, niemals Test/Config/Tool/Contract
namedTests: eindeutige vorhandene HEAD-passed-Identitäten in testFiles
''')+ul([
'1. Vor jedem Mutanten einen neuen clean HEAD aus geprüften Blobs materialisieren. HEAD-Inventar und BASE-Toolchain wiederverwenden nur als unveränderliche Daten; kein beschreibbares Worker-Dateisystem teilen.',
'2. Alle überlappenden Anchor-Vorkommen in den exakten Originalbytes zählen. Null oder mehr als eins, leeres Anchor oder identisches Replacement: NOT_APPLIED. Keine RegEx, kein fuzzy Patch, keine Git-Rename-/Context-Heuristik.',
'3. Genau an der eindeutigen Byteposition ersetzen. Erwartete Ergebnisbytes = prefix + replacement + suffix. Gesamtlänge begrenzen. Diff aller Materialisierungs-Manifest-Einträge muss exakt eine MODIFY-Zeile für path haben, kein Mode-/Pfad-/Test-/Configwechsel. Original- und Resultat-SHA256 aufzeichnen.',
'4. Mutanten-Typecheck mit trusted BASE-tsconfig. Dann ausschließlich die im Plan genannten vollständigen Testdateien ausführen; CLI-Filter werden aus geprüften Pfaden generiert. Kein title-RegEx als Identitätsersatz. Alle namedTests müssen im aktuellen Inventar vorkommen; ihr Vorzustand war HEAD-passed.',
'5. Erst Infrastructure ausschließen: Timeout, Signal/OOM, Compilerfehler, Collection-/Suite-/Hook-/Unhandled-Error, fehlender Report, fehlender benannter Test, skip/todo, unmöglicher Exitcode oder ein fehlgeschlagener nicht benannter Test => INFRA_FAILURE.',
'6. KILLED genau dann: vollständiges Ergebnis, Exit 1, mindestens ein benannter Test failed mit AssertionError und alle Failed-Tests haben ausschließlich AssertionError als Fehlerklasse; alle übrigen ausgewählten Tests passed. Kein Stack-/Message-RegEx und kein bloßes „nonzero“ genügt. Exit 0 plus alle selectedTests passed => SURVIVED. Alle übrigen Kombinationen => INFRA_FAILURE.',
'7. Fixed plan order; alle Mutanten können für Diagnose laufen, aber PASS verlangt jeden erforderlichen KILLED. Primary failure ist kleinster Planindex nach vorangestellten Runtime-Invarianten. Nach jedem Lauf komplette Worker-/Materialisierungsbereinigung.'
])+table(['Probe am echten clampAtZero','Beobachtung','Klassifikation'],[
('return n statt Clamp','Negativer Fall wirft AssertionError; Exit 1','KILLED'),('Äquivalente if-Implementierung','Alle drei Tests bestehen','SURVIVED'),('Nicht vorhandener Anchor','Keine Anwendung; kein Testlauf','NOT_APPLIED'),('return ???','Syntax-/Collection-Fehler','INFRA_FAILURE'),('throw beim Modulimport','Kein gültiger Assertion-Testlauf','INFRA_FAILURE'),('20 s Busy-Loop, Lab-Deadline 4 s','Prozessgruppe beendet; partielles/fehlendes Ergebnis','INFRA_FAILURE')])+p('EXPERIMENTALLY VERIFIED — Diese sechs Fälle liefen tatsächlich mit Vitest 5.0.3. Die Produktionsdeadline ist 30 s für Mutantentests; das Lab nutzt 4 s nur für seine ungefährliche Timeout-Probe. Die Produktionsregel ist absichtlich konservativ: auch ein durch Mutation verursachter TypeError zählt nicht als Assertion-Kill. Der Plan muss ausführbare fachliche Assertion-Mutanten definieren. Kausalität wird als kontrollierter clean-HEAD-Vergleich mit genau einer Byteänderung operationalisiert; gegen absichtliche AssertionError-/Reporter-Spoofing-Angriffe im selben Prozess bleibt die in §6 erklärte Grenze.'))
attestation={
'format':1,'repoId':1401864629,'pr':7,'base':'<40hex>','head':'<40hex>','contractHash':'<64hex>','verifierSha':'<same as base>','policyHash':'<64hex>','runId':123,'runAttempt':2,'action':'approve','externalReviewer':{'provider':'anthropic','model':'<nonempty model identifier>'},'externalReviewHash':'<64hex>','externalReviewResult':'approve','externalReviewBase64':'<canonical base64 of strict JSON report>','supersedes':[],'deployment':{'policyDigest':'<64hex>','checkedAt':'<UTC RFC3339 seconds>'}}
add(9,'Owner Attestation',p('NORMATIVE — Kleinster freigebender Datensatz ist ein GitHub-PR-Review mit serverseitiger user.id = 315180734, state = COMMENTED, commit_id = geprüftem H, submitted_at != null. Nicht Issue-Kommentar, Inline-Reply, Chatname, Author-Email oder APPROVED-State. H1 entfernt last-push approval; dadurch wird kein nativer Self-Approval-Mechanismus umgangen: die explizite Owner-COMMENT-Attestation ist eine getrennte Forge-Regel. Numeric IDs 315180734/337272506 stammen aus dem vorhandenen Designinput und werden als Policy-Pins behandelt; Rechte/Mitgliedschaften wurden hier nicht live administrativ zertifiziert.')+p('Reviewbody exakt: ASCII-Zeile FORGE-ATTESTATION-V1, LF, kanonisches JSON mit zwei Leerzeichen und abschließendem LF; keine Markdown-Fences, weiteren Prosa-Anhänge, BOM, CR, duplicate keys oder unbekannten Felder. Pflichtfelder der approve-Variante:')+code(json.dumps(attestation,indent=2,ensure_ascii=False))+p('externalReviewBase64 enthält höchstens 32 KiB striktes UTF-8-JSON: format=1; binding={repoId,pr,base,head,contractHash,verifierSha,policyHash}; reviewer={provider,model}; result=approve|request_changes; findings=[{id,severity,summary}]. Hash = SHA256("forge-external-review-v1\\n" + exakte dekodierte Bytes). Hash/Result/Reviewer/Binding müssen mit der Attestation übereinstimmen; keine blocking-Findings bei approve. Nichtblocking-Findings bleiben reviewbar. Für DEV mit developer.provider=openai muss externalReviewer.provider=anthropic sein; freie Displaylabels begründen keine Unabhängigkeit. Die Herkunft beim externen Provider wird vom Owner attestiert, nicht durch GitHub oder diesen Hash authentifiziert. Es wird kein Modell-Chat als kryptographische Identität ausgegeben.')+p('Revoke-Variante: gleiche Bindungsfelder repoId,pr,base,head,contractHash,verifierSha,policyHash,runId,runAttempt; action=revoke; supersedes leere Liste. Keine External-/Deploymentfelder. Ein gültiger Widerruf blockiert; er wird niemals als Freigabe interpretiert. Ungebundene oder fehlerhafte neuere Owner-Reviews blockieren ebenfalls bis zu einer neuen korrekten Freigabe. Ein natives CHANGES_REQUESTED vom Owner ist ein Blocker, auch ohne Forge-JSON. Andere öffentliche Nutzer sind keine autorisierten Findings-Schreiber in V0.1.')+p('Reviews vollständig paginieren und alle Owner-Reviews nach (submitted_at, numeric id) sortieren. PENDING zählt nicht als veröffentlichte Freigabe. Neuester veröffentlichter Owner-Review ist maßgeblich: niemals auf einen älteren passenden zurückfallen. APPROVED/DISMISSED/CHANGES_REQUESTED, malformed, stale oder revoke des neuesten Reviews blockieren entsprechend. Neue approve darf ältere Blocker nur explizit in supersedes=[{reviewId,bodyHash,state}] freigeben; IDs allein reichen wegen Editierbarkeit nicht. Keine unbekannten/duplizierten Supersedes; jedes referenzierte Digest/State muss dem aktuellen API-Datensatz entsprechen.')+p('Zu Beginn und vor PASS wird ein Snapshotdigest sämtlicher relevanter Review-IDs, States, Commit-IDs, submitted_at und exact body SHA256 berechnet. Jeder Unterschied während des Laufs führt zu REVIEW_CHANGED oder einem höher priorisierten aktuellen Blocker. Gelöschter ausgewählter Review führt zu FAIL. REST garantiert hier keine vollständige Edit-Historie: eine Bearbeitung vor der ersten Beobachtung ist als aktueller serverseitiger Body behandelbar, nicht als historisch unveränderte Attestation. Diese Grenze wird nicht durch erfundene edited_at-Felder kaschiert. Ein neuer Re-run bindet eine neue aktuelle Beobachtung.')+p('Die Owner-Freigabe bindet zusätzlich runId und den geplanten Ziel-runAttempt. Erstlauf liefert technische Ergebnisse, aber ohne Attestation kein forge-verify-PASS. Owner prüft externes Review und technische Daten, postet COMMENT mit dem nächsten Attempt und wählt Re-run all jobs. Original actor kann Codex sein; triggering_actor muss in diesem Attempt per serverseitigem Run-Datensatz numeric Owner sein. Login wird höchstens zur Auflösung verwendet, niemals als Berechtigung. Eine Änderung am Head/Contract/Main braucht neue passende Bindungen und komplette Wiederholung.'))
add(10,'Final Recheck',p('NORMATIVE — Nach erfolgreichem BASE/HEAD/Mutantentest und vor PASS alle Worker stoppen und Cleanup prüfen. Dann innerhalb eines höchstens 10 s langen Final-Fensters frische GETs ohne Cache-Fallback ausführen. Fehler oder Rate-Limit liefern EXECUTION_API. Kein längerer Loop, der wechselnde Fakten „irgendwann passend“ macht. Ein zweiter kompletter Snapshot muss mit dem ersten Final-Snapshot übereinstimmen; maximal zwei Snapshots, andernfalls FAIL.')+table(['Recheck','Verbindliche Bedingung'],[
('PR / HEAD / BASE / main','Offen, nicht Draft, gleiche repo/PR IDs, base.ref main; HEAD=H, base.sha=B, aktuelles main=B=verifierSha. Contract-, Plan-, Manifest- und Policyblobs aus genau B stimmen weiterhin mit Beginn überein.'),
('Review / Findings','Maßgebliche aktuelle Owner-COMMENT-Attestation unverändert; commit_id H; alle Bindingfelder; komplette relevante Reviewliste inklusive neuer Blocker/Supersedes unverändert. Nicht nur ausgewählten Review GETen.'),
('Run / Attempt / Actor','Run ID, workflow ID/path, event pull_request_target, event-created SHA B, run_attempt gleich Kontext, triggering_actor.id Owner, runAttempt>=2. Gate-Receipt aus demselben Run UND Attempt, B/H/Contract/Policy/Verifierbindungen exakt.'),
('Re-run all jobs','forge-gate setzt nur nach vollem Erfolg output receipt = fixed canonical JSON {runId,runAttempt,B,H,contractHash,policyHash,verifierSha}. Stage 2 vergleicht mit eigenem aktuellen Attempt. Re-run failed jobs behält ein altes Gate-Receipt und scheitert. Jobs des spezifischen Attempts müssen genau einen forge-gate und den einen laufenden forge-verify enthalten; keine Matrix-/Namensduplikate.'),
('Versionierte Policy','Aktuelles main und Policyhash gleich; keine HEAD-kontrollierten Konfigurationswerte. Änderungen erfordern neuen vollständigen Run.'),
('Plattformpolicy','Owner-attestierter deploymentPolicyDigest stimmt mit BASE-Policy überein; checkedAt weder in Zukunft noch älter als 30 min zum Final-Zeitpunkt. Ergebniskennzeichnung ausdrücklich owner_attested, niemals live_verified.'),
('Jobstatus','forge-verify läuft mit if: always(); falls needs.forge-gate.result != success, explizit FAIL, kein successful skip. Nur diese zwei Namen als required checks; Bindung zum richtigen Workflow und nativer PR-Kontext müssen live getestet sein.')])+p('VERIFIED FROM OFFICIAL DOCS — Re-runs behalten den ursprünglichen GITHUB_SHA/Ref und ursprüngliche Actor-Berechtigungen; deshalb können sie kein inzwischen weitergelaufenes main stillschweigend übernehmen. Required Checks können skipped/neutral als erfolgreich betrachten; der explizite red path ist erforderlich. Das dokumentierte GET der Actions Execution Policy benötigt Administration-Rechte mit write-Level; permissions:{} ist dafür kein verlässlicher Lesezugang. Deshalb gehört die Plattformpolicy als Owner-betriebene Deployment-Annahme in den Vertrag, nicht in eine fiktive Live-API-Prüfung.')+p('PRODUCT JUDGMENT / UNKNOWN — H1: Last-Push-Approval deaktiviert. H2: Delete/Force-Push-Schutz in eigenem Ruleset ohne Bypass, auch nicht für Owner. H3: ausschließlich pull_request_target, erlaubte Autoren/Akteure per globaler Ausführungsrichtlinie; keine push/pull_request/workflow_dispatch-Alternative. Diese Settings dürfen in diesem Auftrag nicht verändert werden und sind hier nicht als live aktiv bewiesen. Owner muss vor Aktivierung Native-Check-Zuordnung, Re-run-all vs failed-jobs, same-head/new-main, Fake-Checks, Verbot fremder Workflows und die Settings mit administrativer Einsicht testen. Kein privilegierter Check-Publisher als spontaner Fallback.')+p('Race-Limit: Die API bietet keinen atomaren Snapshot über PR, refs, reviews, Workflow und Settings. Auch zwei gleiche Final-Snapshots garantieren nichts über die Zeit zwischen letztem GET, Check-Abschluss und Merge. Ein späterer Widerruf kann einen bereits grünen Run ohne neuen Trigger nicht rückwirkend rot machen. Owner führt unmittelbar vor Merge seinen Kontrollschritt aus; Merge muss erwarteten HEAD binden, native Up-to-date-Regeln unterstützen aktuelle BASE-Anforderung. Kein Auto-Merge in V0.1. Bei weitergelaufenem main wird eine neue lineare Branch aus dem neuen BASE mit neuer Run-ID/PR und neu gebundenem Contract/Review erstellt. Weder ein Merge-Commit im Developer-Head noch ein durch H2 verbotener Force-Push repariert den alten Run. Wer eine atomare Freigabe gegen nachträgliche Policy-/Reviewänderungen verlangt, erhält NO-GO für diesen minimalen Workflow.'))
add(11,'Failure Codes',p('NORMATIVE — Geschlossene Enum mit '+str(len(errors))+' Codes. Kein dynamischer Fehlermeldungstext, kein untrusted path/title/body/stdout/Exceptiontext. Gemeinsames Ergebnis: {format:1,outcome:"FAIL",phase:<fixed enum>,code:<enum>,reason:<fixed integer>,subjectHash:<64hex|null>,ordinal:<bounded int|null>,binding:{repoId,pr,base,head,runId,runAttempt}}. reason ist in V0.1 immer 0 (reserviert); neue Subursachen brauchen eine explizite Schemarevision. So bleibt keine freie Text- oder Zahlenkonvention offen. subjectHash ist SHA256 der ursprünglichen Rohbytes, kein als Pfad verwendbarer Alias. Contractparser-Issuecode und numerischer Issueindex dürfen als feste zusätzliche Felder übernommen werden, der freie Zod-Text nicht.')+table(['Code','Bedeutung'],errors)+p('Priorität: Bootstrap-/Input-/Transportfehler vor nicht auswertbaren semantischen Phasen; danach §4, BASE, HEAD-Typecheck, HEAD-Inventarform, HEAD-Status, Mutanten in Planreihenfolge, Review, Final. Innerhalb einer Phase Enum-Reihenfolge dieser Tabelle, dann eindeutige strukturierte Subject-Sortierung. Ein failed-Test bei vollständigem Inventar ist TEST_STATUS; Collection/Unhandled/fehlender Report ist TEST_INVENTORY. Vor erfolgreicher BASE ist jede Testursache TEST_BASELINE. In einem bereits anwendbaren Mutantenlauf haben Timeout/Compiler/IO/Reportfehler Klassifikation INFRA_FAILURE und Code MUTANT_INFRA; nicht MUTANT_SURVIVED oder KILLED. Prozessstart vor Mutantenanwendung kann EXECUTION_SANDBOX sein. Auf internes Throwable ausschließlich EXECUTION_INTERNAL, keine Stack-/Secret-Ausgabe.')+p('PASS-Report: feste Bindingfelder, Image-/Manifest-/Policyhash, Zähler und Digest der Inventare, Mutant-ID/Outcome, ausgewählte Review-ID/Bodyhash und policyAssurance="owner_attested". Keine offizielle grüne Entscheidung allein durch Schreiben einer Datei aus dem Worker. exit 0 nur durch trusted Supervisor nach vollständigem Final-Recheck; sämtliche übrigen terminalen Zustände exit 1.'))
modules=[
('A','errors.py','Enum, Fail/Result, fixe Sortierung','fail(code,phase,reason,subject)', 'stdlib',80),
('A','process.py','Env, argv, Deadlines, bounded IO','runBounded(spec); cleanEnv(kind)','errors',170),
('A','paths.py','Bytegrammatik, Windows-/Case-/Prefix-Trie','validatePath(raw); validatePathSet(paths)','errors',170),
('A','objects.py','cat-file-Framing, Commit/Tree, Batchcache','readCommit; readTree; collectTree; collectChanges','process,paths',250),
('A','history.py','Echte Parentkette, Zwischencommitdaten','validateHistory(B,H,odb)','objects',130),
('A','materialize.py','dir_fd-Erzeugung und Cleanup','materialize(snapshot,destination); destroy(root)','objects,paths',190),
('A','bootstrap.py','ODB, fixed fetch, layout/limits','bootstrapTrustedObjects(input)','process,objects,history,materialize',230),
('A','stage0.py','Image-Kernel lädt ausschließlich BASE-Verifier','loadBaseVerifier(event,facts)','bootstrap primitives',100),
('B','contract-adapter.mjs','Original-Parser/-SHA aus BASE, strict IO','parseTrustedContractBytes(bytes)','vier src/forge-Module, Image-Zod',65),
('B','policy.py','Strict Policy/Plan/Contract-Bindung','loadPolicy(B); loadTask(taskId)','process,objects',190),
('B','scope.py','Static-Change-Gate, Profile/Freeze','checkScope(B,history,task)','paths,objects,policy',150),
('B','inventory-reporter.mjs','Vitest runtime identity graph','onTestRunEnd(modules,errors,reason)','Vitest public API',170),
('B','inventory.py','Schema, Multiset, Status/Comparison','parseInventory; compareInventory','errors',160),
('B','worker.py','Sandbox lifecycle, install/typecheck/test transport','installBaseToolchain; runTests; runTypecheck','process,materialize',230),
('B','mutations.py','Exact bytepatch und Klassifikation','runMutants(head,plan,baseline)','worker,inventory,objects',190),
('B','vitest.config.mjs','Trusted fixed config factory','makeConfig(root,approvedFiles)','none',35),
('C','github.py','Fixed GETs, pagination, JSON limits','readPr; readMain; readReviews; readRun','stdlib urllib/json,process',190),
('C','reviews.py','Strict attestation/current review set','bindReview(snapshot,binding)','github,policy',230),
('C','final.py','Snapshot stability / recheck','finalRecheck(start,receipt)','github,reviews,policy',140),
('C','main.py','Gate/verify orchestration only','main(argv) -> exit','all preceding modules',160),
('C','.github/workflows/forge-v01.yml','Zwei Jobs und receipt, gepinnter Stage0-Start','forge-gate / forge-verify','Image',110),
('C','tools/forge_v01/Dockerfile','Reproduzierbares Werkzeug-Image','OCI image digest','pinned inputs',70),
('C','forge/verifier/*.json','Manifest, Policy, Taskplan-Schemas/Beispiel','data only','BASE',100),
('C','src/forge-drill/clamp-at-zero.ts','Grüne Drill-Ausgangsfunktion','clampAtZero(n)','none',8)]
add(12,'Module Split',p('NORMATIVE — Python-/JS-Dateien liegen unter tools/forge_v01/, sofern unten kein voller Pfad genannt ist. Keine neue Datei soll über 300 Produktionszeilen wachsen; objects.py ist mit 250 die größte geplante Einheit. Sicherheitslogik nicht durch Einzeiler komprimieren, um LOC-Ziele zu fälschen. Tests werden als neue Vitest-Dateien unter tests/forge-v01/ geschrieben; sie dürfen Python via argv auf ungefährlichen Fixtures aufrufen. Damit entsteht kein zweites unbeobachtetes Testframework.')+table(['Task','Datei','Verantwortung','Öffentliche API','Dependencies','geschätzte LOC'],modules)+p('Aufwandskalkulation inklusive Workflow/Image-/Policydefinition, ohne Tests und Dokumentation: A = '+str(sum(x[5] for x in modules if x[0]=='A'))+', B = '+str(sum(x[5] for x in modules if x[0]=='B'))+', C = '+str(sum(x[5] for x in modules if x[0]=='C'))+'; insgesamt '+str(sum(x[5] for x in modules))+'. Planungsunsicherheit ±30 %. Dies sind bewusst drei abhängige Bootstrap-Tasks über 400 Zeilen, keine Behauptung, ein sicherer gesamter Verifier passe in 400 Zeilen. Falls diese Größenordnung untragbar ist, muss der Produktumfang reduziert werden, nicht die Sicherheitsgrenze weggelassen.'))
add(13,'100+ Adversarial Tests',p('NORMATIVE TEST CATALOG — '+str(len(matrix))+' konkrete Acceptance-Fälle. Jeder beschreibt einen isolierten Fehler; ansonsten gültige Ausgangsdaten. Die Gruppentitel bestimmen den Test-Einstieg: Parser-/Scope-/Inventory-Unitfälle erhalten bereits zugelassene Eingaben ihrer Schicht. Ein Full-Funnel-Test darf bei vom Transport oder Git-Fetch bereits abgewiesenen Rohobjekten früher mit GIT_FETCH/GIT_OBJECT abbrechen; die frühe Ablehnung ist separat zu protokollieren und keine behauptete Ausführung der späteren Schicht. Ein erwartetes PASS bei einem Kill-Test bedeutet KILLED, kein Überleben. Bei mehreren gleichzeitigen Fehlern gilt §4/§11. Die Evidence-Spalte unterscheidet bereits ausgeführte lokale Proben von noch umzusetzenden Produktions-/Live-Tests. Die bloße Aufnahme in diese Tabelle ist kein behaupteter Testlauf.')+table(['ID','Gruppe','Input / Angriff','Erwartung','Evidenz'],[(x['id'],x['group'],x['input'],x['expected'],x['evidence']) for x in matrix])+p('Zusätzlich verpflichtend: sechs Implementationsmutanten des Verifiers selbst müssen durch diese Suite auffliegen: (M1) GIT_NO_REPLACE_OBJECTS entfernen; (M2) CREATE/MODIFY auf Prefixvergleich umstellen; (M3) Inventory auf Gesamtzahl reduzieren; (M4) jeden nonzero Mutantenexit als KILLED zählen; (M5) review.user.login statt user.id verwenden; (M6) älteren passenden Review trotz neuerem Widerruf wählen; (M7) Gate-Receipt.runAttempt nicht vergleichen; (M8) O_NOFOLLOW bei Parents weglassen; (M9) main im Final nicht neu lesen; (M10) Coordination-Prefixausnahme einführen. Das ist die verbindliche Mutation-Testing-Abnahme der späteren Implementierung, noch kein gemessener Mutation Score.'))
props=[
('Tree diff','Seed 1042026; 5.000 Map-Paare im Lab','diff(A,A)=∅; apply(diff(A,B),A)=B; diff-Reversal vertauscht ADD/DELETE und Vorher/Nachher. Modes separat; gleiche Blobs an anderem Pfad bleiben DELETE+ADD. Für Produktion zusätzlich echte zufällige Rawtrees und Zwischencommits.'),
('Path validation','27 konkrete Pfade, 5 Collision-Sets; 10.000 Zufallsbytefolgen im Policy-Lab','Angenommene Pfade roundtrip bytegleich; weder Normalisierung noch Replacementchars; Fallalias/Directoryprefix-Closure. Zufallsbyteprobe ist reduzierte Admission-Eigenschaft, kein vollständiger Ersatz der produktiven Path-Trie-Fuzzer.'),
('Scope','10.000 deterministische Mengenpaare','Exact-Set-Implementierung gleich unabhängiger Mengendifferenz; Umordnung und doppelte Inputs erweitern nicht; ein zusätzlicher nicht genehmigter Pfad erzwingt FAIL. Produktion: create/modify/mode/protected Profile vollständig generieren.'),
('Inventory','10.000 generierte Titel-/Duplikatfolgen','Tuple+occurrence injektiv innerhalb Collection; Ergebnisreihenfolge irrelevant; jede Entfernung einer Identität erkennbar. Ancestor-Array kein delimiter-joined String. Fuzzer mit Unicode/escaping und wiederholten parametrisierten Namen.'),
('Review binding','29 benannte Fälle + 10.000 Permutations-/Spamfolgen','Listenreihenfolge irrelevant, unautorisierter Spam keine Freigabe; jeder Bindingfeldwechsel verhindert PASS; neuester Blocker kein Fallback; Re-run-attempt muss gleich sein. Produktionssuite ergänzt full-bodyHash/state supersedes und reale API-Pagination.'),
('Mutation classification','10.000 deterministische Boolean-Kombinationen plus sechs echte Mutanten','Jede Infrastructuremarkierung dominiert Assertion-Kill; nie KILLED ohne Assertion; all-pass zu SURVIVED; Not-applied führt zu keinem Workerstart. Produktionssuite generiert vollständige Reportschemata/Exitcodes/Signale.')]
add(14,'Property Tests',table(['Familie','Corpus','Eigenschaften'],props)+p('EXPERIMENTALLY VERIFIED — Git-Lab: 15.000 Assertions. Policy-Lab: 120.000 Assertions über sechs deterministische Modellfamilien, Seed 1042026. Zusammen 135.000 Assertions; das sind keine 135.000 unabhängigen GitHub-Angriffe. Das Policy-Lab ist bewusst ein kleiner ausführbarer Vertragsspiegel, kein Produktionsverifier. Es benutzt u.a. reduzierte Pfadgrammatik und ID-basierte Supersedes; die strengere finale Spezifikation verlangt zusätzlich bodyHash/state und gesonderte Abnahmetests. Keine Aussage „alle Policies formell bewiesen“.')+p('NORMATIVE — Produktionsfuzzing ohne neue Dependency: xorshift32 mit protokolliertem Seed und kleinsten Counterexample-JSONs; je Familie mindestens 10.000 Iterationen. Zwei unabhängige Repräsentationen vergleichen: Tree-Maps gegen sortierte Entrylisten, Scope-Set gegen naive Referenz, Inventory-Multiset gegen sortierten Tupelvektor. Shrimper entfernt Einträge/Bytes deterministisch; Timeout/Ressourcenlimit des Testläufers ist Testfailure, kein erfolgreich bestandener Angriff. Kein Zufall aus Date.now oder Netzwerk.'))
git=json.loads((B/'results/git-lab.json').read_text());coreprobe=json.loads((B/'results/core-probes.json').read_text())
add(15,'Performance',p('EXPERIMENTALLY VERIFIED — Lokale Messungen auf dem Lab-Host, Git 2.51.1/Node 24.19.0; warme Dateien/Objekte, Setup ausgeschlossen. Treewerte sind Mediane aus fünf Wiederholungen, Objectwerte aus drei. Es sind Größenordnungen und Hinweise auf Komplexität, keine Service-Level-Zusagen.')+table(['Dateien','2 Rawtrees + Diff + Pathchecks, ms','Realer alter Scope, ms','Vorbereitetes Set, ms'],[(g['files'],round(g['medianMs'],3),round(c['coreScopeMedianMs'],3),round(c['setMembershipMedianMs'],3)) for g,c in zip(git['treePerformance'],coreprobe['timings'])])+table(['Git-Objekte','Batch-Metadaten, ms','fsck, ms (Einzellauf)','Entpackte Blobbytes'],[(g['objects'],round(g['enumerateMedianMs'],3),round(g['fsckMs'],3),g['uncompressedBytes']) for g in git['objectPerformance']])+p('Die 1k/10k/100k-Objektproben enthalten echte kleine Git-Blobs in Packs, insgesamt bei 100k nur 1,4 MB Rohinhalt. Unreachable Objekte sind absichtlich Teil des Zähltests; dies ist kein realer Repo-Deploymentsnapshot. Einmaliger fsck war durch Cache/Overhead nicht monoton. Keine Aussage zu großen Deltas, feindlichen Packdateien, Internet-Fetch, Registry-Installation oder cgroup-/Dockerstartkosten.')+p('Konkrete vermeidbare Kosten: 1.000 einzelne cat-file-Prozessstarts benötigten 1.782 ms, ein Batch derselben Reads 3,95 ms. Der existierende Scope steigt von 6,43 ms bei 1.000 auf 675,43 ms bei 10.000 Changes; Set-Mitgliedschaft liegt bei 0,12/1,33 ms. Der Vergleich misst nicht identische Gesamtalgorithmen: die schnelle Seite ist nur die Ersatz-Mitgliedschaft, der alte Code prüft zusätzlich Evidence. Der .includes-Nesting ist dennoch direkt im Code nachweisbar und erklärt den dominanten quadratischen Anteil.')+p('INFERRED — Zielkosten: Object-Metadaten O(objects); Roh-Tree-Traversal O(entries+path bytes); Sortierung O(paths log paths); Scope O(changes+scope); Review-Auswahl O(reviews log reviews); Inventory O(tests log tests); exact-anchor search O(blob bytes × anchor bytes) bei einfacher Implementierung, durch feste 8-MiB/64-KiB-Limits nicht beliebig unbounded. Für Anchor-Search verwenden wir ausdrücklich KMP O(blob+anchor), weil Count mit wiederholter Slice-/startswith-Schleife sonst feindliche repetitive Daten unnötig teuer macht. Alle Treffer einschließlich Überlappung zählen bis zweitem Treffer; danach kann NOT_APPLIED sofort feststehen.')+p('History prüft höchstens 128 Zwischencommits. Naiv jeweils vollen Snapshot zu traversieren kostet O(commits × tree size), nicht O(files²) innerhalb eines Trees. V0.1 übernimmt bounded O(C×N), mit Tree-OID-Lesecache und frühzeitigen Limits. Zusätzlich Gesamtbudget 1.000.000 betrachtete Entry-Prefixe über die komplette History; Überschreitung GIT_LIMIT. Kein unbounded memoization und keine Optimierung, die ein noch ungeprüftes Subtree-Prefix überspringt. Tests/Mutanten dominieren realistische Fälle; feste Workerzahl 2 statt ungeprüfter Parallelisierung aller Mutanten.'))
# Normative refinements collected here to keep implementation choices explicit.
extra='''Ergänzende feste Prozessdetails: Image-Kernel/Verifier arbeiten auf einem vom Host angelegten privaten Workspace. Host mountet getrennte tmpfs mit harten Größen: ODB 512 MiB, Toolchain 1 GiB, BASE/HEAD/Mutant je 128 MiB, trusted-source 16 MiB; alle nosuid,nodev und nicht aus PR-Daten benannt. Keine noexec-Vorgabe für die Toolchain, weil TypeScript native optionale Executables verwendet. Docker-Bind-Mounts nutzen denselben absoluten Hostpfad im trusted Supervisor; ein Worker erhält nur seine freigegebenen Unterverzeichnisse. Docker-Version/API-Fähigkeit, AppArmor/seccomp und Mountlimits werden im Deploymentnachweis protokolliert und vor Workerstart geprüft. Die frische VM wird auch bei Cleanupfehler entsorgt. Stage 0 erhält keinen Docker-Socket; erst der ausschließlich aus BASE geladene Stage-2-Supervisor darf die feste Containerstartschnittstelle benutzen.

Trusted Parserauflösung: /trusted/node_modules verweist ausschließlich auf Image-Zod; Node startet mit clean Env und festem /opt/node/bin/node, kein NODE_PATH/NODE_OPTIONS. BASE-Parserimportgraf besteht aus genau contract-document.ts, primitives.ts, freeze.ts, node-sha256.ts. Unzulässige Imports oder fehlende Manifestdateien sind POLICY_INVALID. Manifest enthält keine Hash-Selbstreferenz und nicht den OCI-Digest; Image-Digest liegt im trusted Workflow und wird mit BASE-Policy verglichen.

Produktive Checkregistry: typecheck = forge-v01:typecheck, test = forge-v01:test, mutations = forge-v01:mutations. Normale V0.1-Taskpläne müssen die ersten beiden Namen/Befehle exakt enthalten; bei mutationSmoke required/optional mit vorhandenen Mutanten zusätzlich mutations. Taskplan.checks ist die geordnete Liste {name,command} und muss exakt Contract.requiredChecks entsprechen. Die oben verwendeten forge-v01:baseline/acceptance-a|b|c/mutations-a|b|c sind ausschließlich Bootstrap-Lab-Registryeinträge; sie ermächtigen keinen produktiven Shell-Eval. Nicht bekannte Commands führen zu POLICY_INVALID.

Public API-Reads laufen ohne Authorization-Header. Pro Request Deadline 10 s; höchstens ein identischer Retry nur für Transport/5xx, niemals bei 401/403/404 oder Rate-Limit. Pagination über interne page-Zähler, nicht blindes Folgen beliebiger Link-URLs. Höchstens 2.000 Reviews/Jobs, darüber FAIL. Event- und API-Bodytexte werden nie direkt geloggt. Native Kontrollfelder werden strict selektiert; zusätzliche dokumentierte API-Felder dürfen ignoriert werden, duplicate Keys und widersprüchliche Kontrollfelder nicht. Eigene Policy-/Plan-/Reviewformate bleiben strictObject.

Workflowkonfiguration fest: name Forge V0.1, nur pull_request_target types opened/reopened/synchronize/ready_for_review, branches main; permissions: {}; zwei Jobs mit IDs und Namen forge-gate und forge-verify, keine Matrix, keine Concurrency-Cancel-Freigabe, timeout-minutes 20. forge-verify always() mit eigenem FAIL, falls Gate nicht erfolgreich. Der trusted Host schreibt allein das bounded Receipt in GITHUB_OUTPUT; der Worker kennt weder Pfad noch Variable. Kein job success aus einem bloß skipped Worker. Ein finaler aktuelle-Run-API-Datensatz muss den triggering_actor numerisch liefern; fehlendes Feld ergibt FAIL, kein Login-only-Fallback.
'''
sections=[(n,t,b+('<h3>Verbindliche Start- und Integrationsdetails</h3>'+''.join(p(x) for x in extra.strip().split('\n\n')) if n==2 else '')) for n,t,b in sections]
# Exact allowed file sets for the three drafts.
filesA=['tools/forge_v01/'+x for x in ['errors.py','process.py','paths.py','objects.py','history.py','materialize.py','bootstrap.py','stage0.py']]+['tests/forge-v01/'+x for x in ['git-objects.test.ts','paths.test.ts','materialize.test.ts','bootstrap.test.ts','properties-a.test.ts']]
filesB=['tools/forge_v01/'+x for x in ['contract-adapter.mjs','policy.py','scope.py','inventory-reporter.mjs','inventory.py','worker.py','mutations.py','vitest.config.mjs']]+['tests/forge-v01/'+x for x in ['policy-scope.test.ts','inventory.test.ts','worker.test.ts','mutations.test.ts','properties-b.test.ts']]
filesC=['tools/forge_v01/'+x for x in ['github.py','reviews.py','final.py','main.py','Dockerfile']]+['.github/workflows/forge-v01.yml','forge/verifier/bootstrap-manifest.json','forge/verifier/policy.json','forge/verifier/task-plan.schema.json','forge/verifier/image-inputs.json','forge/verifier/clamp-plan.example.json','src/forge-drill/clamp-at-zero.ts']+['tests/forge-v01/'+x for x in ['reviews.test.ts','final.test.ts','workflow.test.ts','properties-c.test.ts','clamp-at-zero.test.ts']]
contractfiles=[]
common='''## Status und bindende Auslegung

DRAFT, nicht registriert und nicht zur Ausführung dieses Auftrags freigegeben. Dieses Dokument verwendet exakt Forge Contract Format 1 des angegebenen aktuellen main. Kein neuer Frontmatter-Key. Normative Details stehen im mitgelieferten FORGE-MINIMUM-VERIFIER-IMPLEMENTATION-PACKAGE.html, Abschnitte 1–18, und im nachstehenden Task-Scope. Die Implementierung ist eine spätere gesonderte Aufgabe.

Die Task-Dateien enthalten keine Architekturwahl mehr: Python-Stdlib für IO, vorhandener TypeScript-Contractparser unverändert, Vitest-Reporter in JavaScript; keine neue Dependency. Keine Änderung bestehender src/forge- oder Domain-Module, package.json, package-lock.json, tsconfig.json oder bestehender Tests. Nur scope.create-Pfade anlegen. Keine GitHub-Settings, Registrierung, Pushes, Reviews oder Deployments durch diese Drafts autorisiert.

requiredChecks.command ist ein Registry-Schlüssel, kein Shellkommando. "forge-v01:baseline" bedeutet bestehende BASE-Typecheck-/Vitest-Suite in isolierter Umgebung; "forge-v01:acceptance-a/b/c" bedeutet vollständige ausgewiesene Acceptance-Suite mit exaktem Testinventar; "forge-v01:mutations-a/b/c" bedeutet die weiter unten festgelegten Verifier-Mutationen auf lokaler Arbeitskopie. Solange der Verifier nicht installiert ist, führt ein unabhängiger trusted Lab-Runner diese Prüfungen aus. Bootstrap muss offen als externer Initial-Trust-Schritt abgenommen werden; der neue Verifier darf seine eigene Entstehung nicht rückwirkend zertifizieren.

Produktionsfiles ideal <300 LOC; keine künstliche Kompression. Geschätzte Zeilen sind keine harte semantische Abbruchgrenze. Tests sind nicht Teil der Produktionsschätzung. Keine Historien-/Remote-API-Fakes als echte Verifikation ausgeben. Sämtliche Netzwerk-/GitHub- und Docker-Abnahmetests müssen mit Testoberflächen laufen, solange kein separater Owner-Auftrag zur Live-Aktivierung vorliegt.
'''
taskbody={
'A':'''## Ergebnis

Implementiere ausschließlich die vertrauenswürdigen Bootstrap-/Objekt-/Pfad-/Prozess- und Materialisierungsgrenzen aus §§2–5, 11–12. APIs: runBounded, cleanEnv, readCommit, readTree, collectTree, collectChanges, validateHistory, validatePath(Set), materialize, destroy, bootstrapTrustedObjects, loadBaseVerifier. Die Namen und Frozen-Datentypen dürfen intern idiomatisch in Python gespiegelt werden, ihre Bedeutung nicht.

stage0.py und seine Primitiven bilden den später digest-gepinnten Image-Kernel. Er lädt nur BASE-Code, HEAD nie. BASE main.py darf zu diesem Zwischenstand fehlen: A wird mit einem harmlosen generierten BASE-Stub außerhalb des Repos geprüft; ein fehlender realer Entry ist FAIL und kein Produktionspass. Git-Kommandos/Umgebung/Refspecs aus §2 exakt; null Git-Checkout, merge-tree, Rename-Heuristik, Shell-eval, untrusted Hook oder PR-Ausführung.

## Acceptance

Alle Matrixfälle Bootstrap, echte Git-/Filesystem-Proben, Pfad/Modes, History und Materialisierung mit den erwarteten Codes umsetzen. Echte adversariale bare Repositories; Replace-/Alternate-/Graft-/Shallow-Fakten auch bei sauberer Env nachweisen. Mode+Content doppelt sichtbar; 2. Parent verboten nur oberhalb BASE. dir_fd/O_NOFOLLOW auf jedem Parent, O_EXCL am Leaf. Prozessgruppen tatsächlich terminieren. Rawobjekt-/Packgrößen während Verarbeitung begrenzen.

Propertyfamilien Tree/Path mindestens 10.000 deterministische Iterationen je Familie; independent oracle; 100/1000/10000 Files und 1k/10k/100k Objects unter gesetzten Budgets messen. Kein Performance-Gate auf absolute Millisekunden.

## Required Verifier Mutations

A1: GIT_NO_REPLACE_OBJECTS entfernen und Layout-Prüfung für refs/replace entfernen — dedizierter Original-Blob-Assertiontest muss scheitern.
A2: O_NOFOLLOW bei Parent-Open entfernen — Parent-Symlink-Assertiontest muss scheitern.
A3: MODE_CHANGE aus Diff entfernen — eigenständiger Mode+Content-Assertiontest muss scheitern.
A4: duplicate Rawtree-Entry vor Prüfung in dict überschreiben — Duplicate-Assertiontest muss scheitern.

Mutanten sind lokale Testinstrumente, keine HEAD-Dateien. Jede Veränderung muss exakt lokalisierbar, einmal angewandt, nicht äquivalent und durch echte Testassertion erkannt sein. Anchorbytes werden nach finaler Implementierung für den Acceptance-Runner eingefroren und vom Reviewer kontrolliert; keine zur Implementierung passende neue Semantik wählen.
''',
'B':'''## Ergebnis

Implementiere §§4, 6–8 sowie zugehörige Fehler-/Typgrenzen auf den akzeptierten A-APIs. Der aktuelle parseContractDocument wird direkt aus BASE mit nodeSha256Utf8 importiert. Format 1 unverändert. Die Node-Zod-Auflösung kommt aus dem trusted Image, nicht HEAD. Strict Policy-/Plan-JSON, exact Scope, keine Coordination-Ausnahme, keine impliziten Commands.

Der Worker ist eine frische Docker-Sandbox, kein child_process direkt neben einem privilegierten GitHub-Supervisor. BASE npm ci --ignore-scripts; nur BASE-manifest/lock; direkt gepinnte tsc-/vitest-Entrypoints. Testinventar über Laufzeit-Graph, tuple+occurrence, complete errors/status. Mutationen nach §8, Infrastructure dominiert Assertion-Kill. Ohne verfügbaren Docker-/Quota-/seccomp-Nachweis schlägt Integration fehl; unsandboxed Fallback ist nicht erlaubt.

## Acceptance

Matrixgruppen Scope/Freeze, Testinventar, Worker und Mutation vollständig. Bestehende 1087-Tests-Baseline darf sich durch die neuen Tests vergrößern; Identitäten und Status statt feste Gesamtzahl prüfen. Bestehende Testdateien unverändert. Zusätzlich echte Node-Script-/npmrc-/Config-Injektionsfixtures und Image/Worker-Outputangriffe. Der Worker darf weder Netzwerk noch Docker-Socket/Actions-Commandfiles erreichen; kein stdout-Workflowcommand gelangt ungefiltert ins Hostlog.

Propertyfamilien Scope/Inventory/Mutation mit je 10.000 deterministischen Iterationen. Die sechs clamp-Mutanten aus §8 mit echtem Vitest wiederholen. BASE failure stoppt HEAD; fehlender Test/Report/Timeout zählt nicht als KILLED.

## Required Verifier Mutations

B1: exact Scope auf startsWith umstellen — scope escape Assertion muss scheitern.
B2: vollständiges Inventar auf bloße Gesamtzahl reduzieren — löschen+neue Tests Assertion muss scheitern.
B3: nonzero als KILLED klassifizieren — Compiler-/Timeout-Assertion muss scheitern.
B4: Developer-Mutationsfallback zulassen — fake detected Assertion muss scheitern.

## Dependency

A muss unabhängig akzeptiert sein. Vor Ausführung diese Draftrevision mit echtem acceptedCommit von A und neuem baseCommit versehen, kanonisch neu parsen und hashen. null ist im Domain-Schema legal, im zukünftigen Gate bewusst blockierend. Keine erfundene Accepted-SHA einsetzen.
''',
'C':'''## Ergebnis

Implementiere §§9–11, orchestriere A/B in genau forge-gate und forge-verify. Github.py macht ausschließlich feste GETs. Kein Check-Publisher, kein POST/PATCH/PUT/DELETE-Client. Reviews numeric und exakt gebunden; Edit-/Revocation-/Supersedes-Semantik und Re-run-all-Receipt verpflichtend. Final prüft beide stabilen Snapshot-Runden; policyAssurance bleibt owner_attested für GitHub-Einstellungen.

Baue die Image-Rezeptur mit den festgelegten Toolversionen und A-Kernel. Image-Basis fest Ubuntu 24.04 Linux/amd64. forge/verifier/image-inputs.json bindet den realen Base-Image-Digest, A-Kernel-Commit, Buildrezept-SHA256 und die exakten Toolarchive mit URL/SHA256 (Node: nodejs.org; Python: python.org; Git: kernel.org; Zod: BASE-lock resolved/integrity). Keine Installation ungepinnter latest-Pakete als Ersatz. Erzeuge realen Digest und Manifest; keine Platzhalter in aktivierbarem Workflow. Docker- und Paket-/Imageprüfungen laufen lokal oder auf separat autorisierter Testoberfläche. Der Workflow ist im Draft/Implementations-PR nicht produktiv zu aktivieren, bevor alle Deployment-Gates nachgewiesen sind. Ungetestete native Checkzuordnung ist NO-GO, kein automatischer Architektur-Fallback.

Initialisiere die Policy mit leerem taskIndex und inaktivem Deployment-Nachweis. Beispielplan ist ausdrücklich unregistriert. Für erste Developer-Übung seed clampAtZero(n) als if-Form und feste negative/zero/positive Tests; initial BASE ist grün. Ein späterer separat veröffentlichter Drill-Contract genehmigt ausschließlich Source-MODIFY zur gleichwertigen ternären Form; Mutant return n muss KILLED sein. Equivalent-Mutant ist nur negative Verifier-Fixture und darf nicht als required killable in produktiven Plan geraten.

## Acceptance

Review-/Final-/Workflow-Matrix und deterministische Review-Properties vollständig. Weitere Live-Drills auf separat autorisierter Testoberfläche: native PR-target-Checkzuordnung; ausschließlich Re-run all jobs erfüllt neues Receipt; falscher Trigger-Actor fail; gleicher HEAD bei neuer main-SHA fail; Fake-/Doublechecks fail; global unterbundener push/pull_request/dispatch-Workflow; Owner-OPS erlaubt nur exakten BASE-Scope. Plattformpolicy darf nicht mit Job-Rechten als live_verified ausgegeben werden.

Workflow only pull_request_target types [opened,reopened,synchronize,ready_for_review], base main; permissions: {}; keine anderen Trigger, kein actions/checkout, keine Caches, kein HEAD-Step. forge-verify hat always() und expliziten roten Fehlerpfad bei fehlendem Gate-Erfolg. Frische VM je Job und vollständiger Bootstrap in jedem Job. Keine Auth- oder Container-Fallbacks bei Verfügbarkeitsschwierigkeiten.

## Required Verifier Mutations

C1: review.user.login statt user.id — same-name/wrong-ID Assertion muss scheitern.
C2: neuesten Blocker überspringen — revoke/no-fallback Assertion muss scheitern.
C3: runAttempt aus Gate-Receipt nicht prüfen — rerun-failed-jobs Assertion muss scheitern.
C4: final main-Abgleich auslassen — stale-main Assertion muss scheitern.

## Dependency und Stop

B muss akzeptiert sein; B bindet A transitiv. Vor Ausführung echte Accepted-SHA für B sowie aktuellen Authoring-baseCommit einsetzen und Revision erhöhen. Bootstrap-Veröffentlichung, GitHub-Settings, Image-Push und produktive Aktivierung bleiben gesonderte Owner-Aktionen. Dieser Contract verlangt deren überprüfbare Abnahmebedingungen, autorisiert aber keine kanonischen Änderungen aus dem vorliegenden Spezifikationsauftrag.
'''}
specSectionsHash=hashlib.sha256(json.dumps(sections,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
(B/'results/normative-sections.json').write_text(json.dumps(sections,ensure_ascii=False,separators=(',',':')))
common += '\nNormative Bindung: SHA256 der UTF-8-JSON-Sequenz [sectionNumber,title,htmlBody] für Abschnitte 1–15, compact JSON ohne abschließenden LF, ist '+specSectionsHash+'. Die Datei results/normative-sections.json im Evidence-Paket trägt genau diese Bytes.\n'
for letter,files in [('A',filesA),('B',filesB),('C',filesC)]:
 task='FORGE-BOOTSTRAP-0001'+letter
 meta={'forgeContractFormat':1,'taskId':task,'contractVersion':1,'baseCommit':SHA,'dependencies':[] if letter=='A' else [{'taskId':'FORGE-BOOTSTRAP-0001'+('A' if letter=='B' else 'B'),'acceptedCommit':None}],'scope':{'create':files,'modify':[]},'requiredChecks':[{'name':'baseline','command':'forge-v01:baseline'},{'name':'acceptance','command':'forge-v01:acceptance-'+letter.lower()},{'name':'mutations','command':'forge-v01:mutations-'+letter.lower()}],'mutationSmoke':'required'}
 loc=sum(x[5] for x in modules if x[0]==letter)
 text='---json\n'+json.dumps(meta,indent=2,ensure_ascii=False)+'\n---\n\n# '+task+' — Implementation Contract Draft\n\n'+common+f'\nProduktionsschätzung dieses Tasks: {loc} LOC ±30 %, plus eigenständige Tests.\n\n'+taskbody[letter]
 path=D/(task+'.contract.DRAFT.md');path.write_text(text);contractfiles.append(path)
add(16,'Implementation Contract(s)',p('NORMATIVE — Drei separate Drafts im tatsächlich akzeptierten Format 1. A: sichere Objekt-/Prozess-/Dateisystemgrenze. B: Scope, Toolchain, Inventar und Mutationen. C: GitHub-/Review-/Final-Bindung, Workflow und Deployment-Rezeptur. Keine Core-Änderung und kein erfundener Format-2-Block. Dateien/Pfade sind im Frontmatter exakt gelistet, keine Globs. requiredChecks-Befehle werden als feste Registry-IDs interpretiert; der bestehende Parser erlaubt diese Strings, führt sie nicht aus.')+table(['Draft','Abhängigkeit','Produktions-LOC','Status'],[(x.name,'keine' if i==0 else 'voriger Task, acceptedCommit=null bis echte Annahme',sum(m[5] for m in modules if m[0]=='ABC'[i]),'mit echtem aktuellem Parser validiert; nicht registriert') for i,x in enumerate(contractfiles)])+p('Die Drafts tragen den heute echten baseCommit '+SHA+'. Für B/C ist die noch nicht existierende Accepted-SHA ausdrücklich null: legal im aktuellen Schema, blockierend im spezifizierten Gate. Vor Implementationsstart einer abhängigen Revision werden reale Accepted-SHA und aktueller Authoring-baseCommit eingesetzt und Contractversion/Hash neu erzeugt. Das ist ein unvermeidlicher zukünftiger Messwert, keine offene Architekturentscheidung. Ebenso werden Image-Digest/Manifest erst aus realem Build erzeugt; niemals erfundene Platzhalter als aktivierbare Policy einsetzen.')+p('Bootstrap bleibt ein expliziter Initial-Trust-Schritt mit unabhängiger Review und Testabnahme. Der zukünftige Verifier kann die eigene erste Installation nicht vor seiner Existenz kontrollieren. Nach akzeptiertem C wird die erste Developer-Übung clampAtZero über einen separat auf BASE publizierten Contract/Plan registriert. Dieser Auftrag publiziert oder registriert nichts.'))
handoff='''FORGE V0.1 — EXACT CODEX HANDOFF
Status: Spezifikation; keine Implementierung in diesem Auftrag.
Repository: Forge-Dice/Forge
Gelesener main: '''+SHA+'''

1. Lese das vollständige HTML-Paket, dann Contract A/B/C. Normativ sind die expliziten Regeln, nicht Scratch-Prototypen. Scratch-Code dient nur als reproduzierbare Evidenz. Verändere keine bestehenden Core-/Domain-Module als Abkürzung.
2. Spätere Implementierungsreihenfolge: A -> unabhängige Abnahme -> neue B-Contractrevision mit echter A-Accepted-SHA -> B -> unabhängige Abnahme -> neue C-Revision mit echter B-Accepted-SHA -> C. Alle drei Implementationsschritte übersteigen realistisch 400 Produktionszeilen. Dateien klein halten, keinen 400-LOC-Gesamtverifier vortäuschen.
3. Produktionsaufteilung fest: Python-Stdlib für IO/OS/API; unveränderter aktueller parseContractDocument mit nodeSha256Utf8; kleine JS-Adapter für Parser/Vitest. Keine neue Dependency. Image-Kernel aus A; Verifiercode ausschließlich BASE. Image-Digest und Accepted-SHAs sind Build-/Abnahmewerte, keine freien Architekturparameter.
4. Beweise jede Sicherheitsgrenze mit echten negativen Fixtures und den benannten Verifier-Mutanten. Coverage/Anzahl grüner Tests ersetzt keine Inventory-/Binding-Evidenz. Keine Production-Implementierung aus dem verkürzten Lab-Modell kopieren.
5. Prüfe vor Live-Aktivierung separat: frische Runner-VMs, Docker-/Quota-/seccomp-Isolation, gepinnte Imageversionen, PR-target native Checkzuordnung, H1/H2/H3, falsche Workflowchecks, Re-run all jobs vs failed jobs, stale main bei gleichem HEAD. Ohne Nachweis bleibt Deployment NO-GO. Kein Checks-Publisher, keine Admin-Credentials und kein Runtime-Fallback hinzufügen.
6. Seed-Reihenfolge: A/B/C unter expliziter unabhängiger Bootstrap-Abnahme installieren, noch ohne aktivierte erforderliche Forge-Checks. Owner publiziert den echten ersten clampAtZero-Contract/Plan und die für spätere OWNER_OPS benötigten exakten Taskpläne auf BASE, bevor Required Checks scharfgeschaltet werden. Ein leerer taskIndex ist absichtlich nicht produktiv benutzbar; Required Checks vorher einzuschalten wäre ein Bootstrap-Deadlock.
7. Erster Developer-Drill: BASE clampAtZero als if-Form mit bereits grünen negativen/zero/positive Tests. HEAD ändert nur genehmigte Source zur ternären Form. Mutant return n muss am negativen Assertiontest sterben. Gleichwertiger Mutant muss im separaten Negativtest SURVIVED -> roter Verifier ergeben. Initial fehlende Owner-Attestation bleibt forge-verify rot; nach externem Review Owner-COMMENT und Re-run all jobs.
8. Owner prüft Deploymentpolicy administrativ; Job berichtet policyAssurance=owner_attested und prüft Policyhash/TTL. Kein Live-Policy-Prüfversprechen mit permissions:{}. Öffentliche GETs sind rate-limited; bei erschöpftem Kontingent FAIL, warten und vollständig neu starten. Keine automatische Credentialerweiterung.
9. Reporting: getrennt tatsächliche Beobachtung, Codebefund, Designentscheidung, Annahme und unbekannte Live-Eigenschaft nennen. Jede PASS-Entscheidung enthält exakte Bindings und den ehrlichen Race-/Worker-Vertrauensumfang. Keine untrusted Texte in Logs.
10. Stop nach Abnahmebericht des jeweiligen separat autorisierten Implementationstasks. GitHub-Settings, Pushes, Registrierung, Image-Publikation und produktive Aktivierung bleiben separate Owner-Freigaben; dieser Spezifikationsauftrag führt nichts davon aus.
'''
(D/'FORGE-MINIMUM-VERIFIER-CODEX-HANDOFF.txt').write_text(handoff)
add(17,'Exact Codex Handoff',p('NORMATIVE — Der vollständige Handoff liegt zusätzlich als eigene Textdatei im Paket. Keine Architekturentscheidung wird dem Implementationsagenten als „wähle selbst ein sicheres Checkout“ überlassen. Noch nicht erzeugbare Accepted-SHAs, reale Image-Digests und Live-Check-Ergebnisse sind explizite Abnahmewerte. Sie werden gemessen, nicht erraten.')+code(handoff)+p('Scope-Abweichungen vom breiteren Bootstrap-Designinput: V0.1 verweigert vollständiges Unicode-Filename-Authoring, Änderungen bestehender Tests sowie Toolchain-/Dependency-Upgrades, auch im OWNER_OPS-Profil. Diese Erweiterungen verlangen später eine eigene vorgelagerte Policy-/Testplanrevision. Der Minimalpfad bleibt ausdrucksstark genug für den clampAtZero-Drill und kleine source-only-Aufgaben; er ist kein universeller CI-Ersatz.'))
add(18,'GO / NO-GO',table(['Ebene','Urteil','Begründung / verbleibender Nachweis'],[
('Implementationsspezifikation','GO','APIs, Reihenfolge, Trustgrenzen, Formate, drei Scope-Contracts und '+str(len(matrix))+' Acceptance-Fälle festgelegt. Keine kanonische Änderung durchgeführt.'),
('Bestehenden Core als Remote-Verifier benutzen','NO-GO','Core überprüft innere Konsistenz gemeldeter Fakten, nicht deren reale Herkunft/Aktualität.'),
('Lokaler Mechanismusnachweis','GO WITH LIMITS','Echte Git-/Filesystem-/Vitest-/TypeScript-/Mutationsproben und Skalierung; 135.000 modellbasierte Assertions. Vollständiger Produktionsverifier existiert noch nicht.'),
('Produktive Aktivierung heute','NO-GO','Image-/Docker-/Quota-Grenze und native PR-target-/Re-run-/Ruleset-/Executionpolicy-Kombination nicht live abgenommen.'),
('Fälschungssicherer Testbeweis bei beliebigem feindlichem PR-Code','NO-GO','Reporter und Code teilen Testprozess; Read-only-Filesystem macht Laufzeit-Monkeypatching nicht kryptographisch unmöglich.'),
('Atomare Policy-/Review-Frische bis zum Merge','NO-GO','GET-Snapshots und Checkabschluss/Ownermerge sind nicht atomar. V0.1 benennt und bindet das verbleibende Race.'),
('Kontrollierter V0.1-Pfad nach Abnahme','CONDITIONAL GO','TCB/Owner-Annahmen explizit, isolierter Worker, exact Scope/Inventory/Mutation/Reviewbindung, H1–H3 nachgewiesen, manueller expected-HEAD-Merge.')])+p('Exakt nächste Schritte: (1) Contract A separat umsetzen und unabhängig abnehmen; (2) B mit echter Abhängigkeits-SHA umsetzen; (3) C mit echter Abhängigkeits-SHA und Image-/Sandboxabnahme umsetzen; (4) Owner führt autorisierte H1/H2/H3-/Native-Check-Drills auf Testoberfläche durch; (5) erst danach den vorpublizierten clampAtZero-Drill vollständig einschließlich COMMENT und Re-run all jobs ausführen. Keine zusätzliche 30-Punkte-Roadmap und keine stillschweigende Produktionsaktivierung.'))
# API version is already fixed before the normative snapshot is sealed.
# source citations are direct, pinned where possible, and not authority for our new normative choices.
sources=[
('S1 Current main source','https://github.com/Forge-Dice/Forge/tree/'+SHA+'/src/forge','Alle Core-Claims im Code-Manifest und §1; SHA-pinned.'),
('S2 GitHub PR-target events','https://docs.github.com/en/actions/reference/workflows-and-actions/events-that-trigger-workflows#pull_request_target','Aktuelle Dokumentation beschreibt Default-Branch-Kontext des Base-Repositories; Deployment muss tatsächliche native Zuordnung prüfen.'),
('S3 Re-runs','https://docs.github.com/en/actions/how-tos/manage-workflow-runs/re-run-workflows-and-jobs','Ursprünglicher SHA/Ref und Actor-Berechtigungen bleiben erhalten.'),
('S4 PR reviews REST','https://docs.github.com/en/rest/pulls/reviews','Review-State, numeric user, commit_id und editierbarer Body; kein behauptetes vollständiges Edit-Audit.'),
('S5 Actions policies REST','https://docs.github.com/en/rest/actions/policies','Dokumentierte Administration(write)-Anforderung für Policy-Leseendpoint.'),
('S6 Execution protections','https://docs.github.com/en/actions/how-tos/administer/control-workflow-execution','Actor-/Event-Schutz; Default-PR-target-Sperre für öffentliche Repos angekündigt ab 2026-11-02: bei Aktivierung erneut beachten.'),
('S7 Required checks','https://docs.github.com/en/pull-requests/how-tos/merge-and-close-pull-requests/troubleshooting-required-status-checks','Aktuelle SHA und skipped/neutral-Verhalten; Live-Abnahme weiterhin erforderlich.'),
('S8 Workflow run/attempt API','https://docs.github.com/en/rest/actions/workflow-runs','Run-/Attempt-/Actor-Bindung; API-Version 2026-03-10.'),
('S9 Workflow jobs API','https://docs.github.com/en/rest/actions/workflow-jobs','Jobs eines bestimmten Attempts; nicht pauschal letzte gleichnamige Checks.'),
('S10 Git cat-file','https://git-scm.com/docs/git-cat-file','Batch-Rohobjektzugriff; Filters/Textconv werden explizit nicht verwendet.'),
('S11 Python os','https://docs.python.org/3.12/library/os.html','dir_fd, O_NOFOLLOW, O_EXCL; Linux-spezifische Deploymenterwartung.'),
('S12 npm ci','https://docs.npmjs.com/cli/v11/commands/npm-ci/','Lock-konsistenter Install und ignore-scripts; direkte Scriptaufrufe sind gesondert.'),
('S13 Vitest public reporter API','https://vitest.dev/api/advanced/reporters','Runtime-Module/Reporter-Lifecycle, mit lokalem gepinnten 5.0.3 geprüft.'),
('S14 Vitest TestCase API','https://vitest.dev/api/advanced/test-case','Runtime-Ergebnis/Mode; TODO muss gesondert abgebildet werden.'),
('S15 Docker run','https://docs.docker.com/engine/containers/run/','Container-Resource-/Mount-/Security-Flags, vollständige Kombination im Lab nicht ausgeführt.')]
import re
apirows=[]
for src in sorted((B/'source/src/forge').glob('*.ts')):
 text=src.read_text(); functions=re.findall(r'(?:export\s+)?function\s+(\w+)\s*\(',text); arrows=re.findall(r'export const (\w+)[^\n]*=>',text)
 apirows.append((src.name,', '.join(dict.fromkeys(functions+arrows)) or 'Schemas / Typen; keine benannte Funktion'))
appendix='<section id="appendix"><h2>Experimental Appendix und Nachweise</h2>'+p('Stand: 2026-10-04 UTC. Belegklassen: VERIFIED FROM CODE = aktueller gepinnter Source; EXPERIMENTALLY VERIFIED = protokollierte lokale Ausführung; VERIFIED FROM OFFICIAL DOCS = gelesene Primärdokumentation; NORMATIVE/PRODUCT JUDGMENT = vorgeschriebene neue Entscheidung; INFERRED = begründete Folgerung; UNKNOWN = noch nicht geprüfte Eigenschaft. Normative Tabellen behaupten keine bereits existierende Implementierung.')+table(['Evidenzdatei','Inhalt'],[
('base-manifest.json','71 Originaldateien mit Git-OID/SHA256, Main-/Tree-Pin und Designinputhash.'),
('results/git-lab.json','18 benannte Git-/Filesystem-Proben, 27 Pfadfälle, 15.000 Properties, Größenmessungen.'),
('results/runtime-lab.json','1.087-Tests-Baseline, zehn Inventory-Szenarien, sechs echte Mutanten, TypeScript-Resultat.'),
('results/core-probes.json','Vier reale Core-Vertrauensgrenzenproben, Scope-Vergleich.'),
('results/policy-lab.json','29 benannte reduzierte Reviewmodellfälle; 120.000 Property-Assertions.'),
('results/contract-parse.json','Echter aktueller parseContractDocument für alle drei Drafts.'),
('results/final-main-check.json','Abschließende read-only Main-Abfrage und lokaler Source-Integritätscheck.'),
('experiments/*','Scratch-Reproduktionscode; keine Produktionsimplementierung; Runtimefixtures werden erzeugt.'),
('adversarial-matrix.json','Maschinenlesbarer Acceptance-Katalog; spezifiziert vs lokal ausgeführt markiert.')])+p('Reproduktion: exakten Commit in eigenen Scratch-Snapshot extrahieren, dessen BASE-package/lock mit npm ci --ignore-scripts installieren; node_modules im Labroot auf diese Installation zeigen lassen. Danach Python git_lab.py, Python runtime_lab.py, Node core-probes.mjs, Python policy_lab.py. Die Scripts verwenden ungefährliche lokale Probes und vorhandene Tools, nicht den noch fehlenden produktiven Container. Default-Lab-Verzeichnisnamen und Plattformpfade bei eigener Reproduktion kontrolliert anpassen. Git-/Runtimefixture-Verzeichnisse sind wegwerfbar.')+p('Harness-Korrekturen im Experiment: Die ungeschützte Replace-Kontrolle erforderte vollständiges Entfernen von GIT_NO_REPLACE_OBJECTS statt Wert 0; ein leeres Git-Template erforderte explizites info-Verzeichnis für die Graft-Fixture. Der Runtime-Harness bekam Prozessgruppen-Kill nach Timeout und vollständiges Löschen alter Fixturedateien/Reports vor jeder Probe. Die hier angegebenen Counts stammen ausschließlich aus dem abschließenden sauberen Lauf. Keine dieser Harness-Korrekturen war eine kanonische Repositoryänderung.')+p('Nicht gemessen: realer GitHub-Settingszustand, Native-Checkassoziation, zeitliche API-Races, tatsächliche Containerescape-Abwehr, Image-Reproduzierbarkeit, Netzwerklatenz, Packbomb-Resistenz unter cgroup/Quota. Diese bleiben ausdrückliche Abnahme-Gates. Kein Mutation Score für den noch nicht existierenden Verifier.')+'<h3>Vollständiger benannter Funktionskatalog</h3>'+table(['Aktuelles Modul','Benannte Funktionen (auch interne; mechanisch aus gepinntem Source)'],apirows)+'<h3>Primärquellen</h3><ul>'+''.join('<li><a href="'+E(url)+'">'+E(name)+'</a> — '+E(note)+'</li>' for name,url,note in sources)+'</ul></section>'
css='''body{margin:0;background:#f2f4f7;color:#182436;font:16px/1.6 system-ui,-apple-system,Segoe UI,sans-serif}main{max-width:1180px;margin:auto;background:white;padding:48px 5vw 80px}h1{font-size:2.35rem;line-height:1.15;max-width:950px}h2{font-size:1.65rem;border-top:3px solid #dde5ed;padding-top:25px;margin-top:55px}h3{font-size:1.2rem}.eyebrow{color:#416174;font-weight:700;letter-spacing:.07em;font-size:.85rem}.lead{font-size:1.16rem;color:#294459}.callout{background:#eaf2f6;border-left:5px solid #23758d;padding:16px 22px}nav{columns:2;background:#f4f7fa;padding:20px 32px}nav a{display:block;break-inside:avoid;margin:5px 0;color:#214d68}a{color:#075f8c}pre{padding:18px;background:#132334;color:#e8f2f6;white-space:pre-wrap;overflow-wrap:anywhere;border-radius:4px;font:13px/1.55 ui-monospace,monospace}table{width:100%;border-collapse:collapse;font-size:13px;line-height:1.45;margin:16px 0}th{text-align:left;background:#e5edf3}th,td{border:1px solid #cad5df;padding:10px;vertical-align:top;overflow-wrap:anywhere}tr:nth-child(even){background:#f8fafc}.scroll{overflow:auto}li{margin-bottom:9px}p{overflow-wrap:break-word}footer{border-top:1px solid #cbd5df;margin-top:45px;padding-top:20px;font-size:13px;color:#526577}@media(max-width:700px){main{padding:24px 18px}h1{font-size:1.8rem}nav{columns:1}table{min-width:750px}}@media print{body{background:white}main{max-width:none;padding:0}nav{display:none}h2{break-before:page}pre, tr{break-inside:avoid}.scroll{overflow:visible}a{color:inherit}table{font-size:10px}}'''
summary='<div class="callout"><b>Entscheidung:</b> GO für die spezifizierte Implementierung in drei abhängigen Tasks; NO-GO für heutige Produktivaktivierung. Der vorhandene Forge-Core ist kein authentifizierender IO-Verifier. Git-, Testinventar- und Mutationsmechanik wurden lokal geprüft; Sandbox und GitHub-Freigabepfad brauchen noch eigene Abnahme.</div>'
nav='<nav aria-label="Inhalt">'+''.join(f'<a href="#s{n}">{n}. {E(t)}</a>' for n,t,b in sections)+'<a href="#appendix">Experimental Appendix</a></nav>'
doc='<!doctype html><html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>FORGE MINIMUM VERIFIER IMPLEMENTATION PACKAGE</title><style>'+css+'</style></head><body><main><div class="eyebrow">READ-ONLY SPECIFICATION LAB · 2026-10-04</div><h1>FORGE MINIMUM VERIFIER IMPLEMENTATION PACKAGE</h1><p class="lead">Implementierungsnahe Spezifikation, adversariale Evidenz und drei Contract-Drafts für Forge V0.1.</p>'+p('Base SHA: '+SHA+' · Repository: Forge-Dice/Forge · Kein Produktionsverifier implementiert; keine kanonischen Repository-/GitHub-Änderungen.')+summary+nav+''.join(f'<section id="s{n}"><h2>{n}. {E(t)}</h2>{b}</section>' for n,t,b in sections)+appendix+'<footer>Prepared as a read-only technical design lab. Experiments are bounded evidence, not a claim of production deployment or complete formal verification.</footer></main></body></html>'
(D/'FORGE-MINIMUM-VERIFIER-IMPLEMENTATION-PACKAGE.html').write_text(doc)
print(json.dumps({'sections':len(sections),'adversarialCases':len(matrix),'productionLocEstimate':sum(x[5] for x in modules),'htmlBytes':len(doc.encode()),'contracts':[x.name for x in contractfiles]}))
