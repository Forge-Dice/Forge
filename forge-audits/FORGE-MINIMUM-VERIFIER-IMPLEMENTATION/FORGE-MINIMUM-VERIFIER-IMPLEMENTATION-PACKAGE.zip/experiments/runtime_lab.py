"""Actual pinned Vitest/TypeScript probes; no container isolation claimed in this lab."""
from pathlib import Path
import os,json,subprocess,shutil,time,hashlib,collections,signal
B=Path(__file__).resolve().parents[1];W=B/'runtime-fixtures';W.mkdir(exist_ok=True);R=B/'results';NM=B/'node_modules';NODE=shutil.which('node')
BASEENV={'PATH':'/usr/bin:/bin','HOME':str(W),'LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC','CI':'true','NO_COLOR':'1'}
def run(name,root,include=None,timeout=90):
 cfg=W/(name+'.config.mjs');report=R/(name+'.inventory.json');rawjson=R/(name+'.vitest.json');log=R/(name+'.log')
 report.unlink(missing_ok=True);rawjson.unlink(missing_ok=True);log.unlink(missing_ok=True)
 config={'root':str(root),'cacheDir':str(W/'cache'/name),'test':{'name':'forge-v01','include':include or ['tests/**/*.test.ts'],'allowOnly':False,'passWithNoTests':False,'pool':'forks','fileParallelism':True,'maxWorkers':2,'testTimeout':5000,'hookTimeout':10000,'retry':0,'sequence':{'shuffle':False},'reporters':[str(B/'experiments/inventory-reporter.mjs'),['json',{'outputFile':str(rawjson)}]]}}
 cfg.write_text('export default '+json.dumps(config)+';\n')
 env={**BASEENV,'LAB_ROOT':str(root),'LAB_REPORT':str(report)};start=time.monotonic()
 try:
  p=subprocess.Popen([NODE,str(NM/'vitest/vitest.mjs'),'run','--config',str(cfg)],cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);stdout,stderr=p.communicate(timeout=timeout);exitcode=p.returncode;log.write_bytes(stdout+stderr);timedout=False
 except subprocess.TimeoutExpired as e:
  os.killpg(p.pid,signal.SIGKILL);stdout,stderr=p.communicate();exitcode=None;timedout=True;log.write_bytes(stdout+stderr)
 data=json.loads(report.read_text()) if report.exists() else None
 return {'name':name,'exitCode':exitcode,'timeout':timedout,'elapsedMs':round((time.monotonic()-start)*1000,2),'inventory':data}
def key(r):return json.dumps([r['file'],r['project'],r['ancestors'],r['title'],r['occurrence']],ensure_ascii=False,separators=(',',':'))
def acceptable(inv):return bool(inv and inv['reason']=='passed' and inv['files'] and not inv['hooks'] and not inv['unhandled'] and all(f['state']=='passed' and not f['errors'] for f in inv['files']) and all(r['status']=='passed' for r in inv['rows']) and all(any(r['file']==f['file'] for r in inv['rows']) for f in inv['files']))
def compare(base,head):
 if not acceptable(head):return False
 h={key(r):r for r in head['rows']}
 return all(key(r) in h and h[key(r)]['status']=='passed' for r in base['rows'])
summary=[]
baseline=run('baseline',B/'source',timeout=120);assert baseline['exitCode']==0,baseline['name'];assert acceptable(baseline['inventory']);summary.append({k:v for k,v in baseline.items() if k!='inventory'}|{'tests':len(baseline['inventory']['rows']),'files':len(baseline['inventory']['files'])})
# Temporary fixtures are siblings with resolution to the existing pinned dependencies.
root=W/'cases';shutil.rmtree(root,ignore_errors=True);root.mkdir(exist_ok=True);(root/'tests').mkdir(exist_ok=True);(root/'src').mkdir(exist_ok=True)
(root/'package.json').write_text('{"type":"module"}')
(root/'tests/fixture.test.ts').write_text("import {describe,it,expect} from 'vitest';\ndescribe('outer > literal',()=>{describe('inner',()=>{it.each([1,2,2])('parameter %s',x=>expect(x).toBeGreaterThan(0));it('duplicate',()=>expect(1).toBe(1));it('duplicate',()=>expect(2).toBe(2));});});\n")
good=run('inventory-good',root);assert acceptable(good['inventory']);summary.append({'name':'parameterized_duplicates','tests':len(good['inventory']['rows']),'duplicateOccurrences':[r['occurrence'] for r in good['inventory']['rows'] if r['title']=='duplicate']});assert [r['occurrence'] for r in good['inventory']['rows'] if r['title']=='duplicate']==[0,1]
original=(root/'tests/fixture.test.ts').read_text();scenarios={'skip':original.replace("it('duplicate'","it.skip('duplicate'",1),'todo':original+"it.todo('future');\n",'empty':"export {};\n",'collection_error':"throw new Error('collection fixture');\n",'only':original.replace("it('duplicate'","it.only('duplicate'",1),'assertion_fail':original.replace('expect(1).toBe(1)','expect(1).toBe(9)'),'rename_test':original.replace("'duplicate'","'renamed'",1)}
for n,code in scenarios.items():
 (root/'tests/fixture.test.ts').write_text(code);r=run('inventory-'+n,root);accepted=compare(good['inventory'],r['inventory']);assert not accepted,n;summary.append({'name':n,'exitCode':r['exitCode'],'statuses':dict(collections.Counter(x['status'] for x in r['inventory']['rows'])) if r['inventory'] else {},'inventoryAccepted':accepted})
(root/'tests/fixture.test.ts').write_text(original);(root/'tests/new.test.ts').write_text("import {it,expect} from 'vitest';it('new',()=>expect(true).toBe(true));\n");r=run('inventory-new',root);assert compare(good['inventory'],r['inventory']);summary.append({'name':'new_test','inventoryAccepted':True,'tests':len(r['inventory']['rows'])})
(root/'tests/fixture.test.ts').unlink();r=run('inventory-deleted',root);assert not compare(good['inventory'],r['inventory']);summary.append({'name':'deleted_file','exitCode':r['exitCode'],'inventoryAccepted':False})
# clamp drill, actual mutation effects.
shutil.rmtree(root/'tests');(root/'tests').mkdir();(root/'src/clamp.ts').write_text('export function clampAtZero(n: number): number { return n < 0 ? 0 : n; }\n');(root/'tests/clamp.test.ts').write_text("import {describe,it,expect} from 'vitest';import {clampAtZero} from '../src/clamp.ts';describe('clampAtZero',()=>{it('negative',()=>expect(clampAtZero(-1)).toBe(0));it('zero',()=>expect(clampAtZero(0)).toBe(0));it('positive',()=>expect(clampAtZero(2)).toBe(2));});\n")
head=(root/'src/clamp.ts').read_bytes();clean=run('clamp-clean',root);assert acceptable(clean['inventory'])
mutants=[('wrong_result',b'return n < 0 ? 0 : n;',b'return n;','KILLED'),('equivalent',b'return n < 0 ? 0 : n;',b'if (n < 0) return 0; return n;','SURVIVED'),('missing_anchor',b'return impossible;',b'return n;','NOT_APPLIED'),('compile_error',b'return n < 0 ? 0 : n;',b'return ???;','INFRA_FAILURE'),('module_throw',b'export function',b'throw new Error("import fixture"); export function','INFRA_FAILURE'),('timeout',b'return n < 0 ? 0 : n;',b'const end = Date.now() + 20000; while (Date.now() < end) {} return n;','INFRA_FAILURE')]
mutrows=[]
for n,anchor,replacement,expected in mutants:
 (root/'src/clamp.ts').write_bytes(head)
 positions=[i for i in range(len(head)) if head.startswith(anchor,i)]
 if len(positions)!=1:actual='NOT_APPLIED';r=None
 else:
  i=positions[0];changed=head[:i]+replacement+head[i+len(anchor):];(root/'src/clamp.ts').write_bytes(changed);assert changed!=head
  r=run('mutant-'+n,root,timeout=4 if n=='timeout' else 30);inv=r['inventory']
  if r['timeout'] or not inv or inv['unhandled'] or inv['hooks'] or any(f['errors'] for f in inv['files']):actual='INFRA_FAILURE'
  elif any(x['status']=='failed' and any(e['name']=='AssertionError' for e in x['errors']) for x in inv['rows']) and all(x['status'] in ['passed','failed'] for x in inv['rows']):actual='KILLED'
  elif acceptable(inv) and r['exitCode']==0:actual='SURVIVED'
  else:actual='INFRA_FAILURE'
 assert actual==expected,(n,actual,expected)
 mutrows.append({'name':n,'classification':actual,'exitCode':r['exitCode'] if r else None,'timeout':r['timeout'] if r else False})
(root/'src/clamp.ts').write_bytes(head)
# Pinned TypeScript entrypoint; source's config remains exactly BASE.
start=time.monotonic();p=subprocess.run([NODE,str(NM/'typescript/bin/tsc'),'--project',str(B/'source/tsconfig.json'),'--noEmit'],cwd=B,env=BASEENV,capture_output=True,timeout=60);(R/'baseline-typecheck.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0
(R/'runtime-lab.json').write_text(json.dumps({'suiteRuns':summary,'mutants':mutrows,'typecheck':{'exitCode':p.returncode,'elapsedMs':(time.monotonic()-start)*1000},'sandbox':'NOT TESTED: no Docker available; harmless local fixtures only'},indent=2));print(json.dumps({'suiteRuns':summary,'mutants':mutrows},indent=2))
