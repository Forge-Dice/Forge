"""Bounded executable policy model; not production implementation or GitHub integration."""
from pathlib import Path
import random,json,copy,hashlib,collections
R=Path(__file__).resolve().parents[1]/'results'; rng=random.Random(1042026)
BOUND={'repoId':1401864629,'pr':7,'base':'a'*40,'head':'b'*40,'contractHash':'c'*64,'verifierSha':'a'*40,'policyHash':'d'*64,'runId':99,'runAttempt':2}
OWNER=315180734

def review(i=1,**kw):
 d={'id':i,'author':OWNER,'state':'COMMENTED','commit_id':BOUND['head'],'submitted':i,'body':{'binding':BOUND.copy(),'action':'approve','externalResult':'approve','blocking':[],'supersedes':[]},'bodyHash':str(i)};d.update(kw);return d

def decide(reviews, observed_hash=None, final=False,trigger=OWNER,gate_attempt=2):
 if final and (trigger!=OWNER or gate_attempt!=BOUND['runAttempt']):return 'IDENTITY_RECHECK'
 own=sorted([r for r in reviews if r['author']==OWNER and r['state']!='PENDING'],key=lambda r:(r['submitted'],r['id']))
 if not own:return 'REVIEW_MISSING'
 r=own[-1];b=r.get('body')
 if r['state']!='COMMENTED' or not isinstance(b,dict) or b.get('action')!='approve':return 'REVIEW_BLOCKED'
 if r['commit_id']!=BOUND['head'] or b.get('binding')!=BOUND:return 'REVIEW_BINDING'
 if b.get('externalResult')!='approve' or b.get('blocking')!=[]:return 'REVIEW_BLOCKED'
 blockers={x['id'] for x in own[:-1] if x['state']=='CHANGES_REQUESTED' or isinstance(x.get('body'),dict) and x['body'].get('action')=='revoke'}
 if not blockers.issubset(set(b.get('supersedes',[]))):return 'REVIEW_BLOCKED'
 if observed_hash is not None and r['bodyHash']!=observed_hash:return 'REVIEW_CHANGED'
 return 'PASS'
rows=[]
def probe(name,rs,expected,**kw):
 actual=decide(rs,**kw);assert actual==expected,(name,actual,expected);rows.append({'name':name,'expected':expected,'actual':actual})
probe('valid_owner_comment',[review()],'PASS')
probe('no_review',[],'REVIEW_MISSING')
probe('display_name_is_not_id',[review(author=123)],'REVIEW_MISSING')
for state in ['APPROVED','CHANGES_REQUESTED','DISMISSED']:
 probe('state_'+state,[review(state=state)],'REVIEW_BLOCKED')
probe('pending',[review(state='PENDING')],'REVIEW_MISSING')
probe('stale_commit',[review(commit_id='e'*40)],'REVIEW_BINDING')
for field in BOUND:
 a=review();a['body']['binding'][field]=0 if isinstance(BOUND[field],int) else '0'*len(BOUND[field]);probe('binding_'+field,[a],'REVIEW_BINDING')
probe('edit_after_observation',[review(bodyHash='changed')],'REVIEW_CHANGED',observed_hash='original')
probe('current_edit_before_observation',[review(bodyHash='changed')],'PASS',observed_hash='changed')
probe('newest_malformed_no_fallback',[review(),review(2,body=None)],'REVIEW_BLOCKED')
probe('newest_stale_no_fallback',[review(),review(2,commit_id='e'*40)],'REVIEW_BINDING')
rev=review(2);rev['body']['action']='revoke';probe('new_revoke',[review(),rev],'REVIEW_BLOCKED')
app=review(3);probe('cannot_implicitly_clear_revoke',[review(),rev,app],'REVIEW_BLOCKED');app['body']['supersedes']=[2];probe('explicit_reapproval',[review(),rev,app],'PASS')
probe('untrusted_spam_ignored',[review(),review(2,author=888,body=None)],'PASS')
probe('wrong_trigger',[review()],'IDENTITY_RECHECK',final=True,trigger=888)
probe('rerun_failed_jobs_old_gate_receipt',[review()],'IDENTITY_RECHECK',final=True,gate_attempt=1)
probe('owner_all_jobs_same_attempt',[review()],'PASS',final=True)
probe('deleted_selected_review',[],'REVIEW_MISSING')

# Six deterministic property families. Implementations intentionally small and separate from future verifier.
counts=collections.Counter()
for iteration in range(10000):
 # Review ordering and unrelated-author invariance.
 rs=[review(i+1) for i in range(rng.randrange(1,6))];a=decide(rs);rng.shuffle(rs);assert decide(rs)==a;rs.append(review(90000+iteration,author=1,body=None));assert decide(rs)==a;counts['review_binding']+=2
 # Exact scope; prefix has no permission, ordering and duplication have no wider power.
 permitted={f'src/{i}.ts' for i in rng.sample(range(20),rng.randrange(1,15))};changes={f'src/{i}.ts' for i in rng.sample(range(20),rng.randrange(1,15))}
 actual=all(p in permitted for p in changes);oracle=not bool(changes-permitted);assert actual==oracle;assert not all(p in permitted for p in changes|{'src/escape.ts'});counts['scope']+=2
 # Inventory multiset including occurrence, completion ordering ignored.
 titles=[rng.choice(['same','x','x > y','é','e\u0301']) for _ in range(rng.randrange(1,20))];seen=collections.Counter();ids=[]
 for t in titles:ids.append(('tests/a.test.ts','forge-v01',('suite',),t,seen[t]));seen[t]+=1
 assert len(set(ids))==len(ids);permuted=ids.copy();rng.shuffle(permuted);assert set(ids)==set(permuted);assert not set(ids).issubset(set(ids[1:]));counts['inventory']+=3
 # Mutation classification: infrastructure dominates assertion; no guessed killed on nonzero.
 timeout,infra,assertion,passed=[bool(rng.getrandbits(1)) for _ in range(4)]
 outcome='INFRA_FAILURE' if timeout or infra else 'KILLED' if assertion else 'SURVIVED' if passed else 'INFRA_FAILURE'
 assert not ((timeout or infra) and outcome=='KILLED');assert outcome!='KILLED' or assertion;counts['mutation_classification']+=2
 # Byte identities: no Unicode normalization or delimiters-as-structure.
 s=rng.choice(['é','e\u0301','a > b','a\nb','a\\b','nul\x00'])+str(iteration);encoded=json.dumps(['f','p',['a > b'],s,0],ensure_ascii=False,separators=(',',':'));assert json.loads(encoded)[3]==s;assert encoded!=json.dumps(['f','p',['a','b'],s,0],ensure_ascii=False,separators=(',',':'));counts['identity_serialization']+=2
 # Path admission implies UTF8/ASCII portable exact roundtrip. Rejected corpus input never repaired.
 bs=bytes(rng.randrange(256) for _ in range(rng.randrange(1,50)))
 accepted=all(c in b'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-' for c in bs) and bs not in [b'.',b'..'] and not bs.startswith(b'-') and not bs.endswith(b'.')
 assert (not accepted) or bs.decode('ascii').encode('utf8')==bs
 counts['path_bytes']+=1
(R/'policy-lab.json').write_text(json.dumps({'seed':1042026,'reviewCases':rows,'properties':dict(counts),'iterationsPerFamily':10000,'assertions':sum(counts.values()),'limits':'Scratch model only; no live GitHub API races, sandbox escape or cryptographic reviewer provenance tested.'},indent=2));print(json.dumps({'reviewCases':len(rows),'properties':dict(counts),'assertions':sum(counts.values())}))
