"""Disposable Git-object/path experiments. NOT a production bootstrap/verifier."""
import os,sys,re,json,zlib,hashlib,subprocess,tempfile,time,statistics,random,shutil
from pathlib import Path
B=Path(__file__).resolve().parents[1];R=B/'results';W=B/'git-fixtures';R.mkdir(exist_ok=True);W.mkdir(exist_ok=True)
ENV={'PATH':'/usr/bin:/bin','HOME':str(W/'home'),'XDG_CONFIG_HOME':str(W/'xdg'),'LC_ALL':'C','TZ':'UTC','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_SYSTEM':'/dev/null','GIT_CONFIG_GLOBAL':'/dev/null','GIT_NO_REPLACE_OBJECTS':'1','GIT_NO_LAZY_FETCH':'1','GIT_TERMINAL_PROMPT':'0','GIT_OPTIONAL_LOCKS':'0'}
(W/'home').mkdir(exist_ok=True);(W/'empty').mkdir(exist_ok=True)
def git(repo,*args,data=None,clean=True):
 p=subprocess.run(['/usr/bin/git','-c','core.hooksPath=/dev/null','-c','credential.helper=','-c','protocol.file.allow=never',f'--git-dir={repo}',*args],input=data,capture_output=True,env=ENV if clean else {k:v for k,v in ENV.items() if k!='GIT_NO_REPLACE_OBJECTS'},timeout=60)
 if p.returncode:raise RuntimeError((args,p.returncode,p.stderr[:100]))
 return p.stdout
def init(name):
 p=W/name
 if p.exists():shutil.rmtree(p)
 subprocess.run(['/usr/bin/git','init','--bare','--object-format=sha1',f'--template={W/"empty"}',str(p)],env=ENV,capture_output=True,check=True);return p
def put(repo,typ,data):
 obj=typ.encode()+b' '+str(len(data)).encode()+b'\0'+data;sha=hashlib.sha1(obj).hexdigest();p=repo/'objects'/sha[:2]/sha[2:];p.parent.mkdir(exist_ok=True);p.write_bytes(zlib.compress(obj));return sha
def tree(repo,entries):return put(repo,'tree',b''.join(mode.encode()+b' '+name+b'\0'+bytes.fromhex(oid) for name,mode,oid in sorted(entries,key=lambda e:e[0]+(b'/' if e[1]=='40000' else b''))))
def commit(repo,t,parents=()):return put(repo,'commit',(f'tree {t}\n'+''.join(f'parent {p}\n' for p in parents)+'author Lab <lab@example.invalid> 1700000000 +0000\ncommitter Lab <lab@example.invalid> 1700000000 +0000\n\nfixture\n').encode())
def readtree(data):
 rows=[];i=0
 while i<len(data):
  sp=data.index(b' ',i);end=data.index(b'\0',sp+1);mode=data[i:sp].decode('ascii');name=data[sp+1:end];oid=data[end+1:end+21]
  if len(oid)!=20 or not name or b'/' in name:raise ValueError('GIT_OBJECT_INVALID')
  rows.append((name,mode,oid.hex()));i=end+21
 if len({r[0] for r in rows})!=len(rows):raise ValueError('GIT_OBJECT_INVALID')
 return rows
def collect(repo,oid,prefix=b'',seen=None):
 if seen is None:seen=set()
 if oid in seen:raise ValueError('GIT_OBJECT_INVALID')
 out={}
 for name,mode,obj in readtree(git(repo,'cat-file','tree',oid)):
  path=prefix+name
  if mode=='40000':
   for k,v in collect(repo,obj,path+b'/',seen|{oid}).items():
    if k in out:raise ValueError('GIT_OBJECT_INVALID')
    out[k]=v
  else:out[path]=(mode,obj)
 return out
FLAGS=['ADD','MODIFY','DELETE','MODE_CHANGE']
def diff(a,b):
 out=[]
 for p in sorted(a.keys()|b.keys()):
  x=a.get(p);y=b.get(p);f=[]
  if x is None:f=['ADD']
  elif y is None:f=['DELETE']
  else:
   if x[1]!=y[1]:f.append('MODIFY')
   if x[0]!=y[0]:f.append('MODE_CHANGE')
  if f:out.append({'pathHex':p.hex(),'flags':f,'old':x,'new':y})
 return out
reserved=re.compile(r'^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)',re.I)
def validate_path(p):
 try:s=p.decode('utf8','strict')
 except UnicodeDecodeError:return 'invalid_utf8'
 if not 1<=len(p)<=255:return 'length'
 if any(x<32 or x==127 for x in p):return 'control'
 if any(x>127 for x in p):return 'non_ascii'
 if not re.fullmatch(r'[A-Za-z0-9._-]+(?:/[A-Za-z0-9._-]+)*',s):return 'grammar'
 parts=s.split('/')
 if len(parts)>16 or any(len(x)>100 for x in parts):return 'depth_segment'
 for x in parts:
  if x in ['.','..'] or x.endswith('.') or x.startswith('-'):return 'segment'
  if x.lower() in ['.git','git~1']:return 'git_reserved'
  if reserved.match(x):return 'windows_reserved'
 return None
def validate_set(paths):
 seen=set();files=set(paths)
 for p in sorted(paths):
  if validate_path(p):return 'GIT_PATH_INVALID'
  low=p.lower()
  if low in seen:return 'GIT_PATH_COLLISION'
  seen.add(low)
  parts=p.split(b'/')
  if any(b'/'.join(parts[:i]) in files for i in range(1,len(parts))):return 'GIT_PATH_COLLISION'
 # Directory aliases also collide, e.g. Dir/a and dir/b.
 dirs={}
 for p in paths:
  parts=p.split(b'/')
  for i in range(1,len(parts)):
   q=b'/'.join(parts[:i]);k=q.lower()
   if k in dirs and dirs[k]!=q:return 'GIT_PATH_COLLISION'
   dirs[k]=q
  if p.lower() in dirs:return 'GIT_PATH_COLLISION'
 if seen&set(dirs):return 'GIT_PATH_COLLISION'
 return None
repo=init('adversarial.git');a=put(repo,'blob',b'alpha\n');b=put(repo,'blob',b'beta\n');binary=put(repo,'blob',b'\0\xff\x80binary');empty=put(repo,'blob',b'')
t0=tree(repo,[(b'same.ts','100644',a),(b'old.ts','100644',b),(b'mode.ts','100644',a)]);c0=commit(repo,t0)
t1=tree(repo,[(b'same.ts','100644',b),(b'new.ts','100644',b),(b'mode.ts','100755',b),(b'empty.bin','100644',empty),(b'binary.bin','100644',binary),(b'link','120000',put(repo,'blob',b'../../escape')),(b'sub','160000',c0)]);c1=commit(repo,t1,[c0]);changes=diff(collect(repo,t0),collect(repo,t1));assert len(changes)==8
rows=[]
def record(name,ok,detail=None):assert ok,name;rows.append({'name':name,'pass':True,'detail':detail})
record('raw_tree_roundtrip',collect(repo,t1)[b'binary.bin'][1]==binary)
record('rename_is_delete_add',next(x for x in changes if bytes.fromhex(x['pathHex'])==b'old.ts')['flags']==['DELETE'] and next(x for x in changes if bytes.fromhex(x['pathHex'])==b'new.ts')['flags']==['ADD'])
record('mode_and_content_both_visible',next(x for x in changes if bytes.fromhex(x['pathHex'])==b'mode.ts')['flags']==['MODIFY','MODE_CHANGE'])
# Replace ref: raw object reading must not substitute the head.
(repo/'refs/replace').mkdir(parents=True);(repo/'refs/replace'/c1).write_text(c0+'\n')
normal=git(repo,'cat-file','commit',c1,clean=False);safe=git(repo,'cat-file','commit',c1)
record('replace_ref_changes_default_read',normal!=safe and b'tree '+t0.encode() in normal)
record('no_replace_reads_original',b'tree '+t1.encode() in safe)
(repo/'refs/replace'/c1).unlink()
# Alternate is honoured even with clean env.
alt=init('alternate.git');foreign=put(alt,'blob',b'foreign alternate');(repo/'objects/info/alternates').write_text(str((alt/'objects').resolve())+'\n');record('alternates_survive_env_cleaning',git(repo,'cat-file','blob',foreign)==b'foreign alternate');(repo/'objects/info/alternates').unlink()
# Graft affects revision traversal, though raw commit retains parent facts.
(repo/'info').mkdir(exist_ok=True);(repo/'info/grafts').write_text(c1+'\n');grafted=git(repo,'rev-list','--parents','-1',c1).strip().split();record('graft_must_be_rejected',len(grafted)==1 and b'parent '+c0.encode() in git(repo,'cat-file','commit',c1));(repo/'info/grafts').unlink()
(repo/'shallow').write_text(c1+'\n');record('shallow_must_be_rejected',git(repo,'rev-parse','--is-shallow-repository').strip()==b'true');(repo/'shallow').unlink()
merge=commit(repo,t1,[c0,c1]);parents=[l[7:] for l in git(repo,'cat-file','commit',merge).split(b'\n\n',1)[0].splitlines() if l.startswith(b'parent ')];record('second_parent_is_real_raw_fact',len(parents)==2)
baddup=put(repo,'tree',b'100644 x\0'+bytes.fromhex(a)+b'100644 x\0'+bytes.fromhex(b))
try:collect(repo,baddup);dup=False
except ValueError:dup=True
record('duplicate_raw_tree_name_reject',dup)
paths=[b'src/a.ts',b'.github/workflows/a.yml',b'a/b',b'a\xff',b'a\n.ts',b'a\t.ts',b'a\x7f.ts',b'/a',b'a//b',b'a/../b',b'./a',b'.git/config',b'.GiT/config',b'git~1/config',b'CON.ts',b'aux',b'LPT9.log',b'COM1',b'x.',b'a\\b',b'a:b',b'-option',b'%2e%2e', 'é.ts'.encode(),'e\u0301.ts'.encode(),b'a'*101,b'/'.join([b'a']*17)]
pathrows=[{'hex':p.hex(),'reason':validate_path(p)} for p in paths];assert sum(r['reason'] is None for r in pathrows)==3
for group,expected in [([b'A.ts',b'a.ts'],'GIT_PATH_COLLISION'),([b'Dir/a',b'dir/b'],'GIT_PATH_COLLISION'),([b'a',b'a/b'],'GIT_PATH_COLLISION'),([b'A',b'a/b'],'GIT_PATH_COLLISION'),([b'x/a',b'x/b'],None)]:record('pathset_'+repr(group),validate_set(group)==expected,expected)
# Actual dirfd-based blob materialization probes; private root, no untrusted writer.
out=W/'materialize';shutil.rmtree(out,ignore_errors=True);out.mkdir(exist_ok=True);(out/'safe').mkdir(exist_ok=True);(out/'linkdir').symlink_to(out/'safe',target_is_directory=True)
flags=os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC
rootfd=os.open(out,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
try:
 try:os.open('linkdir',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=rootfd);followed=True
 except OSError:followed=False
 record('parent_symlink_no_follow',not followed)
 fd=os.open('binary',flags,0o600,dir_fd=rootfd);os.write(fd,b'\x00\xff');os.close(fd)
 record('binary_exact',(out/'binary').read_bytes()==b'\x00\xff')
 try:os.open('binary',flags,0o600,dir_fd=rootfd);ex=False
 except FileExistsError:ex=True
 record('exclusive_creation',ex)
finally:os.close(rootfd)
# Property differential against an intentionally simple union oracle, seeded.
rng=random.Random(31042026);assertions=0
for i in range(5000):
 names=[f'f{x:03}.ts'.encode() for x in range(40)];aa={p:(rng.choice(['100644','100755']),rng.choice([a,b,empty])) for p in names if rng.random()<.4};bb={p:(rng.choice(['100644','100755']),rng.choice([a,b,empty])) for p in names if rng.random()<.4};dd=diff(aa,bb)
 expected=[]
 for p in names:
  x=aa.get(p);y=bb.get(p)
  if x==y:continue
  f=['ADD'] if x is None else ['DELETE'] if y is None else (["MODIFY"] if x[1]!=y[1] else [])+(["MODE_CHANGE"] if x[0]!=y[0] else [])
  expected.append((p.hex(),f))
 assert [(x['pathHex'],x['flags']) for x in dd]==expected;assert diff(aa,aa)==[];assert {x['pathHex'] for x in diff(bb,aa)}=={x['pathHex'] for x in dd};assertions+=3
# Tree map scale: real packed tree collection and diff; fixture setup excluded.
perf=[]
for n in [100,1000,10000]:
 es=[(f'f{i:05}.ts'.encode(),'100644',a) for i in range(n)];ta=tree(repo,es);eb=list(es);eb[n//2]=(eb[n//2][0],'100644',b);tb=tree(repo,eb)
 times=[]
 for _ in range(5):
  t=time.perf_counter();ma=collect(repo,ta);mb=collect(repo,tb);d=diff(ma,mb);pathok=validate_set(list(mb));times.append((time.perf_counter()-t)*1000);assert len(d)==1 and pathok is None
 perf.append({'files':n,'medianMs':statistics.median(times),'samplesMs':times,'changed':1})
# Exact 1k/10k/100k real objects using fast-import packed blob records.
objperf=[]
for n in [1000,10000,100000]:
 rr=init('objects-'+str(n)+'.git');data=b''.join(b'blob\ndata '+str(len(v)).encode()+b'\n'+v+b'\n' for i in range(n) for v in [f'object-{i:06}\n'.encode()]);git(rr,'fast-import','--quiet',data=data)
 vals=[]
 for _ in range(3):
  start=time.perf_counter();raw=git(rr,'cat-file','--batch-all-objects','--unordered','--batch-check=%(objectname) %(objecttype) %(objectsize)');lines=raw.splitlines();total=sum(int(x.rsplit(b' ',1)[1]) for x in lines);assert len(lines)==n;vals.append((time.perf_counter()-start)*1000)
 start=time.perf_counter();git(rr,'fsck','--strict','--no-reflogs','--no-dangling');fsckms=(time.perf_counter()-start)*1000
 objperf.append({'objects':n,'enumerateMedianMs':statistics.median(vals),'samplesMs':vals,'fsckMs':fsckms,'uncompressedBytes':total,'rawBytes':len(raw)})
 # One batch cat-file content stream is contrasted with per-object subprocesses at 1k only.
 if n==1000:
  ids=[x.split(b' ')[0] for x in lines];start=time.perf_counter()
  for oid in ids:git(rr,'cat-file','blob',oid.decode())
  serial=(time.perf_counter()-start)*1000;start=time.perf_counter();git(rr,'cat-file','--batch',data=b'\n'.join(ids)+b'\n');batch=(time.perf_counter()-start)*1000
  objperf[-1]['perObjectSpawnMs']=serial;objperf[-1]['singleBatchMs']=batch
out={'experiments':rows,'pathCases':pathrows,'properties':{'iterations':5000,'assertions':assertions},'treePerformance':perf,'objectPerformance':objperf,'changes':changes,'limits':'prototype timings are warm local observations; network/container/bootstrap not benchmarked'}
(R/'git-lab.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:out[k] for k in ['properties','treePerformance','objectPerformance']},indent=2))
