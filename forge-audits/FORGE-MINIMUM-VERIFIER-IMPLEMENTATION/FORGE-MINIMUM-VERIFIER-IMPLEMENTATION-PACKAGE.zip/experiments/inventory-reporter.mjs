// Experimental Vitest 5.0.3 reporter. Not a production verifier.
import fs from 'node:fs';import path from 'node:path';
export default class InventoryReporter {
 onTestRunEnd(modules,unhandled,reason){
  const rows=[],files=[],hooks=[];
  for(const mod of modules){
   const file=path.relative(process.env.LAB_ROOT,mod.moduleId).split(path.sep).join('/');const counts=new Map();
   files.push({file,project:mod.project.name,state:mod.state(),errors:mod.errors().map(e=>({name:e.name,message:e.message}))});
   const visit=(node,ancestors)=>{for(const t of node.children){if(t.type==='suite'){hooks.push(...t.errors().map(e=>({file,name:e.name,message:e.message})));visit(t,[...ancestors,t.name]);}else{
    const r=t.result(),base=[file,t.project.name,ancestors,t.name],k=JSON.stringify(base),occurrence=counts.get(k)||0;counts.set(k,occurrence+1);
    const status=t.options.mode==='todo'?'todo':r.state;
    rows.push({file,project:t.project.name,ancestors,title:t.name,occurrence,status,mode:t.options.mode,errors:(r.errors||[]).map(e=>({name:e.name,message:e.message}))});
   }}};visit(mod,[]);
  }
  fs.writeFileSync(process.env.LAB_REPORT,JSON.stringify({reason,files,rows,hooks,unhandled:unhandled.map(e=>({name:e.name,message:e.message}))},null,2));
 }
}
