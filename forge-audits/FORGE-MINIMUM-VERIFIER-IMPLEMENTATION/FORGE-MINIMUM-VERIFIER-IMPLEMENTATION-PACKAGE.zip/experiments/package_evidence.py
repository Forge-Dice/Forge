from pathlib import Path
import json,hashlib,zipfile,platform,subprocess
from html.parser import HTMLParser
B=Path(__file__).resolve().parents[1];D=B/'deliverables';R=B/'results'
env={'pythonObserved':platform.python_version(),'platformObserved':platform.platform(),'node':subprocess.check_output(['node','--version'],text=True).strip(),'npm':subprocess.check_output(['npm','--version'],text=True).strip(),'git':subprocess.check_output(['git','--version'],text=True).strip(),'isolation':'No Docker available in this lab. Harmless local fixtures only.'}
for name in ['typescript','vitest','zod']:
 env[name]=json.loads((B/'node_modules'/name/'package.json').read_text())['version']
(R/'environment.json').write_text(json.dumps(env,indent=2))
class H(HTMLParser):
 def __init__(self):super().__init__();self.ids=[];self.refs=[];self.section_count=0
 def handle_starttag(self,t,a):
  a=dict(a)
  if 'id' in a:self.ids.append(a['id'])
  if t=='a' and a.get('href','').startswith('#'):self.refs.append(a['href'][1:])
  if t=='section':self.section_count+=1
h=H();h.feed((D/'FORGE-MINIMUM-VERIFIER-IMPLEMENTATION-PACKAGE.html').read_text());assert h.section_count==19;assert len(h.ids)==len(set(h.ids));assert set(h.refs)<=set(h.ids)
assert len(json.loads((D/'adversarial-matrix.json').read_text()))==177
contracts=json.loads((R/'contract-parse.json').read_text());assert len(contracts)==3 and all(c['ok'] for c in contracts)
final=json.loads((R/'final-main-check.json').read_text());assert final['localSourceUnchanged']
validation={'numberedSections':18,'appendix':True,'internalLinksValid':True,'adversarialCases':177,'contractsValidated':3,'contractFormat':1,'normativeSectionsHash':contracts[0]['normativeSectionsHash'],'finalMainCheck':final,'deliverySha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in D.iterdir() if p.suffix in ['.html','.md','.txt','.json']}}
(R/'package-validation.json').write_text(json.dumps(validation,indent=2))
readme='''FORGE MINIMUM VERIFIER IMPLEMENTATION PACKAGE — READ-ONLY LAB

Start with deliverables/FORGE-MINIMUM-VERIFIER-IMPLEMENTATION-PACKAGE.html.
Three format-1 drafts, exact handoff and a 177-case matrix are in deliverables/.
Nothing in this archive is an installed or production-ready verifier.

Evidence classes and limits are in the HTML. Source commit:
3d7545d843883418348004e68717399a64da7a7d (Forge-Dice/Forge).
base-manifest.json hashes every read versioned file; no repository copy included.
The input Bootstrap report is identified by its hash, not duplicated here.

Reproduction (isolated scratch only):
1. Put an exact trusted archive of that commit in source/ next to experiments/.
2. Install its pinned package/lock with npm ci --ignore-scripts in disposable storage.
3. Make lab-root node_modules resolve to that installation. Do not upload or reuse
   it as production evidence; runtime-lab uses these exact pinned installed packages.
4. Run python3 experiments/git_lab.py, python3 experiments/runtime_lab.py,
   node experiments/core-probes.mjs, python3 experiments/policy_lab.py.
5. With the supplied deliverables and normative snapshot, run
   node experiments/validate_package.mjs. This calls the real unchanged parser.

The report-building script also requires the aggregate experiment results.
No GitHub settings, review, push, branch, PR or remote mutation is performed by
these probes. git-fixtures/ and runtime-fixtures/ are generated throwaway data.
Docker isolation and native GitHub checks have NOT been tested in this workspace.
Versioned source, dependency directories, Git object databases and API credentials
are intentionally not included. manifest-sha256.json lists the exact archive bytes.
'''
(B/'EVIDENCE-README.txt').write_text(readme)
files=[B/'base-manifest.json',B/'EVIDENCE-README.txt']+sorted((B/'experiments').glob('*.py'))+sorted((B/'experiments').glob('*.mjs'))+sorted(R.glob('*.json'))+sorted(p for p in D.iterdir() if p.suffix in ['.html','.md','.txt','.json'])
manifest={str(p.relative_to(B)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
archive=D/'FORGE-MINIMUM-VERIFIER-IMPLEMENTATION-PACKAGE.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for path in files:z.write(path,str(path.relative_to(B)))
 z.writestr('manifest-sha256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None;assert not any(x.startswith('source/') or '/node_modules/' in x for x in z.namelist())
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'files':len(files)+1,'versions':env,'validation':{'sections':18,'cases':177,'contracts':3}}))
