FORGE MINIMUM VERIFIER IMPLEMENTATION PACKAGE — READ-ONLY LAB

Start with deliverables/FORGE-MINIMUM-VERIFIER-IMPLEMENTATION-PACKAGE.html.
Three format-1 drafts, exact handoff and a 177-case matrix are in deliverables/.
Nothing in this archive is an installed or production-ready verifier.

Evidence classes and limits are in the HTML. Source commit:
3d7545d843883418348004e68717399a64da7a7d (Forge-Dice/Forge).
base-manifest.json hashes every read versioned file; no repository copy included.
The input Bootstrap report is identified by its hash, not duplicated here.

Reproduction (isolated scratch only):
1. Put an exact trusted archive of that commit in source/ next to experiments/.
2. Install its pinned package/lock with npm ci --ignore-scripts in disposable storage.
3. Make lab-root node_modules resolve to that installation. Do not upload or reuse
   it as production evidence; runtime-lab uses these exact pinned installed packages.
4. Run python3 experiments/git_lab.py, python3 experiments/runtime_lab.py,
   node experiments/core-probes.mjs, python3 experiments/policy_lab.py.
5. With the supplied deliverables and normative snapshot, run
   node experiments/validate_package.mjs. This calls the real unchanged parser.

The report-building script also requires the aggregate experiment results.
No GitHub settings, review, push, branch, PR or remote mutation is performed by
these probes. git-fixtures/ and runtime-fixtures/ are generated throwaway data.
Docker isolation and native GitHub checks have NOT been tested in this workspace.
Versioned source, dependency directories, Git object databases and API credentials
are intentionally not included. manifest-sha256.json lists the exact archive bytes.
