MYSTERY CASE AUTHORING STRESS LAB - REPRODUCTION

Scope: Forge-Dice/Forge main @ 3d7545d843883418348004e68717399a64da7a7d.
Read-only investigation. This is a disposable test instrument, not an authoring product.

Start with REPORT.html or the separately delivered PDF. All 21 requested sections,
five authoring templates and ten proposed golden cases are present.

FILES
source/ contains unchanged domain sources, domain tests, package metadata, and
selected baseline/design context from the pinned commit. It is a scoped extract,
not a full Git checkout. domain-integrity.json pins all seven domain blobs.
results/ contains full candidates, failures, projections, measurements and metadata.
experiments/ contains the scratch-only generator and focused probes.

RUN THE LAB
Use Node 24 or later for direct TypeScript imports (measured: 24.19.0).
From this extracted directory:

  npm ci --ignore-scripts --prefix source
  node experiments/stress-lab.mjs
  node experiments/focused-probes.mjs
  node experiments/recheck-overlap.mjs

No GitHub access or credentials are used by the experiments. npm installation
requires the dependencies in the unchanged lockfile to be available from a registry
or cache. node_modules is deliberately not included.

The first two commands replace their corresponding result JSON/log files if you
redirect output, so copy results/ first if preserving the delivered measurements.
The overlap series is retained as fixed inputs and rechecked without repair.

EXPECTED COUNTS
Main: 200 candidates, 24 CaseTruth parser rejects, 24 Semantic rejects,
24 Solution parser rejects, 128 passing pairs.
Mutations: 528; 120 Schema, 168 Semantic, 240 Solution.
NPC: 576; 312 pass, 264 NPC Parser rejects.
Actor matrix: 120 literal attempts; 50 accepted, 70 rejected or undetermined.
Canonicalization: 399 rows, including 384 permutation pairs.
Focused probes: 28, zero unexpected outcomes.
Additional overlap series: 128; 122 pass, 6 semantic contradictions retained.
Runtime measurements vary by machine and load.

BASELINE DOMAIN TESTS
  cd source
  npm test -- tests/case-truth.test.ts tests/case-semantics.test.ts tests/case-solution.test.ts tests/case-truth.identity.test.ts tests/case-solution.identity.test.ts tests/npc-knowledge.test.ts tests/npc-knowledge.projection.test.ts

Recorded original result: 7 test files, 452 tests passed. No Forge audit was run.

REPORT REBUILD (OPTIONAL)
  python3 experiments/build-report-data.py
  python3 experiments/render-report.py

The PDF renderer requires reportlab and DejaVu fonts at the documented Linux
font paths. It writes a PDF under ../output/pdf and REPORT.html here.
The report content builder uses existing result JSON; it does not rerun experiments.

INTERPRETATION
Failure percentages were constructed, not sampled from human/LLM authors.
The 128 baseline pairs are structurally varied test models, not complete playable
stories. Family labels do not create missing typed death/ownership/defect semantics.
No actual LLM generation, Verdict engine, CasePackage or Solvability engine was
implemented or claimed. Full limitations are in sections 1, 3 and 21.
