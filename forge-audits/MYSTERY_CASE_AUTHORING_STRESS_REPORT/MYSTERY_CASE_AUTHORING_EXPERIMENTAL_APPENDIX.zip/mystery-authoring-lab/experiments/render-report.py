import json,pathlib,html,re
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak,KeepTogether,Preformatted,CondPageBreak
LAB=pathlib.Path(__file__).resolve().parents[1];ROOT=LAB.parent;data=json.loads((LAB/'results/report-data.json').read_text());out=ROOT/'output/pdf/MYSTERY_CASE_AUTHORING_STRESS_REPORT.pdf';out.parent.mkdir(parents=True,exist_ok=True)
font='/usr/share/fonts/truetype/dejavu/';pdfmetrics.registerFont(TTFont('DV',font+'DejaVuSans.ttf'));pdfmetrics.registerFont(TTFont('DV-Bold',font+'DejaVuSans-Bold.ttf'));pdfmetrics.registerFont(TTFont('DVM',font+'DejaVuSansMono.ttf'));pdfmetrics.registerFontFamily('DV',normal='DV',bold='DV-Bold',italic='DV',boldItalic='DV-Bold')
navy=colors.HexColor('#122d43');teal=colors.HexColor('#116b70');gray=colors.HexColor('#536170');gold=colors.HexColor('#af7c20');light=colors.HexColor('#eaf0f4')
st=getSampleStyleSheet();st.add(ParagraphStyle(name='BodyX',fontName='DV',fontSize=9.2,leading=14,spaceAfter=8,textColor=navy,allowWidows=0,allowOrphans=0));st.add(ParagraphStyle(name='H1X',fontName='DV-Bold',fontSize=18,leading=23,textColor=navy,spaceAfter=15,keepWithNext=True));st.add(ParagraphStyle(name='H2X',fontName='DV-Bold',fontSize=11.2,leading=15,textColor=teal,spaceBefore=12,spaceAfter=7,keepWithNext=True));st.add(ParagraphStyle(name='LabelX',fontName='DV-Bold',fontSize=7.3,leading=11,textColor=teal,spaceBefore=2,spaceAfter=4,keepWithNext=True));st.add(ParagraphStyle(name='CellX',fontName='DV',fontSize=7.9,leading=11.2,spaceAfter=0,textColor=navy));st.add(ParagraphStyle(name='CellHeadX',fontName='DV-Bold',fontSize=7.7,leading=10.5,textColor=colors.white));st.add(ParagraphStyle(name='CodeX',fontName='DVM',fontSize=7.7,leading=11,textColor=navy,backColor=light,borderPadding=7,spaceAfter=10));st.add(ParagraphStyle(name='CoverX',fontName='DV-Bold',fontSize=27,leading=34,textColor=navy,spaceAfter=18));st.add(ParagraphStyle(name='IntroX',fontName='DV',fontSize=12,leading=18,textColor=gray,spaceAfter=15))
def esc(s):return html.escape(str(s)).replace('\n','<br/>')
def para(text,style='BodyX'):return Paragraph(esc(text),st[style])
W,H=A4;margin=43;avail=W-2*margin
story=[Spacer(1,35),para('MYSTERY','LabelX'),para('CASE AUTHORING\nSTRESS REPORT','CoverX'),para(data['subtitle'],'IntroX'),para('READ-ONLY LAB · '+data['date'],'LabelX'),para('Forge-Dice/Forge · main @ 3d7545d84388','BodyX'),Spacer(1,14)]
for line in data['executive']:story.append(para(line))
story.extend([Spacer(1,15),para('Messgrundlage: 128 valide Basisfälle aus 16 Familien, ergänzt um feste Negativvarianten, Mutationen und fokussierte Grenzproben. Ergebnisse gelten für den fixierten Commit und den dokumentierten Versuchsaufbau.','BodyX'),PageBreak(),para('Inhalt','H1X')])
for section in data['sections']:story.append(para(str(section['number'])+'. '+section['title'],'BodyX'))
story.extend([Spacer(1,10),para('Belegarten: VERIFIED FROM CODE · EXPERIMENTALLY VERIFIED · INFERRED · PRODUCT JUDGMENT · UNKNOWN','LabelX')])
story.append(PageBreak())
for section in data['sections']:
 story.extend([CondPageBreak(150),Spacer(1,15),para(str(section['number'])+'. '+section['title'],'H1X')])
 for b in section['blocks']:
  if b.get('label') and b['type']!='table':story.append(para(b['label'],'LabelX'))
  if b['type']=='p':story.append(para(b['text']))
  elif b['type']=='sub':story.append(para(b['text'],'H2X'))
  elif b['type']=='list':
   for x in b['items']:story.append(para('• '+x))
  elif b['type']=='code':story.append(Preformatted(b['text'],st['CodeX']))
  elif b['type']=='table':
   cols=len(b['headers']);rat=b.get('widths') or [1/cols]*cols;total=sum(rat);widths=[avail*x/total for x in rat]
   hr=1 if b.get('label') else 0
   rows=([[para(b['label'],'LabelX')]+['']*(cols-1)] if hr else [])+[[para(x,'CellHeadX') for x in b['headers']]]+[[para(x,'CellX') for x in row] for row in b['rows']]
   t=Table(rows,colWidths=widths,repeatRows=hr+1,hAlign='LEFT');t.setStyle(TableStyle([('BACKGROUND',(0,hr),(-1,hr),navy),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),('ROWBACKGROUNDS',(0,hr+1),(-1,-1),[colors.white,colors.HexColor('#f1f5f7')]),('LINEBELOW',(0,hr),(-1,hr),.6,navy),('LINEBELOW',(0,hr+1),(-1,-1),.3,colors.HexColor('#d9e1e7'))]+([('SPAN',(0,0),(-1,0)),('LEFTPADDING',(0,0),(-1,0),0),('TOPPADDING',(0,0),(-1,0),0)] if hr else [])));story.extend([t,Spacer(1,10)])
def footer(c,doc):
 c.saveState();c.setStrokeColor(colors.HexColor('#ced8df'));c.line(margin,36,W-margin,36);c.setFont('DV',7);c.setFillColor(gray);c.drawString(margin,23,'MYSTERY · CASE AUTHORING STRESS LAB · 3d7545d84388');c.drawRightString(W-margin,23,str(doc.page));c.restoreState()
doc=SimpleDocTemplate(str(out),pagesize=A4,leftMargin=margin,rightMargin=margin,topMargin=43,bottomMargin=49,title=data['title'],author='Mystery Authoring Stress Lab');doc.build(story,onFirstPage=footer,onLaterPages=footer)
# Accessible standalone HTML counterpart, including linked primary code sources.
parts=['<!doctype html><html lang="de"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+data['title']+'</title><style>body{font:16px/1.6 system-ui,sans-serif;color:#122d43;max-width:1120px;margin:40px auto;padding:0 24px}h1{font-size:40px;line-height:1.2}h2{margin-top:64px;border-top:3px solid #116b70;padding-top:16px}h3{color:#116b70}table{border-collapse:collapse;width:100%;font-size:14px;margin:16px 0 28px}th,td{text-align:left;vertical-align:top;padding:12px;border-bottom:1px solid #d9e1e7}th{background:#122d43;color:white}tr:nth-child(even){background:#f1f5f7}.label{font-size:11px;font-weight:800;letter-spacing:.07em;color:#116b70;margin-bottom:2px}pre{background:#eaf0f4;padding:20px;overflow:auto}nav{columns:2}a{color:#116b70}header{background:#f1f5f7;padding:28px;border-left:5px solid #116b70} .table-wrap{overflow:auto}@media(max-width:700px){body{padding:0 14px}nav{columns:1}table{min-width:640px}h1{font-size:30px}}@media print{h2{break-before:page}tr{break-inside:avoid}thead{display:table-header-group}}</style><header><p class="label">READ-ONLY LAB · '+esc(data['date'])+'</p><h1>'+esc(data['title'])+'</h1><p>'+esc(data['subtitle'])+'</p><p>Forge-Dice/Forge · main @ '+data['commit']+'</p>']
for s in data['executive']:parts.append('<p>'+esc(s)+'</p>')
parts.append('</header><nav><ol>')
for s in data['sections']:parts.append(f'<li><a href="#s{s["number"]}">{esc(s["title"])}</a></li>')
parts.append('</ol></nav>')
for s in data['sections']:
 parts.append(f'<section id="s{s["number"]}"><h2>{s["number"]}. {esc(s["title"])}</h2>')
 for b in s['blocks']:
  if b.get('label'):parts.append('<p class="label">'+b['label']+'</p>')
  if b['type']=='p':parts.append('<p>'+esc(b['text'])+'</p>')
  elif b['type']=='sub':parts.append('<h3>'+esc(b['text'])+'</h3>')
  elif b['type']=='code':parts.append('<pre>'+html.escape(b['text'])+'</pre>')
  elif b['type']=='list':parts.append('<ul>'+''.join('<li>'+esc(x)+'</li>' for x in b['items'])+'</ul>')
  elif b['type']=='table':parts.append('<div class="table-wrap"><table><thead><tr>'+''.join('<th>'+esc(x)+'</th>' for x in b['headers'])+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+esc(x)+'</td>' for x in r)+'</tr>' for r in b['rows'])+'</tbody></table></div>')
 parts.append('</section>')
parts.append('<h2>Primärquellen am geprüften Commit</h2><ul>')
for ref,path,lines in data['sourceRefs']:parts.append('<li><a href="https://github.com/Forge-Dice/Forge/blob/'+data['commit']+'/'+path+'">'+ref+': '+path+'</a> - '+esc(lines)+'</li>')
parts.append('</ul></html>');(LAB/'REPORT.html').write_text('\n'.join(parts));print(out)
