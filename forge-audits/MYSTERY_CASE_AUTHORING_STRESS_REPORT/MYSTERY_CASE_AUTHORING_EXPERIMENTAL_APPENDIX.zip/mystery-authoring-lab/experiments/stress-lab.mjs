import fs from 'node:fs';
import os from 'node:os';
import {performance} from 'node:perf_hooks';
import {createHash} from 'node:crypto';
import {parseCaseTruth} from '../source/src/domain/case-truth.ts';
import {validateCaseSemantics} from '../source/src/domain/case-semantics.ts';
import {hashCaseTruth,serializeCaseTruth} from '../source/src/domain/case-truth.identity.ts';
import {parseCaseSolution} from '../source/src/domain/case-solution.ts';
import {hashCaseSolution,serializeCaseSolution} from '../source/src/domain/case-solution.identity.ts';
import {parseNpcKnowledge} from '../source/src/domain/npc-knowledge.ts';
import {projectNpcKnowledge} from '../source/src/domain/npc-knowledge.projection.ts';
const out=new URL('../results/',import.meta.url); fs.mkdirSync(out,{recursive:true});
const clone=x=>structuredClone(x), save=(n,x)=>fs.writeFileSync(new URL(n,out),JSON.stringify(x,null,2));
const issues=e=>e.issues??[{message:String(e)}];
function rng(seed){let s=Math.imul(seed^0x9e3779b9,2246822507)>>>0;return ()=>{s=(Math.imul(s,1664525)+1013904223)>>>0;return s/2**32;};}
const families=['murder','sabotage','theft','missing_person','staged_disappearance','accident','two_actors','three_actors','planner_actor','facilitator_actor','false_alibi','supernatural','technical_failure','multi_cause','partial_responsibility','multi_role'];
function makeCase(seed,opts={}){
 const r=rng(seed),n=(a,b)=>a+Math.floor(r()*(b-a+1)),pick=a=>a[n(0,a.length-1)];
 const family=opts.family??families[seed%families.length],P=opts.persons??(3+seed%6),L=opts.locations??n(2,6),E=opts.events??n(3,12),I=opts.items??n(1,5);
 const t={schemaVersion:1,caseId:`case:lab-${seed}`,revision:1,title:`LAB ${family} ${seed}`,timeline:{unit:'second',originLabel:'LAB start'},persons:Array.from({length:P},(_,i)=>({id:`person:p${i}`,name:`NAME_MARKER_${seed}_${i}`})),locations:Array.from({length:L},(_,i)=>({id:`location:l${i}`,name:`LOCATION_MARKER_${seed}_${i}`})),items:Array.from({length:I},(_,i)=>({id:`item:i${i}`,name:`ITEM_MARKER_${seed}_${i}`})),relationships:[],events:[],motives:[],propositions:[],evidence:[],secrets:[],redHerrings:[]};
 const pid=i=>t.persons[i%P].id,lid=i=>t.locations[i%L].id,iid=i=>t.items[i%I].id;
 for(let j=0;j<E;j++){
  let ps=[pid(j)],its=[iid(j)]; if(j>1&&r()<.45)ps=[...new Set([pid(j),pid(j+1)])];if(opts.shared)ps=t.persons.map(p=>p.id);
  let causes=j===1?['event:e0']:j>1?(seed%4===0?[]:seed%4===1?[`event:e${j-1}`]:seed%4===2?['event:e0']:[...new Set([`event:e${j-1}`,`event:e${n(0,j-2)}`])]):[];
  if(opts.graph==='dense')causes=Array.from({length:j},(_,k)=>`event:e${k}`); if(opts.graph==='chain')causes=j?[`event:e${j-1}`]:[];
  t.events.push({id:`event:e${j}`,description:`DESCRIPTION_MARKER_${family}_${seed}_${j}`,time:(j+seed)%2?{kind:'instant',at:10+j*20}:{kind:'interval',start:10+j*20,end:15+j*20},locationId:lid(j),participantIds:ps,itemIds:its,causedByEventIds:causes});
 }
 for(let j=0;j<Math.min(P,4);j++)t.relationships.push({id:`relationship:r${j}`,fromPersonId:pid(j),toPersonId:pid(j+1),kind:pick(['debt','family','colleague']),time:{kind:'interval',start:0,end:E*20+30}});
 const add=(claim,truth)=>{let id=`proposition:q${t.propositions.length}`;t.propositions.push({id,claim,truth});return id;};
 for(let j=0;j<E;j++){
  const e=t.events[j],at=e.time.at??e.time.start;
  add({kind:'eventHasParticipant',eventId:e.id,personId:e.participantIds[0]},true);
  const absent=t.persons.find(p=>!e.participantIds.includes(p.id));if(absent)add({kind:'eventHasParticipant',eventId:e.id,personId:absent.id},false);
  add({kind:'eventHasItem',eventId:e.id,itemId:e.itemIds[0]},true);
  if(j%2===0){add({kind:'personAt',personId:e.participantIds[0],locationId:e.locationId,at},true);add({kind:'personAt',personId:e.participantIds[0],locationId:lid(j+1),at},false);}
 }
 for(let j=0;j<Math.min(6,t.propositions.length);j++)t.evidence.push({id:`evidence:v${j}`,description:`EVIDENCE_MARKER_${seed}_${j}`,source:pick([{kind:'person',id:pid(j)},{kind:'item',id:iid(j)},{kind:'location',id:lid(j)},{kind:'event',id:t.events[j%E].id}]),links:[{propositionId:t.propositions[j].id,direction:j%3?'supports':'refutes'}]});
 t.secrets=[{id:'secret:s0',propositionIds:[t.propositions[0].id,t.propositions[2].id]}];
 const falseProp=t.propositions.find(p=>!p.truth);if(falseProp)t.redHerrings=[{id:'red-herring:r0',evidenceIds:[t.evidence[1].id],misleadingPropositionId:falseProp.id}];
 t.motives=[{id:'motive:m0',personId:pid(0),eventIds:[t.events.at(-1).id],description:`MOTIVE_MARKER_${seed}`}];
 for(let j=1;j<=seed%3;j++)t.motives.push({id:`motive:m${j}`,personId:pid(j),eventIds:[t.events[n(0,E-1)].id],description:`MOTIVE_EXTRA_${seed}_${j}`});
 for(let j=1;j<=seed%3;j++)t.secrets.push({id:`secret:s${j}`,propositionIds:[t.propositions[n(0,t.propositions.length-1)].id]});
 for(let j=1;j<=seed%3;j++)t.redHerrings.push({id:`red-herring:r${j}`,evidenceIds:[t.evidence[j%t.evidence.length].id],misleadingPropositionId:pick(t.propositions.filter(p=>!p.truth)).id});
 for(let j=0;j<t.evidence.length;j++)if((j+seed)%2)t.evidence[j].links.push({propositionId:t.propositions[(j+7)%t.propositions.length].id,direction:'supports'});
 const no=['accident','technical_failure','supernatural'].includes(family),count=no?0:family==='three_actors'?3:['two_actors','planner_actor','facilitator_actor'].includes(family)?2:1;
 const assignments=Array.from({length:count},(_,i)=>({personId:pid(i),roles:family==='multi_role'?['planner','direct_actor']:family==='planner_actor'&&i===0?['planner']:family==='facilitator_actor'&&i===0?['facilitator']:['direct_actor']}));
 const eventId=t.events.at(-1).id,completeness=family==='partial_responsibility'?'partial':'complete';
 const resolution={eventId,targets:[{kind:'person',id:pid(P-1)},{kind:'item',id:iid(0)}],responsibility:{completeness,assignments},intent:no?(family==='accident'?'unintended':'not_applicable'):'intended',mechanism:family==='supernatural'?'supernatural':family==='multi_cause'?'mixed':'ordinary',causesComplete:seed%3!==0};
 const s={schemaVersion:1,caseId:t.caseId,revision:1,truthHash:hashCaseTruth(parseCaseTruth(t)),resolutions:[resolution],conclusions:[],requiredConclusions:[]};
 function conclusion(claim,value,required=true){const id=`conclusion:c${s.conclusions.length}`;s.conclusions.push({id,claim});if(required)s.requiredConclusions.push({conclusionId:id,value});}
 for(const a of assignments){conclusion({kind:'personResponsibleForEvent',personId:a.personId,eventId},true);for(const role of a.roles)conclusion({kind:'personRoleForEvent',personId:a.personId,eventId,role},true);}
 conclusion({kind:'noPersonResponsibleForEvent',eventId},no,completeness==='complete'||count>0);
 const outsider=t.persons.find(p=>!assignments.some(a=>a.personId===p.id));if(outsider)conclusion({kind:'personResponsibleForEvent',personId:outsider.id,eventId},false,completeness==='complete');
 conclusion({kind:'eventIntent',eventId,value:resolution.intent},true);conclusion({kind:'eventMechanism',eventId,value:resolution.mechanism},true);
 for(const causeEventId of t.events.at(-1).causedByEventIds)conclusion({kind:'eventCausedEvent',eventId,causeEventId},true);
 return {seed,family,truth:t,solution:s};
}
function funnel(c){const row={seed:c.seed,family:c.family,scenario:c.scenario??'baseline'};let t,s;try{t=parseCaseTruth(c.truth);row.truth='PASS';}catch(e){return {...row,stage:'Schema',issues:issues(e)};}
 const sem=validateCaseSemantics(t);row.findings=sem.findings;if(sem.findings.length)return {...row,stage:'Semantic Validator'};
 try{s=parseCaseSolution(c.solution,t);return {...row,stage:'PASS',truthHash:hashCaseTruth(t),solutionHash:hashCaseSolution(s)};}catch(e){return {...row,stage:'Solution Parser',issues:issues(e)};}}
const bases=Array.from({length:128},(_,i)=>makeCase(1000+i));
const candidates=clone(bases);
const faults=[
 ['missing_reference',c=>c.truth.events[0].participantIds.push('person:absent')],
 ['duplicate_id',c=>c.truth.persons.push(clone(c.truth.persons[0]))],
 ['wrong_id_kind',c=>c.truth.events[0].locationId='person:p0'],
 ['invalid_interval',c=>c.truth.events[0].time={kind:'interval',start:5,end:5}],
 ['claim_mismatch',c=>c.truth.propositions[0].truth=false],
 ['reversed_cause',c=>c.truth.events[0].causedByEventIds=['event:e1']],
 ['person_two_places',c=>c.truth.events.push({...clone(c.truth.events[0]),id:'event:overlap',locationId:c.truth.locations[1].id,itemIds:[]})],
 ['item_two_places',c=>c.truth.events.push({...clone(c.truth.events[0]),id:'event:overlap',locationId:c.truth.locations[1].id,participantIds:[]})],
 ['stale_truth_hash',c=>c.solution.truthHash='0'.repeat(64)],
 ['impossible_required',c=>c.solution.requiredConclusions[0].value=!c.solution.requiredConclusions[0].value],
 ['duplicate_conclusion_claim',c=>c.solution.conclusions.push({...clone(c.solution.conclusions[0]),id:'conclusion:duplicate'})],
 ['unresolved_required',c=>c.solution.requiredConclusions[0].conclusionId='conclusion:missing']
];
for(let i=0;i<72;i++){const c=clone(bases[i]);const [scenario,fn]=faults[i%faults.length];c.scenario=scenario;fn(c);candidates.push(c);}
const funnelRows=candidates.map(funnel);save('candidates.json',candidates);save('funnel.json',funnelRows);
if(bases.some(c=>funnel(c).stage!=='PASS'))throw Error('Unexpected baseline failure; preserve and investigate');
console.log('BASELINES',bases.length,'FUNNEL',funnelRows.reduce((a,x)=>(a[x.stage]=(a[x.stage]??0)+1,a),{}));
// Mutations are independent: each starts from an unchanged passing baseline.
const mutationBases=bases.filter(c=>c.solution.resolutions[0].responsibility.assignments.length>0&&c.solution.resolutions[0].responsibility.completeness==='complete').slice(0,24);
const truthMutations=[...faults.slice(0,8),
 ['contradictory_propositions',c=>c.truth.propositions.push({...clone(c.truth.propositions[0]),id:'proposition:opposite',truth:false})],
 ['item_claim_mismatch',c=>c.truth.propositions.find(p=>p.claim.kind==='eventHasItem').truth=false],
 ['presence_negated',c=>c.truth.propositions.find(p=>p.claim.kind==='personAt'&&p.truth).truth=false],
 ['self_cause',c=>c.truth.events[0].causedByEventIds=['event:e0']],
];
const solutionMutations=[...faults.slice(8),
 ['responsibility_removed',c=>c.solution.resolutions[0].responsibility.assignments=[]],
 ['roles_null_required',c=>c.solution.resolutions[0].responsibility.assignments[0].roles=null],
 ['complete_to_partial',c=>c.solution.resolutions[0].responsibility.completeness='partial'],
 ['intent_null_required',c=>c.solution.resolutions[0].intent=null],
 ['mechanism_null_required',c=>c.solution.resolutions[0].mechanism=null],
 ['unknown_responsible_person',c=>c.solution.resolutions[0].responsibility.assignments[0].personId='person:missing']
];
const mutations=[];
for(const b of mutationBases)for(const [name,fn] of [...truthMutations,...solutionMutations]){const c=clone(b);fn(c);c.scenario=name;mutations.push(funnel(c));}
save('mutations.json',mutations);console.log('MUTATIONS',mutations.length);
function npcBase(c,solution=true){const t=parseCaseTruth(c.truth),s=solution?parseCaseSolution(c.solution,t):null;return {schemaVersion:1,caseId:t.caseId,truthHash:hashCaseTruth(t),solutionHash:s?hashCaseSolution(s):null,npcId:t.persons.at(-1).id,revision:1,asOf:10000,awareness:[],attitudes:[]};}
function entry(subject,stance,provenance={kind:'prior_knowledge'},acquiredAt=0){return {subject,stance,acquiredAt,provenance};}
const npcRows=[],projections=[];
const npcVariants=[
 ['knowledge_true',(n,c)=>n.attitudes.push(entry({kind:'proposition',id:c.truth.propositions.find(p=>p.truth).id},{kind:'knowledge',value:true}))],
 ['knowledge_false',(n,c)=>n.attitudes.push(entry({kind:'proposition',id:c.truth.propositions.find(p=>!p.truth).id},{kind:'knowledge',value:false}))],
 ['false_belief',(n,c)=>n.attitudes.push(entry({kind:'proposition',id:c.truth.propositions.find(p=>!p.truth).id},{kind:'belief',value:true}))],
 ...[true,false,null].map(v=>[`uncertain_${v}`,(n,c)=>n.attitudes.push(entry({kind:'proposition',id:c.truth.propositions[0].id},{kind:'uncertain',leaning:v}))]),
 ['evidence_awareness',(n,c)=>n.awareness.push({subject:{kind:'evidence',id:c.truth.evidence[0].id},acquiredAt:2,provenance:{kind:'observed_evidence',evidenceId:c.truth.evidence[0].id}})],
 ['event_awareness',(n,c)=>n.awareness.push({subject:{kind:'event',id:c.truth.events[0].id},acquiredAt:0,provenance:{kind:'prior_knowledge'}})],
 ['witnessed_nonparticipant',(n,c)=>n.attitudes.push(entry({kind:'proposition',id:c.truth.propositions[0].id},{kind:'belief',value:true},{kind:'witnessed_event',eventId:c.truth.events[0].id},10))],
 ['told_by_person',(n,c)=>n.attitudes.push(entry({kind:'proposition',id:c.truth.propositions[0].id},{kind:'belief',value:true},{kind:'told_by_person',personId:c.truth.persons[1].id},4))],
 ['prior_knowledge_future_event',(n,c)=>n.attitudes.push(entry({kind:'proposition',id:c.truth.propositions[0].id},{kind:'knowledge',value:true}))],
 ['authored_inference',(n,c)=>n.attitudes.push(entry({kind:'conclusion',id:c.solution.conclusions[0].id},{kind:'belief',value:false},{kind:'author_modeled_inference'},100))],
 ['false_knowledge',(n,c)=>n.attitudes.push(entry({kind:'proposition',id:c.truth.propositions[0].id},{kind:'knowledge',value:false}))],
 ['stale_truth_hash',n=>n.truthHash='0'.repeat(64)],['stale_solution_hash',n=>n.solutionHash='0'.repeat(64)],
 ['conclusion_knowledge',(n,c)=>n.attitudes.push(entry({kind:'conclusion',id:c.solution.conclusions[0].id},{kind:'knowledge',value:true}))],
 ['witnessed_wrong_time',(n,c)=>n.attitudes.push(entry({kind:'proposition',id:c.truth.propositions[0].id},{kind:'belief',value:true},{kind:'witnessed_event',eventId:c.truth.events[0].id},9))],
 ['prior_nonzero',(n,c)=>n.attitudes.push(entry({kind:'proposition',id:c.truth.propositions[0].id},{kind:'belief',value:true},{kind:'prior_knowledge'},1))],
 ['acquisition_in_future',(n,c)=>n.attitudes.push(entry({kind:'proposition',id:c.truth.propositions[0].id},{kind:'belief',value:true},{kind:'author_modeled_inference'},10001))],
 ['duplicate_attitude',(n,c)=>{let e=entry({kind:'proposition',id:c.truth.propositions[0].id},{kind:'belief',value:true});n.attitudes.push(e,clone(e));}],
 ['unknown_provenance',(n,c)=>n.attitudes.push(entry({kind:'proposition',id:c.truth.propositions[0].id},{kind:'belief',value:true},{kind:'told_by_person',personId:'person:missing'}))],
 ['conflicting_beliefs',(n,c)=>{let props=c.truth.propositions.filter(p=>p.claim.kind==='personAt').slice(0,2);for(const p of props)n.attitudes.push(entry({kind:'proposition',id:p.id},{kind:'belief',value:true}));}],
 ['unknown_awareness',n=>n.awareness.push({subject:{kind:'event',id:'event:absent'},acquiredAt:0,provenance:{kind:'prior_knowledge'}})],
 ['duplicate_awareness',(n,c)=>{let e={subject:{kind:'event',id:c.truth.events[0].id},acquiredAt:0,provenance:{kind:'prior_knowledge'}};n.awareness.push(e,clone(e));}]
];
for(const c of bases.slice(0,24)){
 const t=parseCaseTruth(c.truth),s=parseCaseSolution(c.solution,t);
 for(const [variant,fn] of npcVariants){let n=npcBase(c);fn(n,c);try{const snapshot=parseNpcKnowledge(n,t,s),projection=projectNpcKnowledge(snapshot,t,s);npcRows.push({seed:c.seed,variant,stage:'PASS'});projections.push({seed:c.seed,variant,snapshot:n,projection});}catch(e){npcRows.push({seed:c.seed,variant,stage:'NPC Parser',issues:issues(e)});}}
}
save('npc-results.json',npcRows);save('npc-projections.json',projections);console.log('NPC',npcRows.length,'PASS',npcRows.filter(x=>x.stage==='PASS').length);
// False lead representations: intentionally not a semantic correctness oracle for evidence.
const redRows=[];
function redProbe(name,fn,solutionChange=false){let c=clone(bases[0]);fn(c);if(!solutionChange){try{c.solution.truthHash=hashCaseTruth(parseCaseTruth(c.truth));}catch{}}redRows.push({name,...funnel(c)});}
redProbe('false_objective_proposition',()=>{});
redProbe('true_bait_as_red_herring',c=>c.truth.redHerrings[0].misleadingPropositionId=c.truth.propositions[0].id);
redProbe('false_responsibility_forced_into_proposition',c=>c.truth.propositions[0].claim={kind:'personResponsibleForEvent',personId:'person:p0',eventId:'event:e0'});
redProbe('conclusion_reference_in_old_red_herring',c=>c.truth.redHerrings[0].misleadingPropositionId=c.solution.conclusions[0].id);
redProbe('false_alibi',c=>c.truth.redHerrings[0].misleadingPropositionId=c.truth.propositions.find(p=>p.claim.kind==='personAt'&&!p.truth).id);
redProbe('misleading_evidence_supports_false',c=>c.truth.evidence[0].links=[{propositionId:c.truth.propositions.find(p=>!p.truth).id,direction:'supports'}]);
redProbe('evidence_refutes_true',c=>c.truth.evidence[0].links=[{propositionId:c.truth.propositions[0].id,direction:'refutes'}]);
redProbe('red_herring_no_target_link',c=>{c.truth.redHerrings[0].evidenceIds=[c.truth.evidence[0].id];});
redProbe('true_bait_separate_false_conclusion',()=>{},true);
save('false-leads.json',redRows);
// Detailed multi-actor matrix: require a single tested literal each time.
const actorRows=[]; const actorConfigurations=[['one',[['direct_actor']],'complete'],['two',[['direct_actor'],['direct_actor']],'complete'],['three',[['direct_actor'],['direct_actor'],['direct_actor']],'complete'],['planner_actor',[['planner'],['direct_actor']],'complete'],['facilitator_actor',[['facilitator'],['direct_actor']],'complete'],['multi_role',[['planner','direct_actor']],'complete'],['none',[],'complete'],['partial_empty',[],'partial'],['partial_one',[['direct_actor']],'partial'],['null_role',[null],'complete']];
for(const [name,roles,completeness] of actorConfigurations){
 let c=makeCase(7777,{persons:5,family:'murder'}),t=parseCaseTruth(c.truth),s=c.solution,r=s.resolutions[0];r.responsibility={completeness,assignments:roles.map((roles,i)=>({personId:`person:p${i}`,roles}))};
 const claims=[{kind:'personResponsibleForEvent',personId:'person:p0',eventId:r.eventId},{kind:'personResponsibleForEvent',personId:'person:p4',eventId:r.eventId},{kind:'noPersonResponsibleForEvent',eventId:r.eventId},{kind:'personRoleForEvent',personId:'person:p0',eventId:r.eventId,role:'direct_actor'},{kind:'personRoleForEvent',personId:'person:p0',eventId:r.eventId,role:'planner'},{kind:'personRoleForEvent',personId:'person:p0',eventId:r.eventId,role:'facilitator'}];
 for(const claim of claims)for(const value of [true,false]){s.conclusions=[{id:'conclusion:probe',claim}];s.requiredConclusions=[{conclusionId:'conclusion:probe',value}];try{parseCaseSolution(s,t);actorRows.push({name,claim,value,result:'PASS'});}catch(e){actorRows.push({name,claim,value,result:'REJECT',issues:issues(e)});}}
}
save('multi-actor.json',actorRows);
// Leakage scan: key allowlist + exact canonical value sentinels, including specially named IDs.
const leakRows=[];
function leaks(c,projection){const str=JSON.stringify(projection);const needles=[c.truth.caseId,...['persons','locations','items','events','propositions','evidence','secrets','redHerrings','motives','relationships'].flatMap(k=>c.truth[k].flatMap(e=>[e.id,e.name,e.description].filter(Boolean))),...c.solution.conclusions.map(c=>c.id)];return needles.filter(n=>str.includes(n));}
for(const p of projections){const c=bases.find(c=>c.seed===p.seed);leakRows.push({seed:p.seed,variant:p.variant,canonicalValueLeaks:leaks(c,p.projection),forbiddenKeyLeaks:['truth','truthHash','solutionHash','resolutions','requiredConclusions','secrets','provenance','acquiredAt','name','description'].filter(k=>JSON.stringify(p.projection).includes(`"${k}":`))});}
let speaking=clone(bases[0]);const map={'person:p0':'person:killer','event:e0':'event:murder','evidence:v0':'evidence:murder-weapon','location:l0':'location:hidden-basement'};function replace(x){if(Array.isArray(x))return x.map(replace);if(x&&typeof x==='object')return Object.fromEntries(Object.entries(x).map(([k,v])=>[k,replace(v)]));return typeof x==='string'&&map[x]?map[x]:x;}speaking=replace(speaking);speaking.solution.truthHash=hashCaseTruth(parseCaseTruth(speaking.truth));
let st=parseCaseTruth(speaking.truth),ss=parseCaseSolution(speaking.solution,st),sn=npcBase(speaking);sn.attitudes=[entry({kind:'proposition',id:speaking.truth.propositions[0].id},{kind:'knowledge',value:true})];sn.awareness=[{subject:{kind:'evidence',id:'evidence:murder-weapon'},acquiredAt:0,provenance:{kind:'prior_knowledge'}}];let sp=projectNpcKnowledge(parseNpcKnowledge(sn,st,ss),st,ss);leakRows.push({variant:'speaking_ids',canonicalValueLeaks:leaks(speaking,sp),projection:sp});
let hidden=clone(speaking);hidden.truth.persons.push({id:'person:hidden','name':'HIDDEN_SENTINEL'});hidden.truth.locations.push({id:'location:secret-room',name:'HIDDEN_ROOM'});hidden.solution.truthHash=hashCaseTruth(parseCaseTruth(hidden.truth));let ht=parseCaseTruth(hidden.truth),hs=parseCaseSolution(hidden.solution,ht),hn=clone(sn);hn.truthHash=hashCaseTruth(ht);hn.solutionHash=hashCaseSolution(hs);let hp=projectNpcKnowledge(parseNpcKnowledge(hn,ht,hs),ht,hs);
leakRows.push({variant:'hidden_entity_noninterference',equal:JSON.stringify(sp)===JSON.stringify(hp)});
leakRows.push({variant:'projection_stale_truth',result:projectNpcKnowledge(parseNpcKnowledge(sn,st,ss),ht,hs)});
let changedS=clone(speaking.solution);changedS.revision++;let cs=parseCaseSolution(changedS,st);leakRows.push({variant:'projection_stale_solution',result:projectNpcKnowledge(parseNpcKnowledge(sn,st,ss),st,cs)});
save('leakage.json',leakRows);
// Canonical metamorphic tests. Reparse every input; never hash malformed raw objects.
function reorder(x,r,arrays=true){if(Array.isArray(x)){const a=x.map(v=>reorder(v,r,arrays));return arrays?a.map(v=>({v,r:r()})).sort((a,b)=>a.r-b.r).map(o=>o.v):a;}if(x&&typeof x==='object')return Object.fromEntries(Object.entries(x).sort(()=>r()-.5).map(([k,v])=>[k,reorder(v,r,arrays)]));return x;}
const canonical=[];
for(const c of bases){const t=parseCaseTruth(c.truth),s=parseCaseSolution(c.solution,t);for(let j=0;j<3;j++){const tt=parseCaseTruth(reorder(c.truth,rng(c.seed+j))),sss=parseCaseSolution(reorder(c.solution,rng(c.seed+j+200)),tt);canonical.push({name:'permutation',seed:c.seed,truthEqual:hashCaseTruth(t)===hashCaseTruth(tt),solutionEqual:hashCaseSolution(s)===hashCaseSolution(sss)});}}
function pairTruth(name,modifyA,modifyB){let a=clone(bases[0].truth),b=clone(a);modifyA(a);modifyB(b);try{const aa=parseCaseTruth(a),bb=parseCaseTruth(b);canonical.push({name,equal:hashCaseTruth(aa)===hashCaseTruth(bb),sameCanonical:serializeCaseTruth(aa)===serializeCaseTruth(bb)});}catch(e){canonical.push({name,error:issues(e)});}}
pairTruth('unicode_NFC_NFD',t=>t.title='Café',t=>t.title='Cafe\u0301');
pairTruth('escaped_vs_literal_text',t=>t.title='Line\nnext',t=>t.title='Line\\nnext');
pairTruth('whitespace',t=>t.title='Case',t=>t.title=' Case ');
pairTruth('emoji_and_escape_property_permutation',t=>t.title='𝄞 🕵️ " \\ \t \n',t=>t.title='𝄞 🕵️ " \\ \t \n');
pairTruth('duplicate_like_proposition',()=>{},t=>t.propositions.push({...clone(t.propositions[0]),id:'proposition:alias'}));
pairTruth('secret_grouping',t=>{t.secrets=[{id:'secret:s0',propositionIds:['proposition:q0','proposition:q1']},{id:'secret:s1',propositionIds:['proposition:q2']}];},t=>{t.secrets=[{id:'secret:s0',propositionIds:['proposition:q0']},{id:'secret:s1',propositionIds:['proposition:q1','proposition:q2']}];});
pairTruth('revision',()=>{},t=>t.revision++);
pairTruth('same_tick_instant_vs_unit_interval',t=>t.events[0].time={kind:'instant',at:10},t=>t.events[0].time={kind:'interval',start:10,end:11});
pairTruth('duplicate_entity_rejected',()=>{},t=>t.persons.push(clone(t.persons[0])));
for(const name of ['role_grouping','complete_partial','null_known_role','solution_revision']){let c=makeCase(8888,{persons:5,family:'planner_actor'}),t=parseCaseTruth(c.truth),a=clone(c.solution),b=clone(a);a.requiredConclusions=b.requiredConclusions=[a.requiredConclusions.find(l=>a.conclusions.find(c=>c.id===l.conclusionId).claim.kind==='eventIntent')];if(name==='role_grouping'){b.resolutions[0].responsibility.assignments[0].roles=['direct_actor'];b.resolutions[0].responsibility.assignments[1].roles=['planner'];}if(name==='complete_partial')b.resolutions[0].responsibility.completeness='partial';if(name==='null_known_role')b.resolutions[0].responsibility.assignments[0].roles=null;if(name==='solution_revision')b.revision++;canonical.push({name,equal:hashCaseSolution(parseCaseSolution(a,t))===hashCaseSolution(parseCaseSolution(b,t))});}
const collisionMap=new Map();let unexpected=0;for(const c of bases){const t=parseCaseTruth(c.truth),h=hashCaseTruth(t),ser=serializeCaseTruth(t);if(collisionMap.has(h)&&collisionMap.get(h)!==ser)unexpected++;collisionMap.set(h,ser);}canonical.push({name:'observed_digest_collisions',samples:128,unexpected});save('canonicalization.json',canonical);
// Feedback cascade and gates that can be skipped by a caller.
const probes=[];let bad=clone(bases[0]);bad.truth.events[0].causedByEventIds=['event:e1'];bad.solution.truthHash=hashCaseTruth(parseCaseTruth(bad.truth));const bt=parseCaseTruth(bad.truth);try{parseCaseSolution(bad.solution,bt);probes.push({name:'semantic_invalid_world_solution_direct',result:'PASS',findings:validateCaseSemantics(bt).findings});}catch(e){probes.push({name:'semantic_invalid_world_solution_direct',issues:issues(e)});}
let masked=clone(bases[0]);masked.solution.truthHash='0'.repeat(64);masked.solution.resolutions[0].eventId='event:absent';probes.push({name:'stale_hash_masks_references',result:funnel(masked)});masked.solution.truthHash=bases[0].solution.truthHash;probes.push({name:'after_rebind_references_visible',result:funnel(masked)});
let empty=clone(bases[0]);empty.truth.evidence=[];empty.truth.redHerrings=[];empty.solution.truthHash=hashCaseTruth(parseCaseTruth(empty.truth));probes.push({name:'zero_evidence_answer_key',result:funnel(empty)});
// Exact mutation fault localization using a simultaneous two-edge cycle with equal start times.
let cyc=makeCase(6666);cyc.truth.events[1].time=clone(cyc.truth.events[0].time);cyc.truth.events[1].locationId=cyc.truth.events[0].locationId;cyc.truth.propositions=[];cyc.truth.evidence=[];cyc.truth.secrets=[];cyc.truth.redHerrings=[];cyc.truth.events[0].causedByEventIds=['event:e1'];cyc.solution.truthHash=hashCaseTruth(parseCaseTruth(cyc.truth));probes.push({name:'cycle_equal_start_isolated',result:funnel(cyc)});
save('special-probes.json',probes);
// Runtime scaling: repeated medians, no throughput/SLA claim.
const benchmark=[];function measure(fn){for(let i=0;i<4;i++)fn();let times=[];for(let i=0;i<15;i++){const a=performance.now();fn();times.push(performance.now()-a);}times.sort((a,b)=>a-b);return {medianMs:times[7],p95Ms:times[14],minMs:times[0],samples:15};}
for(const [name,P,E] of [['small',5,10],['medium',10,30],['large',25,100],['stress',50,250]])for(const graph of ['chain','dense','shared']){
 const c=makeCase(9000+E,{persons:P,locations:6,events:E,items:5,family:'planner_actor',graph:graph==='shared'?'chain':graph,shared:graph==='shared'}),t=parseCaseTruth(c.truth),s=parseCaseSolution(c.solution,t),n=npcBase(c);n.attitudes=[entry({kind:'proposition',id:t.propositions[0].id},{kind:'knowledge',value:true})];const np=parseNpcKnowledge(n,t,s);
 benchmark.push({size:name,persons:P,events:E,graph,edges:t.events.reduce((s,e)=>s+e.causedByEventIds.length,0),propositions:t.propositions.length,bytes:JSON.stringify(c).length,findings:validateCaseSemantics(t).findings.length,parse:measure(()=>parseCaseTruth(c.truth)),semantic:measure(()=>validateCaseSemantics(t)),truthHash:measure(()=>hashCaseTruth(t)),solution:measure(()=>parseCaseSolution(c.solution,t)),npc:measure(()=>parseNpcKnowledge(n,t,s)),projection:measure(()=>projectNpcKnowledge(np,t,s))});
 if(name==='stress'&&graph==='dense'){const r=parseCaseTruth(reorder(c.truth,rng(3)));canonical.push({name:'large_collection_permutation',events:E,edges:t.events.reduce((s,e)=>s+e.causedByEventIds.length,0),equal:hashCaseTruth(t)===hashCaseTruth(r)});}
}
save('canonicalization.json',canonical);save('benchmark.json',benchmark);
const counts=(rows,k)=>rows.reduce((a,r)=>(a[r[k]]=(a[r[k]]??0)+1,a),{});
const summary={seedRange:[1000,1127],families:counts(bases,'family'),cases:candidates.length,baseline:128,uniqueTruthHashes:new Set(bases.map(c=>hashCaseTruth(parseCaseTruth(c.truth)))).size,funnel:counts(funnelRows,'stage'),findingOccurrences:counts(funnelRows.flatMap(x=>x.findings??[]),'code'),mutations:mutations.length,mutationStages:counts(mutations,'stage'),npcSnapshots:npcRows.length,npcStages:counts(npcRows,'stage'),projectionScans:projections.length,canonicalTests:canonical.length,environment:{node:process.version,platform:process.platform,arch:process.arch,cpu:os.cpus()[0]?.model},timestamp:new Date().toISOString()};save('summary.json',summary);console.log(JSON.stringify(summary,null,2));
