import fs from 'node:fs';
import assert from 'node:assert/strict';
import {parseCaseTruth} from '../source/src/domain/case-truth.ts';
import {validateCaseSemantics} from '../source/src/domain/case-semantics.ts';
import {parseCaseSolution} from '../source/src/domain/case-solution.ts';
const root=new URL('../results/',import.meta.url);
const cases=JSON.parse(fs.readFileSync(new URL('overlap-candidates.json',root)));
const expected=JSON.parse(fs.readFileSync(new URL('overlap-funnel.json',root)));
const rows=cases.map(c=>{const t=parseCaseTruth(c.truth),findings=validateCaseSemantics(t).findings;if(findings.length)return {seed:c.seed,stage:'Semantic Validator',findings};parseCaseSolution(c.solution,t);return {seed:c.seed,stage:'PASS',findings};});
for(let i=0;i<rows.length;i++){assert.equal(rows[i].stage,expected[i].stage);assert.deepEqual(rows[i].findings,expected[i].findings);}
console.log(JSON.stringify({cases:rows.length,pass:rows.filter(x=>x.stage==='PASS').length,semanticRejected:rows.filter(x=>x.stage!=='PASS').length,reproduced:true}));
