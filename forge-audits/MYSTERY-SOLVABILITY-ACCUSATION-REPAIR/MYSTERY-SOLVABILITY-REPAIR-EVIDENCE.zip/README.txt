MYSTERY SOLVABILITY & ACCUSATION REPAIR LAB — REPRODUCTION

All checker/gameplay behavior here is a SCRATCH HYPOTHESIS, not current-main
implementation. Canonical source authority is Forge-Dice/Forge at
3d7545d843883418348004e68717399a64da7a7d. No canonical files are included or modified.

Obtain that immutable source in a disposable directory and place its src/, tests/,
package.json, package-lock.json, tsconfig.json into scratch-repo/. Provide the pinned
dependencies normally in that disposable directory. The original laboratory reused
a pinned dependency layout; its copied .bin/tsc wrapper was broken, so actual typecheck
was run through node node_modules/typescript/bin/tsc --noEmit (exit 0).

Run in scratch-repo:
  node --experimental-strip-types domain_probe.ts
  node --experimental-strip-types extra_probe.ts
  node node_modules/typescript/bin/tsc --noEmit
  node node_modules/vitest/vitest.mjs run
Then in the lab root:
  python3 run_lab.py
  python3 make_contract.py
Then in scratch-repo:
  node --experimental-strip-types validate_contracts.ts

make_contract.py reads immutable Git blob IDs through a read-only sibling checkout
named ../forge-audit containing the pinned SHA. Supply that checkout to regenerate
the Draft. The already provided Draft can be validated without regenerating it.

Canonical ConclusionStatus is obtained ONLY through the current parser's required
literal validation. This test oracle is not recommended as production API.
The future production task requires the MYST-0002 public evaluator; it is NOT on
the audited main. The generated Draft is not approved, registered, or executable
until its real prerequisites/base have been pinned.

Evidence contains complete 36 fixtures, 768 generated configurations, 1106 shotgun
attempts, structured expectations/findings, mutation replacements and baseline results.
Two dedicated counterexamples show omitted-competitor risk and conditional soundness
under an arbitrary publicly authored axiom. No general world/human solver is claimed.
