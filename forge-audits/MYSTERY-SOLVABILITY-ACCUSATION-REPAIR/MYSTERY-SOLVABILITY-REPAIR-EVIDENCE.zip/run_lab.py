"""Deterministic experiments for a proposed authoring checker, not main code."""
from pathlib import Path
import copy, hashlib, itertools, json, random, collections, importlib.util
import checker
ROOT=Path(__file__).parent; E=ROOT/'evidence'
def clone(x):return copy.deepcopy(x)
def dump(name,value): (E/name).write_text(json.dumps(value,indent=2,sort_keys=True))
def lit(cid,v):return {'kind':'conclusion','id':cid,'value':v}

def publish(case):
    """Author fixture publication, before replay; checker never manufactures it."""
    nodes={n['id']:n for n in case['profile']['nodes']}
    for o in case['observations']:
        if o['mode']=='PUBLIC_RULE':o['rules']=[]
    for edge in case['profile']['edges']:
        license_node=nodes.get(edge['license']);target=nodes.get(edge['to'])
        if not license_node or not target or target['kind']!='literal':continue
        observation=next((o for o in case['observations'] if o['id']==license_node.get('observationId')),None)
        if observation and observation['mode']=='PUBLIC_RULE':
            d={'id':edge['id'],'allOf':sorted(set(edge['allOf'])-{edge['license']}),'yields':target['literal']}
            if d not in observation['rules']:observation['rules'].append(d)
    case['bindings']['releaseHash']=checker.manifest_digest(case)
    return case

def equip(raw):
    c=clone(raw); goals=list(c['required']);scope=list(goals)
    optional='conclusion:responsible-p2'
    if optional not in scope:scope.append(optional)
    if c['category'] in ['partial','ambiguous-allowed','ambiguous-forbidden']:
        scope=['conclusion:responsible-p0','conclusion:responsible-p1','conclusion:responsible-p2']
    o=[{'id':'o:rules','mode':'PUBLIC_RULE','source':'initial','publicText':'Closed answer domain and case-specific implication licenses.'},
       {'id':'o:signal','mode':'OBSERVED','source':'evidence:token','literal':{'kind':'proposition','id':'proposition:signal','value':True}},
       {'id':'o:alibi','mode':'OBSERVED','source':'evidence:alibi','literal':{'kind':'proposition','id':'proposition:other-away','value':True}},
       {'id':'o:red','mode':'OBSERVED','source':'evidence:red','literal':{'kind':'proposition','id':'proposition:other-earlier','value':True}},
       {'id':'o:belief','mode':'REPORTED_BY_NPC','source':'person:p3','literal':{'kind':'proposition','id':'proposition:other-scene','value':True}},
       {'id':'o:awareness','mode':'ENTITY_AWARENESS','source':'initial','entity':'person:p1'}]
    nodes=[{'id':x['id'],'kind':'observation','observationId':x['id']} for x in o]
    edges=[]
    for i,cid in enumerate(scope):
        v=c['statuses'][cid]
        if type(v) is bool:
            target='l:'+cid;nodes.append({'id':target,'kind':'literal','literal':lit(cid,v)})
            edges.append({'id':f'e:{i}','allOf':['o:rules','o:signal' if i==0 else 'o:alibi'], 'license':'o:rules','to':target})
    hypotheses=[{'id':f'h:{i}','values':dict(zip(scope,values))} for i,values in enumerate(itertools.product([False,True],repeat=len(scope)))]
    policy='may_remain_ambiguous' if c['category']=='ambiguous-allowed' or c['category']=='partial' and c['variant']==0 else 'must_disambiguate'
    c['observations']=o;c['game']={'initial':['o:rules','o:awareness'],'actions':[
        {'id':'search-token','requires':['o:awareness'],'grants':['o:signal']},
        {'id':'search-alibi','requires':['o:rules'],'grants':['o:alibi']},
        {'id':'search-red','requires':['o:rules'],'grants':['o:red']},
        {'id':'ask-belief','requires':['o:awareness'],'grants':['o:belief']}]}
    c['witness']=['search-token','search-alibi','ask-belief','search-red']
    c['profile']={'model':'authored-hybrid-v1','answerScope':scope,'questionMode':'required_literals',
        'ambiguityPolicy':policy,'nodes':nodes,'edges':edges,'hypotheses':hypotheses}
    expected=True;reason='all scoped literals proved from released records + public licenses'
    if c['category']=='two-plausible' and c['variant']==1:
        c['witness'].remove('search-alibi');expected=False;reason='alibi exists only in hidden Truth, not released'
    if c['category']=='two-plausible' and c['variant']==2:
        # Explicit NPC report can be licensed by a public, case-bound reliability rule.
        next(x for x in o if x['id']=='o:alibi')['mode']='REPORTED_BY_NPC'
        next(x for x in o if x['id']=='o:alibi')['source']='person:p3'
        c['game']['actions'][1]['id']='ask-certified-alibi';c['witness'][1]='ask-certified-alibi'
        reason='true NPC report with explicit public case license, not internal knowledge stance'
    if c['category']=='false-belief' and c['variant']==1:
        false={'id':'l:bad-belief','kind':'literal','literal':{'kind':'proposition','id':'proposition:other-scene','value':True}}
        nodes.append(false);edges.append({'id':'e:bad','allOf':['o:rules','o:belief'],'license':'o:rules','to':false['id']})
        expected=False;reason='false NPC belief cannot be promoted to objective canonical premise'
    if c['category']=='partial' and c['variant']!=0:
        expected=False;reason='partial scope retains multiple complete answer vectors under must_disambiguate'
    if c['category']=='ambiguous-forbidden':expected=False;reason='answer scope has unresolved extra responsibility dimensions'
    c['expectedPass']=expected;c['expectationReason']=reason
    c['expectedVerdict']={'minimalCorrect':True,'missingRequired':False,'unsupportedExtras':False,'source':'E_bounded_supported; gameplay proposal'}
    return publish(c)

corpus=[equip(x) for x in json.loads((E/'domain-corpus.json').read_text())]
corpus_results=[]
for c in corpus:
    r=checker.check(c);assert r['pass']==c['expectedPass'],(c['id'],r,c['expectedPass'])
    corpus_results.append({'id':c['id'],'category':c['category'],'variant':c['variant'],'expectedPass':c['expectedPass'],'result':r})
dump('experimental-corpus.json',corpus);dump('corpus-results.json',corpus_results)
base=clone(corpus[0]);base['profile']['answerScope']=list(base['required'])
base['profile']['nodes']=[n for n in base['profile']['nodes'] if n['kind']=='observation' or n['literal']['id'] in base['required']]
base['profile']['edges']=[e for e in base['profile']['edges'] if e['to'] in {n['id'] for n in base['profile']['nodes']}]
base['profile']['hypotheses']=[h for h in base['profile']['hypotheses'] if h['values']['conclusion:responsible-p2'] is False]
for h in base['profile']['hypotheses']:h['values'].pop('conclusion:responsible-p2')
publish(base)
assert checker.check(base)['pass']

# At least 60 separately named adversarial/positive probes, with real expectations.
unit=[]
def test(name,case,expected,code=None,witness=None):
    if name!='unpublished case rule':publish(case)
    else:case['bindings']['releaseHash']=checker.manifest_digest(case)
    result=checker.check(case,witness)
    assert result['pass']==expected,(name,result)
    if code:assert code in {f['code'] for f in result['findings']},(name,result)
    unit.append({'name':name,'expected':expected,'expectedCode':code,'case':case,'witness':witness,'result':result})
test('baseline independent paths',clone(base),True)
for i,cid in enumerate(base['required']):
    c=clone(base);c['profile']['edges']=[e for e in c['profile']['edges'] if e['to']!='l:'+cid]
    test(f'missing proof path {i}',c,False,'REQUIRED_NOT_DERIVED')
for action in ['search-token','search-alibi']:
    c=clone(base);c['witness'].remove(action);test('unreachable premise '+action,c,False,'REQUIRED_NOT_DERIVED')
c=clone(base);c['profile']['edges']=[]
goal=list(c['required'])[0];other=list(c['required'])[1]
c['profile']['edges']=[{'id':'cycle-a','allOf':['o:rules','l:'+other],'license':'o:rules','to':'l:'+goal},
 {'id':'cycle-b','allOf':['o:rules','l:'+goal],'license':'o:rules','to':'l:'+other}]
test('circular proof without seed',c,False,'PROOF_CYCLE')
c=clone(base);c['profile']['edges'][0]['allOf']=['o:rules',c['profile']['edges'][0]['to']]
test('self supporting goal',c,False,'PROOF_CYCLE')
c=clone(base);next(x for x in c['observations'] if x['id']=='o:signal')['literal']['value']=False
test('false observed premise',c,False,'FALSE_OBSERVATION')
c=clone(base);next(x for x in c['observations'] if x['id']=='o:signal')['mode']='INFERRED'
test('inferred input cannot be root',c,False,'INFERRED_ROOT')
c=clone(base);c['profile']['edges'].append(clone(c['profile']['edges'][0]));c['profile']['edges'][-1]['id']='duplicate-other-id'
test('duplicate semantic edge',c,False,'DUPLICATE_EDGE')
c=clone(base);c['profile']['edges'][0]['allOf']=['o:signal'];test('missing public license',c,False,'MISSING_PUBLIC_LICENSE')
c=clone(base);c['witness'].remove('search-token');c['profile']['edges'][0]['allOf']=['o:rules','o:belief']
# No license-specific reliability is assumed by this checker: explicit authored
# implication is an assumption. Remove it to test no automatic belief lifting.
c['profile']['edges'].pop(0);test('false belief is not automatically a fact',c,False,'REQUIRED_NOT_DERIVED')
c=clone(base);c['profile']['hypotheses']=[h for h in c['profile']['hypotheses'] if all(h['values'][x]==v for x,v in c['required'].items())]
c['profile']['edges']=[];test('single declared canonical option still needs proof',c,False,'REQUIRED_NOT_DERIVED')
c=clone(base);c['profile']['hypotheses']=c['profile']['hypotheses'][:1];test('canonical answer missing',c,False,'CANONICAL_ANSWER_NOT_IN_DOMAIN')
c=clone(base);c['profile']['hypotheses'][0]['values'].pop(next(iter(c['required'])))
test('incomplete hypothesis vector',c,False,'INCOMPLETE_HYPOTHESIS')
c=clone(base);c['profile']['hypotheses'].append(clone(c['profile']['hypotheses'][0]));test('duplicate hypothesis',c,False,'DUPLICATE_HYPOTHESIS')
c=clone(base);c['profile']['hypotheses'].append({'id':'other-label','values':clone(c['profile']['hypotheses'][0]['values'])})
test('same vector another ID',c,False,'DUPLICATE_ANSWER_VECTOR')
c=clone(base);c['profile']['answerScope'].append(c['profile']['answerScope'][0]);test('duplicate answer scope',c,False,'DUPLICATE_SCOPE')
c=clone(base);c['profile']['answerScope'].remove(next(iter(c['required'])));test('required outside question',c,False,'REQUIRED_OUT_OF_SCOPE')
c=clone(base);c['profile']['edges'][0]['allOf'].append('missing-node');test('unknown body node',c,False,'UNKNOWN_NODE')
c=clone(base);c['profile']['edges'][0]['to']='o:awareness';test('edge cannot rewrite report observation',c,False,'INVALID_EDGE_TARGET')
c=clone(base);c['profile']['edges'][0]['allOf']=[];test('empty rule cannot assert truth',c,False,'INVALID_EDGE_BODY')
c=clone(base);c['profile']['edges'][0]['allOf'].append(c['profile']['edges'][0]['allOf'][0]);test('duplicate body premise',c,False,'INVALID_EDGE_BODY')
c=clone(base);c['profile']['nodes'].append(clone(c['profile']['nodes'][0]));test('duplicate node',c,False,'DUPLICATE_NODE')
c=clone(base);c['observations'].append(clone(c['observations'][0]));test('duplicate source record',c,False,'DUPLICATE_OBSERVATION')
c=clone(base);c['profile']['ambiguityPolicy']='magic';test('unknown ambiguity policy',c,False,'INVALID_AMBIGUITY_POLICY')
c=clone(corpus[-1]);test('must disambiguate unresolved scope',c,False,'AMBIGUITY_POLICY_VIOLATION')
c['profile']['ambiguityPolicy']='may_remain_ambiguous';test('same scope ambiguity allowed',c,True)
for i in range(6):
    c=clone(base);w=checker.replay(c);w['bindings']=clone(w['bindings']);w['bindings']['releaseHash']='f'*64
    test(f'witness foreign release binding {i}',c,False,'WITNESS_BINDING_MISMATCH',w)
for i in range(6):
    c=clone(base);w=checker.replay(c);next(o for o in w['records'] if o['id']=='o:signal')['literal']['value']=False
    test(f'witness payload changed {i}',c,False,'RELEASE_RECORD_MISMATCH',w)
for i in range(6):
    c=clone(base);c['witness'].append(f'unknown-step-{i}');test(f'unknown command ref {i}',c,False,'INVALID_WITNESS_STEP')
for i in range(6):
    c=clone(base);c['profile']['edges'].append({'id':f'alternative-{i}','allOf':['o:rules','o:red'],'license':'o:rules','to':'l:'+goal})
    test(f'independent alternative path {i}',c,True)
for i in range(6):
    c=clone(base);c['profile']['nodes'].append({'id':f'unreached-{i}','kind':'observation','observationId':f'unreached-{i}'})
    c['observations'].append({'id':f'unreached-{i}','mode':'OBSERVED','source':'evidence:token','literal':{'kind':'proposition','id':'proposition:signal','value':True}})
    test(f'irrelevant unreachable evidence {i}',c,True)
c=clone(base);c['profile']['questionMode']='identify_all_responsible';c['responsibilityCompleteness']='partial'
test('whole responsibility question cannot use partial key',c,False,'FULL_ANSWER_INCOMPLETE')
c=clone(base);c['profile']['questionMode']='identify_all_responsible';test('role scope is not whole responsibility answer',c,False,'ANSWER_SCOPE_INVALID_FOR_QUESTION')
c=clone(base);c['required']={'conclusion:responsible-p0':True};c['profile']['answerScope']=[f'conclusion:responsible-p{i}' for i in range(4)]+['conclusion:nobody']
c['profile']['questionMode']='identify_all_responsible';c['profile']['nodes']=[n for n in c['profile']['nodes'] if n['kind']=='observation'];c['profile']['edges']=[]
for i,cid in enumerate(c['profile']['answerScope']):
    c['profile']['nodes'].append({'id':'l:'+cid,'kind':'literal','literal':lit(cid,c['statuses'][cid])})
    c['profile']['edges'].append({'id':f'resp-{i}','allOf':['o:rules','o:signal'],'license':'o:rules','to':'l:'+cid})
c['profile']['hypotheses']=[{'id':f'full-{i}','values':dict(zip(c['profile']['answerScope'],values))} for i,values in enumerate(itertools.product([False,True],repeat=5))]
test('full positive answer is fully required',c,True)
# Isolated branch exclusivity proves why union-of-releases is unsound.
c=clone(base);c['game']['actions'][0]['exclusiveGroup']='choice';c['game']['actions'][1]['exclusiveGroup']='choice'
test('exclusive proof leaves cannot be unioned',c,False,'INVALID_WITNESS_STEP')
# A report of the required claim is not an observed canonical conclusion.
c=clone(base);c['profile']['hypotheses']=[h for h in c['profile']['hypotheses'] if all(h['values'][x]==v for x,v in c['required'].items())]
c['profile']['edges']=[e for e in c['profile']['edges'] if e['to']!='l:'+goal]
next(o for o in c['observations'] if o['id']=='o:signal').update({'mode':'REPORTED_BY_NPC','literal':lit(goal,c['required'][goal])})
test('reported required conclusion is not objective root',c,False,'REQUIRED_NOT_DERIVED')
c=clone(base);next(o for o in c['observations'] if o['id']=='o:rules')['rules']=[]
test('unpublished case rule',c,False,'UNPUBLISHED_RULE')
c=clone(base);next(o for o in c['observations'] if o['id']=='o:signal')['literal']=lit(goal,c['required'][goal])
test('solution literal cannot be observed root',c,False,'INVALID_OBSERVATION_PAYLOAD')
dump('adversarial-probes.json',unit)

# 768 bounded configurations, 8 metamorphic properties each.
rng=random.Random(20261003);props=[];counterexamples=[]
for i in range(768):
    c=clone(base)
    if rng.randrange(2):c['witness'].remove('search-token')
    if rng.randrange(2):c['profile']['edges']=[e for e in c['profile']['edges'] if e['to']!='l:'+other]
    if rng.randrange(2):c['profile']['ambiguityPolicy']='may_remain_ambiguous'
    # independent serial proof chain variation
    for j in range(rng.randrange(1,8)):
        nid=f'chain-{i}-{j}';c['profile']['nodes'].append({'id':nid,'kind':'literal','literal':lit(goal,c['required'][goal])})
        earlier=['o:signal']+[f'chain-{i}-{k}' for k in range(j)]
        rng.shuffle(earlier);body=['o:rules']+earlier[:rng.randrange(1,min(3,len(earlier))+1)]
        c['profile']['edges'].append({'id':f'chain-edge-{j}','allOf':body,'license':'o:rules','to':nid})
    publish(c)
    original=checker.check(c)['pass'];cases=[]
    d=clone(c);oid=f'unreachable-{i}';d['observations'].append({'id':oid,'mode':'OBSERVED','source':'evidence:token','literal':{'kind':'proposition','id':'proposition:signal','value':True}});d['profile']['nodes'].append({'id':oid,'kind':'observation','observationId':oid})
    publish(d)
    cases.append(('unreachable cannot help',not checker.check(d)['pass'] or original))
    d=clone(c);d['profile']['edges']=[e for e in d['profile']['edges'] if e['to']!='l:'+goal]
    cases.append(('removing path cannot improve',not checker.check(d)['pass'] or original))
    d=clone(c)
    for field in ['nodes','edges','hypotheses','answerScope']:rng.shuffle(d['profile'][field])
    rng.shuffle(d['observations']);rng.shuffle(d['game']['actions'])
    publish(d)
    cases.append(('set permutations preserve pass',checker.check(d)['pass']==original))
    d=clone(c);d['profile']['edges'].append({'id':f'independent-{i}','allOf':['o:rules','o:red'],'license':'o:rules','to':'l:'+goal})
    publish(d)
    cases.append(('independent valid path cannot break',not original or checker.check(d)['pass']))
    d=clone(c);d['profile']['edges']=[{'id':'self','allOf':['o:rules','l:'+goal],'license':'o:rules','to':'l:'+goal}]
    cases.append(('cycles alone cannot establish',not checker.check(d)['pass']))
    d=clone(c);d['profile']['edges']=[e for e in d['profile']['edges'] if e['to']!='l:'+goal];d['witness']=['ask-belief','search-alibi']
    cases.append(('false belief no automatic fact',not checker.check(d)['pass']))
    d=clone(c);d['profile']['ambiguityPolicy']='must_disambiguate';strict=checker.check(d)['pass'];d['profile']['ambiguityPolicy']='may_remain_ambiguous'
    cases.append(('may never stricter than must',not strict or checker.check(d)['pass']))
    w=checker.replay(c);w['records']=list(reversed(w['records']));cases.append(('record order irrelevant',checker.check(c,w)['pass']==original))
    failures=[name for name,passed in cases if not passed]
    if failures:counterexamples.append({'configuration':i,'properties':failures,'case':c})
    props.append({'configuration':i,'basePass':original,'properties':dict(cases),'configurationHash':hashlib.sha256(json.dumps(c,sort_keys=True).encode()).hexdigest(),'case':c})
assert not counterexamples,counterexamples[:2]
dump('property-configurations.json',props);dump('property-counterexamples.json',counterexamples)

# Every source-based mutation is checked against the same expectations.
source=(ROOT/'checker.py').read_text();mutations=[
 ('allow false observed premise',"if mode=='OBSERVED' and not coherent(obs['literal']):","if False and mode=='OBSERVED' and not coherent(obs['literal']):"),
 ('seed all canonical inference nodes',"elif n['kind']=='literal':\n            if not coherent", "elif n['kind']=='literal':\n            established.add(n['id']); used[n['id']]=[]\n            if not coherent"),
 ('ignore witness binding',"if witness['bindings'] != case['bindings']:","if False and witness['bindings'] != case['bindings']:"),
 ('ignore must disambiguate',"if p['ambiguityPolicy']=='must_disambiguate' and len(survivors)!=1:","if False and p['ambiguityPolicy']=='must_disambiguate' and len(survivors)!=1:"),
 ('accept all claimed literals',"return type(lit['value']) is bool and type(status) is bool and status == lit['value']","return True"),
 ('seed unreachable roots',"if oid not in reached: continue","if False and oid not in reached: continue"),
 ('never eliminate competitor',"contradicted=any(('conclusion',cid,not v) in derived for cid,v in values.items())","contradicted=False"),
 ('forget required path',"if ('conclusion',cid,v) not in derived:f('REQUIRED_NOT_DERIVED',[cid])","if False:f('REQUIRED_NOT_DERIVED',[cid])"),
 ('reports become observed literals',"if o['mode']=='OBSERVED':derived.add(key(o['literal']))","if o['mode'] in ['OBSERVED','REPORTED_BY_NPC']:derived.add(key(o['literal']))")]
mutation_results=[]
for name,old,new in mutations:
    assert source.count(old)==1,(name,source.count(old))
    module={};exec(compile(source.replace(old,new),name,'exec'),module)
    killed=[]
    for t in unit:
        try:
            result=module['check'](t['case'],t['witness'])
            mismatch=result['pass']!=t['expected'] or t['expectedCode'] and t['expectedCode'] not in {f['code'] for f in result['findings']}
        except Exception as error:mismatch=True
        if mismatch:killed.append(t['name'])
    mutation_results.append({'name':name,'killed':bool(killed),'tests':killed[:8],'mutationOld':old,'mutationNew':new})
assert all(x['killed'] for x in mutation_results),mutation_results
dump('mutation-results.json',mutation_results)

configs=json.loads((E/'shotgun-configurations.json').read_text());strategies=['A_neutral_unknown','B_reject_unknown','C_scope_only','D_complete_authoring_gate','E_bounded_supported','F_exact_required']
counts={s:collections.Counter() for s in strategies};accusations=[]
for config in configs:
    minimal=[{'id':cid,'value':v} for cid,v in config['required'].items()]
    submitted={a['id'] for a in minimal};st=config['statuses'];variants=[('minimal correct',minimal)]
    groups={
      'true extras':[(cid,v) for cid,v in st.items() if type(v) is bool and cid not in submitted],
      'undetermined extras':[(cid,True) for cid,v in st.items() if v=='undetermined' and cid not in submitted],
      'contradicted extras':[(cid,not v) for cid,v in st.items() if type(v) is bool and cid not in submitted],
      'all persons':[(cid,True) for cid in st if 'responsible-p' in cid and cid not in submitted],
      'all roles':[(cid,True) for cid in st if any(x+'-p' in cid for x in ['direct_actor','planner','facilitator']) and cid not in submitted],
      'extra cause':[(cid,True) for cid in st if 'cause-e' in cid and cid not in submitted],
      'extra intent':[(cid,True) for cid in st if 'intent-' in cid and cid not in submitted],
      'extra mechanism':[(cid,True) for cid in st if 'mechanism-' in cid and cid not in submitted]}
    for name,extras in groups.items():
        if extras:
            for n in [1,5,10,50]:
                if len(extras)>=n:variants.append((f'{name} count {n}',minimal+[{'id':cid,'value':v} for cid,v in extras[:n]]))
    for j in range(24):
        available=[cid for cid in st if cid not in submitted];rng.shuffle(available)
        n=[1,5,10,50][j%4]
        variants.append((f'random extras {j} count {n}',minimal+[{'id':cid,'value':bool(rng.randrange(2))} for cid in available[:n]]))
    for name,a in variants:
        # Intended bounded-supported challenge: false, unknown or unrelated extras unacceptable.
        reasons=[]
        if any(st[x['id']]=='undetermined' for x in a):reasons.append('unsupported_unknown')
        if any(type(st[x['id']]) is bool and st[x['id']]!=x['value'] for x in a):reasons.append('canonically_contradicted')
        if any(x['id'] not in config['answerScope'] for x in a):reasons.append('outside_question_scope')
        bad=bool(reasons)
        result={s:checker.verdict(config,a,s) for s in strategies}
        for s,solved in result.items():
            counts[s]['attempts']+=1;counts[s]['solved']+=solved;counts[s]['unacceptableAttempts']+=bad
            counts[s]['unacceptableSolved']+=bad and solved;counts[s]['acceptableAttempts']+=not bad;counts[s]['acceptableRejected']+=not bad and not solved
            for reason in reasons:counts[s][reason+'Solved']+=solved
        accusations.append({'configuration':config['id'],'name':name,'literals':a,'unacceptableForBoundedQuestion':bad,'reasons':reasons,'results':result})
dump('shotgun-attempts.json',accusations);dump('shotgun-comparison.json',{s:dict(v) for s,v in counts.items()})
assert counts['E_bounded_supported']['unacceptableSolved']==0 and counts['E_bounded_supported']['acceptableRejected']==0
summary={'model':'SCRATCH HYPOTHESIS authored-hybrid-v1','corpus':len(corpus),'categories':dict(collections.Counter(c['category'] for c in corpus)),
 'corpusExpectedPass':sum(c['expectedPass'] for c in corpus),'corpusExpectedFail':sum(not c['expectedPass'] for c in corpus),
 'adversarialProbes':len(unit),'propertyConfigurations':len(props),'uniquePropertyConfigurations':len({x['configurationHash'] for x in props}),
 'propertyAssertions':len(props)*8,'propertyCounterexamples':len(counterexamples),'mutantsKilled':sum(m['killed'] for m in mutation_results),
 'shotgunConfigurations':len(configs),'shotgunAttempts':len(accusations),'comparison':{s:dict(v) for s,v in counts.items()}}
dump('lab-summary.json',summary);print(json.dumps(summary,indent=2))
