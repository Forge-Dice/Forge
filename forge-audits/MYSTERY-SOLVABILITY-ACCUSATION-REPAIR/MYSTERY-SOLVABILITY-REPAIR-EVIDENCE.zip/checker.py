"""SCRATCH HYPOTHESIS: bounded authored proof + finite answer elimination.
No production implementation. Canonical statuses come from unmodified TS parsers.
Replay is a trusted executable adapter, never an authored reachable Boolean.
"""
import copy, hashlib, json

def key(literal):
    return (literal['kind'], literal['id'], literal['value'])

def manifest_digest(case):
    payload={'observations':case['observations'],'nodeMeanings':case['profile']['nodes'],
             'answerScope':case['profile']['answerScope'],'question':case['profile'].get('questionMode'),
             'game':case['game']}
    text=json.dumps(payload,sort_keys=True,separators=(',',':'))
    return hashlib.sha256(('repair-lab-release-v1\n'+text).encode()).hexdigest()

def replay(case, steps=None):
    """Disposable monotone release host. A single concrete path, not path union."""
    released = set(case['game']['initial'])
    actions = {a['id']: a for a in case['game']['actions']}
    exclusive = set()
    failures = []
    for step in case['witness'] if steps is None else steps:
        action = actions.get(step)
        if action is None or not set(action.get('requires', [])) <= released:
            failures.append(step); continue
        if action.get('exclusiveGroup') in exclusive:
            failures.append(step); continue
        if action.get('exclusiveGroup'): exclusive.add(action['exclusiveGroup'])
        released.update(action['grants'])
    bindings=copy.deepcopy(case['bindings']);bindings['releaseHash']=manifest_digest(case)
    return {'bindings': bindings, 'records':
            [copy.deepcopy(o) for o in case['observations'] if o['id'] in released], 'failedSteps': failures}

def check(case, witness=None):
    p = case['profile']; findings = []
    def f(code, subjects=(), severity='error'):
        findings.append({'code': code, 'subjectIds': sorted(subjects), 'severity': severity})
    if witness is None: witness = replay(case)
    if witness['bindings'] != case['bindings']:
        f('WITNESS_BINDING_MISMATCH'); return finish(False, findings, [], [])
    if witness.get('failedSteps'): f('INVALID_WITNESS_STEP', witness['failedSteps'])
    scope = p['answerScope']; scope_set = set(scope)
    if len(scope) != len(scope_set): f('DUPLICATE_SCOPE')
    if not set(case['required']) <= scope_set: f('REQUIRED_OUT_OF_SCOPE')
    if not scope or len(scope)>6 or len(p['hypotheses'])>64: f('LIMIT_EXCEEDED')
    nodes = {n['id']: n for n in p['nodes']}
    if len(nodes)!=len(p['nodes']): f('DUPLICATE_NODE')
    catalog = {o['id']: o for o in case['observations']}
    if len(catalog)!=len(case['observations']): f('DUPLICATE_OBSERVATION')
    reached = {}
    for record in witness['records']:
        if record['id'] not in catalog or record != catalog[record['id']]:
            f('RELEASE_RECORD_MISMATCH', [record['id']]); continue
        reached[record['id']] = record
    def literal_status(lit):
        return case['statuses' if lit['kind']=='conclusion' else 'propositionStatuses'].get(lit['id'], 'UNKNOWN_REFERENCE')
    def coherent(lit):
        status=literal_status(lit)
        return type(lit['value']) is bool and type(status) is bool and status == lit['value']
    established=set(); used={}
    for n in p['nodes']:
        if n['kind']=='observation':
            oid=n['observationId']; obs=catalog.get(oid)
            if obs is None: f('UNKNOWN_OBSERVATION',[n['id'],oid]); continue
            if oid not in reached: continue
            mode=obs['mode']
            if mode=='INFERRED': f('INFERRED_ROOT',[n['id']]); continue
            if mode=='OBSERVED' and obs['literal']['kind']!='proposition':
                f('INVALID_OBSERVATION_PAYLOAD',[n['id']]);continue
            if mode=='OBSERVED' and not coherent(obs['literal']):
                f('FALSE_OBSERVATION',[n['id']]); continue
            if mode not in ['OBSERVED','REPORTED_BY_NPC','ENTITY_AWARENESS','PUBLIC_RULE']:
                f('INVALID_OBSERVATION_MODE',[n['id']]);continue
            established.add(n['id']); used[n['id']]=[oid]
        elif n['kind']=='literal':
            if not coherent(n['literal']): f('NONCANONICAL_INFERENCE',[n['id']])
        else: f('INVALID_NODE_KIND',[n['id']])
    signatures=set(); ids=set(); good=[]
    for edge in p['edges']:
        eid=edge['id']; body=edge['allOf']; target=nodes.get(edge['to']); lic=nodes.get(edge['license'])
        sig=(tuple(sorted(body)),edge['to'],edge['license'])
        if eid in ids or sig in signatures: f('DUPLICATE_EDGE',[eid])
        ids.add(eid); signatures.add(sig)
        if not body or len(body)!=len(set(body)):
            f('INVALID_EDGE_BODY',[eid]);continue
        if any(x not in nodes for x in body) or target is None or lic is None:
            f('UNKNOWN_NODE',[eid]);continue
        if target['kind']!='literal': f('INVALID_EDGE_TARGET',[eid]);continue
        license_observation=catalog.get(lic.get('observationId',''))
        if edge['license'] not in body or not license_observation or license_observation['mode']!='PUBLIC_RULE':
            f('MISSING_PUBLIC_LICENSE',[eid]);continue
        descriptor={'id':eid,'allOf':sorted(set(body)-{edge['license']}),'yields':target['literal']}
        if descriptor not in license_observation.get('rules',[]):
            f('UNPUBLISHED_RULE',[eid]);continue
        if not coherent(target['literal']): continue
        good.append(edge)
    # Least fixed point. No circular bootstrap, no negation-as-failure.
    for _ in range(len(nodes)+1):
        changed=False
        for edge in sorted(good,key=lambda e:e['id']):
            if edge['to'] not in established and set(edge['allOf']) <= established:
                established.add(edge['to']);used[edge['to']]=sorted(set(
                    x for source in edge['allOf'] for x in used[source]))
                changed=True
        if not changed:break
    # Cycles are diagnostics; seeded cycles never generate unsupported roots.
    graph={nid:set() for nid in nodes}
    for e in good:
        for b in e['allOf']:graph[b].add(e['to'])
    visiting=set(); visited=set(); cycle=set()
    def dfs(n,trail):
        if n in visiting:
            cycle.update(trail[trail.index(n):]);return
        if n in visited:return
        visiting.add(n)
        for nxt in sorted(graph[n]):dfs(nxt,trail+[n])
        visiting.remove(n);visited.add(n)
    for n in sorted(nodes):dfs(n,[])
    if cycle:f('PROOF_CYCLE',cycle,'warning')
    derived={key(n['literal']) for nid,n in nodes.items() if nid in established and n['kind']=='literal'}
    # Observed literals count only after an explicit release (not evidence.links).
    for nid in established:
        n=nodes[nid]
        if n['kind']=='observation':
            o=catalog[n['observationId']]
            if o['mode']=='OBSERVED':derived.add(key(o['literal']))
    for cid,v in case['required'].items():
        if ('conclusion',cid,v) not in derived:f('REQUIRED_NOT_DERIVED',[cid])
    for n in nodes.values():
        if n['kind']=='observation' and n['observationId'] not in reached:
            f('PREMISE_NOT_REACHED',[n['id'],n['observationId']],'warning')
    survivors=[]; seen_vectors=set(); hypothesis_ids=set(); compatible=[]
    for h in p['hypotheses']:
        values=h['values']
        if h['id'] in hypothesis_ids:f('DUPLICATE_HYPOTHESIS',[h['id']])
        hypothesis_ids.add(h['id'])
        if set(values)!=scope_set or any(type(v) is not bool for v in values.values()):
            f('INCOMPLETE_HYPOTHESIS',[h['id']]);continue
        vec=tuple((c,values[c]) for c in sorted(scope))
        if vec in seen_vectors:f('DUPLICATE_ANSWER_VECTOR',[h['id']])
        seen_vectors.add(vec)
        if all(case['statuses'].get(c)=='undetermined' or case['statuses'].get(c)==v for c,v in values.items()):compatible.append(h['id'])
        contradicted=any(('conclusion',cid,not v) in derived for cid,v in values.items())
        if not contradicted:survivors.append(h)
    # The lab exports the generated table for inspection. Production should
    # generate it internally: no author can omit an inconvenient competitor.
    if len(scope_set)<=6 and len(seen_vectors)!=2**len(scope_set):f('HYPOTHESIS_DOMAIN_INCOMPLETE')
    if not compatible:f('CANONICAL_ANSWER_NOT_IN_DOMAIN')
    if not survivors:f('NO_SURVIVING_HYPOTHESIS')
    if any(not all(h['values'][c]==v for c,v in case['required'].items()) for h in survivors):
        f('REQUIRED_AMBIGUOUS',[h['id'] for h in survivors])
    if p['ambiguityPolicy']=='must_disambiguate' and len(survivors)!=1:
        f('AMBIGUITY_POLICY_VIOLATION',[h['id'] for h in survivors])
    if p['ambiguityPolicy'] not in ['must_disambiguate','may_remain_ambiguous']:f('INVALID_AMBIGUITY_POLICY')
    # Full-responsibility questions require a complete, fully required positive set.
    if p.get('questionMode')=='identify_all_responsible':
        responsible_keys={c['id'] for c in case['solution']['conclusions'] if c['claim']['kind'] in ['personResponsibleForEvent','noPersonResponsibleForEvent']}
        if scope_set!=responsible_keys:f('ANSWER_SCOPE_INVALID_FOR_QUESTION')
        if case.get('responsibilityCompleteness')!='complete':f('FULL_ANSWER_INCOMPLETE')
        for cid in scope:
            if case['statuses'][cid] is True and case['required'].get(cid) is not True:
                f('POSITIVE_ANSWER_NOT_REQUIRED',[cid])
    errors=any(x['severity']=='error' for x in findings)
    return finish(not errors,findings,sorted(derived),[h['id'] for h in survivors],used)

def finish(passed,findings,derived,survivors,used=None):
    return {'pass':passed,'findings':sorted(findings,key=lambda f:(f['code'],f['subjectIds'])),
            'derived':derived,'survivors':sorted(survivors),'proofSources':used or {}}

def verdict(case,literals,strategy):
    """Strategies are proposals; statuses are actual-current-code oracle outputs."""
    submitted={x['id']:x['value'] for x in literals}
    if len(submitted)!=len(literals):return False
    if any(type(x['value']) is not bool or x['id'] not in case['statuses'] for x in literals):return False
    if any(submitted.get(cid) is not v for cid,v in case['required'].items()):return False
    if any(type(case['statuses'][cid]) is bool and case['statuses'][cid]!=v for cid,v in submitted.items()):return False
    if strategy=='D_complete_authoring_gate' and case['responsibilityCompleteness']!='complete':return False
    if strategy in ['B_reject_unknown','E_bounded_supported','F_exact_required']:
        if any(case['statuses'][cid]=='undetermined' for cid in submitted):return False
    if strategy in ['C_scope_only','E_bounded_supported']:
        if not set(submitted)<=set(case['answerScope']):return False
    if strategy=='F_exact_required' and set(submitted)!=set(case['required']):return False
    return True
