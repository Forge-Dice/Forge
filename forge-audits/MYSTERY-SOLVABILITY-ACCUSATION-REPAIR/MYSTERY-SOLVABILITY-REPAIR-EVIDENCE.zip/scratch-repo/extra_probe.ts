import {readFileSync,writeFileSync} from 'node:fs';
import {parseCaseTruth} from './src/domain/case-truth.ts';
import {parseCaseSolution} from './src/domain/case-solution.ts';
import {hashCaseTruth} from './src/domain/case-truth.identity.ts';
import {hashCaseSolution} from './src/domain/case-solution.identity.ts';
import {validateCaseSemantics} from './src/domain/case-semantics.ts';
const c=JSON.parse(readFileSync('../evidence/domain-corpus.json','utf8'))[0];
const truth=parseCaseTruth(c.truth);const original=parseCaseSolution(c.solution,truth);
const alt=structuredClone(c.solution);alt.resolutions[0].responsibility.assignments=[{personId:'person:p1',roles:['direct_actor']}];
alt.requiredConclusions=[{conclusionId:'conclusion:direct_actor-p1',value:true}];
const alternate=parseCaseSolution(alt,truth);
const misleading=structuredClone(c.truth);misleading.evidence[2].links=[{propositionId:'proposition:other-scene',direction:'supports'}];
const misleadingTruth=parseCaseTruth(misleading);
const result={sameTruth:hashCaseTruth(truth),originalSolution:hashCaseSolution(original),alternateSolution:hashCaseSolution(alternate),
 originalRequired:c.solution.requiredConclusions,alternateRequired:alt.requiredConclusions,alternateAccepted:true,
 falseSupportingEvidenceAccepted:validateCaseSemantics(misleadingTruth).findings.length===0,
 rolePresenceConstraint:'not implemented; world/answer compatibility does not imply player deduction',
 originalSemanticFindings:validateCaseSemantics(truth).findings};
writeFileSync('../evidence/current-code-counterexamples.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
