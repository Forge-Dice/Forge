import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {parseContractDocument} from './src/forge/contract-document.ts';
const hash=(s:string)=>createHash('sha256').update(s).digest('hex');
const paths=['../MYST-SOLVABILITY-0001.contract.DRAFT.md',
'../design/MYST-0002-ACCUSATION-VERDICT-V1.contract.DRAFT.md',
'../design/MYST-0003-EVIDENCE-ACCESS-V1.contract.DRAFT.md'];
const results=paths.map(path=>{const text=readFileSync(path,'utf8');const r=parseContractDocument(text,hash);
return {path,sha256:hash(text),result:r.ok?{ok:true,ref:r.document.ref,metadata:r.document.metadata}:r};});
const own=readFileSync(paths[0]!,'utf8');const format2=parseContractDocument(own.replace('"forgeContractFormat": 1','"forgeContractFormat": 2'),hash);
const report={currentMain:'3d7545d843883418348004e68717399a64da7a7d',results,format2Rejected:!format2.ok,format2Issues:format2.ok?[]:format2.issues,
 notRegistrationOrApproval:true};
writeFileSync('../evidence/contract-parser-results.json',JSON.stringify(report,null,2));
if(results.some(x=>!x.result.ok)||format2.ok)throw Error(JSON.stringify(report));
console.log(JSON.stringify({draftsParsed:results.length,ownContractHash:(results[0]!.result as any).ref.contentHash,format2Rejected:!format2.ok}));
