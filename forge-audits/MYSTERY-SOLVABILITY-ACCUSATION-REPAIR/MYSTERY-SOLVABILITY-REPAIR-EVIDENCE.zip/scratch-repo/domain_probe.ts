// Disposable generation/oracle. Uses unchanged current-main domain modules.
import {writeFileSync, readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {parseCaseTruth} from './src/domain/case-truth.ts';
import {hashCaseTruth} from './src/domain/case-truth.identity.ts';
import {parseCaseSolution, ConclusionClaimSchema} from './src/domain/case-solution.ts';
import {hashCaseSolution} from './src/domain/case-solution.identity.ts';
import {validateCaseSemantics} from './src/domain/case-semantics.ts';
import {parseNpcKnowledge} from './src/domain/npc-knowledge.ts';
import {parseContractDocument} from './src/forge/contract-document.ts';

const out='../evidence/';
const sha=(s:string)=>createHash('sha256').update(s).digest('hex');
function truthInput(id:string,n=4,events=3){
 return {schemaVersion:1,caseId:`case:${id}`,revision:1,title:`Lab ${id}`,
 timeline:{unit:'second',originLabel:'Lab'},persons:Array.from({length:n},(_,i)=>({id:`person:p${i}`,name:`P${i}`})),
 locations:[{id:'location:scene',name:'Scene'},{id:'location:away',name:'Away'}],items:[{id:'item:token',name:'Token'}],relationships:[],
 events:Array.from({length:events},(_,i)=>({id:`event:e${i}`,description:`Private event ${i}`,
 time:{kind:'instant',at:i*10},locationId:'location:scene',participantIds:[],itemIds:i===events-1?['item:token']:[],causedByEventIds:i===events-1?['event:e0']:[]})),
 motives:[],propositions:[{id:'proposition:signal',claim:{kind:'eventHasItem',eventId:`event:e${events-1}`,itemId:'item:token'},truth:true},
 {id:'proposition:other-away',claim:{kind:'personAt',personId:'person:p1',locationId:'location:away',at:20},truth:true},
 {id:'proposition:other-earlier',claim:{kind:'personAt',personId:'person:p1',locationId:'location:scene',at:10},truth:true},
 {id:'proposition:other-scene',claim:{kind:'personAt',personId:'person:p1',locationId:'location:scene',at:20},truth:false}],
 evidence:[{id:'evidence:token',description:'Private authored signal',source:{kind:'item',id:'item:token'},links:[{propositionId:'proposition:signal',direction:'supports'}]},
 {id:'evidence:alibi',description:'Private authored alibi',source:{kind:'location',id:'location:away'},links:[{propositionId:'proposition:other-away',direction:'supports'}]},
 {id:'evidence:red',description:'Private red herring',source:{kind:'location',id:'location:scene'},links:[{propositionId:'proposition:other-earlier',direction:'supports'}]}],
 secrets:[],redHerrings:[{id:'red-herring:earlier',evidenceIds:['evidence:red'],misleadingPropositionId:'proposition:other-earlier'}]};
}
const claims=(eventId:string,n=4,events=3)=>{
 const result:any[]=[];const c=(id:string,claim:any)=>result.push({id:`conclusion:${id}`,claim});
 for(let i=0;i<n;i++){c(`responsible-p${i}`,{kind:'personResponsibleForEvent',personId:`person:p${i}`,eventId});
 for(const role of ['direct_actor','planner','facilitator'])c(`${role}-p${i}`,{kind:'personRoleForEvent',personId:`person:p${i}`,eventId,role});}
 c('nobody',{kind:'noPersonResponsibleForEvent',eventId});
 for(let i=0;i<events-1;i++)c(`cause-e${i}`,{kind:'eventCausedEvent',causeEventId:`event:e${i}`,eventId});
 for(const value of ['intended','unintended','not_applicable'])c(`intent-${value}`,{kind:'eventIntent',eventId,value});
 for(const value of ['ordinary','supernatural','mixed'])c(`mechanism-${value}`,{kind:'eventMechanism',eventId,value});
 return result;
};
function solutionInput(t:any,assignments:any[],complete='complete',intent:any='intended',mechanism:any='ordinary',causesComplete=true){
 const eventId=t.events.at(-1).id;
 return {schemaVersion:1,caseId:t.caseId,revision:1,truthHash:hashCaseTruth(t),resolutions:[{eventId,targets:[{kind:'item',id:'item:token'}],responsibility:{completeness:complete,assignments},intent,mechanism,causesComplete}],
 conclusions:claims(eventId,t.persons.length,t.events.length),requiredConclusions:[{conclusionId:'conclusion:cause-e0',value:true}]};
}
function statuses(si:any,t:any){
 const result:Record<string,boolean|string>={};
 for(const c of si.conclusions){
  ConclusionClaimSchema.parse(c.claim);
  const success:boolean[]=[];
  for(const value of [true,false])try{parseCaseSolution({...structuredClone(si),requiredConclusions:[{conclusionId:c.id,value}]},t);success.push(value);}catch{}
  if(success.length>1)throw Error('Oracle inconsistent');
  result[c.id]=success.length===1?success[0]!:'undetermined';
 }
 return result;
}
const categories=['obvious-single','two-plausible','multi-actor','planner-actor','accident','nobody','supernatural','false-belief','true-red-herring','partial','ambiguous-allowed','ambiguous-forbidden'];
const corpus:any[]=[];
for(const [index,category] of categories.entries())for(let variant=0;variant<3;variant++){
 const id=`lab-${index}-${variant}`;const ti=truthInput(id);const truth=parseCaseTruth(ti);
 const sem=validateCaseSemantics(truth);if(sem.findings.length)throw Error(JSON.stringify(sem));
 let assignments:any[]=[{personId:'person:p0',roles:['direct_actor']}];let completeness='complete';let intent:any='intended';let mechanism:any='ordinary';
 let goals:Record<string,boolean>={'conclusion:direct_actor-p0':true,'conclusion:direct_actor-p1':false};
 if(category==='multi-actor'){assignments.push({personId:'person:p1',roles:['direct_actor']});goals={'conclusion:responsible-p0':true,'conclusion:responsible-p1':true};}
 if(category==='planner-actor'){assignments=[{personId:'person:p0',roles:['planner']},{personId:'person:p1',roles:['direct_actor']}];goals={'conclusion:planner-p0':true,'conclusion:direct_actor-p1':true};}
 if(category==='accident'){intent='unintended';goals={'conclusion:responsible-p0':true,'conclusion:intent-unintended':true};}
 if(category==='nobody'){assignments=[];intent='not_applicable';goals={'conclusion:nobody':true,'conclusion:responsible-p0':false};}
 if(category==='supernatural'){mechanism='supernatural';goals={'conclusion:responsible-p0':true,'conclusion:mechanism-supernatural':true};}
 if(['partial','ambiguous-allowed','ambiguous-forbidden'].includes(category)){completeness='partial';goals={'conclusion:responsible-p0':true};}
 const si=solutionInput(truth,assignments,completeness,intent,mechanism);si.requiredConclusions=Object.entries(goals).map(([conclusionId,value])=>({conclusionId,value}));
 const solution=parseCaseSolution(si,truth);const st=statuses(si,truth);
 const npcInput={schemaVersion:1,caseId:truth.caseId,truthHash:hashCaseTruth(truth),solutionHash:hashCaseSolution(solution),npcId:'person:p3',revision:1,asOf:30,awareness:[],attitudes:[
 {subject:{kind:'proposition',id:'proposition:other-scene'},stance:{kind:category==='false-belief'?'belief':'uncertain',...(category==='false-belief'?{value:true}:{leaning:null})},acquiredAt:0,provenance:{kind:'prior_knowledge'}},
 {subject:{kind:'proposition',id:'proposition:other-away'},stance:{kind:'knowledge',value:true},acquiredAt:0,provenance:{kind:'prior_knowledge'}}]};
 parseNpcKnowledge(npcInput,truth,solution);
 corpus.push({id,category,variant,truth:ti,solution:si,required:goals,statuses:st,
 propositionStatuses:Object.fromEntries(truth.propositions.map(p=>[p.id,p.truth])),npcInput,bindings:{truthHash:hashCaseTruth(truth),solutionHash:hashCaseSolution(solution),releaseHash:sha('release:'+id)},responsibilityCompleteness:completeness});
}
writeFileSync(out+'domain-corpus.json',JSON.stringify(corpus,null,2));
const configs:any[]=[];
for(let i=0;i<24;i++){
 const ti=truthInput(`shotgun-${i}`,52,8);const truth=parseCaseTruth(ti);
 const shapes:any[][]=[[{personId:'person:p0',roles:['direct_actor']}],[{personId:'person:p0',roles:null}],[{personId:'person:p0',roles:['direct_actor']},{personId:'person:p1',roles:['facilitator']}],[],[{personId:'person:p0',roles:['planner']},{personId:'person:p1',roles:['direct_actor']}],Array.from({length:52},(_,j)=>({personId:`person:p${j}`,roles:['direct_actor']}))];
 const group=Math.floor(i/6);const complete=group%2===0?'complete':'partial';
 const si=solutionInput(truth,shapes[i%6]!,complete,group>=2?null:'intended',group>=2?null:'ordinary',group<2);
 let required:any={};if(shapes[i%6]!.length)required={'conclusion:responsible-p0':true};else if(complete==='complete')required={'conclusion:nobody':true};else required={'conclusion:cause-e0':true};
 si.requiredConclusions=Object.entries(required).map(([conclusionId,value])=>({conclusionId,value}));parseCaseSolution(si,truth);
 const st=statuses(si,truth);
 const answerScope=i%6===3&&complete==='partial'?['conclusion:cause-e0']:[...Array.from({length:52},(_,j)=>`conclusion:responsible-p${j}`),'conclusion:nobody'];
 configs.push({id:`shotgun-${i}`,truth:ti,solution:si,statuses:st,required,answerScope,responsibilityCompleteness:complete});
}
writeFileSync(out+'shotgun-configurations.json',JSON.stringify(configs,null,2));
const summary={currentMain:'3d7545d843883418348004e68717399a64da7a7d',corpus:corpus.length,canonicalParsersPassed:corpus.length,
 semanticValidCorpus:corpus.length,npcSnapshotsParsed:corpus.length,solutionConfigurations:configs.length,claimsPerShotgunConfiguration:Object.keys(configs[0].statuses).length,
 oracle:'parseCaseSolution required-literal black-box; no copied truth table'};
writeFileSync(out+'domain-probe-summary.json',JSON.stringify(summary,null,2));console.log(JSON.stringify(summary));
