#!/usr/bin/env python3
import os,subprocess,tempfile,json,base64,pathlib,shutil
ROOT=pathlib.Path(__file__).resolve().parents[1]; OUT=ROOT/'evidence'; OUT.mkdir(exist_ok=True)
r=pathlib.Path(tempfile.mkdtemp(prefix='forge-git-lab-')); home=r/'home';home.mkdir(); repo=r/'repo'
env={'PATH':os.environ['PATH'],'HOME':str(home),'LC_ALL':'C','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_NO_REPLACE_OBJECTS':'1','GIT_TERMINAL_PROMPT':'0'}
def git(*args,input=None,check=True,replace=False):
 e=env.copy()
 if replace:e.pop('GIT_NO_REPLACE_OBJECTS')
 p=subprocess.run(['git','-c','core.hooksPath=/dev/null','-c','core.attributesFile=/dev/null','-c','protocol.file.allow=never','-C',str(repo),*args],env=e,input=input,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 if check and p.returncode:raise RuntimeError((args,p.stderr.decode()))
 return p
subprocess.run(['git','init','--initial-branch=main',str(repo)],env=env,check=True,stdout=subprocess.DEVNULL)
git('config','user.email','lab@example.invalid');git('config','user.name','Local lab')
def write(p,b):
 f=repo/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b)
def commit(msg):
 git('add','--all');git('commit','-m',msg);return git('rev-parse','HEAD').stdout.strip().decode()
for p,b in {'modify.txt':b'old\n','delete.txt':b'delete\n','rename-old':b'rename\n','exec.sh':b'echo harmless\n','Case.ts':b'case\n','both.txt':b'old\n'}.items():write(p,b)
base=commit('base')
write('modify.txt',b'new\n');(repo/'delete.txt').unlink();(repo/'rename-old').rename(repo/'rename-new');os.chmod(repo/'exec.sh',0o755)
(repo/'Case.ts').rename(repo/'case.ts');os.symlink('/tmp/never-follow',repo/'link');write('empty',b'');write('binary',b'\x00\xff\x01');write('unicode/ä雪\n\t.txt',b'unicode');write('collision/A.ts',b'a');write('collision/a.ts',b'b');write('both.txt',b'new\n');os.chmod(repo/'both.txt',0o755)
git('add','--all');git('update-index','--add','--cacheinfo',f'160000,{base},submod');git('commit','-m','adversarial tree');head=git('rev-parse','HEAD').stdout.strip().decode()
def tree(sha):
 data=git('ls-tree','-r','-z','--full-tree',sha).stdout; out={}
 for rec in data.split(b'\0'):
  if not rec:continue
  meta,path=rec.split(b'\t',1);mode,kind,oid=meta.split(b' ');out[path]=(mode.decode(),kind.decode(),oid.decode())
 return out
def collect(a,b):
 aa,bb=tree(a),tree(b);out=[]
 for path in sorted(set(aa)|set(bb)):
  old,new=aa.get(path),bb.get(path)
  if old==new:continue
  kinds=['ADD'] if old is None else ['DELETE'] if new is None else (['MODIFY'] if old[2]!=new[2] else [])+(['MODE_CHANGE'] if old[0]!=new[0] else [])
  out.append({'path':path.decode('utf-8',errors='backslashreplace'),'pathBase64':base64.b64encode(path).decode(),'types':kinds,'oldMode':old[0] if old else None,'newMode':new[0] if new else None,'oldObject':old[2] if old else None,'newObject':new[2] if new else None,'oldType':old[1] if old else None,'newType':new[1] if new else None})
 return out
changes=collect(base,head); assert changes==collect(base,head)
from collect_diff import collect as external_collect
external=external_collect(repo/'.git',base,head)
assert [{k:v for k,v in row.items() if k not in ('oldBlob','newBlob')} for row in external]==changes
(OUT/'canonical-diff-adversarial.json').write_text(json.dumps(external,indent=2,ensure_ascii=True))
by={c['path']:c for c in changes}
for path,types in [('rename-old',['DELETE']),('rename-new',['ADD']),('exec.sh',['MODE_CHANGE']),('both.txt',['MODIFY','MODE_CHANGE']),('Case.ts',['DELETE']),('case.ts',['ADD'])]:assert by[path]['types']==types
assert by['submod']['newType']=='commit';assert by['link']['newMode']=='120000'
# refs/replace makes an ordinary reader see the base tree as head.
git('replace',head,base)
unsafe=git('ls-tree','-r','-z',head,replace=True).stdout;safe=git('ls-tree','-r','-z',head).stdout
assert unsafe==git('ls-tree','-r','-z',base).stdout and unsafe!=safe
assert collect(base,head)==changes
# Poisoned local config: object-only commands must not run these drivers.
marker=r/'EXECUTED'
write('.gitattributes',b'*.txt filter=evil diff=evil merge=evil\n')
git('config','filter.evil.smudge',f'touch {marker}');git('config','filter.evil.clean',f'touch {marker}');git('config','diff.evil.command',f'touch {marker}');git('config','merge.evil.driver',f'touch {marker}')
commands={}
for name,args in {'cat-file':['cat-file','-p',head],'ls-tree':['ls-tree','-r','-z','--full-tree',head],'diff-tree':['diff-tree','--no-commit-id','--raw','-r','-z','--no-renames','--no-ext-diff','--no-textconv',base,head],'diff':['diff','--raw','--no-abbrev','-z','--no-renames','--no-ext-diff','--no-textconv',base,head,'--'],'merge-base':['merge-base','--is-ancestor',base,head],'merge-tree':['merge-tree','--write-tree',base,head]}.items():
 p=git(*args);commands[name]={'args':args,'exit':p.returncode,'bytes':len(p.stdout)}
assert not marker.exists()
# Merge commits: default one-commit diff-tree omits combined merge delta, explicit trees don't.
treeid=git('rev-parse',head+'^{tree}').stdout.strip().decode()
merge=git('commit-tree',treeid,'-p',head,'-p',base,input=b'merge fixture\n').stdout.strip().decode()
assert collect(base,merge)==changes
commands['merge-commit-default-diff-tree']={'bytes':len(git('diff-tree','--no-commit-id','-r',merge).stdout),'explicitPairChanges':len(collect(base,merge))}
# Alternates are LOCAL metadata: environment sanitation alone doesn't disable this file.
alt=r/'alternate.git';subprocess.run(['git','init','--bare',str(alt)],env=env,check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
(alt/'objects/info/alternates').write_text(str(repo/'.git/objects')+'\n')
p=subprocess.run(['git','--git-dir='+str(alt),'cat-file','-t',head],env=env,capture_output=True);assert p.returncode==0
# Safe materialization: object bytes, only ordinary modes, fresh dir, O_EXCL/O_NOFOLLOW.
def materialize(sha,dest):
 t=tree(sha);seen=set()
 for path,(mode,kind,oid) in t.items():
  s=path.decode('utf-8',errors='strict');parts=s.split('/')
  if any(p in ('','.','..') or p.lower()=='.git' for p in parts):raise ValueError('unsafe path')
  if mode not in ('100644','100755') or kind!='blob':raise ValueError('unsupported mode')
  key=s.casefold()
  if key in seen:raise ValueError('case collision')
  seen.add(key)
 dest.mkdir()
 for path,(mode,kind,oid) in t.items():
  target=dest/path.decode();target.parent.mkdir(parents=True,exist_ok=True)
  fd=os.open(target,os.O_CREAT|os.O_EXCL|os.O_WRONLY|os.O_NOFOLLOW,0o700 if mode=='100755' else 0o600)
  with os.fdopen(fd,'wb') as f:f.write(git('cat-file','blob',oid).stdout)
materialize(base,r/'materialized-base')
try:materialize(head,r/'materialized-head');raise AssertionError('must reject')
except ValueError:pass
# merge-tree CAN run custom merge drivers if local config enables one.
git('replace','-d',head);git('config','--unset-all','filter.evil.clean');git('config','--unset-all','filter.evil.smudge')
git('read-tree',base);attr=git('hash-object','-w','--stdin',input=b'modify.txt merge=evil\n').stdout.strip().decode();git('update-index','--add','--cacheinfo',f'100644,{attr},.gitattributes')
mt=git('write-tree').stdout.strip().decode();mb=git('commit-tree',mt,'-p',base,input=b'merge driver base\n').stdout.strip().decode()
def child(content):
 git('read-tree',mb);blob=git('hash-object','-w','--stdin',input=content).stdout.strip().decode();git('update-index','--cacheinfo',f'100644,{blob},modify.txt');t=git('write-tree').stdout.strip().decode();return git('commit-tree',t,'-p',mb,input=b'child\n').stdout.strip().decode()
l=child(b'left\n');rr=child(b'right\n');git('merge-tree','--write-tree',l,rr,check=False);driver_ran=marker.exists();assert driver_ran
result={'base':base,'head':head,'changes':changes,'commands':commands,'replaceDetected':True,'safeCommandsDidNotRunDrivers':True,'mergeTreeCanRunConfiguredDriver':driver_ran,'alternatesStillHonoredWithSanitizedEnvironment':True,'baseMaterializedWithoutCheckout':True,'unsafeHeadMaterializationRejected':True,'caseCollisionStored':True,'gitVersion':git('--version').stdout.decode().strip()}
(OUT/'git-lab.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('changes','commands')},indent=2));shutil.rmtree(r)
