#!/usr/bin/env python3
import json, pathlib, subprocess, shutil, os, re
R=pathlib.Path(__file__).resolve().parents[2]; O=R/'lab/evidence'; B=R/'baseline-work'; W=R/'test-lab-work'
if W.exists():shutil.rmtree(W)
shutil.copytree(B,W,ignore=shutil.ignore_patterns('node_modules'))
(W/'node_modules').symlink_to(B/'node_modules',target_is_directory=True)
env=os.environ.copy();env['CI']='true'
base=json.load(open(O/'tests-ignore.json'))
def inventory(doc):
 rows=[]
 for f in doc['testResults']:
  path=f['name'].split('/tests/',1)[1]
  for t in f['assertionResults']:rows.append({'file':'tests/'+path,'name':t['fullName'],'status':t['status']})
 return sorted(rows,key=lambda x:(x['file'],x['name'],x['status']))
bi=inventory(base); (O/'baseline-inventory.json').write_text(json.dumps(bi,indent=2))
assert len(bi)==1087
from collections import Counter
def compare(inv):
 b=Counter((x['file'],x['name']) for x in bi);h=Counter((x['file'],x['name']) for x in inv)
 return {'missing':sum((b-h).values()),'added':sum((h-b).values()),'notPassed':sum(x['status']!='passed' for x in inv),'count':len(inv)}
trusted=R/'lab/prototypes/trusted-vitest.config.mjs'
trusted.write_text("export default { test: { include: ['tests/**/*.test.ts'], exclude: [], allowOnly: false, passWithNoTests: false } };\n")
results=[]
def run(name,trustedConfig=False):
 output=O/(name+'.json');args=['node',str(B/'node_modules/vitest/vitest.mjs'),'run','--reporter=json','--outputFile='+str(output)]
 if trustedConfig:args+=['--config',str(trusted)]
 p=subprocess.run(args,cwd=W,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=90);(O/(name+'.log')).write_bytes(p.stdout)
 doc=json.load(open(output));res={'experiment':name,'exit':p.returncode,**compare(inventory(doc)),'passed':doc['numPassedTests'],'pending':doc['numPendingTests'],'todo':doc['numTodoTests']};results.append(res);print(json.dumps(res),flush=True)
run('trusted-baseline',True)
f=W/'tests/forge/identity.test.ts';orig=f.read_text()
f.unlink();run('deleted-test');f.write_text(orig)
f.write_text(re.sub(r'\bit\(', 'it.skip(',orig,count=1) if 'it(' in orig else re.sub(r'\btest\(', 'test.skip(',orig,count=1));run('skipped-test');f.write_text(orig)
f.write_text(re.sub(r'\bdescribe\(', 'describe.skip(',orig,count=1));run('skipped-describe');f.write_text(orig)
f.write_text(orig+"\nit.todo('LAB todo marker');\n" if re.search(r'\bit\b',orig) else orig+"\ntest.todo('LAB todo marker');\n");run('todo-test');f.write_text(orig)
(W/'vitest.config.mjs').write_text("export default { test: { include: ['tests/forge/identity.test.ts'] } };\n")
run('injected-config');run('injected-config-trusted-override',True)
(W/'vitest.config.mjs').unlink()
# package and tsconfig shrinkage demonstrated in isolated copy.
pkg=json.loads((W/'package.json').read_text());pkg['scripts']['test']='vitest run tests/forge/identity.test.ts';(W/'package.json').write_text(json.dumps(pkg))
p=subprocess.run(['npm','test','--','--reporter=json','--outputFile='+str(O/'package-shrink.json')],cwd=W,env=env,capture_output=True,timeout=90)
doc=json.load(open(O/'package-shrink.json'));results.append({'experiment':'package-shrink','exit':p.returncode,**compare(inventory(doc))})
# Type error: complete tsconfig fails, narrowed config succeeds.
(W/'src/lab-error.ts').write_text('const labValue: number = "wrong";\n')
a=subprocess.run(['node',str(B/'node_modules/typescript/bin/tsc'),'--noEmit'],cwd=W,capture_output=True)
ts=json.loads((W/'tsconfig.json').read_text());ts['include']=['src/forge/primitives.ts'];(W/'tsconfig.json').write_text(json.dumps(ts))
b=subprocess.run(['node',str(B/'node_modules/typescript/bin/tsc'),'--noEmit'],cwd=W,capture_output=True)
results.append({'experiment':'tsconfig-shrink','fullConfigExit':a.returncode,'shrunkConfigExit':b.returncode});assert a.returncode!=0 and b.returncode==0
(O/'test-lab-summary.json').write_text(json.dumps(results,indent=2)+'\n')
