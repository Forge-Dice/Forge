#!/usr/bin/env python3
"""Logical model, NOT a GitHub emulator or live authorization test."""
import json,pathlib,itertools
O=pathlib.Path(__file__).resolve().parents[1]/'evidence'
OWNER='Wuerfelduell';DEV='forge-codex';ACTIONS='github-actions'
def namespace(ref):
 if ref=='main':return 'main'
 for ns,prefix in [('codex','forge/run/codex/'),('owner','forge/owner/'),('contract','forge/contract/')]:
  if ref.startswith(prefix) and len(ref)>len(prefix):return ns
 return 'closed'
def applicable(ref,tag=False):
 if tag:return ['R7']
 ns=namespace(ref)
 return ['R1']+({'main':['R2','R3'],'codex':['R4'],'owner':['R5'],'contract':['R5'],'closed':['R6']}[ns])
def allowed(actor,ref,op,checks=True,review=True,tag=False,omit=None):
 for r in applicable(ref,tag):
  if r==omit:continue
  bypass=(r=='R3' and actor==OWNER and op=='merge') or (r=='R4' and actor==DEV) or (r=='R5' and actor==OWNER)
  if bypass:continue
  if r=='R1' and op in ['delete','force']:return False
  if r=='R2' and op in ['update','force','merge'] and (op!='merge' or not checks or not review):return False
  if r in ['R3','R4','R5','R6'] and op in ['create','update','force','merge']:return False
  if r=='R7':return False
 return True
rows=[]
for actor,ref,op,expected in [(OWNER,'main','update',False),(DEV,'main','update',False),(OWNER,'forge/owner/OPS-1','create',True),(DEV,'forge/run/codex/DRILL-1','create',True),(OWNER,'forge/run/codex/DRILL-1','update',False),(DEV,'forge/owner/OPS-1','update',False),(DEV,'forge/run/codex/DRILL-1','delete',False),(DEV,'forge/run/codex/DRILL-1','force',False),(OWNER,'stray','create',False),(DEV,'forge/run/claude/x','create',False),(OWNER,'forge/contract/C-v1','create',True),(DEV,'main','merge',False),(OWNER,'main','merge',True),(ACTIONS,'main','merge',False)]:
 actual=allowed(actor,ref,op);assert actual==expected;rows.append({'actor':actor,'ref':ref,'operation':op,'result':'ALLOW' if actual else 'DENY'})
for actor in [OWNER,DEV,ACTIONS]:
 for op in ['create','update','delete']:assert not allowed(actor,'v1',op,tag=True)
 for ref in ['main','forge/owner/a','forge/contract/a','forge/run/codex/a','forge/run/claude/a','stray']:
  assert not allowed(actor,ref,'delete');assert not allowed(actor,ref,'force')
assert not allowed(OWNER,'main','merge',checks=False);assert not allowed(OWNER,'main','merge',review=False)
witnesses={}
for r in ['R1','R2','R3','R4','R5','R6','R7']:
 found=[]
 for actor,ref,op,checks,tag in itertools.product([OWNER,DEV,ACTIONS],['main','forge/run/codex/x','forge/owner/x','forge/contract/x','stray','v1'],['create','update','delete','force','merge'],[True,False],[False,True]):
  if not allowed(actor,ref,op,checks=checks,tag=tag) and allowed(actor,ref,op,checks=checks,tag=tag,omit=r):found.append({'actor':actor,'ref':ref,'op':op,'checks':checks,'tag':tag})
 assert found;witnesses[r]=found[0]
(O/'ruleset-model.json').write_text(json.dumps({'label':'EXPERIMENTALLY VERIFIED local model; GitHub enforcement INFERRED','matrix':rows,'removalCounterexamples':witnesses},indent=2))
print('7 rules individually necessary in this modeled decomposition; 14 matrix assertions + invariants passed')
