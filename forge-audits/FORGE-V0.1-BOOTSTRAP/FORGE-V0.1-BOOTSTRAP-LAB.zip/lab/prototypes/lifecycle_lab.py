import pathlib,tempfile,json,subprocess,shutil
out=pathlib.Path(__file__).resolve().parents[1]/'evidence/lifecycle-lab.json';d=pathlib.Path(tempfile.mkdtemp(prefix='forge-npm-lab-'))
(d/'package.json').write_text(json.dumps({'name':'local-lifecycle-probe','version':'1.0.0','scripts':{'preinstall':'node -e "require(\'fs\').writeFileSync(\'pre-marker\',\'ok\')"','postinstall':'node -e "require(\'fs\').writeFileSync(\'post-marker\',\'ok\')"','test':'node -e "require(\'fs\').writeFileSync(\'test-marker\',\'ok\')"'}}))
subprocess.run(['npm','install','--package-lock-only','--ignore-scripts','--no-audit','--no-fund'],cwd=d,check=True,capture_output=True)
rows=[]
for flags in [[],['--ignore-scripts']]:
 for f in d.glob('*-marker'):f.unlink()
 p=subprocess.run(['npm','ci','--no-audit','--no-fund',*flags],cwd=d,capture_output=True)
 rows.append({'command':['npm','ci',*flags],'exit':p.returncode,'preinstall':(d/'pre-marker').exists(),'postinstall':(d/'post-marker').exists()})
p=subprocess.run(['npm','test','--ignore-scripts'],cwd=d,capture_output=True);rows.append({'command':['npm','test','--ignore-scripts'],'exit':p.returncode,'explicitTestRan':(d/'test-marker').exists()})
out.write_text(json.dumps(rows,indent=2));print(out.read_text());shutil.rmtree(d)
