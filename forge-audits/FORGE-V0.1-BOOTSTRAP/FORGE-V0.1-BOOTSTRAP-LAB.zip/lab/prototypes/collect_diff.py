#!/usr/bin/env python3
"""Object-only canonical diff. Use a NEW verifier-owned bare repository.
Reject borrowed object stores, replacements and shallow/graft metadata.
No rename inference. A content+mode change has both change types.
"""
import os,sys,re,json,base64,pathlib,subprocess

def collect(repo,base,head):
 repo=pathlib.Path(repo).resolve()
 for sha in (base,head):
  if not re.fullmatch('[0-9a-f]{40}',sha):raise ValueError('full SHA-1 required')
 for p in ['objects/info/alternates','info/grafts','shallow']:
  if (repo/p).exists():raise ValueError('unsupported repository metadata: '+p)
 env={'PATH':os.environ['PATH'],'HOME':'/nonexistent','LC_ALL':'C','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_NO_REPLACE_OBJECTS':'1','GIT_TERMINAL_PROMPT':'0','GIT_NO_LAZY_FETCH':'1'}
 def git(*args):
  return subprocess.run(['git','--git-dir='+str(repo),'-c','core.hooksPath=/dev/null','-c','core.attributesFile=/dev/null',*args],env=env,check=True,capture_output=True,timeout=20).stdout
 if git('for-each-ref','--format=%(refname)','refs/replace/').strip():raise ValueError('replace refs disallowed')
 def tree(sha):
  if git('cat-file','-t',sha).strip()!=b'commit':raise ValueError('commit required')
  out={}
  for rec in git('ls-tree','-r','-z','--full-tree',sha).split(b'\0'):
   if rec:
    meta,p=rec.split(b'\t',1);mode,kind,oid=meta.split(b' ');out[p]=(mode.decode(),kind.decode(),oid.decode())
  return out
 a,b=tree(base),tree(head);rows=[]
 for p in sorted(a.keys()|b.keys()):
  x,y=a.get(p),b.get(p)
  if x==y:continue
  types=['ADD'] if x is None else ['DELETE'] if y is None else (['MODIFY'] if x[2]!=y[2] else [])+(['MODE_CHANGE'] if x[0]!=y[0] else [])
  rows.append({'path':p.decode('utf-8','backslashreplace'),'pathBase64':base64.b64encode(p).decode(),'types':types,'oldMode':x[0] if x else None,'newMode':y[0] if y else None,'oldBlob':x[2] if x and x[1]=='blob' else None,'newBlob':y[2] if y and y[1]=='blob' else None,'oldObject':x[2] if x else None,'newObject':y[2] if y else None,'oldType':x[1] if x else None,'newType':y[1] if y else None})
 return rows
if __name__=='__main__':print(json.dumps(collect(*sys.argv[1:]),ensure_ascii=True,indent=2))
