export default { test: { include: ['tests/**/*.test.ts'], exclude: [], allowOnly: false, passWithNoTests: false } };
