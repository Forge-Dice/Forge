FORGE V0.1 BOOTSTRAP EXPERIMENTAL LAB
2026-10-03 — canonical repository read-only

This package contains no credentials, node_modules, cloned repository or deployed workflow.
All prototypes are local experimental code, not a production security verifier.
Workflow and TypeScript files end in .txt deliberately: DESIGN ONLY.

Evidence overview:
- remote-repository.json / remote-pulls-2.json / remote-rulesets.json: read-only GitHub API snapshots.
- baseline-files.json and remote-main-final.txt: pinned main files and final remote SHA.
- git-lab.json: adversarial Git object tests and command outcomes.
- canonical-diff-adversarial.json: canonical changes including modes and blob/object IDs.
- pr2-canonical-diff.json: empty diff for the identity spike.
- tests-ignore.json / tests-normal.json: full baseline runs, 1087 tests each.
- baseline-inventory.json: normalized test identities/statuses.
- test-lab-summary.json: independent deletion/skip/todo/config/package/tsconfig probes.
- vitest-list.json vs vitest-list-runtime.json: 370 static vs 1087 runtime cases.
- lifecycle-lab.json: harmless local marker experiment.
- installed-lifecycle-scripts.json: presence of prepare scripts, not evidence of execution.
- ruleset-model.json: local logical model, NOT GitHub enforcement evidence.

Reproduce in a fresh disposable parent directory (network + Linux + Node >=22 required;
recorded runtime was Node 24.19.0, npm 11.9.0, Git 2.51.1):
1. Unpack package; keep lab/ directory and prototypes/ as provided.
2. Clone canonical repo read-only into baseline/ with --no-checkout.
3. Verify commit 3d7545d843883418348004e68717399a64da7a7d exists.
4. Export that exact commit with git archive into baseline-work/ and normal-work/.
5. In baseline-work: npm ci --ignore-scripts --no-audit --no-fund;
   npm run typecheck;
   npm test -- --reporter=json --outputFile=../lab/evidence/tests-ignore.json
6. In normal-work: npm ci --foreground-scripts --no-audit --no-fund;
   npm run typecheck;
   npm test -- --reporter=json --outputFile=../lab/evidence/tests-normal.json
7. From parent:
   python3 lab/prototypes/git_lab.py
   python3 lab/prototypes/ruleset_model.py
   python3 lab/prototypes/lifecycle_lab.py
   python3 lab/prototypes/test_lab.py
8. Optional current baseline list commands (in baseline-work):
   node node_modules/vitest/vitest.mjs list --json=../lab/evidence/vitest-list.json
   node node_modules/vitest/vitest.mjs list --no-staticParse --json=../lab/evidence/vitest-list-runtime.json

The test_lab deliberately executes only known harmless local mutations and reuses
baseline node_modules via a symlink for speed. This is NOT the proposed production
sandbox or secure dependency materialization procedure. Do not run unknown PRs this way.
Git fixtures create and delete only fresh tempfile directories; their SHAs vary with time.
The source export and all GitHub interactions in the original experiment were read-only.

Required live follow-up and the exact five-step bootstrap are in the HTML report.
