import subprocess, shutil, json
CS="src/domain/case-solution.ts"; CA="src/domain/case-accusation.ts"
M=[
("m1",CS,'if (resolution === undefined) return Object.freeze({ success: true, status: "undetermined" });','if (resolution === undefined) return Object.freeze({ success: true, status: false });'),
("m2",CS,'solution.caseId !== truth.caseId || solution.truthHash !== hashCaseTruth(truth)','solution.caseId !== truth.caseId'),
("m3",CA,'if (evaluation.status !== "undetermined" && evaluation.status !== literal.value) contradicted = true;','if (evaluation.status !== literal.value) contradicted = true;'),
("m4",CA,'if (evaluation.status !== "undetermined" && evaluation.status !== literal.value) contradicted = true;','if (evaluation.status === false && literal.value) contradicted = true;'),
("m5",CA,'const covered = solution.requiredConclusions.every(','const covered = solution.requiredConclusions.some('),
("m6",CA,'const key = claimKey(literal.claim);','const key = `${claimKey(literal.claim)}|${String(literal.value)}`;'),
("m7",CA,'if (accusation.caseId !== truth.caseId || accusation.truthHash !== truthHash) return failure("ACCUSATION_BINDING_MISMATCH");','if (accusation.caseId !== truth.caseId) return failure("ACCUSATION_BINDING_MISMATCH");'),
("m8",CA,'if (solution.caseId !== truth.caseId || solution.truthHash !== truthHash) return failure("SOLUTION_BINDING_MISMATCH");',''),
("x9-person-ref-eval",CS,'const personKnown = !("personId" in c) || truth.persons.some((p) => p.id === c.personId);','const personKnown = true;'),
("x10-parse-ref",CA,'if ("personId" in claim && !persons.has(claim.personId))','if (false)'),
("x11-coverage-polarity",CA,'asserted.get(claimKey(catalog.get(literal.conclusionId)!)) === literal.value','asserted.has(claimKey(catalog.get(literal.conclusionId)!))'),
("x12-binding-abort",CA,'  if (!bound) return;\n',''),
]
out=[]
for mid,f,b,a in M:
    src=open(f).read(); n=src.count(b)
    if n!=1: out.append((mid,"ANCHOR_COUNT_%d"%n)); continue
    shutil.copy(f,f+".bak"); open(f,"w").write(src.replace(b,a))
    tc=subprocess.run(["npx","tsc","--noEmit"],capture_output=True).returncode
    t=subprocess.run(["npx","vitest","run","tests/acc.test.ts","tests/case-solution.test.ts"],capture_output=True,text=True)
    shutil.move(f+".bak",f)
    out.append((mid,"tsc=%d"%tc,"KILLED" if t.returncode!=0 else "SURVIVED", [l.strip() for l in t.stdout.splitlines() if l.strip().startswith("×") or "FAIL" in l][:4]))
for o in out: print(json.dumps(o))
