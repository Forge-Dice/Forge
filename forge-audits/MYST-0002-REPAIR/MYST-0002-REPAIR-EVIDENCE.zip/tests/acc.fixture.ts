import { parseCaseTruth } from "../src/domain/case-truth.ts";
import { hashCaseTruth } from "../src/domain/case-truth.identity.ts";
import { parseCaseSolution } from "../src/domain/case-solution.ts";
import { solutionTruthInput } from "./case-solution.fixture.ts";
export const T1 = parseCaseTruth(solutionTruthInput());
export const T2 = parseCaseTruth({ ...solutionTruthInput(), revision: 2 });
const P = (x: string) => `person:${x}`, E = (x: string) => `event:${x}`;
export const resp = (p: string, e = "death") => ({ kind: "personResponsibleForEvent", personId: P(p), eventId: E(e) });
export const role = (p: string, r: string, e = "death") => ({ kind: "personRoleForEvent", personId: P(p), eventId: E(e), role: r });
export const nobody = (e = "death") => ({ kind: "noPersonResponsibleForEvent", eventId: E(e) });
export const caused = (c: string, e = "death") => ({ kind: "eventCausedEvent", causeEventId: E(c), eventId: E(e) });
export const intent = (v: string, e = "death") => ({ kind: "eventIntent", eventId: E(e), value: v });
export const mech = (v: string, e = "death") => ({ kind: "eventMechanism", eventId: E(e), value: v });
export const res = (eventId: string, completeness: string, assignments: any[], i: any, m: any, cc: boolean) => ({ eventId: E(eventId), targets: [], responsibility: { completeness, assignments }, intent: i, mechanism: m, causesComplete: cc });
export function solInput(rev: number, resolutions: any[], req: [any, boolean][], truth = T1) {
  return { schemaVersion: 1, caseId: "case:poison", revision: rev, truthHash: hashCaseTruth(truth), resolutions,
    conclusions: req.map(([c], i) => ({ id: `conclusion:r${i}`, claim: c })), requiredConclusions: req.map(([, v], i) => ({ conclusionId: `conclusion:r${i}`, value: v })) };
}
const sol = (rev: number, r: any[], q: [any, boolean][], truth = T1) => parseCaseSolution(solInput(rev, r, q, truth), truth);
const s1r = () => [res("death", "complete", [{ personId: P("a"), roles: ["direct_actor", "planner"] }], "intended", "ordinary", true), res("poisoning", "partial", [{ personId: P("a"), roles: null }], null, null, false)];
const s1q = (): [any, boolean][] => [[resp("a"), true], [resp("b"), false], [intent("intended"), true]];
export const SOL: Record<string, any> = {
  S1: sol(1, s1r(), s1q()),
  S2: sol(2, [res("death", "complete", [{ personId: P("b"), roles: ["direct_actor"] }], "unintended", "ordinary", true)], [[resp("b"), true], [resp("a"), false]]),
  S3: sol(3, [res("death", "complete", [{ personId: P("a"), roles: ["planner"] }, { personId: P("b"), roles: ["direct_actor"] }], "intended", "ordinary", true)], [[resp("a"), true], [resp("b"), true], [role("b", "direct_actor"), true]]),
  S4: sol(4, [res("death", "complete", [], "not_applicable", "ordinary", true)], [[nobody(), true]]),
  S5: sol(5, [res("death", "partial", [{ personId: P("a"), roles: null }], null, "mixed", false)], [[resp("a"), true], [mech("mixed"), true]]),
  S6: sol(6, [res("death", "partial", [{ personId: P("a"), roles: ["direct_actor"] }], "intended", "ordinary", false)], [[role("a", "direct_actor"), true]]),
  S7: sol(7, [res("death", "partial", [], null, null, false)], [[caused("poisoning"), true]]),
  S1T2: sol(1, s1r(), s1q(), T2),
};
export const X1: [any, boolean][] = s1q();
export const acc = (lits: [any, boolean][], truth = T1) => ({ schemaVersion: 1, caseId: "case:poison", truthHash: hashCaseTruth(truth), literals: lits.map(([claim, value]) => ({ claim: structuredClone(claim), value })) });
export function universe(): any[] {
  const persons = ["a","b","c"], events = ["purchase","poisoning","death","storm"], roles=["direct_actor","planner","facilitator"];
  const all: any[] = [];
  for (const e of events) { for (const p of persons) { all.push(resp(p, e)); for (const r of roles) all.push(role(p, r, e)); } all.push(nobody(e)); for (const c of events) if (c !== e) all.push(caused(c, e)); for (const v of ["intended","unintended","not_applicable"]) all.push(intent(v, e)); for (const v of ["ordinary","supernatural","mixed"]) all.push(mech(v, e)); }
  return all;
}
