import { describe, expect, it } from "vitest";
import { ZodError } from "zod";
import { parseCaseTruth } from "../src/domain/case-truth.ts";
import { createAccusationSchema, evaluateAccusation, parseAccusation } from "../src/domain/case-accusation.ts";
import { evaluateConclusionClaim } from "../src/domain/case-solution.ts";
import { solutionTruthInput } from "./case-solution.fixture.ts";
import { SOL, T1, T2, X1, acc, caused, intent, mech, nobody, resp, role, universe } from "./acc.fixture.ts";
const v = (s: string, lits: [any, boolean][]) => { const r = evaluateAccusation(T1, SOL[s], parseAccusation(acc(lits), T1)); if (!r.success) throw new Error(r.code); return r.verdict; };
const schema = createAccusationSchema(T1);
const pathsOf = (input: unknown) => { const r = schema.safeParse(input); return r.success ? null : r.error.issues.map((i) => JSON.stringify(i.path)); };
const S5 = (...x: [any, boolean][]): [any, boolean][] => [[resp("a"), true], [mech("mixed"), true], ...x];
const S3X: [any, boolean][] = [[resp("a"), true], [resp("b"), true], [role("b", "direct_actor"), true]];
describe("AV verdicts", () => {
  it.each<[string, string, [any, boolean][], string]>([
    ["AV-01", "S1", [], "not_solved"], ["AV-02", "S1", X1, "solved"], ["AV-03", "S1", [...X1].reverse(), "solved"],
    ["AV-04", "S1", [X1[1]!, X1[2]!], "not_solved"], ["AV-05", "S1", [X1[0]!, X1[2]!], "not_solved"], ["AV-06", "S1", [X1[0]!, X1[1]!], "not_solved"],
    ["AV-07", "S1", [[resp("a"), false], X1[1]!, X1[2]!], "not_solved"], ["AV-08", "S1", [X1[0]!, [resp("b"), true], X1[2]!], "not_solved"],
    ["AV-09", "S1", [...X1, [role("a", "planner"), true]], "solved"], ["AV-10", "S1", [...X1, [resp("c"), false]], "solved"],
    ["AV-11", "S1", [...X1, [resp("c"), true]], "not_solved"], ["AV-12", "S1", [...X1, [role("a", "facilitator"), true]], "not_solved"],
    ["AV-13", "S1", [...X1, [role("a", "facilitator"), false]], "solved"], ["AV-14", "S1", [...X1, [role("a", "direct_actor"), false]], "not_solved"],
    ["AV-15", "S1", [...X1, [intent("intended", "poisoning"), true]], "solved"], ["AV-16", "S1", [...X1, [resp("b", "purchase"), true]], "solved"],
    ["AV-17", "S1", [...X1, [resp("a", "storm"), false]], "solved"], ["AV-18", "S1", [...X1, [caused("poisoning"), true]], "solved"],
    ["AV-19", "S1", [...X1, [caused("purchase"), true]], "not_solved"], ["AV-20", "S1", [...X1, [caused("storm"), false]], "solved"],
    ["AV-21", "S1", [...X1, [caused("storm", "poisoning"), true]], "solved"], ["AV-22", "S1", [...X1, [caused("purchase", "poisoning"), false]], "not_solved"],
    ["AV-23", "S1", [...X1, [intent("unintended"), true]], "not_solved"], ["AV-24", "S1", [...X1, [intent("unintended"), false]], "solved"],
    ["AV-25", "S1", [...X1, [mech("ordinary"), true]], "solved"], ["AV-26", "S1", [...X1, [mech("mixed"), true]], "not_solved"],
    ["AV-27", "S1", [...X1, [nobody(), true]], "not_solved"], ["AV-28", "S1", [...X1, [nobody(), false]], "solved"],
    ["AV-29", "S1", [...X1, [nobody("poisoning"), true]], "not_solved"],
    ["AV-30", "S1", [...X1, [intent("intended", "poisoning"), true], [intent("unintended", "poisoning"), true]], "solved"],
    ["AV-31", "S1", [X1[0]!, X1[2]!, [resp("c"), true]], "not_solved"],
    ["AV-32", "S1", [...X1, [role("a", "direct_actor"), true], [nobody(), false], [caused("poisoning"), true], [mech("ordinary"), true]], "solved"],
    ["AV-33", "S1", [...X1, [resp("a", "poisoning"), true]], "solved"], ["AV-34", "S1", [...X1, [role("a", "planner", "poisoning"), true]], "solved"],
    ["AV-35", "S1", [...X1, [resp("b", "poisoning"), true]], "solved"],
    ["AV-36", "S5", S5(), "solved"], ["AV-37", "S5", S5([resp("b"), true], [resp("c"), true]), "solved"], ["AV-38", "S5", S5([role("a", "planner"), true]), "solved"],
    ["AV-39", "S5", S5([nobody(), true]), "not_solved"], ["AV-40", "S5", S5([intent("intended"), true]), "solved"], ["AV-41", "S5", S5([mech("ordinary"), true]), "not_solved"],
    ["AV-42", "S5", S5([caused("storm"), true]), "solved"], ["AV-43", "S5", S5([resp("b"), false]), "solved"], ["AV-44", "S5", S5([caused("purchase"), true]), "solved"],
    ["AV-45", "S6", [[role("a", "direct_actor"), true]], "solved"], ["AV-46", "S6", [[role("a", "direct_actor"), true], [role("a", "planner"), true]], "not_solved"],
    ["AV-47", "S6", [[role("a", "direct_actor"), true], [resp("b"), true]], "solved"],
    ["AV-48", "S3", S3X, "solved"], ["AV-49", "S3", S3X.slice(1), "not_solved"], ["AV-50", "S3", [...S3X, [role("a", "planner"), true]], "solved"],
    ["AV-51", "S3", [...S3X, [role("a", "direct_actor"), true]], "not_solved"], ["AV-52", "S3", [...S3X, [resp("c"), true]], "not_solved"],
    ["AV-53", "S4", [[nobody(), true]], "solved"], ["AV-54", "S4", [[nobody(), true], [resp("a"), true]], "not_solved"], ["AV-55", "S4", [], "not_solved"],
    ["AV-56", "S4", [[resp("a"), false], [resp("b"), false], [resp("c"), false]], "not_solved"], ["AV-57", "S4", [[nobody(), true], [intent("not_applicable"), true]], "solved"],
    ["AV-58", "S2", X1, "not_solved"], ["AV-59", "S2", [[resp("b"), true], [resp("a"), false]], "solved"],
    ["AV-60", "S7", [[caused("poisoning"), true], [nobody(), true]], "solved"],
    ["AV-61", "S7", [[caused("poisoning"), true], [resp("a"), true], [resp("b"), true], [resp("c"), true]], "solved"],
    ["AV-62", "S5", S5(...["direct_actor", "planner", "facilitator"].map((r): [any, boolean] => [role("a", r), true])), "solved"],
    ["AV-63", "S1", [...X1, [role("a", "direct_actor"), true], [role("a", "planner"), true]], "solved"],
    ["AV-65", "S1", [[role("a", "planner"), true], [caused("poisoning"), true], [resp("c"), false]], "not_solved"],
    ["AV-64", "S1", [...X1, [resp("b", "purchase"), true], [resp("c", "storm"), true], [caused("storm", "poisoning"), true], [mech("supernatural", "poisoning"), true]], "solved"],
  ])("%s", (_n, s, lits, exp) => expect(v(s, lits)).toBe(exp));
});
describe("AP parse", () => {
  it("AP-01", () => { for (const x of [null, [], "x", {}]) { expect(() => schema.safeParse(x)).not.toThrow(); expect(schema.safeParse(x).success).toBe(false); } });
  it("AP-02/03/04/05/06/07", () => {
    expect(pathsOf({ ...acc(X1), schemaVersion: 2 })).toContain('["schemaVersion"]');
    expect(pathsOf({ ...acc(X1), solutionHash: "0".repeat(64) })).not.toBeNull();
    const a: any = acc(X1); a.literals[0].conclusionId = "conclusion:r0"; expect(pathsOf(a)).not.toBeNull();
    expect(pathsOf(acc([[{ ...nobody(), personId: "person:a" }, true]]))).not.toBeNull();
    const b: any = acc(X1); delete b.literals; expect(pathsOf(b)).not.toBeNull();
    const c: any = acc(X1); c.literals[0].value = "true"; expect(pathsOf(c)).not.toBeNull();
    const d: any = acc(X1); d.literals[0].value = null; expect(pathsOf(d)).not.toBeNull();
  });
  it("AP-08 binding short-circuits", () => expect(pathsOf({ ...acc([[resp("z"), true]]), caseId: "case:other" })).toEqual(['["caseId"]']));
  it("AP-09/10", () => {
    expect(pathsOf(acc(X1, T2))).toEqual(['["truthHash"]']);
    const t3 = parseCaseTruth({ ...solutionTruthInput(), title: "anders" });
    expect(pathsOf(acc(X1, t3))).toEqual(['["truthHash"]']);
  });
  it("AP-11..18", () => {
    expect(pathsOf(acc([[resp("z"), true]]))).toEqual(['["literals",0,"claim","personId"]']);
    expect(pathsOf(acc([[resp("a", "ghost"), true]]))).toEqual(['["literals",0,"claim","eventId"]']);
    expect(pathsOf(acc([[caused("ghost"), true]]))).toEqual(['["literals",0,"claim","causeEventId"]']);
    for (const bad of [{ ...resp("a"), personId: "item:k" }, { ...resp("a"), eventId: "person:a" }, caused("death"), { kind: "personGuilty", personId: "person:a", eventId: "event:death" }, role("a", "accomplice"), intent("accidental"), mech("magic")])
      expect(pathsOf(acc([[bad, true]]))).not.toBeNull();
  });
  it("AP-19/20/21 duplicates", () => {
    expect(pathsOf(acc([[resp("a"), true], [resp("a"), true]]))).toEqual(['["literals",1,"claim"]']);
    expect(pathsOf(acc([[resp("a"), true], [resp("a"), false]]))).toEqual(['["literals",1,"claim"]']);
    const r = resp("a"); const reordered = { eventId: r.eventId, personId: r.personId, kind: r.kind };
    expect(pathsOf(acc([[resp("a"), true], [reordered, true]]))).toEqual(['["literals",1,"claim"]']);
  });
  it("AP-22 reorder single", () => { const r = resp("a"); expect(v("S1", [[{ eventId: r.eventId, kind: r.kind, personId: r.personId }, true], X1[1]!, X1[2]!])).toBe("solved"); });
  it("AP-23/24 immutability", () => {
    const input: any = acc(X1); const a: any = parseAccusation(input, T1);
    input.literals[0].value = false; input.literals[0].claim.personId = "person:b"; input.literals.push({ claim: nobody(), value: true });
    expect(a.literals).toHaveLength(3); expect(a.literals[0].value).toBe(true); expect(a.literals[0].claim.personId).toBe("person:a");
    expect(Object.isFrozen(input)).toBe(false);
    for (const o of [a, a.literals, a.literals[0], a.literals[0].claim]) expect(Object.isFrozen(o)).toBe(true);
    const before = JSON.stringify(a);
    for (const f of [() => (a.caseId = "x"), () => a.literals.push(1), () => (a.literals[0].value = false), () => (a.literals[0].claim.personId = "person:b")]) expect(f).toThrow(TypeError);
    expect(JSON.stringify(a)).toBe(before);
  });
  it("AP-25 no cap", () => { const u = universe(); expect(u).toHaveLength(88); const r = evaluateAccusation(T1, SOL.S1, parseAccusation(acc(u.map((c) => [c, true])), T1)); expect(r.success).toBe(true); });
  it("AP-26 throws ZodError", () => expect(() => parseAccusation({}, T1)).toThrow(ZodError));
});
describe("AB binding", () => {
  it("AB-01", () => expect(evaluateAccusation(T2, SOL.S1T2, parseAccusation(acc(X1), T1))).toEqual({ success: false, code: "ACCUSATION_BINDING_MISMATCH" }));
  it("AB-02", () => expect(evaluateAccusation(T1, SOL.S1T2, parseAccusation(acc(X1), T1))).toEqual({ success: false, code: "SOLUTION_BINDING_MISMATCH" }));
  it("AB-03", () => { const r: any = evaluateAccusation(T1, SOL.S1T2, parseAccusation(acc([]), T1)); expect(r).toEqual({ success: false, code: "SOLUTION_BINDING_MISMATCH" }); expect("verdict" in r).toBe(false); expect(Object.isFrozen(r)).toBe(true); });
  it("AB-05", () => { const a = parseAccusation(acc(X1), T1); expect(evaluateAccusation(T1, SOL.S1, a)).toEqual({ success: true, verdict: "solved" }); expect(evaluateAccusation(T1, SOL.S2, a)).toEqual({ success: true, verdict: "not_solved" }); });
});
describe("AE", () => {
  it("AE-01/02", () => {
    const a = parseAccusation(acc(X1), T1); const snap = JSON.stringify([a, T1, SOL.S1]);
    const rs = [1, 2, 3].map(() => evaluateAccusation(T1, SOL.S1, a));
    expect(rs[0]).toEqual(rs[2]); expect(Object.isFrozen(rs[0])).toBe(true); expect(JSON.stringify([a, T1, SOL.S1])).toBe(snap);
    expect(Object.keys(rs[0]!).sort()).toEqual(["success", "verdict"]); expect(JSON.stringify(rs[0])).not.toMatch(/person:|event:|conclusion:|[0-9a-f]{64}/);
  });
});
describe("AC-E evaluateConclusionClaim", () => {
  it("AC-E1/2/3/4", () => {
    for (const x of [{ kind: "x" }, null, "s", []]) expect(evaluateConclusionClaim(T1, SOL.S1, x)).toEqual({ success: false, code: "INVALID_CLAIM" });
    expect(evaluateConclusionClaim(T1, SOL.S1, resp("z"))).toEqual({ success: false, code: "UNKNOWN_REFERENCE" });
    expect(evaluateConclusionClaim(T1, SOL.S1, caused("ghost"))).toEqual({ success: false, code: "UNKNOWN_REFERENCE" });
    expect(evaluateConclusionClaim(T1, SOL.S1T2, resp("a"))).toEqual({ success: false, code: "SOLUTION_BINDING_MISMATCH" });
    expect(evaluateConclusionClaim(T1, SOL.S1T2, { kind: "x" })).toEqual({ success: false, code: "SOLUTION_BINDING_MISMATCH" });
    for (const c of [resp("a", "purchase"), role("a", "planner", "purchase"), nobody("purchase"), caused("storm", "purchase"), intent("intended", "purchase"), mech("ordinary", "purchase")])
      expect(evaluateConclusionClaim(T1, SOL.S1, c)).toEqual({ success: true, status: "undetermined" });
  });
  it("AC-E5 getter read once", () => {
    let n = 0; const c: any = { kind: "personResponsibleForEvent", eventId: "event:death", get personId() { n++; return n === 1 ? "person:a" : "person:c"; } };
    expect(evaluateConclusionClaim(T1, SOL.S1, c)).toEqual({ success: true, status: true });
  });
  it("AC-E7 metamorphic chain", () => {
    let checked = 0;
    for (const s of ["S1", "S2", "S3", "S4", "S5", "S6", "S7"]) {
      const sol = SOL[s]; const cat = new Map(sol.conclusions.map((c: any) => [c.id, c.claim]));
      const req: [any, boolean][] = sol.requiredConclusions.map((l: any) => [cat.get(l.conclusionId), l.value]);
      expect(v(s, req)).toBe("solved");
      const reqKeys = new Set(req.map(([c]) => JSON.stringify(Object.entries(c).sort())));
      for (const c of universe()) { if (reqKeys.has(JSON.stringify(Object.entries(c).sort()))) continue;
        for (const val of [true, false]) { const st: any = evaluateConclusionClaim(T1, sol, c); const exp = st.status !== "undetermined" && st.status !== val ? "not_solved" : "solved"; expect(v(s, [...req, [c, val]])).toBe(exp); checked++; } }
    }
    expect(checked).toBeGreaterThan(1000);
  });
});
