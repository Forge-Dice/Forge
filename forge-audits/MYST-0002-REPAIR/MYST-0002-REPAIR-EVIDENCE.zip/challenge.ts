import { evaluateConclusionClaim, claimKey } from "./src/domain/case-solution.ts";
import { evaluateAccusation, parseAccusation } from "./src/domain/case-accusation.ts";
import { SOL, T1, acc, universe } from "./tests/acc.fixture.ts";
const U = universe();
const scope = new Set(U.filter((c: any) => c.eventId === "event:death" && c.kind !== "eventCausedEvent").map((c: any) => claimKey(c)));
// scratch challenge wrapper: core solved AND every literal in scope, determined, polarity == canonical
function challenge(sol: any, lits: [any, boolean][]) {
  for (const [c, v] of lits) { if (!scope.has(claimKey(c))) return "not_solved"; const e: any = evaluateConclusionClaim(T1, sol, c); if (e.status === "undetermined" || e.status !== v) return "not_solved"; }
  const r: any = evaluateAccusation(T1, sol, parseAccusation(acc(lits), T1)); return r.verdict;
}
const tally: any = { accusations: 0, coreSolved: 0, challengeSolved: 0, coreOnly: 0, challengeOnly: 0, coreOnlyReasons: { undetermined: 0, outOfScope: 0, both: 0 } };
for (const s of ["S1", "S2", "S3", "S4", "S5", "S6", "S7"]) {
  const sol = SOL[s]; const cat = new Map(sol.conclusions.map((c: any) => [c.id, c.claim]));
  const req: [any, boolean][] = sol.requiredConclusions.map((l: any) => [cat.get(l.conclusionId), l.value]);
  for (const r of req) if (!scope.has(claimKey(r[0]))) scope.add(claimKey(r[0])); // authoring invariant: required ⊆ allowedClaims
  const rk = new Set(req.map(([c]) => claimKey(c)));
  const extras = U.filter((c: any) => !rk.has(claimKey(c))).flatMap((c: any) => [[c, true], [c, false]] as [any, boolean][]);
  const sets: [any, boolean][][] = [req, ...extras.map((x) => [...req, x])];
  for (let i = 0; i < extras.length; i += 7) for (let j = i + 1; j < extras.length; j += 5) if (claimKey(extras[i]![0]) !== claimKey(extras[j]![0])) sets.push([...req, extras[i]!, extras[j]!]);
  for (const lits of sets) {
    tally.accusations++;
    const core = (evaluateAccusation(T1, sol, parseAccusation(acc(lits), T1)) as any).verdict; const ch = challenge(sol, lits);
    if (core === "solved") tally.coreSolved++; if (ch === "solved") tally.challengeSolved++;
    if (ch === "solved" && core !== "solved") tally.challengeOnly++;
    if (core === "solved" && ch !== "solved") { tally.coreOnly++; const und = lits.some(([c]) => (evaluateConclusionClaim(T1, sol, c) as any).status === "undetermined"); const oos = lits.some(([c]) => !scope.has(claimKey(c))); tally.coreOnlyReasons[und && oos ? "both" : und ? "undetermined" : "outOfScope"]++; }
  }
}
console.log(JSON.stringify(tally));
