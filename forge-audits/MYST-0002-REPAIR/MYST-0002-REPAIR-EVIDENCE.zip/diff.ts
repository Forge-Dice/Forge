import { parseCaseSolution, evaluateConclusionClaim, __probeResolve, ConclusionClaimSchema } from "./src/domain/case-solution.ts";
import { T1, res, solInput, universe, resp } from "./tests/acc.fixture.ts";
const P = (x: string) => `person:${x}`;
const assignmentSets: any[][] = [
  [], [{ personId: P("a"), roles: null }], [{ personId: P("a"), roles: ["direct_actor"] }], [{ personId: P("a"), roles: ["direct_actor", "planner"] }],
  [{ personId: P("a"), roles: ["planner"] }, { personId: P("b"), roles: ["direct_actor"] }], [{ personId: P("a"), roles: null }, { personId: P("b"), roles: ["facilitator"] }],
  [{ personId: P("a"), roles: ["direct_actor", "planner", "facilitator"] }, { personId: P("b"), roles: null }, { personId: P("c"), roles: ["facilitator"] }],
];
const intents = [null, "intended", "unintended", "not_applicable"], mechs = [null, "ordinary", "supernatural", "mixed"];
const poisoningVariants = [null, res("poisoning", "complete", [{ personId: P("a"), roles: ["direct_actor"] }], "intended", null, true), res("poisoning", "partial", [], null, "ordinary", false)];
const U = universe().map((c) => ConclusionClaimSchema.parse(c));
// roles [] must be rejected by the existing schema
let rolesEmptyRejected = false; try { parseCaseSolution(solInput(1, [res("death", "complete", [{ personId: P("a"), roles: [] }], null, null, true)], [[resp("a"), true]]), T1); } catch { rolesEmptyRejected = true; }
let solutions = 0, cmpInternal = 0, cmpD5 = 0, diffs = 0, oracleCmp = 0, oracleDiff = 0; const dist: Record<string, number> = {};
const statusOf = (resolutions: any[], claim: any) => { const ok = (v: boolean) => { try { parseCaseSolution({ ...solInput(1, resolutions, []), conclusions: [{ id: "conclusion:p", claim }], requiredConclusions: [{ conclusionId: "conclusion:p", value: v }] }, T1); return true; } catch { return false; } }; const t = ok(true), f = ok(false); if (t && f) throw new Error("both"); return t ? true : f ? false : "undetermined"; };
for (const comp of ["complete", "partial"]) for (const as of assignmentSets) for (const cc of [true, false]) for (const i of intents) for (const m of mechs) for (const pv of poisoningVariants) {
  const resolutions = [res("death", comp, as, i, m, cc), ...(pv ? [pv] : [])];
  // required literal must be valid: pick the first claim with a boolean status via internal resolver
  const death = T1.events.find((e) => e.id === "event:death")!;
  const anchor = U.find((c) => c.eventId === "event:death" && typeof __probeResolve(c, resolutions[0] as any, death) === "boolean")!;
  const sol = parseCaseSolution(solInput(1, resolutions, [[anchor, __probeResolve(anchor, resolutions[0] as any, death) as boolean]]), T1);
  solutions++;
  for (const c of U) {
    const pub: any = evaluateConclusionClaim(T1, sol, c);
    const r = sol.resolutions.find((x) => x.eventId === c.eventId); const ev = T1.events.find((e) => e.id === c.eventId)!;
    if (!pub.success) { diffs++; continue; }
    dist[String(pub.status)] = (dist[String(pub.status)] ?? 0) + 1;
    if (r) { cmpInternal++; if (__probeResolve(c, r, ev) !== pub.status) diffs++; }
    else { cmpD5++; if (pub.status !== "undetermined") diffs++; }
    if (r && c.eventId === "event:death" && pv === null && (i === null || i === "intended") && (m === null || m === "mixed")) { oracleCmp++; if (statusOf(resolutions, c) !== pub.status) oracleDiff++; }
  }
}
console.log(JSON.stringify({ rolesEmptyRejected, solutions, cmpInternal, cmpD5, diffs, oracleCmp, oracleDiff, dist }));
