MYST-0002 repair evidence (scratch only; never committed to Forge-Dice/Forge).
Base: Forge-Dice/Forge main 3d7545d843883418348004e68717399a64da7a7d (git archive of src, tests, forge, tsconfig.json, package.json).
scratch-impl/case-solution.ts   base file + MYST-0002 changes per contract (2 changed lines + 27 added)
scratch-impl/case-accusation.ts scratch implementation of the contract (106 lines)
tests/acc.fixture.ts, tests/acc.test.ts  scratch matrix (83 vitest cases incl. AV-01..65, metamorphic chain)
mut.py       applies mutants (m1..m8, x9 = contract m10, x12 = contract m9, x10/x11 extra probes)
diff.ts      differential: private resolveConclusion vs evaluateConclusionClaim vs parser oracle (needs a scratch-only export appended)
challenge.ts core vs scratch challenge wrapper on bounded accusations
results.txt  captured outputs
Not an implementation deliverable; the implementer writes their own code against the contract.
