import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {parseCaseTruth} from './src/domain/case-truth.ts';
import {hashCaseTruth} from './src/domain/case-truth.identity.ts';
import {parseCaseSolution} from './src/domain/case-solution.ts';
import {hashCaseSolution} from './src/domain/case-solution.identity.ts';
import {validateCaseSemantics} from './src/domain/case-semantics.ts';
import {parseNpcKnowledge} from './src/domain/npc-knowledge.ts';
import {projectNpcKnowledge} from './src/domain/npc-knowledge.projection.ts';
import {parseContractDocument} from './src/forge/contract-document.ts';
const root=new URL('../../first-playable-case-lab/case-pack/',import.meta.url);
const read=(n:string)=>JSON.parse(fs.readFileSync(new URL(n,root),'utf8'));
const truth=parseCaseTruth(read('truth.json')), solution=parseCaseSolution(read('solution.json'),truth);
const statuses:any={};
for(const c of solution.conclusions){const accepted=[];for(const value of [false,true]){try{parseCaseSolution({...solution,requiredConclusions:[{conclusionId:c.id,value}]},truth);accepted.push(value);}catch{}}
 statuses[c.id]=accepted.length===1?accepted[0]:'undetermined';}
const npcs:any={};
for(const n of ['max','lina','nora','oskar']){const snap=parseNpcKnowledge(read(`npc-${n}.json`),truth,solution); const projected=projectNpcKnowledge(snap,truth,solution);if(!projected.success)throw Error('projection');npcs[n]={snapshot:snap,projection:projected.context};}
const report={main:'3d7545d843883418348004e68717399a64da7a7d',truthHash:hashCaseTruth(truth),solutionHash:hashCaseSolution(solution),semantics:validateCaseSemantics(truth),statuses,npcs,scope:'Current main parsers/projection only. Conclusion parser used as black-box experiment oracle; not proposed runtime implementation.'};
fs.writeFileSync(new URL('../evidence/main-validation.json',import.meta.url),JSON.stringify(report,null,2));
const contracts=fs.readdirSync(new URL('../',import.meta.url)).filter(x=>x.endsWith('.DRAFT.md'));
const checks=contracts.map(n=>{const t=fs.readFileSync(new URL('../'+n,import.meta.url),'utf8');const r=parseContractDocument(t,s=>createHash('sha256').update(s).digest('hex'));if(!r.ok)throw Error(JSON.stringify(r));return {file:n,...r.document.ref};});
fs.writeFileSync(new URL('../evidence/contract-validation.json',import.meta.url),JSON.stringify(checks,null,2));
console.log(JSON.stringify({main:report.main,semanticFindings:report.semantics.findings.length,npcs:Object.keys(npcs).length,contracts:checks.length}));
