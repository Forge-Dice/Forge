"""Disposable session semantics model. NOT production modules or PlayerRef implementation.
Fresh draft-aligned fixture adapters; actual main validation/oracle in runtime/verify-main.ts.
No imports of earlier scratch engines. Python JSON vectors here use ASCII keys/integers.
"""
import copy, hashlib, json, random
from pathlib import Path
R=Path(__file__).parent
CASE=R.parent/'first-playable-case-lab/case-pack'
def read(n): return json.loads((CASE/n).read_text())
def canon(x): return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def digest(tag,x): return hashlib.sha256((tag+'\n'+canon(x)).encode()).hexdigest()
T,S,H=read('truth.json'),read('solution.json'),read('case-host.design.json')
VALID=json.loads((R/'evidence/main-validation.json').read_text())
ENTITY={x['id']:k for k,group in [('person','persons'),('location','locations'),('item','items'),('event','events'),('evidence','evidence')] for x in T[group]}
# Finite fixture token table, explicitly NOT the missing MYST-0001 algorithm.
REF={id:'pr1_'+format(i+1,'016x') for i,id in enumerate(sorted(ENTITY))}
REV={v:k for k,v in REF.items()}
FIELDS={'personId':'person','locationId':'location','itemId':'item','eventId':'event','causeEventId':'causeEvent'}
def pubclaim(c):return {FIELDS.get(k,k):(REF[v] if k in FIELDS else v) for k,v in c.items()}
def claimrefs(c):return [(ENTITY[v],REF[v]) for k,v in c.items() if k in FIELDS]
PROPS={x['id']:x['claim'] for x in T['propositions']}
CONCS={x['id']:x['claim'] for x in S['conclusions']}
STATUS={canon(pubclaim(c)):VALID['statuses'][id] for id,c in CONCS.items()}
REQUIRED={canon(pubclaim(CONCS[x['conclusionId']])):x['value'] for x in S['requiredConclusions']}
CAT={x['id']:x for x in read('questions.design.json')['questions']}
PROFILES={f'person:{n}':{q['questionId']:q for q in read(f'interrogation-{n}.design.json')['rules']} for n in VALID['npcs']}
PRESENT={}
for eid,old in H['presentation'].items():
    claims=[PROPS[id] for id in old['observed']]
    mentions={r for c in claims for r in claimrefs(c)}
    PRESENT[eid]={'schemaVersion':1,'evidence':REF[eid],'text':old['text'],
      'mentions':[{'kind':k,'ref':v} for k,v in sorted(mentions,key=lambda x:x[1])],
      'reports':[{'claim':pubclaim(c),'stance':'affirms','source':{'kind':'observation'}} for c in claims]}
ACCESS=read('evidence-access.design.json')['entries']
def initial():return {'events':[],'phase':'active','known':sorted(REF[x['id']] for x in H['initialKnown']), 'discoveries':{},'observations':[],'verdicts':[]}
def inv(id,action=None):return {'type':'investigate','action':action or {'location':'search_location','person':'examine_person','item':'examine_item'}[ENTITY[id]],'target':REF[id]}
def ask(n,q):return {'type':'interrogate','npc':REF['person:'+n],'questionId':'question:'+q}
def accuse(person='lina'):
 return {'type':'accuse','literals':[{'claim':pubclaim(c),'value':c['personId']=='person:'+person} for c in H['challenge']['answerScope']]}
def available_claim(c,s):
 if not isinstance(c,dict):return False
 kinds={'personResponsibleForEvent':{'kind','person','event'},'personRoleForEvent':{'kind','person','event','role'},'noPersonResponsibleForEvent':{'kind','event'},'eventCausedEvent':{'kind','event','causeEvent'},'eventIntent':{'kind','event','value'},'eventMechanism':{'kind','event','value'}}
 if c.get('kind') not in kinds or set(c)!=kinds[c['kind']]:return False
 for k,kind in [('person','person'),('event','event'),('causeEvent','event')]:
  if k in c and (c[k] not in s['known'] or c[k] not in REV or ENTITY[REV[c[k]]]!=kind):return False
 if 'role' in c and c['role'] not in ['direct_actor','planner','facilitator']:return False
 if c['kind']=='eventIntent' and c['value'] not in ['intended','unintended','not_applicable']:return False
 if c['kind']=='eventMechanism' and c['value'] not in ['ordinary','supernatural','mixed']:return False
 return c.get('causeEvent')!=c.get('event') if c['kind']=='eventCausedEvent' else True
def step(s,e,fault=None):
 if s['phase']=='solved':return s,'SESSION_CLOSED'
 if len(s['events'])>=512:return s,'LIMIT_REACHED'
 if not isinstance(e,dict):return s,'ACTION_UNAVAILABLE'
 typ=e.get('type');shapes={'investigate':{'type','action','target'},'interrogate':{'type','npc','questionId'},'accuse':{'type','literals'}}
 if typ not in shapes or set(e)!=shapes[typ]:return s,'ACTION_UNAVAILABLE'
 n=copy.deepcopy(s);seq=len(s['events']);known=set(s['known'])
 if typ=='investigate':
  kind={'search_location':'location','examine_person':'person','examine_item':'item'}.get(e['action'])
  ref=e['target']
  if not isinstance(ref,str) or ref not in known or ref not in REV or ENTITY[REV[ref]]!=kind:return s,'ACTION_UNAVAILABLE'
  id=REV[ref];found=[]
  for entry in ACCESS:
   if entry['access']['kind']=='discoverable' and any(p['kind']==e['action'] and p.get(kind+'Id')==id for p in entry['access']['paths']):found.append(entry['evidenceId'])
  for eid in sorted(found,key=lambda x:REF[x]):
   if REF[eid] in n['discoveries']:continue
   if fault==eid:return s,'HOST_FAILURE'
   obs=copy.deepcopy(PRESENT[eid]);n['discoveries'][REF[eid]]=seq;known.add(REF[eid])
   n['observations'].append({'source':{'kind':'evidence','eventIndex':seq,'evidence':REF[eid]},'observation':obs})
   known.update(x['ref'] for x in obs['mentions'])
 elif typ=='interrogate':
  ref=e['npc'];qid=e['questionId']
  if not isinstance(ref,str) or ref not in known or ref not in REV or ENTITY[REV[ref]]!='person' or not isinstance(qid,str):return s,'ACTION_UNAVAILABLE'
  npc=REV[ref];rule=PROFILES.get(npc,{}).get(qid)
  if rule is None or not all(REF[x['id']] in known for x in CAT[qid]['mentions']):return s,'ACTION_UNAVAILABLE'
  obs={'schemaVersion':1,'npc':ref,'questionId':qid,'act':rule['act']}
  if rule['act']=='answer':
   snap=VALID['npcs'][npc.split(':')[1]]['snapshot'];att=next((x for x in snap['attitudes'] if (PROPS|CONCS)[x['subject']['id']]==rule['claim']),None)
   if att is None:obs['stance']='does_not_know'
   else:
    stance=att['stance'];v=stance.get('value',stance.get('leaning'))
    obs['stance']=('uncertain' if v is None else 'leans_affirms' if v else 'leans_denies') if stance['kind']=='uncertain' else ('affirms' if v else 'denies')
    obs['statement']=pubclaim(rule['claim']);obs['mentions']=[{'kind':k,'ref':r} for k,r in sorted(set(claimrefs(rule['claim'])),key=lambda x:x[1])]
    known.update(x['ref'] for x in obs['mentions'])
  if fault:return s,'HOST_FAILURE'
  n['observations'].append({'source':{'kind':'npc','eventIndex':seq,'npc':ref,'questionId':qid},'observation':obs})
 else:
  ls=e['literals']
  if not isinstance(ls,list) or len(ls)>32:return s,'ACTION_UNAVAILABLE'
  if any(not isinstance(x,dict) or set(x)!={'claim','value'} or type(x['value'])!=bool or not available_claim(x['claim'],s) for x in ls):return s,'ACTION_UNAVAILABLE'
  keys=[canon(x['claim']) for x in ls]
  if len(set(keys))!=len(keys):return s,'ACTION_UNAVAILABLE'
  submitted={canon(x['claim']):x['value'] for x in ls}
  solved=all(submitted.get(k) is v for k,v in REQUIRED.items()) and all(k in REQUIRED and STATUS[k] is v for k,v in submitted.items())
  verdict='solved' if solved else 'not_solved';n['verdicts'].append({'eventIndex':seq,'verdict':verdict});n['phase']='solved' if solved else 'active'
 n['known']=sorted(known);n['events'].append(copy.deepcopy(e));return n,'accepted'
IDENTITY={'schemaVersion':1,'packageHash':digest('fixture-package-v1',{'T':VALID['truthHash'],'S':VALID['solutionHash'],'presentation':PRESENT,'initial':H['initialKnown']}),'rulesetVersion':'mystery-session-v1'}
def save(s):
 body={'schemaVersion':1,'packageIdentity':IDENTITY,'events':s['events']}
 return canon({**body,'checksum':digest('forge-session-save-v1',body)})
def replay(events):
 s=initial()
 for i,e in enumerate(events):
  n,c=step(s,e)
  if c!='accepted':return None,{'index':i,'code':c}
  s=n
 return s,None
def load(text):
 if not isinstance(text,str) or len(text.encode())>1048576:return None,'SIZE'
 def unique(pairs):
  d={}
  for k,v in pairs:
   if k in d:raise ValueError('duplicate')
   d[k]=v
  return d
 try:o=json.loads(text,object_pairs_hook=unique)
 except (ValueError,RecursionError):return None,'FORMAT'
 if not isinstance(o,dict) or set(o)!={'schemaVersion','packageIdentity','events','checksum'} or o['schemaVersion']!=1 or not isinstance(o['events'],list):return None,'FORMAT'
 if o['packageIdentity']!=IDENTITY:return None,'INCOMPATIBLE'
 if len(o['events'])>512:return None,'LIMIT'
 body={k:v for k,v in o.items() if k!='checksum'}
 if o['checksum']!=digest('forge-session-save-v1',body):return None,'CHECKSUM'
 return replay(o['events'])
WITNESS=[inv('location:hof'),ask('nora','q08'),inv('item:kamera'),ask('oskar','q14'),inv('item:terminal')]
def run(events):
 s=initial();codes=[]
 for e in events:s,c=step(s,e);codes.append(c)
 return s,codes
def experiment():
 records=[]
 def check(name,ok):
  records.append({'id':f'X{len(records)+1:03}','case':name,'passed':bool(ok)})
  if not ok:raise AssertionError(name)
 s,codes=run(WITNESS);check('ordered witness releases both sources',all(x=='accepted' for x in codes) and REF['evidence:d04'] in s['discoveries'] and REF['evidence:d05'] in s['discoveries'])
 check('wrong order cannot read camera',step(initial(),inv('item:kamera'))[1]=='ACTION_UNAVAILABLE')
 check('unknown question indistinguishable',step(initial(),ask('nora','missing'))[1]==step(initial(),ask('nora','q08'))[1])
 check('empty search accepted',step(initial(),inv('person:max'))[1]=='accepted')
 one,_=step(initial(),inv('location:galerie'));two,_=step(one,inv('location:galerie'))
 check('repeat search no new observation',one['observations']==two['observations']);check('repeat search still an event',len(two['events'])==2)
 a,_=step(initial(),ask('max','q01'));b,_=step(a,ask('max','q01'))
 check('repeat question two provenance occurrences',len(b['observations'])==2 and b['observations'][1]['source']['eventIndex']==1)
 check('repeat NPC payload stable',b['observations'][0]['observation']==b['observations'][1]['observation'])
 fail,code=step(initial(),inv('location:galerie'),fault='evidence:d02');check('second release failure atomic',code=='HOST_FAILURE' and fail==initial())
 solved,_=step(initial(),accuse());check('correct guess solved without evidence by Challenge design',solved['phase']=='solved')
 check('wrong accusation accepted not solved',step(initial(),accuse('max'))[0]['verdicts'][-1]['verdict']=='not_solved')
 for e in WITNESS+[accuse(),{'type':'bad'}]:check('terminal rejects '+canon(e),step(solved,e)==(solved,'SESSION_CLOSED'))
 check('save contains only permitted fields',set(json.loads(save(s)))=={'schemaVersion','packageIdentity','events','checksum'})
 check('roundtrip exact derived state',load(save(s))[0]==s)
 changed=json.loads(save(s));changed['events'].reverse();check('checksum sees order',load(canon(changed))[1]=='CHECKSUM')
 changed['checksum']=digest('forge-session-save-v1',{k:v for k,v in changed.items() if k!='checksum'});check('valid checksum does not authorize wrong order',load(canon(changed))[0] is None)
 check('empty history valid',load(save(initial()))[0]==initial())
 check('newly generated solved history accepted no anti-cheat',load(save(solved))[0]==solved)
 for field in ['knowledge','phase','observations','verdicts','discoveries','snapshot','solution','proof','seq','timestamp']:
  altered=json.loads(save(s));altered[field]={};check('derived/extra save field '+field,load(canon(altered))[1]=='FORMAT')
 for e in [inv('location:hof'),ask('max','q01'),accuse()]:
  for field in ['seq','timestamp','proof','verdict','observation','known','packageHash','truthHash','solution','debug']:
   altered={**e,field:1};check('event '+e['type']+' extra '+field,step(initial(),altered)[1]=='ACTION_UNAVAILABLE')
 for id in sorted(ENTITY):
  if ENTITY[id] in ['event','evidence','item']:
   check('wrong kind search '+id,step(initial(),{'type':'investigate','action':'search_location','target':REF[id]})[1]=='ACTION_UNAVAILABLE')
 for x in [None,False,0,1,[],{},'true','false']:
  altered=accuse();altered['literals'][0]['value']=x;check('literal Boolean strict '+repr(x),step(initial(),altered)[1]=='ACTION_UNAVAILABLE' if type(x)!=bool else step(initial(),altered)[1]=='accepted')
 for key in ['schemaVersion','packageHash','rulesetVersion']:
  altered=json.loads(save(s));altered['packageIdentity'][key]='changed';check('identity drift '+key,load(canon(altered))[1]=='INCOMPATIBLE')
 for size in [0,1,31,32,33,50]:
  e={'type':'accuse','literals':accuse()['literals'][:1]*size};check('duplicate/size literals '+str(size),step(initial(),e)[1]==('accepted' if size<2 else 'ACTION_UNAVAILABLE'))
 for n in ['max','lina','nora','oskar']:
  e=accuse(n);out,_=step(initial(),e);check('four answer vectors '+n,out['phase']==('solved' if n=='lina' else 'active'))
 for typ,field in [('investigate','target'),('interrogate','npc')]:
  for ref in ['pr1_ffffffffffffffff','pr1_0000000000000000','person:lina','',{'kind':'person','index':1},None]:
   e=inv('location:hof') if typ=='investigate' else ask('max','q01');e[field]=ref;check(typ+' hostile ref '+repr(ref),step(initial(),e)[1]=='ACTION_UNAVAILABLE')
 o,c=run([ask('oskar','q12'),ask('nora','q09')]);check('conflicting reports retained',len(o['observations'])==2 and o['observations'][0]['observation']['stance']=='affirms' and o['observations'][1]['observation']['stance']=='denies')
 check('no report to objective fact field','facts' not in o)
 limit,_=run([inv('person:max')]*512);check('512 accepted',len(limit['events'])==512);check('513 rejected atomically',step(limit,inv('person:max'))==(limit,'LIMIT_REACHED'))
 check('oversized JSON rejected',load(' '*1048577)[1]=='SIZE');check('duplicate JSON rejected',load('{"schemaVersion":1,"schemaVersion":1}')[1]=='FORMAT')
 # Distinct reference-model histories, adversarial category construction + seeded permutations.
 histories=[];action_count=0;accepted_count=0;categories=['normal','exhaustive','spam','repeat_search','repeat_question','wrong_order','minimal','contradictory','stale','post_solved']
 base=[inv(id) for id,k in ENTITY.items() if k in ['person','location','item']]+[ask(n,q['questionId'].split(':')[1]) for n in ['max','lina','nora','oskar'] for q in PROFILES['person:'+n].values()]+[accuse(n) for n in ['max','nora','oskar']]
 for category in categories:
  for seed in range(64):
   rng=random.Random(category+str(seed));noise=[copy.deepcopy(rng.choice(base)) for _ in range(5+seed%13)]
   prefixes={'normal':WITNESS,'exhaustive':base,'spam':[accuse('max')]*8,'repeat_search':[inv('location:hof')]*8,'repeat_question':[ask('oskar','q12')]*8,'wrong_order':list(reversed(WITNESS)),'minimal':[],'contradictory':[ask('oskar','q12'),ask('nora','q09')],'stale':[{'type':'investigate','action':'search_location','target':'pr1_ffffffffffffffff'}],'post_solved':[accuse()]}
   events=prefixes[category]+noise+WITNESS+[accuse()]+noise[:2];state,codes=run(events);replayed,err=replay(state['events']);loaded,err2=load(save(state))
   assert err is None and err2 is None and state==replayed==loaded
   # Every rejected command leaves state unchanged, all prefix snapshots replay identically.
   prefix=initial()
   for event in events:
    before=copy.deepcopy(prefix);prefix,code=step(prefix,event)
    if code!='accepted':assert prefix==before
    rr,ee=replay(prefix['events']);assert ee is None and rr==prefix
   histories.append({'category':category,'seed':seed,'inputHash':digest('history-v1',events),'attempted':len(events),'accepted':len(state['events']),'phase':state['phase'],'stateHash':digest('state-v1',state),'events':events,'acceptedEvents':state['events'],'codes':codes})
   action_count+=len(events);accepted_count+=len(state['events'])
 assert len({x['inputHash'] for x in histories})==640
 result={'scope':'Scratch reference semantics; fixture token table NOT PlayerRef; draft ports simulated, no production integration claim','adversarialCases':len(records),'passed':sum(x['passed'] for x in records),'generatedHistories':len(histories),'distinctHistories':640,'attemptedActions':action_count,'acceptedActions':accepted_count,'replayFailures':0,'prefixReplayFailures':0,'categories':{c:64 for c in categories},'confirmedDesignDifference':'Correct complete answer can solve with zero evidence. Citation requirement is absent from Challenge draft.'}
 (R/'evidence/adversarial-results.json').write_text(json.dumps(records,indent=2));(R/'evidence/histories.json').write_text(json.dumps(histories,separators=(',',':')));(R/'evidence/replay-results.json').write_text(json.dumps(result,indent=2));(R/'evidence/presentation-adaptation.json').write_text(json.dumps(PRESENT,indent=2));print(json.dumps(result))
if __name__=='__main__':experiment()
