from pathlib import Path
import json,hashlib,html,zipfile,re,shutil,subprocess,os
R=Path(__file__).parent
SHA='3d7545d843883418348004e68717399a64da7a7d'
rows={
'A':[
('Truth unbekanntes Rootfeld','SHAPE; keine Packageausgabe'),('Solution falscher truthHash','BINDING vor Folgeprüfung'),('Access fremder Case','BINDING'),('Presentation stale truthHash','BINDING'),('Catalogue anderer Truthstand','BINDING'),('NPC-Profil falscher catalogueHash','BINDING'),('Snapshot andere solutionHash','BINDING'),('Snapshot/Profil verschiedene npcId','BINDING'),('Doppeltes NPC-Paar','REFERENCE'),('NPC nicht in Truth.persons','REFERENCE'),
('Initialref unbekannte Entity','REFERENCE'),('Initialref falsche Art','REFERENCE'),('Doppelte initial known','SHAPE/REFERENCE'),('Initial bekannte Evidence','Known, aber keine Discovery/Observation'),('Leeres initial known','gültig; keine automatische Freigabe'),('Refsource falscher caseId','REF_MAPPING'),('Refsource falscher truthHash','REF_MAPPING'),('Refsource salt 31/33 Hexzeichen','SHAPE'),('Ref fehlt für eine verborgene Entity','REF_MAPPING'),('Zwei Entities gleicher Token','REF_MAPPING'),
('Refinverse andere Art/ID','REF_MAPPING'),('Ref syntaktisch ungültig','REF_MAPPING'),('Source nach Resolve verändert','bestehendes Package unverändert'),('Snapshot private Provenance geändert','snapshotHash und packageHash ändern'),('Snapshot asOf/revision geändert','packageHash ändert'),('Challenge Scope hinzugefügt','packageHash ändert'),('Nur Scope-Reihenfolge geändert','Hash gleich'),('Known-Reihenfolge geändert','Hash gleich'),('Witness-Schritte vertauscht','proofHash/packageHash ändern'),('Proof binding.releaseHash falsch','PROOF_BINDING'),
('Manifest releaseContextHash falsch','PROOF_BINDING'),('Manifest executable JS als String','nie ausführen; nur Daten; keine PASS-Behauptung'),('proof null','technisches Package zulässig; Slice-Publikation noch nicht zertifiziert'),('proof pass-artiges Zusatzflag','Schemafehler; keine abgeleitete Autorität'),('Presentation ein Leerzeichen verändert','packageHash ändert'),('Salt verändert bei gleichem Mapping','refsHash/packageHash ändern'),('Mapping verändert bei gleicher Config','refsHash/packageHash ändern'),('257 Entities oder 65 Evidence','LIMIT'),('Package über 2MiB/Depth32/100000 Nodes','LIMIT vor Domainparse'),('ResolvedPackage JSON.stringify','wirft; Public DTO bleibt serialisierbar')],
'B':[
('Verfügbaren Ort untersuchen','akzeptiert; passende Evidence released'),('Validen unbekannten Ort raten','ACTION_UNAVAILABLE'),('Nicht existierenden Ref raten','derselbe öffentliche Fehler'),('Item als search_location','ACTION_UNAVAILABLE'),('Bekannte Person ohne Evidence untersuchen','akzeptiert; leere Ausgabe'),('Gleichen Ort zweimal durchsuchen','zwei Events, nur erste Discovery/Observation'),('Mehrere Evidence bei einem Fund','öffentliche Ref-Sortierung, atomare Übernahme'),('Zweiter Evidence-Release fehlschlägt','HOST_FAILURE, kompletter Rollback'),('Evidence.source ohne Accesspfad','kein impliziter Fund'),('Neues Item durch Evidence mention','Known; Untersuchung erst im nächsten Event'),
('Report-Claim mit nicht autorisiertem Ref','HOST_FAILURE, keine automatische Known-Erweiterung'),('Bekannte Evidence nur erwähnt','keine physische Discovery'),('NPC-Frage verfügbar','exakter 5B-Output plus Empfangsprovenance'),('Frage über unbekannte Person','ACTION_UNAVAILABLE; kein Existenzorakel'),('Unbekannte questionId','derselbe öffentliche Fehler'),('Bekannte Person ohne NPC-Profil','ACTION_UNAVAILABLE'),('NPC decline','akzeptiertes Event; kein Statement erfunden'),('NPC does_not_know','akzeptiert; keine Mentions erfunden'),('NPC false belief','als Report erhalten; kein objective truth'),('NPC uncertain','genaue Stance; keine Boolean-Konversion'),
('Gleiche Frage wiederholen','gleicher Payload, zwei Records mit verschiedenen eventIndex'),('Widersprüchliche NPC-Berichte','beide erhalten; kein Last-writer-wins-Fakt'),('NPC kennt mehr als Spieler','nur explizit erlaubte Reveal-Mentions'),('Spieler kennt mehr als NPC','NPC-Snapshot unverändert; does_not_know möglich'),('Richtige vollständige Anklage','Challenge solved; terminal'),('Falsche bestimmte Anklage','akzeptiert not_solved; weiter active'),('Undetermined Extra in Scope','not_solved, kein false-Rewrite'),('Wahres Extra außerhalb Scope','not_solved'),('Wahres Extra innerhalb Scope','solved wenn Required vollständig'),('Fehlendes negatives Requiredliteral','not_solved'),
('Doppelclaim mit gleicher/anderer Polarität','ACTION_UNAVAILABLE, kein Logeintrag'),('Alle sechs PlayerConclusionClaim-Arten','feldweise korrekte Canonical-Übersetzung'),('eventCausedEvent falscher Kind/stale causeEvent','ACTION_UNAVAILABLE'),('Event ohne neue Infos aber gültig','trotzdem geloggt'),('Event nach solved inkl. malformed','SESSION_CLOSED; keine Portaufrufe'),('Fremde Packageidentity im State','HOST_FAILURE vor terminal'),('33 Anklageliterale oder >16KiB','ACTION_UNAVAILABLE; unverändert'),('513. gültiges Event','LIMIT_REACHED; unverändert'),('Prospective Save überschreitet 1MiB','LIMIT_REACHED vor Commit'),('Raw Event/Output nach Aufruf mutieren','eigener frozen State bleibt unverändert')],
'C':[
('Leere Historie speichern/laden','initialSession identisch'),('Vollständiger Vitrine-Witness roundtrip','Known/Discoveries/Records identisch'),('Solved-Historie roundtrip','terminal unverändert'),('State Derived-Knowledge manipuliert beim Encode','INVALID_STATE'),('State Verdict manipuliert beim Encode','INVALID_STATE'),('Save mit knowledge-Zusatzfeld','INVALID_SAVE'),('Save mit phase/snapshot-Zusatzfeld','INVALID_SAVE'),('Save root schemaVersion=2','INVALID_SAVE'),('Unbekannter rulesetVersion','INCOMPATIBLE_PACKAGE'),('Geänderter packageHash','INCOMPATIBLE_PACKAGE'),
('Nur Presentationtext neuer Packageversion','INCOMPATIBLE_PACKAGE'),('Nur NPC-Provenance neuer Packageversion','INCOMPATIBLE_PACKAGE'),('Alter Save mit archiviertem exakten Package','erfolgreich bei gleichem Ruleset'),('Geändertes Event ohne Checksumupdate','CHECKSUM_MISMATCH'),('Checksum uppercase/falsche Länge','INVALID_SAVE'),('Neuer gültiger Verlauf mit neuer Checksum','akzeptiert; keine Anti-Cheat-Garantie'),('Kürzeres gültiges Präfix neu checksummiert','akzeptiert; kein Rollbackschutz'),('Historie umgeordnet, Checksum neu','Replay entscheidet; ungültiges Präfix INVALID_HISTORY'),('Historie nach solved, Checksum neu','INVALID_HISTORY, kein Abschneiden'),('Abgewiesenes Event zwischen gültigen','INVALID_HISTORY, kein Überspringen'),
('Unbekannte/stale Refs in neu checksummiertem Log','INVALID_HISTORY'),('Unsinniges accepted=true-Zusatzfeld','INVALID_HISTORY/INVALID_SAVE; nie Autorität'),('Doppelte JSON-Rootkeys','INVALID_SAVE durch Wirekanonisierung'),('Doppelte verschachtelte Keys','INVALID_SAVE'),('Whitespace vor/nach JSON','INVALID_SAVE; Codec akzeptiert seine kanonische Form'),('BOM/invalid JSON','INVALID_SAVE'),('String mit lone surrogate','INVALID_SAVE'),('NFC versus NFD','keine Normalisierung; verschiedene Bytes'),('JSON -0 versus 0','nichtkanonisches -0 abweisen'),('Propertyorder nicht kanonisch','INVALID_SAVE; intern C ordnet Objekte'),
('Events vertauschen im Checksumpräimage','Checksum verschieden'),('Literale innerhalb Event vertauschen','Verlaufbytes verschieden; semantischer Verdict kann gleich sein'),('Save exakt 1MiB und ein Byte darüber','Grenze inklusive / LIMIT_REACHED'),('Mehr als 512 Events vor Replay','LIMIT_REACHED'),('Tiefe 33 / über 100000 Nodes','LIMIT_REACHED vor rekursiven Funktionen'),('Replay-Port wirft','HOST_FAILURE; keine Teilzustandsausgabe'),('Replay ohne alte Packageversion','kein automatisches Upgrade'),('Gleiche Historie zweimal replayen','tiefe Gleichheit, keine geteilte veränderliche Stateautorität'),('640 generierte Historien mit Präfixvergleich','incremental = replay = load, Reject unverändert'),('Checksum korrekt aber technischer Bindingfehler','HOST_FAILURE/inkompatibel, niemals not_solved')]
}
assert all(len(v)==40 for v in rows.values())
matrix=[]
for task,rs in rows.items():
 for i,(case,expected) in enumerate(rs,1):matrix.append({'id':f'{task}{i:02}','task':task,'case':case,'expected':expected,'status':'NORMATIVE FUTURE PRODUCTION ACCEPTANCE; NOT EXECUTED AGAINST PRODUCTION'})
(R/'evidence/acceptance-matrix.json').write_text(json.dumps(matrix,ensure_ascii=False,indent=2))
matrixmd='| ID | Fall | Erwartung |\n|---|---|---|\n'+'\n'.join(f"| {r['id']} | {r['case']} | {r['expected']} |" for r in matrix)
(R/'SESSION-ACCEPTANCE-120.md').write_text('# 120 normative Production-Acceptance Cases\n\n'+matrixmd+'\n')
spec=(R/'SPECIFICATION.txt').read_text()
# Explicit module exports and dependency-safe codec sizing.
extra='''
### Ergänzung: genaue A-Helfer und größenbedingte B/C-Abhängigkeit

PROPOSED normativ. player-knowledge.ts exportiert Typen KnownEntity, ObservationRecord, PlayerKnowledge sowie initialPlayerKnowledge(pkg), recordEvidence(knowledge,observation,eventIndex), recordInterrogation(knowledge,observation,eventIndex). Initial überführt ausschließlich pkg.initial.known mit pkg.refs; recordEvidence nimmt die Evidence selbst und Mentions auf, entdeckt genau einmal; recordInterrogation nimmt ausschließlich Mentions auf und hängt jeden Empfang an. Alle drei geben eine neue deeply frozen Kopie zurück, keine Mutation. Sie sind trusted-only und werden erst nach vollständiger Port-/Ref-Validierung von B verwendet. Eine reine helper-Funktion darf keine Eigenautorität zum Evidence-Release erhalten.

case-package.identity.ts exportiert serializeSessionJson(value) für das beschriebene C, hashSessionJson(profile,value) für H sowie die konkreten package-internen Componenthashfunktionen. Keine Nutzung des Truth-Serializers für Historien. Die JSON-Safety-Prüfung validateSessionJson(value,{maxDepth,maxNodes}) arbeitet iterativ und meldet Limit/Shape vor rekursiver Serialisierung; keine Caller-konfigurierbare Semantik, nur die hier festgelegten Konstanten. Sie wird in A/C wiederverwendet und gehört zum A-Zeilenbudget. Plain JSON bedeutet keine Funktionen, undefined, Symbole, BigInt, NaN/Infinity, unsichere Integer, Accessoren, Zyklen oder fremde Prototypen. Fremder ausführbarer JS-Code, der Proxies liefert, ist keine unterstützte untrusted Schnittstelle.

B prüft die prospektive Savegröße ohne Import von C: C({schemaVersion:1,packageIdentity:pkg.identity,events:prospectiveEvents,checksum:"0".repeat(64)}) in UTF-8. Alle echten Checksums sind genau 64 ASCIIzeichen; die Länge ist deshalb exakt. C verwendet denselben Serializer und dieselbe Envelopeform. Kein Dependencyzyklus. B kann den Check vor vollständiger Gameplayauswertung ausführen, sobald ein Event geparst ist; die Abnahme/Commitentscheidung bleibt nach allen Portprüfungen atomar.

Strict private Packageinput-JSON darf proof.releaseManifest als String enthalten. Dessen nach JSON.parse geprüfter Envelope hat exakt schemaVersion/releaseContextHash/adapterVersion/certificateData; adapterVersion ASCII [a-z][a-z0-9._-]{0,63}, certificateData ausschließlich bounded JSON. A akzeptiert ihn als gebundenes authoring artifact und führt weder Witness noch Zertifikatsinterpretation aus. Nicht vorhandener standardisierter Adapter bleibt eine ausdrücklich spätere Fall-Abnahme, kein stillschweigender Solvability-PASS.
'''
if '### Ergänzung: genaue A-Helfer' not in spec:
 spec=spec.replace('## 3. PlayerKnowledge',extra+'\n## 3. PlayerKnowledge')
spec=spec.replace('Semantic Validation darf für Veröffentlichung keine error-Findings haben','Semantic Validation muss für Veröffentlichung eine leere findings-Liste haben (das heutige SemanticFinding hat kein severity-Feld)')
(R/'SPECIFICATION.txt').write_text(spec)
common=spec[spec.index('## 2. Package Identity'):spec.index('## 12. 100+ Cases')]
vectors=json.loads((R/'evidence/save-golden-vectors.json').read_text())
common+='\n### Save-Hash-Golden-Vektoren\n\nEXPERIMENTALLY VERIFIED: dieselben Bytes unabhängig in Python hashlib und Node crypto geprüft. order-a/order-b sind isolierte Kanonisierungstests, keine vollständigen Save-Envelope-Fixtures.\n\n'
for v in vectors:
 common+='**'+v['name']+'**\n\n```json\n'+v['canonical']+'\n```\n\nSHA-256 von `forge-session-save-v1\\n` + diesen Bytes: `'+v['checksum']+'`.\n\n'
scope={
'A':['src/domain/case-package.ts','src/domain/case-package.identity.ts','src/domain/player-knowledge.ts','tests/case-package.test.ts','tests/case-package.identity.test.ts','tests/player-knowledge.test.ts','tests/case-package.fixture.ts','tests/case-package.typecheck.ts'],
'B':['src/domain/case-session.ts','tests/case-session.test.ts','tests/case-session.security.test.ts','tests/case-session.fixture.ts','tests/case-session.typecheck.ts'],
'C':['src/domain/case-session-save.ts','tests/case-session-save.test.ts','tests/case-session-replay.generated.test.ts','tests/case-session-save.typecheck.ts']}
deps={'A':['MYST-0001','MYST-0002','MYST-0003','MYST-0004','MYST-0005A','MYST-0005B','MYST-CHALLENGE-0001','MYST-SOLVABILITY-0001'],'B':['MYST-SESSION-0001A'],'C':['MYST-SESSION-0001A','MYST-SESSION-0001B']}
mutants={
'A':[('Bindingcheck Truth→Solution entfernen','A02'),('Snapshot-provenance aus Hash entfernen','A24'),('allowedClaims unsortiert hashen','A27'),('Refinverseprüfung entfernen','A21'),('RefsHash aus releaseContextHash entfernen','A37'),('Witnessarray als Menge sortieren','A29'),('Initial Evidence automatisch releasen','A14'),('Globale Refkollision tolerieren','A20')],
'B':[('Known-Prüfung bei Auflösung entfernen','B02'),('found unmittelbar in discoveries committen','B08'),('Wiederholung von Evidence erneut an Journal anhängen','B06'),('NPC belief automatisch als faktiv übernehmen','B19'),('evaluateAccusation statt evaluateChallengeAccusation aufrufen','B27/B28'),('Terminalguard entfernen','B35'),('Prospective-Byteguard entfernen','B39'),('auseinanderliegende Eingaberefarten coercen','B04/B33')],
'C':[('Events vor Checksum sortieren','C31'),('Derived-Felder aus Save übernehmen','C06/C07'),('Replayfehler überspringen','C20'),('packageHash-Vergleich entfernen','C10'),('PresentationHash aus Kompatibilität ausschließen','C11'),('Kanonische Wiregleichheit entfernen','C23/C24/C25'),('Encode ohne Derived-Statevergleich','C04/C05'),('Log nach solved abschneiden','C19')]}
for task in 'ABC':
 tid='MYST-SESSION-0001'+task
 meta={'forgeContractFormat':1,'taskId':tid,'contractVersion':1,'baseCommit':SHA,'dependencies':[{'taskId':d,'acceptedCommit':None} for d in deps[task]],'scope':{'create':scope[task],'modify':[]},'requiredChecks':[{'name':'typecheck','command':'npm run typecheck'},{'name':'test','command':'npm test'}],'mutationSmoke':'required'}
 text='---json\n'+json.dumps(meta,indent=2)+'\n---\n# '+tid+' — '+{'A':'Package / PlayerKnowledge','B':'Session Reducer','C':'Save / Replay'}[task]+' V1\n\n'
 text+='**DRAFT. Nicht registriert, nicht freigegeben, auf dieser Basis nicht startbar. Kein Implementierungsauftrag durch dieses Lab.**\n\n'
 text+='## Verbindlichkeit und Startgate\n\n'
 text+='Dieser Contract verwendet ausschließlich das heute akzeptierte Format 1. dependencies.acceptedCommit=null ist absichtlich ungelöst, kein Dummy-Pin. Vor Architekturfreigabe alle Abhängigkeiten tatsächlich akzeptieren, Commits pinnen und baseCommit/contractVersion nach erneuter API-Prüfung revidieren. MYST-0001 ist ein nur sekundär belegter Taskname; vollständigen Contract/Ref-Adapter und Namespace vor Start prüfen. Task-ID nicht extern reserviert. Alte Scratch-Mocks sind kein Produktionsersatz.\n\n'
 text+='Normativ sind die folgenden gemeinsamen Semantikabschnitte und die taskeigene Testmatrix. Nur der im Frontmatter aufgeführte Scope wird implementiert; gemeinsam beschriebene andere Taskteile werden importiert, nicht dupliziert. Keine bestehenden Dateien verändern. Neue Runtime- oder Dev-Dependencies verboten. Kein Import aus src/forge. Vorhandenes zod/node:crypto genügt.\n\n'
 text+='## Ziel, API und Abgrenzung dieses Tasks\n\n'
 text+= {'A':'Implementiere ausschließlich resolveCasePackage, Componentidentitäten, die neuen JSON-Helfer und PlayerKnowledge-Typen/Helper. Runtimeexports in case-package.ts: PACKAGE_LIMITS, resolveCasePackage. Identity-/Knowledgeexports sind in der gemeinsamen Ergänzung definiert; alle dort genannten Typen exportieren. Kein Reducer, Save oder Solvability-Runner. Package.proof:null technisch zulässig; Publication-PASS nie aus Metadata ableiten.','B':'Implementiere SessionEvent/PlayerConclusionClaim-Schema, initialSession, reduceSession und replaySession. Runtimeexports exakt SESSION_LIMITS, SessionEventSchema, initialSession, reduceSession, replaySession. Schema validiert shape; Ref-Known bleibt Reducerpflicht. Eigene Result-/State-/Output-Typen exportieren. A-Helfer importieren. Alle Draft-Gameplayports gegen dann akzeptierte Implementierungen importieren; keine Produktions-Injection durch Spieler. Keine Savekodierung oder Interpretation von Proofcertifikaten.','C':'Implementiere ausschließlich encodeSessionSave und decodeSessionSave sowie SAVE_LIMITS und die Resulttypen. A-JSON-Helfer und B-replaySession importieren. Kein zweiter Reducer oder eigener Verdictalgorithmus. Untrusted Eingang ist ein begrenzter String, kein frei ausführbares Objekt. Saveformat bleibt strict/canonical und hat exakt die vier Rootfelder.'}[task]+'\n\n'
 text+='## Reads / Source of truth\n\n'
 text+='Aktueller main: src/domain/case-truth.ts, case-truth.identity.ts, case-semantics.ts, case-solution.ts, case-solution.identity.ts, npc-knowledge.ts, npc-knowledge.projection.ts sowie bestehende zugehörige Tests. Draft-Inputs: MYST-0002 FINAL CANDIDATE; MYST-0003; MYST-0004 vom 2026-10-04; MYST-0005A/B; MYST-CHALLENGE-0001; MYST-SOLVABILITY-0001. Die exakten SHA-256 der gelesenen Texte stehen im Evidenceinventar. Vor Start gelten akzeptierte Quellen statt dieser Draftannahmen; Abweichung → Contractrevision, keine API-Erfindung.\n\n'
 text+=common+'\n\n## Acceptance Criteria dieses Tasks\n\n'
 text+='1. Alle 40 nachfolgenden Fälle sowie relevante gemeinsame Invarianten mit realen Dependencies grün; typecheck und bestehende vollständige Testsuite grün. Keine Tests löschen/skippen.\n2. Nur Scope-Dateien; keine neue Dependency; Ziel '+{'A':'340–399','B':'300–399','C':'180–280'}[task]+' Produktionszeilen, lesbarer Code. Wenn <400 nicht seriös möglich: Contractrevision vor Scopeerweiterung, keine Golf-Lösung.\n3. Alle Input/Output-Grenzen frozen/eigene Kopie; keine Mutation und keine heimliche Zeit/Zufallsabhängigkeit.\n4. Kein Runtime-LLM, kein I/O im Domainpfad außer SHA-256, keine Dateipfad-/URLauflösung aus Save.\n5. Authentizität, Anti-Cheat, Online-Synchronisation, Save-Migration, Gameplayzeit, dynamische NPCs, Mehrfach-Challenges und Citation-Gates sind Non-goals.\n6. Die reale Vitrine-Fallabnahme ist separat: ursprüngliche Citationpflicht reconciliieren, echter Proof-Witness statt Stub.\n'
 if task=='C':text+='7. Mindestens 640 unterschiedliche deterministisch generierte Eventhistorien über dieselben zehn Kategorien wie im Lab: alle Präfixe incremental=replay=save/load, jeder Reject unverändert, mindestens je ein solved/not_solved/invalid-order/terminal-Control. Seed und failing history vollständig ausgeben. Dieser Test verwendet echte Module, nicht den Python-Scratch-Reducer.\n'
 text+='\n| ID | Inputvariation | Erwartung |\n|---|---|---|\n'
 text+='\n'.join(f"| {r['id']} | {r['case']} | {r['expected']} |" for r in matrix if r['task']==task)
 text+='\n\n## Mutation Smoke — mindestens acht\n\n| Mutant | Semantische Mutation | Killer |\n|---|---|---|\n'
 text+='\n'.join(f'| M{i} | {m} | {t} |' for i,(m,t) in enumerate(mutants[task],1))
 text+='\n\nMutanten sind semantische Anforderungen, keine vorgetäuschten vorhandenen Quelltextanker. Der spätere Reviewer bestimmt am echten Diff einen ausführbaren Patch je Mutant, hält ihn im Evidencepacket fest und repliziert den Killer. Ein Compilefehler ersetzt keinen logischen Killer. Überlebender Mutant blockiert. Keine Tests gegen eine zweite implementierungsgleiche Wahrheitstabelle.\n\n## Handoff\n\nAbgabe: tatsächlicher Head, diff --stat, Produktionszeilenzahl, typecheck/test-Ausgabe, alle Matrixfälle zu Testnamen zugeordnet, Mutationpacket und API-Reconciliation. Keine Aktivierung oder Registrierung wird durch dieses Dokument autorisiert. Kein spezieller Format-2-Endmarker.\n'
 (R/(tid+'.contract.DRAFT.md')).write_text(text)

# HTML report, standalone, no browser/network runtime.
def md(x):
 script="import fs from 'node:fs';import {marked} from '"+os.environ['CODEX_PRIMARY_RUNTIME_NODE_MODULES']+"/marked/lib/marked.esm.js';process.stdout.write(marked.parse(fs.readFileSync(0,'utf8')));"
 return subprocess.run([os.environ['CODEX_PRIMARY_RUNTIME_NODE'],'--input-type=module','-e',script],input=x,text=True,capture_output=True,check=True).stdout
result=json.loads((R/'evidence/replay-results.json').read_text())
executed=json.loads((R/'evidence/adversarial-results.json').read_text())
facts='\n### Tatsächlich ausgeführte Ergebnisse\n\n| Kennzahl | Ergebnis |\n|---|---|\n'+ '\n'.join(f'| {k} | {v} |' for k,v in result.items() if not isinstance(v,dict))
spec=spec.replace('## 14. Task Split',facts+'\n\n## 14. Task Split')
appendix='\n## Evidence Appendix\n\nRemote: https://github.com/Forge-Dice/Forge/commit/'+SHA+' . Lokale Referenzdateien im Scratch-Lauf unverändert.\n\n### Normative 120er-Matrix\n\n'+matrixmd+'\n\n### Ausgeführte 124er-Scratch-Matrix\n\n| ID | Prüfung | Ergebnis |\n|---|---|---|\n'+'\n'.join(f"| {x['id']} | {x['case']} | {'PASS' if x['passed'] else 'FAIL'} |" for x in executed)
inputs=[]
for f in sorted((R/'inputs').iterdir()):inputs.append({'name':f.name,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size,'status':'DESIGN INPUT'})
current=[]
for f in sorted((R.parent/'forge-audit/src/domain').glob('*.ts')):current.append({'path':'src/domain/'+f.name,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'status':'IMPLEMENTED','main':SHA})
(R/'evidence/source-inventory.json').write_text(json.dumps({'remoteMain':SHA,'mainFiles':current,'drafts':inputs,'unavailable':['full MYST-0001 PlayerRef contract','old VS-5 Session Replay preflight'],'noCanonicalChanges':True},indent=2))
appendix+='\n\n### Quellensnapshots\n\n| Datei | SHA-256 |\n|---|---|\n'+'\n'.join(f"| {x['name']} | {x['sha256']} |" for x in inputs)
appendix+='\n\n### Zusätzliche Hashprüfung\n\nDrei Save-Kanonisierungs-/Checksumvektoren wurden unabhängig in Python und Node reproduziert. Sie liegen als evidence/save-golden-vectors.json bei und stehen in allen drei Contracts. Der Ordnungswechsel der Events verändert den Hash. Dies ist kein Test der noch fehlenden Produktionscodec-Implementierung.\n'
doc='''<!doctype html><html lang="de"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>MYSTERY SESSION PRODUCTION PACKAGE</title><style>body{font:16px/1.55 system-ui,sans-serif;color:#182231;max-width:1140px;margin:40px auto;padding:0 24px;background:#fafbfc}h1{font-size:36px;color:#103951}h2{margin-top:52px;padding-top:20px;border-top:2px solid #b5cad3;color:#103951}h3{margin-top:28px}table{width:100%;border-collapse:collapse;font-size:14px;margin:24px 0}th,td{padding:9px;border:1px solid #cbd6dc;text-align:left;vertical-align:top;overflow-wrap:anywhere}th{background:#deebf0}code{font-family:ui-monospace,monospace;font-size:.88em}pre{background:#eaf0f3;padding:18px;overflow:auto;white-space:pre-wrap;overflow-wrap:anywhere}a{color:#006e9f}@media print{body{max-width:none;margin:0;font-size:11px}h2{break-before:page}tr{break-inside:avoid}pre{font-size:10px}}</style><body>'''+md(spec+appendix)+'</body></html>'
(R/'MYSTERY-SESSION-PRODUCTION-PACKAGE.html').write_text(doc)
readme='''MYSTERY SESSION LAB — 2026-10-04
Read-only against Forge-Dice/Forge main 3d7545d843883418348004e68717399a64da7a7d.
No production implementation. Draft modules are not present on main.

Deliverables: report HTML; three Format-1 draft contracts; 120-case normative matrix.
Executed: 124 scratch checks; 640 histories; 16900 attempted/13584 accepted actions;
zero replay/prefix mismatches. See evidence/replay-results.json.

Reproduction in original workspace:
  node runtime/verify-main.ts
  python3 replay_lab.py
The Python model is intentionally disposable and uses fixture refs, not MYST-0001.
To reproduce outside this workspace, place the included case-pack at
../first-playable-case-lab/case-pack relative to this extracted folder, install
the exact package-lock dependencies in runtime using a temporary checkout,
then run the two commands. No writes to canonical repo are required.
runtime/src is an unchanged source snapshot from the verified main.
Existing historical fixture files are input only; new results go to evidence/.
The main-validation oracle is a black-box parser experiment, NEVER a production
replacement for evaluateConclusionClaim or Challenge.

Not established: full PlayerRef contract, old VS-5 preflight, real draft-port
integration, actual production performance, Proof/PublicRule certificate adapter.
The production codec adds strict canonical-wire/depth/nodes checks beyond the
Python simulation; normative C-tests specify them.
'''
(R/'README.txt').write_text(readme)
print(json.dumps({'contracts':3,'normativeCases':len(matrix),'executed':len(executed),'reportBytes':len(doc.encode())}))
