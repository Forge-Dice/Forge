MYSTERY CROSS-CONTRACT CONSISTENCY LAB — 2026-10-04

READ-ONLY canonical source: Forge-Dice/Forge main
3d7545d843883418348004e68717399a64da7a7d

This archive is evidence, not an implementation or an authorization to modify Forge.
35 assertions execute existing, unchanged main modules. 73 assertions execute
small explicitly labeled boundary models. 14 compiler-negative probes verify
that direct, inappropriate interface wiring is rejected. Missing PlayerRef and
Session APIs are deliberately not declared as if known.

Layout:
  inputs/        Read-only copies of the 18 available source artifacts.
  source/        Unmodified git archive of the pinned main (no .git, no credentials).
  lab/           Declarations, probes, logs, raw cases, manifest and DAG.
  build_report.py Report generator (reads cases/manifest; no repository writes).

To reproduce from the ZIP root (network access for npm packages required):
  npm --prefix cross-contract/source ci --ignore-scripts
  ln -s ../source/node_modules cross-contract/lab/node_modules
  node cross-contract/source/node_modules/typescript/bin/tsc --project cross-contract/lab/tsconfig.json
    Expected: exit 0.
  node cross-contract/source/node_modules/typescript/bin/tsc --project cross-contract/lab/tsconfig.negative.json
    Expected: exit 1, 14 diagnostics.
  node cross-contract/lab/boundary-cases.mjs
    Expected: 108 PASS assertions, 0 FAIL; MAIN 35, MODEL 73.

Compiler fixture deliberately uses contracts.d.ts only. It does not call
nonexistent runtime modules. Its Proof.Released tag 'kind' is an explicit
scratch transcription choice because the SOL draft defines that union in prose.
M4 Document entries are reduced to unknown[] in declarations used only for
assignability tests; no parser conformance is claimed.

The report distinguishes MODEL PASS from real module integration. There is no
implemented or verified complete Mystery session/replay chain in this archive.
The old HTML source artifacts contain historical lab results; those were not
counted as new runs here. Their original bytes are preserved in inputs/.
