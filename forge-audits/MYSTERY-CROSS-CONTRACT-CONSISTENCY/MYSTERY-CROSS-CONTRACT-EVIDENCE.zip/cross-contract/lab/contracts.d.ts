// SCRATCH declarations only. No proposed module is implemented here.
// Sources: MYST-0002 §5/6; 0003 §3/5; 0004 §5; 0005A §3/6; 0005B §4/5;
// CHALLENGE §3/4; SOLVABILITY §3/4. Missing PlayerRef/Session API is NOT invented.
import type { z } from 'zod';
import type { CaseTruth, DeepReadonly, CaseId, PersonId, EvidenceId, EventId, PropositionId } from '../source/src/domain/case-truth.ts';
import type { CaseSolution, ConclusionClaim, ConclusionId, ResponsibilityRole, Intent, Mechanism } from '../source/src/domain/case-solution.ts';
import type { AwarenessSubject, NpcKnowledgeSnapshot } from '../source/src/domain/npc-knowledge.ts';
import type { VisibleRef, NpcVisibleClaim, NpcVisibleContext } from '../source/src/domain/npc-knowledge.projection.ts';
export type { CaseTruth, CaseSolution, VisibleRef, NpcKnowledgeSnapshot };
export type EntityRef = AwarenessSubject;
export type Binding = { readonly caseId: CaseId; readonly truthHash: string };
export namespace Access {
 export type Map = DeepReadonly<Binding & {schemaVersion:1; entries: {evidenceId:EvidenceId; access: {kind:'inaccessible'} | {kind:'discoverable';paths: Action[]}}[]}> & z.$brand<'EvidenceAccessMap'>;
 export type Action = {kind:'search_location';locationId:Extract<EntityRef,{kind:'location'}>['id']} | {kind:'examine_item';itemId:Extract<EntityRef,{kind:'item'}>['id']} | {kind:'examine_person';personId:PersonId};
 export type Result = {readonly success:true;readonly found:readonly EvidenceId[]} | {readonly success:false;readonly code:'INVALID_ACTION'|'INVALID_KNOWN_REFS'|'TARGET_NOT_KNOWN'};
 export function resolveInvestigation(map:Map,known:unknown,action:unknown):Result;
}
export namespace Presentation {
 export type RefKind='person'|'location'|'item'|'event'|'evidence';
 export type Translator={readonly caseId:string;readonly truthHash:string;readonly refFor:(kind:RefKind,id:string)=>string|null};
 export type PlayerClaim={readonly kind:'personAt';readonly person:string;readonly location:string;readonly at:number}|{readonly kind:'eventHasParticipant';readonly event:string;readonly person:string}|{readonly kind:'eventHasItem';readonly event:string;readonly item:string};
 export type Report={readonly claim:PlayerClaim;readonly stance:'affirms'|'denies';readonly source:{readonly kind:'observation'}|{readonly kind:'testimony';readonly person:string}};
 export type Observation={readonly schemaVersion:1;readonly evidence:string;readonly text:string;readonly mentions:readonly {readonly kind:'person'|'location'|'item'|'event';readonly ref:string}[];readonly reports:readonly Report[]};
 export type Document=DeepReadonly<Binding & {schemaVersion:1;entries:unknown[]}> & z.$brand<'EvidencePresentation'>; // entry fields unused in assignability probes
 export type Result={readonly success:true;readonly observation:Observation}|{readonly success:false;readonly code:'BINDING_MISMATCH'|'UNKNOWN_EVIDENCE'|'REF_UNAVAILABLE'};
 export function releaseEvidence(p:Document,id:unknown,refs:Translator):Result;
}
export namespace Authoring {
 export type QuestionId=string & z.$brand<'QuestionId'>;
 export type StatementClaim=CaseTruth['propositions'][number]['claim']|ConclusionClaim;
 export type Catalogue=DeepReadonly<Binding & {schemaVersion:1;revision:number;questions:{id:QuestionId;mentions:EntityRef[]}[]}> & z.$brand<'QuestionCatalogue'>;
 export type Profile=DeepReadonly<Binding & {schemaVersion:1;catalogueHash:string;npcId:PersonId;revision:number;rules:({questionId:QuestionId;act:'answer';claim:StatementClaim;reveal:EntityRef[]}|{questionId:QuestionId;act:'decline'})[]}> & z.$brand<'NpcInterrogationProfile'>;
 export function parseQuestionCatalogue(input:unknown,truth:CaseTruth):Catalogue;
 export function parseInterrogationProfile(input:unknown,truth:CaseTruth,catalogue:Catalogue):Profile;
}
export namespace Interrogation {
 export type Translator=Presentation.Translator; // identical structural text in both drafts
 export type PlayerClaim=Presentation.PlayerClaim|{readonly kind:'personResponsibleForEvent';readonly person:string;readonly event:string}|{readonly kind:'personRoleForEvent';readonly person:string;readonly event:string;readonly role:ResponsibilityRole}|{readonly kind:'noPersonResponsibleForEvent';readonly event:string}|{readonly kind:'eventCausedEvent';readonly causeEvent:string;readonly event:string}|{readonly kind:'eventIntent';readonly event:string;readonly value:Intent}|{readonly kind:'eventMechanism';readonly event:string;readonly value:Mechanism};
 export type Stance='affirms'|'denies'|'leans_affirms'|'leans_denies'|'uncertain'|'does_not_know';
 export type Observation={readonly schemaVersion:1;readonly npc:string;readonly questionId:Authoring.QuestionId;readonly act:'decline'}|{readonly schemaVersion:1;readonly npc:string;readonly questionId:Authoring.QuestionId;readonly act:'answer';readonly stance:'does_not_know'}|{readonly schemaVersion:1;readonly npc:string;readonly questionId:Authoring.QuestionId;readonly act:'answer';readonly stance:Exclude<Stance,'does_not_know'>;readonly statement:PlayerClaim;readonly mentions:readonly {readonly kind:'person'|'location'|'item'|'event';readonly ref:string}[]};
 export type Bridge={readonly visibleClaimOf:(claim:Authoring.StatementClaim)=>NpcVisibleClaim|null;readonly entityOf:(ref:VisibleRef)=>{readonly kind:Presentation.RefKind;readonly id:string}|null;readonly toJSON:()=>never};
 export type Input={readonly truth:CaseTruth;readonly solution:CaseSolution|null;readonly snapshot:NpcKnowledgeSnapshot;readonly catalogue:Authoring.Catalogue;readonly profile:Authoring.Profile;readonly refs:Translator;readonly known:readonly EntityRef[];readonly questionId:unknown};
 export type Result={readonly success:true;readonly observation:Observation}|{readonly success:false;readonly code:'BINDING_MISMATCH'|'QUESTION_NOT_AVAILABLE'|'REF_UNAVAILABLE'};
 export function interrogate(input:Input):Result;
 export function projectNpcKnowledgeWithBridge(snapshot:NpcKnowledgeSnapshot,t:CaseTruth,s:CaseSolution|null):{readonly success:true;readonly context:NpcVisibleContext;readonly bridge:Bridge}|{readonly success:false;readonly code:'CONTEXT_BINDING_MISMATCH'};
}
export namespace Core {
 export type Accusation=DeepReadonly<Binding & {schemaVersion:1;literals:{claim:ConclusionClaim;value:boolean}[]}> & z.$brand<'Accusation'>;
 export type ConclusionEvaluation={readonly success:true;readonly status:boolean|'undetermined'}|{readonly success:false;readonly code:'SOLUTION_BINDING_MISMATCH'|'INVALID_CLAIM'|'UNKNOWN_REFERENCE'};
 export type Result={readonly success:true;readonly verdict:'solved'|'not_solved'}|{readonly success:false;readonly code:'ACCUSATION_BINDING_MISMATCH'|Extract<ConclusionEvaluation,{success:false}>['code']};
 export function parseAccusation(input:unknown,t:CaseTruth):Accusation;
 export function evaluateAccusation(t:CaseTruth,s:CaseSolution,a:Accusation):Result;
 export function evaluateConclusionClaim(t:CaseTruth,s:CaseSolution,c:unknown):ConclusionEvaluation;
 export function claimKey(c:ConclusionClaim):string;
}
export namespace Challenge {
 export type Document=DeepReadonly<Binding & {schemaVersion:1;solutionHash:string;allowedClaims:ConclusionClaim[]}> & z.$brand<'AccusationChallenge'>;
 export type Result={readonly success:true;readonly verdict:'solved'|'not_solved'}|{readonly success:false;readonly code:Extract<Core.Result,{success:false}>['code']|'CHALLENGE_BINDING_MISMATCH'};
 export function evaluateChallengeAccusation(t:CaseTruth,s:CaseSolution,c:Document,a:Core.Accusation):Result;
}
export namespace Proof {
 export type Bindings=Binding & {readonly solutionHash:string;readonly releaseHash:string};
 export type Literal={readonly kind:'proposition';readonly propositionId:PropositionId;readonly value:boolean}|{readonly kind:'conclusion';readonly conclusionId:ConclusionId;readonly value:boolean};
 export type Released={readonly id:string} & ({readonly kind:'OBSERVED';readonly literal:Extract<Literal,{kind:'proposition'}>;readonly source:{readonly kind:'initial'}|{readonly kind:'evidence';readonly evidenceId:EvidenceId}}|{readonly kind:'REPORTED_BY_NPC';readonly npcId:PersonId;readonly literal:Literal}|{readonly kind:'ENTITY_AWARENESS';readonly entity:EntityRef}|{readonly kind:'PUBLIC_RULE';readonly rules:readonly {readonly edgeId:string;readonly allOf:readonly string[];readonly yields:Literal}[]});
 // 'kind' on Released chosen for the union tag in this scratch transcription: prose does not freeze its field name.
 export type ReplayResult={readonly success:true;readonly bindings:Bindings;readonly released:readonly Released[]}|{readonly success:false;readonly code:'REPLAY_UNAVAILABLE'|'INVALID_WITNESS'};
 export type Replay=(orderedStepIds:readonly string[])=>ReplayResult;
}
