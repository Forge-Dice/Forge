import { Access, Authoring, Presentation, Interrogation, Core, Challenge, Proof, type EntityRef, type VisibleRef, type CaseTruth, type CaseSolution } from './contracts.js';
import type { ConclusionId, ConclusionClaim } from '../source/src/domain/case-solution.ts';
import type { PersonId } from '../source/src/domain/case-truth.ts';
declare const t:CaseTruth,s:CaseSolution, map:Access.Map, pres:Presentation.Document;
declare const refs:Presentation.Translator, ic:Interrogation.PlayerClaim, ec:Presentation.PlayerClaim;
declare const eo:Presentation.Observation, io:Interrogation.Observation, vr:VisibleRef;
declare const bridge:Interrogation.Bridge, ids:readonly ConclusionId[], challenge:Challenge.Document;
declare const input:Interrogation.Input, known:readonly EntityRef[], raw:string;
// Compatible edges and deliberately weak compile boundaries.
const samePort:Interrogation.Translator=refs;
const widerClaim:Interrogation.PlayerClaim=ec;
Access.resolveInvestigation(map,known,{kind:'search_location',locationId:raw}); // unknown is parsed at runtime
Presentation.releaseEvidence(pres,raw,refs);
Interrogation.interrogate({...input,refs:samePort,known});
const accusation=Core.parseAccusation({schemaVersion:1,caseId:t.caseId,truthHash:raw,literals:[]},t);
Challenge.evaluateChallengeAccusation(t,s,challenge,accusation);
const hashA:string='same shape, different identity',hashB:string=hashA; // compiler cannot enforce package binding
// Each rejected direct wire is intentional and must remain a compiler diagnostic.
// @ts-expect-error C01: NPC's 9 claims cannot narrow to evidence's 3
const c01:Presentation.PlayerClaim=ic;
// @ts-expect-error C02: NPC DTO is not evidence DTO
const c02:Presentation.Observation=io;
// @ts-expect-error C03: public report is not certified internal proof release
const c03:Proof.Released=eo;
// @ts-expect-error C04: NPC response requires provenance/ID adapter to proof literal
const c04:Proof.Released=io;
// @ts-expect-error C05: local handle not persistent player ref
const c05:string=vr;
// @ts-expect-error C06: bridge's id:string is not branded domain EntityRef
const c06:EntityRef|null=bridge.entityOf(vr);
// @ts-expect-error C07: mentions must resolve ref->kind/id
const c07:readonly EntityRef[]=eo.mentions;
// @ts-expect-error C08: answerScope IDs are not allowedClaims
const c08:readonly ConclusionClaim[]=ids;
// @ts-expect-error C09: opaque string is not domain person ID
const c09:PersonId=raw;
// @ts-expect-error C10: callback output lacks bindings/released
const c10:Proof.Replay=()=>Presentation.releaseEvidence(pres,raw,refs);
// @ts-expect-error C11: not every NPC response has mentions
const c11=io.mentions;
// @ts-expect-error C12: not every evaluation result carries status
const c12=Core.evaluateConclusionClaim(t,s,{}).status;
// @ts-expect-error C13: player claim field names/ref domain differ from canonical conclusion
const c13:ConclusionClaim=ic;
// @ts-expect-error C14: frozen returned arrays not writable
const c14:EntityRef[]=known;
