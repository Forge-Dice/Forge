import { Access, Authoring, Presentation, Interrogation, Core, Challenge, Proof, type EntityRef, type VisibleRef, type CaseTruth, type CaseSolution } from './contracts.js';
import type { ConclusionId, ConclusionClaim } from '../source/src/domain/case-solution.ts';
import type { PersonId } from '../source/src/domain/case-truth.ts';
declare const t:CaseTruth,s:CaseSolution, map:Access.Map, pres:Presentation.Document;
declare const refs:Presentation.Translator, ic:Interrogation.PlayerClaim, ec:Presentation.PlayerClaim;
declare const eo:Presentation.Observation, io:Interrogation.Observation, vr:VisibleRef;
declare const bridge:Interrogation.Bridge, ids:readonly ConclusionId[], challenge:Challenge.Document;
declare const input:Interrogation.Input, known:readonly EntityRef[], raw:string;
// Compatible edges and deliberately weak compile boundaries.
const samePort:Interrogation.Translator=refs;
const widerClaim:Interrogation.PlayerClaim=ec;
Access.resolveInvestigation(map,known,{kind:'search_location',locationId:raw}); // unknown is parsed at runtime
Presentation.releaseEvidence(pres,raw,refs);
Interrogation.interrogate({...input,refs:samePort,known});
const accusation=Core.parseAccusation({schemaVersion:1,caseId:t.caseId,truthHash:raw,literals:[]},t);
Challenge.evaluateChallengeAccusation(t,s,challenge,accusation);
const hashA:string='same shape, different identity',hashB:string=hashA; // compiler cannot enforce package binding
// Each rejected direct wire is intentional and must remain a compiler diagnostic.
const c01:Presentation.PlayerClaim=ic;
const c02:Presentation.Observation=io;
const c03:Proof.Released=eo;
const c04:Proof.Released=io;
const c05:string=vr;
const c06:EntityRef|null=bridge.entityOf(vr);
const c07:readonly EntityRef[]=eo.mentions;
const c08:readonly ConclusionClaim[]=ids;
const c09:PersonId=raw;
const c10:Proof.Replay=()=>Presentation.releaseEvidence(pres,raw,refs);
const c11=io.mentions;
const c12=Core.evaluateConclusionClaim(t,s,{}).status;
const c13:ConclusionClaim=ic;
const c14:EntityRef[]=known;
