# MYST — Accusation Challenge Exactness Lab

Strict read-only study. No canonical repository mutation. No production challenge implementation.
Base: Forge-Dice/Forge main `3d7545d843883418348004e68717399a64da7a7d`.

## Evidence boundary

Real code exercised: CaseTruth parser, Semantic Validator, CaseSolution parser, ConclusionClaimSchema, Truth/Solution hashing, contract-document format parser.
MYST-0002 is a pinned DESIGN DEPENDENCY. Its neutral Core and Accusation refinements are simulated, not existing production code. Challenge parsing/evaluation is test instrumentation only.

The report explains the finite-set oracle and its limits. 60 configurations, 25,680 attempts (25,440 parsed), 92,160 property assertions; 29 additional targeted policy cases and 12 boundary probes. 94 acceptance cases in the draft are normative future tests, not a claim of 94 implementation tests passed.

## Reproduce

Use Node 24.19.0 (run used this version), Python 3, and access to the pinned repository commit. The repository is intentionally not duplicated in this deliverable. Its source identities are in base-manifest.json.

From this evidence directory:

```sh
mkdir source
git -C /path/to/Forge archive 3d7545d843883418348004e68717399a64da7a7d | tar -x -C source
npm ci --ignore-scripts --prefix source
ln -s source/node_modules node_modules
node experiments/targeted-lab.mjs
./node_modules/.bin/tsc --noEmit --strict --noUncheckedIndexedAccess --exactOptionalPropertyTypes --allowImportingTsExtensions --module NodeNext --moduleResolution NodeNext --target ES2022 --skipLibCheck --types node experiments/declaration-smoke.mts
python3 experiments/write-contract.py
python3 experiments/write-report.py
python3 experiments/check-evidence.py
```

No new dependency. Existing lock pins Zod 4.6.5, Vitest 5.0.3, TypeScript 7.0.2 and Node types. `targeted-lab.mjs` imports and runs `policy-lab.mjs` first. Node test output timestamps will change; deterministic counts and truth/solution content remain fixed. Report build uses already supplied format-check.json; check-evidence.py recomputes the draft format/hash using the actual pinned parser.

`attempts.json` references claim indices in `universe.json`. Parse-rejected rows store raw claims. Main metric categories overlap. Canonically false asserted false is a correct negative assertion, not a false accusation. The known-false/wrong-polarity distinction is explicit in report.

`declaration-smoke.mts` is compile-only: declarations of the proposed API, not a production module. The first invocation omitted --types node and failed TS2591. The corrected compiler command passed; no domain source was changed.

## Integrity

SHA256SUMS.json covers the packaged files except itself. It contains ordinary file hashes, distinct from the domain-separated contract hash in results/contract-format-check.json. The manifest verifies identity, not approval.

The draft remains unregistered with acceptedCommit:null for MYST-0002. No push, implementation, or registry action is authorized by this archive.
