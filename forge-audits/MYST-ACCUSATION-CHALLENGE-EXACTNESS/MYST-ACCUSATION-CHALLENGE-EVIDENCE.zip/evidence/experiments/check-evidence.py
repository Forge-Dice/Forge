from pathlib import Path
from html.parser import HTMLParser
import json,subprocess,hashlib
B=Path(__file__).resolve().parents[1]
class Check(HTMLParser):
 def __init__(self):super().__init__();self.ids=[];self.anchors=[];self.headings=0;self.scripts=0;self.stack=[]
 def handle_starttag(self,t,a):
  d=dict(a)
  if 'id' in d:self.ids.append(d['id'])
  if t=='a' and d.get('href','').startswith('#'):self.anchors.append(d['href'][1:])
  if t=='h2':self.headings+=1
  if t=='script':self.scripts+=1
  if t not in {'meta','link','br','hr','img','input','source','wbr'}:self.stack.append(t)
 def handle_endtag(self,t):
  assert self.stack and self.stack[-1]==t,('tag mismatch',t,self.stack[-3:]);self.stack.pop()
h=Check();h.feed((B/'deliverables/MYST-ACCUSATION-CHALLENGE-EXACTNESS-REPORT.html').read_text());assert not h.stack;assert h.headings==12;assert len(h.ids)==len(set(h.ids));assert set(h.anchors)<=set(h.ids);assert h.scripts==0
s=json.loads((B/'results/summary.json').read_text());assert s['attempts']==25680 and s['configs']==60
assert s['parsedAttempts']+s['parseRejected']==s['attempts']
for k in ['E','F']:
 assert s['policies'][k]['invalidAccepted']==s['policies'][k]['validRejected']==0
assert json.loads((B/'results/acceptance-catalog.json').read_text())['count']==94
js='''import fs from 'node:fs';import {createHash} from 'node:crypto';import {parseContractDocument} from './source/src/forge/contract-document.ts';const s=fs.readFileSync('deliverables/MYST-CHALLENGE-0001.contract.DRAFT.md','utf8');let r=parseContractDocument(s,x=>createHash('sha256').update(x).digest('hex'));if(!r.ok)throw Error(JSON.stringify(r));console.log(JSON.stringify({ok:r.ok,contentHash:r.document.ref.contentHash}));'''
r=subprocess.run(['node','--input-type=module','-e',js],cwd=B,text=True,capture_output=True);assert r.returncode==0,r.stderr
actual=json.loads(r.stdout);assert actual['contentHash']==json.loads((B/'results/contract-format-check.json').read_text())['ref']['contentHash']
result={'htmlBalanced':True,'sections':h.headings,'anchorsChecked':len(h.anchors),'externalScripts':0,'summaryConsistent':True,'draftFormat':actual,'acceptanceCases':94}
(B/'results/artifact-check.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
