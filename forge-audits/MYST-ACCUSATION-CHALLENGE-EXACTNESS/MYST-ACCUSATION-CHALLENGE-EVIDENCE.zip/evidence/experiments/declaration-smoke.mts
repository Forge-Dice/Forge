// DESIGN declaration smoke only. No challenge implementation is defined or imported.
import type { z } from 'zod';
import type {CaseTruth, DeepReadonly} from '../source/src/domain/case-truth.ts';
import type {CaseSolution, ConclusionClaim, ConclusionClaimSchema} from '../source/src/domain/case-solution.ts';
type Accusation = DeepReadonly<{caseId:CaseTruth['caseId'];truthHash:string;literals:{claim:ConclusionClaim;value:boolean}[]}> & z.$brand<'Accusation'>;
type ChallengeInput={schemaVersion:1;caseId:string;truthHash:string;solutionHash:string;allowedClaims:z.input<typeof ConclusionClaimSchema>[]};
type Challenge=DeepReadonly<{schemaVersion:1;caseId:CaseTruth['caseId'];truthHash:string;solutionHash:string;allowedClaims:ConclusionClaim[]}> & z.$brand<'AccusationChallenge'>;
type Result={readonly success:true;readonly verdict:'solved'|'not_solved'}|{readonly success:false;readonly code:'SOLUTION_BINDING_MISMATCH'|'CHALLENGE_BINDING_MISMATCH'|'ACCUSATION_BINDING_MISMATCH'|'INVALID_CLAIM'|'UNKNOWN_REFERENCE'};
declare function parse(input:unknown,truth:CaseTruth,solution:CaseSolution):Challenge;
declare function evaluate(truth:CaseTruth,solution:CaseSolution,challenge:Challenge,accusation:Accusation):Result;
declare const truth:CaseTruth,solution:CaseSolution,accusation:Accusation,challenge:Challenge,input:ChallengeInput,result:Result;
function neverExecuted(){
 input.solutionHash='mutable';input.allowedClaims.push({kind:'eventIntent',eventId:'event:e3',value:'intended'});
 const parsed=parse(input,truth,solution);evaluate(truth,solution,parsed,accusation);
 // @ts-expect-error TC1 root readonly
 challenge.solutionHash='x';
 // @ts-expect-error TC2 array readonly
 challenge.allowedClaims.push({kind:'noPersonResponsibleForEvent',eventId:'event:e3'});
 // @ts-expect-error TC3 nested readonly
 challenge.allowedClaims[0]!.kind='eventIntent';
 // @ts-expect-error TC4 no brand on authoring input
 evaluate(truth,solution,input,accusation);
 const {schemaVersion,caseId,truthHash,solutionHash,allowedClaims}=challenge;
 // @ts-expect-error TC5 shape alone has no brand
 const forged:Challenge={schemaVersion,caseId,truthHash,solutionHash,allowedClaims};
 // @ts-expect-error TC6 no cross snapshot brand substitution
 evaluate(truth,solution,solution,accusation);
 // @ts-expect-error TC7 incorrect accusation argument
 evaluate(truth,solution,challenge,input);
 if(result.success){
  // @ts-expect-error TC8 result readonly
  result.verdict='not_solved';
  // @ts-expect-error TC9 no per-literal feedback
  result.matchedClaims;
 }else{
  // @ts-expect-error TC10 no verdict on technical failure
  result.verdict;
 }
}
void neverExecuted;
