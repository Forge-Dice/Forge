from pathlib import Path
import json,runpy
root=Path(__file__).resolve().parents[1]
meta={'forgeContractFormat':1,'taskId':'MYST-CHALLENGE-0001','contractVersion':1,'baseCommit':'3d7545d843883418348004e68717399a64da7a7d','dependencies':[{'taskId':'MYST-0002','acceptedCommit':None}],'scope':{'create':['src/domain/accusation-challenge.ts','tests/accusation-challenge.fixture.ts','tests/accusation-challenge.test.ts','tests/accusation-challenge.typecheck.ts'],'modify':[]},'requiredChecks':[{'name':'typecheck','command':'npm run typecheck'},{'name':'test','command':'npm test'}],'mutationSmoke':'required'}
body='''# MYST-CHALLENGE-0001 — Exactness Wrapper V1 · DRAFT

**Status: DRAFT, nicht implementiert, nicht akzeptiert, nicht registriert.** Dieses Dokument ist ein Entwurf außerhalb des Repositories und autorisiert keine Änderung. Kein ausführbarer Run-Contract, solange MYST-0002 fehlt. Stand: 2026-10-03.

## 1. Basis und Dependency-Gate

Gelesener `Forge-Dice/Forge/main`: `3d7545d843883418348004e68717399a64da7a7d`. Implementiert: CaseTruth, CaseSolution, deren Hashes und private dreifache Conclusion-Auflösung. Accusation/Verdict und `evaluateConclusionClaim` fehlen auf dieser Basis.

Design Dependency: `MYST-0002-ACCUSATION-VERDICT-V1.contract.DRAFT.md`, Inhaltshash `sha256("forge-contract-v1\\n" + exactText)` = `3758b20c5eef9ee9dbaa9b04660cc0d82de041da183326308e7d1f37868b027d`. Dort: Unknown neutral; zusätzliche korrekte Literale zulässig; alle Required-Literale notwendig; strukturelle Duplikate unabhängig von Polarität verboten; Event ohne Resolution ergibt undetermined (D5).

`acceptedCommit:null` behauptet keine akzeptierte Dependency. Vor einer späteren Implementierung: akzeptierten MYST-0002-Stand und dessen API belegen, Draft gegen diesen Stand neu prüfen, Basis und Dependency in einer neuen Contract-Version pinnen. Abweichende Core-Semantik blockiert diesen Entwurf. Keine Resolver-Kopie als Ersatz.

Reads: `src/domain/case-truth.ts`, `case-truth.identity.ts`, `case-solution.ts`, `case-solution.identity.ts`; nach Dependency-Erfüllung zusätzlich `case-accusation.ts` und MYST-0002-Tests. Format-1-Frontmatter folgt dem vorhandenen Contract-Parser. Seine syntaktische Gültigkeit ist keine fachliche Freigabe.

## 2. Ziel und Grenze

Vertrauenswürdiger Host wählt eine bereits geparste Challenge. Spieler liefert ausschließlich die durch MYST-0002 geparste Accusation. Keine frei vom Spieler wählbare Solution, Challenge oder Scope. TypeScript-Brands und unkeyed Hashes sind keine Authentisierung.

Solved genau dann, wenn der neutrale Core solved liefert und jedes eingereichte Literal einen erlaubten Claim mit exakt passendem bestimmten kanonischen Boolean enthält. Korrekte zusätzliche in-scope Literale bleiben zulässig. Partial-Solutions bleiben zulässig. Unknown wird niemals als false ausgewertet.

Keine Proof-, Solvability-, PlayerKnowledge-, Evidence-Access-, Session-, Save-, UI-, Score- oder Attempt-Limit-Logik. Keine Runtime-LLM-Nutzung. Kein neuer Frage-Typ, keine Package-Architektur, kein Challenge-Hash, kein neues Winning-Array, keine neue Dependency. Bestehende Domain-Dateien bleiben in diesem Task unverändert.

## 3. Vollständige öffentliche API

```ts
export type AccusationChallengeInput = z.input<typeof ChallengeShapeSchema>;
export type AccusationChallenge = DeepReadonly<z.output<typeof ChallengeShapeSchema>>
  & z.$brand<"AccusationChallenge">; // ChallengeShapeSchema bleibt privat
export type ChallengeAccusationResult =
  | { readonly success: true; readonly verdict: "solved" | "not_solved" }
  | { readonly success: false; readonly code:
      "SOLUTION_BINDING_MISMATCH" | "CHALLENGE_BINDING_MISMATCH" |
      "ACCUSATION_BINDING_MISMATCH" | "INVALID_CLAIM" | "UNKNOWN_REFERENCE" };

export function parseAccusationChallenge(
  input: unknown, truth: CaseTruth, solution: CaseSolution
): AccusationChallenge; // wirft ZodError

export function evaluateChallengeAccusation(
  truth: CaseTruth, solution: CaseSolution,
  challenge: AccusationChallenge, accusation: Accusation
): ChallengeAccusationResult;
```

Typ-Pseudocode bezeichnet die geforderte Oberfläche, keine bestehende Implementierung. Alle Ergebnisobjekte sind gefroren. Keine weitere Export-Funktion, kein öffentlicher ungebrandeter Output-Shape, keine Factory oder Klasse. `claimKey` und `evaluateConclusionClaim` aus MYST-0002 wiederverwenden; keine zweite Wahrheits- oder Gleichheitstabelle.

## 4. Challenge-Dokument und Parse-Vertrag

Striktes Root-Objekt: `schemaVersion:1`, `caseId:CaseIdSchema`, `truthHash` und `solutionHash` jeweils 64 lowercase Hex-Zeichen, `allowedClaims: ConclusionClaimSchema[]`. **1..256** Elemente. 256 ist ein konservatives V1-Ressourcenbudget, keine fachliche Schuldgrenze. Es begrenzt die Wrapper-Evaluation, nicht die Größe der bestehenden Truth oder die Kosten beliebiger Raw-JSON-Verarbeitung.

Scope enthält nackte Claims ohne Boolean-Polarität. `eventIntent.value` und `eventMechanism.value` sind notwendige String-Enum-Felder; sie dürfen nicht entfernt werden. Keine `conclusionId`, Labels oder versteckten Answer-Metadaten im Challenge-Shape.

Nach Shape-Prüfung in dieser Reihenfolge:

1. Solution an Truth prüfen (`caseId`, `truthHash`). Fehler: Root-Zod-Issue `SOLUTION_BINDING_MISMATCH`; keine weiteren Cross-Checks.
2. Challenge an Truth und Solution prüfen: `caseId`, `truthHash === hashCaseTruth(truth)`, `solutionHash === hashCaseSolution(solution)`. Fehler jeweils am betreffenden Root-Feld; dann keine Referenz-/Coverage-Folgefehler.
3. Scope-Claims referenzprüfen: eventId, optional personId und causeEventId müssen in Truth existieren. Präzise Feldpfade `allowedClaims[i].<field>`. Keine Katalog- oder Resolution-Mitgliedschaft fordern.
4. Eindeutigkeit mit dem bestehenden `claimKey`, unabhängig von Property-Reihenfolge. Fehler am späteren `allowedClaims[j]`, mit Index des ersten Auftretens. Keine stille Deduplikation.
5. Jeder `solution.requiredConclusions`-Claim muss im Scope liegen. Bei Fehlen Issue an `allowedClaims` mit interner Conclusion-ID und Claim-Key. Das ist privates Autorenfeedback, niemals Player-Feedback.
6. Input klonen und rekursiv einfrieren; nominal brand. Eingabe weder verändern noch einfrieren. Array-Reihenfolge bewahren; sie ist für Membership und Verdict bedeutungslos.

Kanonisch false und undetermined Scope-Mitglieder sind zulässig und für eine antwortunabhängige Kandidatenmenge oft notwendig. Required-Coverage prüft nur die formale Gewinnbarkeit dieses Vertrags, keine Beweisbarkeit oder öffentliche Kandidaten-Vollständigkeit.

## 5. Evaluation und Fehlerpriorität

Vor jedem Ergebnis, auch bei leerer oder zu langer Anklage: Solution→Truth, Challenge→Truth+Solution, Accusation→Truth prüfen, in genau dieser Reihenfolge. Bei Fehler entsprechenden `…_BINDING_MISMATCH` zurückgeben. Keinen technischen Fehler in ein fachliches `not_solved` umdeuten.

Danach:

1. `accusation.literals.length > challenge.allowedClaims.length` → `not_solved` ohne Core-/Conclusion-Evaluation. MYST-0002 garantiert eindeutige Claim-Keys, somit ist mindestens ein Claim außerhalb des Scopes.
2. Scope als Set aus `claimKey` bilden. Jeder Claim muss enthalten sein; sonst `not_solved` ohne per-Literal-Hinweis.
3. `evaluateAccusation(truth, solution, accusation)` aufrufen. Technischen Fehler durchreichen. Core `not_solved` → `not_solved`.
4. Für jedes Literal `evaluateConclusionClaim(...)` aufrufen. Technischen Fehler durchreichen. Nur `status === literal.value` ist zulässig; jede Abweichung → `not_solved`. Sind alle exakt passend → `solved`.

`"undetermined" === true` und `"undetermined" === false` sind beide false. Das ist eine Annahmebedingung für einen eingereichten Satz, keine Umdeutung seines Wahrheitswerts. Ein zusätzlicher `status !== "undetermined"`-Guard wäre logisch redundant. Alternativ ist Core + Scope + Reject-Unknown gleichwertig, weil der Core bestimmte falsche Polaritäten bereits ausschließt. Keine Null-/Truthiness-Coercion.

Die Wrapper-Funktion akzeptiert bereits geparste Snapshots. Keine zweite Raw-Accusation-Parsing-Schicht; keine Antwort-Hinweise für defekte Raw-Eingaben. Shape-/Autorenfehler sind host-intern. Spielerfachliche Oberfläche: ausschließlich `solved | not_solved`. Technische Fehler bleiben getrennte Host-Fehler, nicht Spieler-Fehlschläge.

## 6. Public-Question-Vertrag (Publication-Voraussetzung)

Diese Regeln sind verpflichtende Autoren-/Publication-Prüfungen. Sie sind **nicht** durch das generische Zwei-Funktionen-API automatisch beweisbar und führen zu keinem neuen Domain-Feld oder Validator-Export dieses Tasks.

| Öffentliche Frage | Pflichtregel |
|---|---|
| `identify_all_responsible(event)` | Responsibility muss complete sein. Kandidaten sind alle öffentlich zugelassenen Personen, nicht die geheimen Assignments; keine tatsächliche verantwortliche Person darf fehlen. nobody-Claim immer anbieten, nicht nur bei leerer Antwort. Alle tatsächlichen Verantwortlichen als positive Required-Literale, bei keiner Person nobody=true. Keine unerklärten weiteren globalen Required-Ziele. |
| `required_literals` / enge Teilfrage | Frage und ausgewählte Claim-Dimensionen müssen öffentlich begründet und unabhängig von geheimen Polaritäten sein. Scope=Required-Claim-Keys kann bei einer vorab gewählten Ja/Nein-Frage korrekt sein. Core-R ist weiterhin global: eine Teilfrage darf nicht übrige Required-Literale ignorieren. Bei Bedarf später eine eigene Solution authoren und neu binden, kein per-Challenge Winning-Set ergänzen. |
| Rollenfrage | Für jeden öffentlich gewählten Kandidaten alle drei Rollen-Claims anbieten. Nicht nur bekannte/wahre Rollen oder Personen aus geheimen Assignments auswählen. Bekannte Rollenliste ist geschlossen; roles:null bleibt U. „Alle Rollen“ ist bei null nicht als bestimmte Abschlussantwort veröffentlichbar. |
| Ursachenfrage | Kandidaten aus öffentlichem Ereignisraum, unabhängig von tatsächlichen causedByEventIds; Selbstursache ausschließen. Direkte Ursachen, keine transitive Erreichbarkeit. „Alle Ursachen“ erfordert causesComplete:true und vollständige Required-Ursachen; kein Ursachenfreiheits-Claim existiert, diesen nicht erfinden. |
| Intent-/Mechanism-Frage | Alle drei Varianten der jeweiligen vorhandenen Enum für das öffentlich gewählte Event anbieten. Bei null keine bestimmte Abschlussantwort versprechen. Vorab bestimmte Ja/Nein-Teilfrage ist möglich, wenn ihr Literal kanonisch bestimmt ist. |

Ein geschlossenes „alle“-Versprechen mit partial, fehlenden Required-Akteuren, unvollständigen öffentlichen Kandidaten oder Scope aus nur wahren Claims ist ein Authoringfehler. Generischer Parser kann Unterauthoring nicht erkennen. Gegenwelten-Test: gleiche öffentliche Frage/Daten bei geänderter privater Antwort → gleiche veröffentlichte Kandidaten-Claims. Absichtlich schmale öffentliche Frage kann Person oder Event nennen; nicht jede solche Nennung ist ein Leak.

Das vollständige interne Challenge-Dokument wird nicht automatisch veröffentlicht. Insbesondere kein solutionHash, keine Required-Polaritäten, keine internen technischen Fehler, keine kanonischen IDs verborgener Entities. Lösungshash ist Bindung, kein Geheimnis-Schutz; ein kleiner bekannter Lösungsraum erlaubt Wörterbuchtests. Diese Grenze definiert keine Transport-, PlayerRef- oder UI-Architektur.

## 7. Konkrete Acceptance Tests

Fixture-Konvention: `R` ist die vollständige Menge korrekt signierter Required-Claims. „plus R“ ergänzt Claim-eindeutig. Positive und negative Required-Literale verwenden. Alle Solutions mit echtem `parseCaseSolution`, Truth zusätzlich mit echtem Semantic Validator prüfen. P/V/B/T sind zukünftige Implementierungs-Akzeptanztests; L sind Publication-Review-Fixtures. Sie sind nicht als heute ausgeführte Tests einer existierenden Wrapper-Implementierung zu bezeichnen.

'''
tests=runpy.run_path(str(root/'experiments/acceptance-data.py'))['TESTS']
body+='| ID | Eingabe / Eingriff | Erwartung |\n|---|---|---|\n'+'\n'.join('| '+' | '.join(row)+' |' for row in tests)+'\n'
body+='''
## 8. Deterministische Properties und Mutanten

Keine neue Dependency: vorhandene Vitest-/TypeScript-Werkzeuge, eigener fester LCG-Seed `0x03175a99`, bounded Fixtures. Nicht nur den Produktionsalgorithmus in Tests spiegeln. Kanonische Statuswerte für auflösbare Claims über beide Required-Polaritäten im echten `parseCaseSolution` gewinnen; keine kopierte Resolver-Switch-Tabelle. D5 gesondert über akzeptiertes MYST-0002 testen.

Unabhängiges Mengen-Oracle: R = signierte Required-Menge; M = alle bestimmten, kanonisch korrekt signierten Scope-Claims; A = eingereichte signierte Menge. Erwartung `R ⊆ A ⊆ M`. Je mindestens 30 Configs mit complete/partial, 0/1/mehreren Assignments, null/mehreren Rollen, null/bekannter Ursache/Intent/Mechanism, positiven und negativen Requirements. Mindestens 2.000 Versuche.

Properties: (1) Scope-/Literal-/Property-Permutation invariant; (2) E = Mengen-Oracle = F; (3) solved impliziert Core solved; (4) solved enthält weder U noch Fehlpolarität noch Fremd-Claim; (5) jedes fehlende R führt not_solved; (6) korrektes extra in-scope Literal erhält solved; (7) beliebige Required-Boolean-Flips scheitern; (8) Reparse/Freeze schützt Snapshot; (9) gleiche semantische Reihenfolgevariation ändert die gebundenen Hashes nicht, Inhaltsänderung schon. Mindestens ein positiver Zeuge je Property, kein ausschließlich vacuous random set.

| Mutant | Erforderlicher Zeuge |
|---|---|
| M1 Scope-Prüfung entfernt | R + korrekte Aussage zu fremdem Event würde solved |
| M2 Unknown-/Exactness-Guard entfernt | R + partial unlisted person=true würde solved |
| M3 U zu false coerced | R + partial unlisted person=false würde solved |
| M4 Core-/Required-Coverage entfernt | Leere Anklage würde solved |
| M5 Required every durch some ersetzt | Einer von mehreren erforderlichen Akteuren fehlt |
| M6 Nur erstes Literal geprüft | Späteres U oder out-of-scope Literal |
| M7 solutionHash-Bindung entfernt | Gleiche Truth + erhöhte Solution-Revision |
| M8 Scope-Duplikatprüfung entfernt | Property-umgeordnetes Duplikat |
| M9 Scope-Cap entfernt | 257 unterschiedliche referenzgültige Claims |
| M10 Per-Literal-Diagnose im Result ergänzt | Exakte Result-Key-Allowlist bricht |

Äquivalente Mutanten NICHT als fehlende Testgüte werten: explizite determined-Prüfung entfernen bei verbleibendem striktem Matching; Matching entfernen bei unverändertem Core + determined-Prüfung. Beide erhalten die Policy. Type-level Tests müssen wirklich per tsc laufen; Laufzeit-Object.freeze ersetzt keine Brand-/Readonly-Prüfung.

## 9. Abnahme und Nichtziele

Abnahme erst auf belegter MYST-0002-Implementierung: beide Required Checks grün, konkrete Tests und deterministisches Oracle grün, mindestens sechs nichtäquivalente Mutanten getötet, keine neue Dependency, nur die vier neuen Scope-Dateien. Produktionsdatei bleibt ein dünner Adapter, ohne Resolution-Switch, Wissensmodell oder zusätzliche Winning-Regeln. Präzise Autorenpfade und strikt minimales Spielergebnis gehören zum Vertrag.

Die vorliegende Lab-Evidenz prüft reale heutige Parser/Hashes sowie ausdrücklich simulierte MYST-0002-/Wrapper-Policies. Sie ersetzt diese spätere Abnahme nicht. Keine Freigabe, Push-, Registry- oder GitHub-Aktion folgt aus diesem Draft.
'''
text='---json\n'+json.dumps(meta,ensure_ascii=False,indent=2)+'\n---\n'+body
(root/'deliverables/MYST-CHALLENGE-0001.contract.DRAFT.md').write_text(text)
(root/'results/acceptance-catalog.json').write_text(json.dumps({'count':len(tests),'status':'NORMATIVE FUTURE TESTS; publication rows L are review fixtures','tests':[dict(zip(['id','input','expected'],t)) for t in tests]},ensure_ascii=False,indent=2))
print({'acceptanceCases':len(tests),'bytes':len(text.encode())})
