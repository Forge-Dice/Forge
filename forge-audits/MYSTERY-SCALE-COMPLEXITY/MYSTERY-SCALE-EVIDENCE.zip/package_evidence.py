from pathlib import Path
import hashlib,json,zipfile,math
from html.parser import HTMLParser
class QA(HTMLParser):
 def __init__(self):super().__init__();self.sections=0;self.images=0;self.scripts=0;self.ids=set();self.anchors=[]
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if 'id' in a:self.ids.add(a['id'])
  if tag=='a' and a.get('href','').startswith('#'):self.anchors.append(a['href'][1:])
  if tag=='section':self.sections+=1
  if tag=='script':self.scripts+=1
  if tag=='img':self.images+=1;assert a['src'].startswith('data:image/png;base64,')
p=Path('MYSTERY-SCALE-COMPLEXITY-REPORT.html');q=QA();q.feed(p.read_text());assert(q.sections,q.images,q.scripts)==(31,3,0);assert all(a in q.ids for a in q.anchors)
for file in ['benchmarks.json','all-benchmark-groups.json','component-bench.json','phases.json','integrated-replay.json']:
 for r in json.loads((Path('lab/results')/file).read_text()):assert math.isfinite(r['median_ms']) and r['median_ms']>=0
files=[Path('README.txt'),p,Path('package_evidence.py')]
files.extend(x for x in Path('baseline').rglob('*') if x.is_file() and 'node_modules' not in x.parts)
files.extend(x for x in Path('lab').rglob('*') if x.is_file() and 'node_modules' not in x.parts and '__pycache__' not in x.parts and '.libraryhelpers' not in x.parts and x.suffix!='.pyc')
files.extend(Path('inputs').glob('*.md'));files.extend(x for x in Path('inputs/DIE-LEERE-VITRINE-CASE-PACK').rglob('*') if x.is_file() and '__pycache__' not in x.parts)
manifest={str(f):{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in files};Path('MYSTERY-SCALE-MANIFEST.json').write_text(json.dumps(manifest,indent=2));files.append(Path('MYSTERY-SCALE-MANIFEST.json'))
with zipfile.ZipFile('MYSTERY-SCALE-EVIDENCE.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in files:z.write(f,str(f))
with zipfile.ZipFile('MYSTERY-SCALE-EVIDENCE.zip') as z:assert z.testzip() is None
print('Verified 31 sections, 3 figures,',len(files),'archive files;',Path('MYSTERY-SCALE-EVIDENCE.zip').stat().st_size,'ZIP bytes')
