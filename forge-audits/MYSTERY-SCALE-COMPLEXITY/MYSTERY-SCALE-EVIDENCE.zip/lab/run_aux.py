import subprocess,json,time,pathlib
out=[]
def run(args,timeout=30):
 start=time.perf_counter()
 try:
  r=subprocess.run(args,text=True,capture_output=True,timeout=timeout);record={'args':args,'wall_s':time.perf_counter()-start,'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
 except subprocess.TimeoutExpired as e:record={'args':args,'wall_s':time.perf_counter()-start,'timeout_s':timeout,'censored':True,'stdout':(e.stdout or b'').decode() if isinstance(e.stdout,bytes) else e.stdout,'stderr':(e.stderr or b'').decode() if isinstance(e.stderr,bytes) else e.stderr}
 out.append(record);pathlib.Path('results/aux-run.json').write_text(json.dumps(out,indent=2));print(args[-1],record.get('exitCode','timeout'),flush=True)
run(['node','--expose-gc','supplemental.ts'],60)
for n in ['250','500','1000']:run(['node','--expose-gc','adversary.ts',n],20)
run(['node','vitrine.ts']);run(['python3','vitrine_host_bench.py']);run(['node','phases.ts'],60)
for repeat in range(3):run(['node','--expose-gc','copy-probe.ts','50000'],20)
for size in ['TINY','SMALL','MEDIUM','LARGE','STRESS']:
 for mode in ['package','projections','session1000','session10000']:
  for repeat in range(3):run(['node','--expose-gc','memory.ts',size,mode],30)
