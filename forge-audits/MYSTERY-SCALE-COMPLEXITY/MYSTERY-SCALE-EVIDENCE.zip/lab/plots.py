import json,pathlib,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=pathlib.Path('results');b=json.loads((p/'benchmarks.json').read_text());ir=json.loads((p/'integrated-replay.json').read_text());plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'white','axes.grid':True,'grid.alpha':.2})
fig,ax=plt.subplots(figsize=(10,5.3));styles={'sparse':('#357b59','-'),'dense':('#a03944','-'),'chain':('#24658e','-'),'star':('#82a354','--'),'components':('#786a9d',':'),'near-cycle':('#769aad','--'),'cycle':('#b27c27','-')}
for shape,(color,line) in styles.items():
 rows=[r for r in b if r['op']=='semantics.graph' and r['size']['shape']==shape];x=[r['size']['n'] for r in rows];y=[r['median_ms'] for r in rows];err=[[r['median_ms']-r['min_ms'] for r in rows],[r['max_ms']-r['median_ms'] for r in rows]]
 ax.errorbar(x,y,yerr=err,label=shape,color=color,linestyle=line,marker='o',capsize=2,linewidth=1.7)
ax.set_xscale('log');ax.set_yscale('log');ax.set_xlabel('Events');ax.set_ylabel('Median ms, log');ax.set_title('Produktiver Semantic Validator: Struktur und Größe');ax.legend(ncol=4,loc='upper left',fontsize=9);fig.text(.1,.005,'MEASURED PRODUCTION · Node 24 · Warmup ausgeschlossen · Fehlerbalken Min–Max · keine Big-O-Kurvenanpassung',fontsize=8);fig.tight_layout(rect=[0,.025,1,1]);fig.savefig(p/'semantic-scale.png',dpi=170);plt.close(fig)
fig,axs=plt.subplots(1,2,figsize=(11.5,4.9))
for op,label,color in [('session.replay-working','Working state','#357b59'),('session.replay-copy','Copy every event','#a03944')]:
 rows=[r for r in b if r['op']==op];axs[0].plot([r['size'] for r in rows],[r['median_ms'] for r in rows],marker='o',label=label,color=color)
axs[0].scatter([50000],[20000],marker='^',color='#a03944');axs[0].annotate('50k: >20 s\n3 Timeouts',(50000,20000),xytext=(-80,-10),textcoords='offset points',fontsize=9);axs[0].set_title('Reducer-Skeleton')
for variant,label,color in [('rebuild-each-action','Hash/Projection pro Aktion','#a03944'),('working-bound','Gebundener Arbeitskontext','#357b59')]:
 rows=[r for r in ir if r['size']['variant']==variant];axs[1].plot([r['size']['n'] for r in rows],[r['median_ms'] for r in rows],marker='o',label=label,color=color)
axs[1].set_title('TINY Action-Komposition')
for ax in axs:ax.set_xscale('log');ax.set_yscale('log');ax.set_xlabel('Accepted events');ax.set_ylabel('Median ms, log');ax.legend(fontsize=8)
fig.suptitle('Replay: abgeleitete Arbeit gehört zur Messung');fig.text(.07,.005,'MEASURED SCRATCH · links keine Mystery-Aktionssemantik · rechts echte produktive Hashes/Projections, kein kompletter Sessioncontract',fontsize=8);fig.tight_layout(rect=[0,.03,1,.96]);fig.savefig(p/'replay-scale.png',dpi=170);plt.close(fig)
rows=[r for r in b if r['op']=='solvability.enumeration'];x=[r['size']['dimensions'] for r in rows];fig,axs=plt.subplots(1,2,figsize=(11,4.5));axs[0].plot(x,[r['size']['vectors'] for r in rows],marker='o',color='#24658e');axs[0].set_ylabel('Vektoren, log');axs[0].set_title('Vollständiger Scope: 2^d');axs[1].plot(x,[r['median_ms'] for r in rows],marker='o',color='#a03944');axs[1].set_ylabel('Median ms, log');axs[1].set_title('Scratch-Materialisierung')
for ax in axs:ax.set_yscale('log');ax.axvline(6,color='#357b59',ls='--');ax.axvspan(6.05,12.2,color='#fff0dc',alpha=.7);ax.set_xlabel('Antwortdimensionen');ax.set_xlim(.7,12.2);ax.set_xticks([1,2,3,4,5,6,7,8,10,12])
fig.suptitle('Sechs Dimensionen = 64 Vektoren; größerer Scope bleibt exponentiell');fig.text(.07,.005,'MEASURED SCRATCH + finite Vektorzahl · Node · schattiert außerhalb des aktuellen V1-Draftcaps · kein allgemeiner Welt-Solver',fontsize=8);fig.tight_layout(rect=[0,.03,1,.96]);fig.savefig(p/'answer-scale.png',dpi=170);plt.close(fig)
