import fs from 'node:fs';
import {performance} from 'node:perf_hooks';
import {__bench} from './semantics-instrumented.ts';
import {fixture} from './generator.ts';
import * as M from './models.ts';
import assert from 'node:assert/strict';
const rows:any[]=[];
function bench(op:string,size:any,fn:()=>any){for(let i=0;i<2;i++)fn();const samples=[];for(let i=0;i<7;i++){const cpu=process.cpuUsage(),t=performance.now();const result=fn();const c=process.cpuUsage(cpu);samples.push({ms:performance.now()-t,cpu_ms:(c.user+c.system)/1000,outputCount:result?.length??result?.size??null});}const ms=samples.map(s=>s.ms).sort((a,b)=>a-b);rows.push({source:op.startsWith('semantics')?'MEASURED PRODUCTION private function, export-only instrumented copy':'MEASURED SCRATCH',op,size,median_ms:ms[3],samples});}
for(const n of [40,100,250,500])for(const shape of ['star','chain','dense','cycle']){
const t=fixture({persons:12,locations:15,events:n,evidence:n},7341,shape).truth,map=new Map(t.events.map(e=>[e.id,e]));
const facts=t.events.flatMap(e=>e.participantIds.map(id=>({entityId:id,locationId:e.locationId,time:e.time,sourceId:e.id})));
for(const part of ['location','claims','causality'])bench(`semantics.phase.${part}`,{n,shape},()=>{const out:any[]=[];const emit=(code:any,subjectIds:any,message:any)=>out.push(Object.freeze({code,subjectIds:Object.freeze(subjectIds),message}));if(part==='location')__bench.checkLocationConflicts(facts,'PERSON_LOCATION_CONFLICT',emit);if(part==='claims')__bench.checkClaims(t,map,emit);if(part==='causality')__bench.checkCausality(t,map,emit);return out;});
}
// Small SCC counterexperiment: iterative Kosaraju over direct graph, same component semantics.
function scc(t:any){const ids=t.events.map((e:any)=>e.id),g=new Map(ids.map((id:any)=>[id,[]])),rev=new Map(ids.map((id:any)=>[id,[]]));for(const e of t.events)for(const c of e.causedByEventIds){g.get(c).push(e.id);rev.get(e.id).push(c);}const seen=new Set(),finish=[];for(const id of ids){if(seen.has(id))continue;seen.add(id);const stack=[[id,0]];while(stack.length){const top=stack.at(-1),cs=g.get(top[0]);if(top[1]<cs.length){const c=cs[top[1]++];if(!seen.has(c)){seen.add(c);stack.push([c,0]);}}else{finish.push(top[0]);stack.pop();}}}const visited=new Set(),components=[];for(const id of finish.reverse()){if(visited.has(id))continue;visited.add(id);const component=[],stack=[id];while(stack.length){const node=stack.pop();component.push(node);for(const c of rev.get(node))if(!visited.has(c)){visited.add(c);stack.push(c);}}if(component.length>1)components.push(component.sort());}return components.sort((a,b)=>a.join(',').localeCompare(b.join(',')));}
for(const shape of ['star','chain','dense','cycle','components']){const t=fixture({persons:12,locations:15,events:250,evidence:250},7341,shape).truth,map=new Map(t.events.map(e=>[e.id,e]));const findings:any[]=[];__bench.checkCausality(t,map,(code,ids)=>{if(code==='CAUSAL_CYCLE')findings.push([...ids]);});assert.deepEqual(findings,scc(t));bench('causality.scc-experiment',{n:250,shape},()=>scc(t));}
fs.writeFileSync('results/phases.json',JSON.stringify(rows,null,2));console.log(`DONE ${rows.length} phase groups`);
