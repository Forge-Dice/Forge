import fs from 'node:fs';
import os from 'node:os';
import assert from 'node:assert/strict';
import { performance } from 'node:perf_hooks';
import { sizes,fixture,generate,npcInput,solutionInput,counts } from './generator.ts';
import * as M from './models.ts';
import { parseCaseTruth } from '../baseline/src/domain/case-truth.ts';
import { hashCaseTruth } from '../baseline/src/domain/case-truth.identity.ts';
import { parseCaseSolution,createCaseSolutionSchema } from '../baseline/src/domain/case-solution.ts';
import { hashCaseSolution } from '../baseline/src/domain/case-solution.identity.ts';
import { validateCaseSemantics } from '../baseline/src/domain/case-semantics.ts';
import { parseNpcKnowledge,createNpcKnowledgeSchema } from '../baseline/src/domain/npc-knowledge.ts';
import { projectNpcKnowledge } from '../baseline/src/domain/npc-knowledge.projection.ts';
const rows:any[]=process.env.RESUME?JSON.parse(fs.readFileSync('results/benchmarks.json','utf8')):[], checks:any[]=[], metadata:any={};let sink:any;
fs.mkdirSync('results',{recursive:true});
function check(name:string,fn:()=>void){fn();checks.push({name,pass:true});}
// Calibrate once, exclude two warmups, seven batches; expensive calls use three batches.
// No discarded outliers. CPU is process user+system per operation. Memory sampled at boundaries, NOT true peak.
function bench(source:string,op:string,size:any,fn:()=>any,notes=''){
 const previous=rows.find(r=>r.source===source&&r.op===op&&JSON.stringify(r.size)===JSON.stringify(size));if(previous)return previous;
global.gc?.();let warmMs=0;for(let i=0;i<2;i++){const t=performance.now();sink=fn();warmMs+=performance.now()-t;}
 const estimate=warmMs/2,iterations=Math.min(1000,Math.max(1,Math.ceil(12/Math.max(.01,estimate)))),repeats=estimate>100?3:7;
 const samples=[];for(let run=0;run<repeats;run++){const before=process.cpuUsage(),mem0=process.memoryUsage(),t=performance.now();for(let i=0;i<iterations;i++)sink=fn();const ms=(performance.now()-t)/iterations,cpu=process.cpuUsage(before),mem=process.memoryUsage();samples.push({run,wall_ms:ms,cpu_ms:(cpu.user+cpu.system)/1000/iterations,heap_before:mem0.heapUsed,heap_after:mem.heapUsed,rss_after:mem.rss});}
 const ordered=samples.map(x=>x.wall_ms).sort((a,b)=>a-b),median=ordered[Math.floor(ordered.length/2)];const row={source,op,size,warmups:2,warm_ms:warmMs,iterations,repeats,median_ms:median,min_ms:ordered[0],max_ms:ordered.at(-1),samples,notes};rows.push(row);fs.writeFileSync('results/benchmarks.json',JSON.stringify(rows,null,2));console.log(`${source} ${op} ${JSON.stringify(size)} ${median.toFixed(3)} ms`);return row;
}
const prod='MEASURED PRODUCTION',scratch='MEASURED SCRATCH';
for(const [name,c] of Object.entries(sizes)){
 const f=fixture(c),{truth:t,solution:s}=f;metadata[name]={...c,truth:counts(t),solution:counts(s)};
 check(`valid-${name}`,()=>assert.equal(validateCaseSemantics(t).findings.length,0));
 bench(prod,'truth.parse',name,()=>parseCaseTruth(f.input));
 bench(prod,'semantics.sparse',name,()=>validateCaseSemantics(t));
 bench(prod,'solution.parse',name,()=>parseCaseSolution(f.si,t));
 const ss=createCaseSolutionSchema(t);bench(prod,'solution.parse.bound-schema',name,()=>ss.parse(f.si));
 bench(prod,'hash.truth',name,()=>hashCaseTruth(t));bench(prod,'hash.solution',name,()=>hashCaseSolution(s));
 const ni=npcInput(t,s,1e9,1e9),ns=parseNpcKnowledge(ni,t,s);metadata[name].npc=counts(ns);
 bench(prod,'npc.parse',name,()=>parseNpcKnowledge(ni,t,s));const nsch=createNpcKnowledgeSchema(t,s);bench(prod,'npc.parse.bound-schema',name,()=>nsch.parse(ni));
 bench(prod,'projection.broad',name,()=>projectNpcKnowledge(ns,t,s));
 const small=parseNpcKnowledge(npcInput(t,s,2,2),t,s);bench(prod,'projection.small',name,()=>projectNpcKnowledge(small,t,s));
 for(const [kind,obj] of [['truth',t],['solution',s],['npc',ns],['projection',projectNpcKnowledge(ns,t,s)]]){
  bench(scratch,'clone',`${name}.${kind}`,()=>structuredClone(obj));
  bench(scratch,'clone+freeze',`${name}.${kind}`,()=>M.freeze(structuredClone(obj)));
 }
 const refs=M.playerIndex(M.entitiesOf(t)),pi=M.presentationInput(t),pv=M.parsePresentation(pi,t);
 bench(scratch,'presentation.parse',name,()=>M.parsePresentation(pi,t));
 bench(scratch,'presentation.hash',name,()=>M.digest('forge-evidence-presentation-c14n-v1',pv));bench(scratch,'presentation.release',name,()=>M.release(pv.entries[0],refs));
 const es=M.accessEntries(c.evidence,c.locations);bench(scratch,'investigation.scan',name,()=>M.accessScan(es,'location|location:x0'));
 const all=t.persons.map((p:any)=>parseNpcKnowledge(npcInput(t,s,1e9,1e9,t.persons.indexOf(p)),t,s));
 bench(prod,'projection.all-NPCs',name,()=>all.map(n=>projectNpcKnowledge(n,t,s)));
 bench(scratch,'package.load',name,()=>{const tt=parseCaseTruth(f.input),sol=parseCaseSolution(f.si,tt);const rr=M.playerIndex(M.entitiesOf(tt),hashCaseTruth(tt)),npcs=all.map((n:any)=>parseNpcKnowledge(n,tt,sol));const presentation=M.parsePresentation(pi,tt);return {truth:tt,solution:sol,refs:rr,npcs,access:M.accessIndex(es),presentation,presentationHash:M.digest('presentation',presentation),identity:M.digest('package',{truth:hashCaseTruth(tt),solution:hashCaseSolution(sol),presentation:M.digest('presentation',presentation)},false)};},'Composed implemented parsers + provisional package, not complete ResolvedCasePackage conformance');
}
for(const n of [8,15,40,100,250,500])for(const shape of ['sparse','dense','chain','star','components','near-cycle','cycle']){
 const t=parseCaseTruth(generate({persons:12,locations:15,events:n,evidence:Math.min(n,250)},7341,shape));
 bench(prod,'semantics.graph',{n,shape,edges:t.events.reduce((n:any,e:any)=>n+e.causedByEventIds.length,0)},()=>validateCaseSemantics(t));
 if(shape==='cycle')check(`cycle-detected-${n}`,()=>assert.ok(validateCaseSemantics(t).findings.some(x=>x.code==='CAUSAL_CYCLE')));
}
for(const n of [100,250,500,1000]){
 const raw=generate({persons:4,locations:5,events:n,evidence:1,propositions:n*2,broad:true},7341,'star');
 raw.events.forEach((e:any)=>{e.time={kind:'interval',start:0,end:10};e.locationId='location:x0';});
 let t=parseCaseTruth(raw);bench(prod,'semantics.presence-no-conflict',n,()=>validateCaseSemantics(t));
 raw.events.forEach((e:any,i:number)=>e.locationId=`location:x${i%5}`);t=parseCaseTruth(raw);if(n<1000)bench(prod,'semantics.conflict-output',n,()=>validateCaseSemantics(t));
 const duplicate=generate({persons:4,locations:5,events:1,evidence:1,propositions:n},7341,'star');duplicate.propositions.forEach((p:any,i:number)=>{p.claim={kind:'personAt',personId:'person:x0',locationId:'location:x0',at:100};p.truth=!!(i%2);});t=parseCaseTruth(duplicate);bench(prod,'semantics.duplicate-claims',n,()=>validateCaseSemantics(t));
}
for(const n of [10,50,100,500,1000]){
 const f=fixture({persons:50,locations:60,events:Math.max(n,100),evidence:Math.max(n,100),propositions:n*3}),ni=npcInput(f.truth,f.solution,n,n);const ns=parseNpcKnowledge(ni,f.truth,f.solution);
 metadata[`npc-${n}`]={awareness:ns.awareness.length,attitudes:ns.attitudes.length};assert.equal(ns.attitudes.length,n);assert.equal(ns.awareness.length,n);
 bench(prod,'npc.entries.parse',n,()=>parseNpcKnowledge(ni,f.truth,f.solution));bench(prod,'npc.entries.project',n,()=>projectNpcKnowledge(ns,f.truth,f.solution));
}
for(const n of [10,100,1000,10000]){
 const es=Array.from({length:n},(_,i)=>({kind:'event',id:`event:x${i}`})),index=M.playerIndex(es),last=es.at(-1),r=index.refOf(last);
 bench(scratch,'playerref.build',n,()=>M.playerIndex(es));bench(scratch,'playerref.refOf+resolve+membership',n,()=>[index.refOf(last),index.resolve(r),index.parse(r)]);
 check(`playerref-roundtrip-${n}`,()=>es.forEach(e=>assert.deepEqual(index.resolve(index.refOf(e)),e)));
 const access=M.accessEntries(n);const ix=M.accessIndex(access);bench(scratch,'access.scan',n,()=>M.accessScan(access,'location|location:x0'));bench(scratch,'access.index-build',n,()=>M.accessIndex(access));bench(scratch,'access.indexed',n,()=>M.accessIndexed(ix,'location|location:x0'));check(`access-equivalence-${n}`,()=>assert.deepEqual(M.accessScan(access,'location|location:x0'),M.accessIndexed(ix,'location|location:x0')));
 const obs=M.replay(M.events(n)).observations;const map=new Map(obs.map((o:any)=>[o.id,o]));bench(scratch,'knowledge.lookup-array',n,()=>obs.find((o:any)=>o.id===obs.at(-1).id));bench(scratch,'knowledge.lookup-map',n,()=>map.get(obs.at(-1).id));bench(scratch,'knowledge.serialize',n,()=>M.canonical(obs,false));
}
check('playerref-injected-collision',()=>assert.throws(()=>M.playerIndex([{kind:'person',id:'person:x0'},{kind:'person',id:'person:x1'}],'a','b',()=> 'pr1_0000000000000000'),/collision/));
for(const n of [1,5,10,50,100,500]){
 const f=fixture({persons:Math.min(n+1,100),locations:5,events:n,evidence:n});const lits=f.solution.conclusions.map((c:any)=>({claim:c.claim,value:true}));
 bench(scratch,'accusation.naive',{claims:n,required:n},()=>M.accuse(lits,f.truth,f.solution));bench(scratch,'accusation.index-per-call',{claims:n,required:n},()=>M.accuse(lits,f.truth,f.solution,true));check(`accusation-equivalence-${n}`,()=>assert.equal(M.accuse(lits,f.truth,f.solution),M.accuse(lits,f.truth,f.solution,true)));
 if(n>=5)bench(scratch,'challenge.wrapper',{allowed:n,claims:n},()=>M.challenge(lits,lits.map((x:any)=>x.claim),f.truth,f.solution),n>256?'OUTSIDE DRAFT CAP 256':'');
 const si=solutionInput(f.truth,f.truth.persons.length,4);bench(prod,'solution.wide.parse',{events:n,assignments:f.truth.persons.length,conclusions:si.conclusions.length},()=>parseCaseSolution(si,f.truth));
}
for(const n of [5,10,25,50,100,500]){const f=fixture({persons:4,locations:5,events:n,evidence:n}),allowed=f.solution.conclusions.map((c:any)=>c.claim);for(const k of [1,Math.min(n,10),n])bench(scratch,'challenge.scope',{allowed:n,claims:k},()=>M.challenge(allowed.slice(0,k).map((claim:any)=>({claim,value:true})),allowed,f.truth,f.solution),n>256?'OUTSIDE DRAFT CAP 256':'');}
for(const n of [10,100,1000,10000])for(const shape of ['chain','cycles','dense']){
 const g=M.proofGraph(n,shape);bench(scratch,'proof.closure-naive',{edges:g.edges.length,shape},()=>M.closureNaive(g),'Reverse ordered fixed point; cost model, not complete proof validator');bench(scratch,'proof.closure-queue',{edges:g.edges.length,shape},()=>M.closureQueue(g));check(`proof-equivalence-${n}-${shape}`,()=>assert.deepEqual([...M.closureNaive(g)].sort((a,b)=>a-b),[...M.closureQueue(g)].sort((a,b)=>a-b)));
}
for(const d of [1,2,3,4,5,6,7,8,10,12])bench(scratch,'solvability.enumeration',{dimensions:d,vectors:2**d},()=>M.enumerate(d),d>6?'OUTSIDE DRAFT CAP 6':'');
for(const qn of [20,100,500,2000])for(const npcCount of [4,20,100]){
 const c={persons:npcCount,locations:15,events:40,evidence:40},f=fixture(c),ni=npcInput(f.truth,f.solution,1e9,1e9),ns=parseNpcKnowledge(ni,f.truth,f.solution);const catalogue=Array.from({length:qn},(_,i)=>({id:`question:x${i}`,mentions:[{kind:'person',id:f.truth.persons[0].id}]})),rules=catalogue.map(q=>({questionId:q.id,act:'answer',claim:f.truth.propositions[0].claim,reveal:M.refsOfClaim(f.truth.propositions[0].claim)})),q=catalogue.at(-1),refs=M.playerIndex(M.entitiesOf(f.truth)),ctx=projectNpcKnowledge(ns,f.truth,f.solution),known=new Set(M.entitiesOf(f.truth).map(M.refKey));
 bench(scratch,'interrogation.lookup-availability',{questions:qn,npcs:npcCount},()=>{const r=rules.find(r=>r.questionId===q.id),cq=catalogue.find(x=>x.id===q.id);return !!r&&cq.mentions.every(x=>known.has(M.refKey(x)));});
 bench(scratch,'interrogation.policy+release',{questions:qn,npcs:npcCount},()=>{const target=ctx.context.attitudes[0].claim;const attitude=ctx.context.attitudes.find((a:any)=>M.key(a.claim)===M.key(target));return M.freeze({stance:attitude.stance.kind==='uncertain'?'uncertain':'affirms',statement:M.translateClaim(rules.at(-1).claim,refs)});},'Successful authorized path cost only, projection isolated separately');
 bench(scratch,'interrogation.total',{questions:qn,npcs:npcCount},()=>{M.digest('catalogue',catalogue);projectNpcKnowledge(ns,f.truth,f.solution);const rule=rules.find(r=>r.questionId===q.id);return M.freeze({statement:M.translateClaim(rule.claim,refs)});},'Composition includes catalogue hash + real projection, not exact runtime conformance');
}
for(const n of [10,100,1000,10000,50000]){
 const es=M.events(n);bench(scratch,'session.replay-working',n,()=>M.replay(es));bench(scratch,'session.replay-working-dedup',n,()=>M.replay(es,false,false));
 if(n<=10000)bench(scratch,'session.replay-copy',n,()=>M.replay(es,true));
 const live=M.fresh();es.forEach(e=>M.applyWorking(live,e));check(`live-replay-${n}`,()=>assert.deepEqual(M.publicState(live),M.publicState(M.replay(es))));if(n<=10000)check(`copy-working-${n}`,()=>assert.deepEqual(M.publicState(M.replay(es,true)),M.publicState(M.replay(es))));
 const save=M.save(es),data=JSON.stringify(save);metadata[`save-${n}`]={bytes:Buffer.byteLength(data),observations:live.observations.length,known:live.known.size};
 bench(scratch,'save.serialize',n,()=>JSON.stringify(save));bench(scratch,'save.checksum',n,()=>M.save(es));bench(scratch,'save.json-parse',n,()=>JSON.parse(data));bench(scratch,'save.load-check-replay',n,()=>M.load(data));
 check(`save-roundtrip-${n}`,()=>assert.deepEqual(M.publicState(M.load(data)),M.publicState(live)));
}
const tiny=fixture(sizes.TINY),perm=structuredClone(tiny.input);perm.events.reverse();check('truth-hash-permutation',()=>assert.equal(hashCaseTruth(parseCaseTruth(perm)),hashCaseTruth(tiny.truth)));check('save-order-sensitive',()=>assert.notEqual(M.save(M.events(10)).checksum,M.save(M.events(10).reverse()).checksum));
for(const length of [1000,10000,100000,1000000])for(const chars of ['ASCII','Unicode']){const raw=structuredClone(tiny.input);raw.title=(chars==='ASCII'?'x':'雪🕵').repeat(Math.ceil(length/(chars==='ASCII'?1:3)));const t=parseCaseTruth(raw);bench(prod,'truth.parse-long-string',{length:t.title.length,chars,utf8:Buffer.byteLength(t.title)},()=>parseCaseTruth(raw));bench(prod,'truth.hash-long-string',{length:t.title.length,chars,utf8:Buffer.byteLength(t.title)},()=>hashCaseTruth(t));}
const profiles=['playerref-identity','accessHash','presentationHash','npc-snapshot-hash','interrogationHash','proof-profile-hash','package-identity','save-checksum'];for(const profile of profiles)bench(scratch,'hash.profile',{profile},()=>M.digest(profile,{a:tiny.truth,b:tiny.solution}));
check('save-tamper',()=>{const v=M.save(M.events(10));v.events[0].target='pr1_1111111111111111';assert.throws(()=>M.load(JSON.stringify(v)),/checksum/);});
check('generator-reproducibility',()=>assert.deepEqual(generate(sizes.MEDIUM,321),generate(sizes.MEDIUM,321)));
check('generator-seed-varies',()=>assert.notDeepEqual(generate(sizes.MEDIUM,321),generate(sizes.MEDIUM,322)));
for(let seed=0;seed<100;seed++){const f=fixture(sizes.SMALL,seed);check(`seed-valid-${seed}`,()=>assert.equal(validateCaseSemantics(f.truth).findings.length,0));}
fs.writeFileSync('results/metadata.json',JSON.stringify(metadata,null,2));fs.writeFileSync('results/checks.json',JSON.stringify(checks,null,2));fs.writeFileSync('results/environment.json',JSON.stringify({date:new Date().toISOString(),node:process.version,v8:process.versions.v8,platform:process.platform,arch:process.arch,cpu:os.cpus()[0],logicalCPUs:os.cpus().length,memoryBytes:os.totalmem(),runtimeFlags:process.execArgv,resourceUsage:process.resourceUsage(),sourceCommit:'3d7545d843883418348004e68717399a64da7a7d',method:'2 excluded warmups; 7 calibrated batches (~12ms), 3 if >100ms/op; all raw samples retained; fixed execution order; boundary memory only'},null,2));
fs.writeFileSync('results/benchmarks.csv','source,op,size,median_ms,min_ms,max_ms,iterations,repeats\n'+rows.map(r=>[r.source,r.op,JSON.stringify(r.size),r.median_ms,r.min_ms,r.max_ms,r.iterations,r.repeats].map(x=>JSON.stringify(String(x))).join(',')).join('\n'));
console.log(`DONE ${rows.length} benchmark groups, ${checks.length} properties`);
