import assert from 'node:assert/strict';
import fs from 'node:fs';
import {fixture,generate,sizes,rng,solutionInput,npcInput} from './generator.ts';
import {__benchSolution} from './solution-instrumented.ts';
import {parseCaseTruth} from '../baseline/src/domain/case-truth.ts';
import {hashCaseTruth} from '../baseline/src/domain/case-truth.identity.ts';
import {parseCaseSolution} from '../baseline/src/domain/case-solution.ts';
import {hashCaseSolution} from '../baseline/src/domain/case-solution.identity.ts';
import {parseNpcKnowledge} from '../baseline/src/domain/npc-knowledge.ts';
import {projectNpcKnowledge} from '../baseline/src/domain/npc-knowledge.projection.ts';
import * as M from './models.ts';
let assertions=0;const rows:any[]=[];
for(let seed=0;seed<100;seed++){
 const r=rng(seed),f=fixture(sizes.SMALL,seed),si=structuredClone(f.si);for(const resolution of si.resolutions){resolution.responsibility.completeness=r()<.5?'partial':'complete';resolution.responsibility.assignments[0].roles=r()<.5?null:['direct_actor'];resolution.intent=r()<.5?null:'intended';resolution.mechanism=r()<.5?null:'ordinary';resolution.causesComplete=r()<.5;}
 const s=parseCaseSolution(si,f.truth);
 for(const e of f.truth.events){const claims:any[]=[];for(const person of f.truth.persons){claims.push({kind:'personResponsibleForEvent',eventId:e.id,personId:person.id});for(const role of ['direct_actor','planner','facilitator'])claims.push({kind:'personRoleForEvent',eventId:e.id,personId:person.id,role});}claims.push({kind:'noPersonResponsibleForEvent',eventId:e.id});for(const value of ['intended','unintended','not_applicable'])claims.push({kind:'eventIntent',eventId:e.id,value});for(const value of ['ordinary','supernatural','mixed'])claims.push({kind:'eventMechanism',eventId:e.id,value});for(const cause of f.truth.events.filter(x=>x.id!==e.id).slice(0,2))claims.push({kind:'eventCausedEvent',eventId:e.id,causeEventId:cause.id});
  const resolution=s.resolutions.find(x=>x.eventId===e.id);for(const c of claims){assert.equal(M.resolve(c,s,f.truth),__benchSolution.resolveConclusion(c,resolution,e));assert.equal(M.key(c),__benchSolution.claimKey(c));assertions+=2;}
 }
 const raw=structuredClone(f.input);for(const coll of ['persons','locations','items','events','propositions','evidence'])raw[coll].reverse();assert.equal(hashCaseTruth(parseCaseTruth(raw)),hashCaseTruth(f.truth));assertions++;
 const ns=parseNpcKnowledge(npcInput(f.truth,s,10000,10000),f.truth,s),ni=structuredClone(ns);ni.awareness.reverse();ni.attitudes.reverse();assert.deepEqual(projectNpcKnowledge(ns,f.truth,s),projectNpcKnowledge(parseNpcKnowledge(ni,f.truth,s),f.truth,s));assertions++;
 const edges=Array.from({length:100},(_,i)=>({allOf:[0,Math.floor(r()*30)],license:0,to:Math.floor(r()*30)+1})),graph={roots:[0,1],edges};assert.deepEqual([...M.closureNaive(graph)].sort((a,b)=>a-b),[...M.closureQueue(graph)].sort((a,b)=>a-b));assertions++;
 rows.push({seed,passed:true});
}
const f=fixture(sizes.SMALL);const raw=structuredClone(f.input);raw.title='é';const a=hashCaseTruth(parseCaseTruth(raw));raw.title='e\u0301';assert.notEqual(a,hashCaseTruth(parseCaseTruth(raw)));assertions++;
const all=M.entitiesOf(f.truth),aIndex=M.playerIndex(all,'a'.repeat(64)),bIndex=M.playerIndex(all,'b'.repeat(64));for(const e of all){assert.equal(bIndex.resolve(aIndex.refOf(e)),null);assertions++;}
const sv=M.save(M.events(10));sv.events.reverse();assert.throws(()=>M.load(JSON.stringify(sv)),/checksum/);assertions++;
assert.throws(()=>M.parsePresentation({...M.presentationInput(f.truth),entries:[{...M.presentationInput(f.truth).entries[0],text:'person:spoiler'}]},f.truth));assertions++;
fs.writeFileSync('results/differential-properties.json',JSON.stringify({seeds:100,assertions,rows,oracle:'Export-only instrumented original private resolveConclusion/claimKey. Same source bodies, no production changes. Random finite proof graph cost-model equivalence; not proof soundness certification.'},null,2));console.log(assertions+' assertions passed');
