// Action-composed replay cost model. NOT a production Session/Replay contract.
import fs from 'node:fs';import assert from 'node:assert/strict';import {performance} from 'node:perf_hooks';
import {fixture,sizes,npcInput,solutionInput} from './generator.ts';
import {parseCaseSolution,ConclusionClaimSchema} from '../baseline/src/domain/case-solution.ts';
import {hashCaseTruth} from '../baseline/src/domain/case-truth.identity.ts';
import {parseNpcKnowledge} from '../baseline/src/domain/npc-knowledge.ts';
import {projectNpcKnowledge} from '../baseline/src/domain/npc-knowledge.projection.ts';
import * as M from './models.ts';
const f=fixture(sizes.TINY),si=structuredClone(f.si);si.requiredConclusions=si.requiredConclusions.slice(0,4);const s=parseCaseSolution(si,f.truth),snapshot=parseNpcKnowledge(npcInput(f.truth,s,10000,10000),f.truth,s),projection=projectNpcKnowledge(snapshot,f.truth,s),index=M.solutionIndex(f.truth,s),access=M.accessEntries(8,5),lits=s.requiredConclusions.map(r=>({claim:s.conclusions.find(c=>c.id===r.conclusionId).claim,value:r.value}));
const rows:any[]=[],identity=hashCaseTruth(f.truth);let sink:any;
function run(n:number,variant:string){let state=M.fresh();for(const e of M.events(n,8)){
 let out:any;if(e.type==='investigate')out=M.accessScan(access,'location|location:x0');
 if(e.type==='interrogate')out=variant==='working-bound'?projection:projectNpcKnowledge(snapshot,f.truth,s);
 if(e.type==='accuse'){if(variant!=='working-bound')hashCaseTruth(f.truth);for(const l of lits){if(variant!=='working-bound')assert.equal(hashCaseTruth(f.truth),s.truthHash);const c=ConclusionClaimSchema.parse(l.claim);assert.equal(M.resolve(c,s,f.truth,variant==='working-bound'?index:undefined),l.value);}out='solved';}
 M.applyWorking(state,e);if(e.type==='accuse')state.verdicts[state.verdicts.length-1]=out;
 }return M.publicState(state);}
for(const n of [10,100,1000,10000,50000])for(const variant of ['rebuild-each-action','working-bound']){run(100,variant);global.gc?.();const samples=[];for(let i=0;i<3;i++){const cpu=process.cpuUsage(),start=performance.now();sink=run(n,variant);const c=process.cpuUsage(cpu);samples.push({wall_ms:performance.now()-start,cpu_ms:(c.user+c.system)/1000});}const ms=samples.map(x=>x.wall_ms).sort((a,b)=>a-b);rows.push({source:'MEASURED SCRATCH composition with real production projection and hashing',op:'integrated-replay',size:{n,variant},median_ms:ms[1],samples,warmupEvents:100,repeats:3,notes:'TINY immutable NPC, all targets presumed authorized; investigation scan, per-claim binding/hash in accusation; core-like successful path only, no full challenge or interrogation bridge. Working-bound variant reuses exact immutable projection + package-bound evaluator cost model.'});fs.writeFileSync('results/integrated-replay.json',JSON.stringify(rows,null,2));console.log(n,variant,ms[1].toFixed(1));if(n<=1000)assert.deepEqual(run(n,'rebuild-each-action'),run(n,'working-bound'));}
