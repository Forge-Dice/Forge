import { performance } from 'node:perf_hooks';
import * as M from './models.ts';
const n=Number(process.argv[2]??50000),es=M.events(n),start=performance.now(),cpu=process.cpuUsage();
const s=M.replay(es,true);console.log(JSON.stringify({n,wall_ms:performance.now()-start,cpu:process.cpuUsage(cpu),observations:s.observations.length,maxRSSKiB:process.resourceUsage().maxRSS}));
