// OPTIONAL original OOM mechanism. Do not run in the normal reproduction suite.
// Retains last report while constructing next; bounded process may abort.
import {generate} from './generator.ts';
import {parseCaseTruth} from '../baseline/src/domain/case-truth.ts';
import {validateCaseSemantics} from '../baseline/src/domain/case-semantics.ts';
const n=Number(process.argv[2]??1000),raw=generate({persons:4,locations:5,events:n,evidence:1,propositions:n*2,broad:true},7341,'star');raw.events.forEach((e:any,i:number)=>{e.time={kind:'interval',start:0,end:10};e.locationId=`location:x${i%5}`;});const t=parseCaseTruth(raw);let sink:any;for(let i=0;i<5;i++){sink=validateCaseSemantics(t);console.log(i,sink.findings.length,process.memoryUsage());}
