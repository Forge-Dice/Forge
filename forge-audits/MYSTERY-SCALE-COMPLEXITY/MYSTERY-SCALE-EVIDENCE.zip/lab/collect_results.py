"""Normalize all existing raw results, without replacing failed/censored runs."""
import json,pathlib,csv
p=pathlib.Path('results');groups=[]
for name in ['benchmarks.json','supplemental.json','component-bench.json','phases.json','integrated-replay.json','vitrine.json','vitrine-extra.json','vitrine-host.json']:
 v=json.loads((p/name).read_text());rows=v['rows'] if isinstance(v,dict) else v
 groups.extend({'file':name,**r} for r in rows)
(p/'all-benchmark-groups.json').write_text(json.dumps(groups,indent=2))
with (p/'all-benchmark-groups.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['file','source','op','size','median_ms','min_ms','max_ms']);w.writeheader()
 for r in groups:w.writerow({k:json.dumps(r.get(k),ensure_ascii=False) if k=='size' else r.get(k,'') for k in w.fieldnames})
memory=[]
for r in json.loads((p/'aux-run.json').read_text()):
 if 'memory.ts' in r['args'] and r.get('exitCode')==0:memory.append(json.loads(r['stdout']))
(p/'memory.json').write_text(json.dumps(memory,indent=2))
print(len(groups),'benchmark groups;',len(memory),'memory children')
