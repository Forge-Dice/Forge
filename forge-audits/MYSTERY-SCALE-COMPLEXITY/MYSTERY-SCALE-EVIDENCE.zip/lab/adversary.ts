import {generate} from './generator.ts';
import {parseCaseTruth} from '../baseline/src/domain/case-truth.ts';
import {validateCaseSemantics} from '../baseline/src/domain/case-semantics.ts';
import {performance} from 'node:perf_hooks';
const n=Number(process.argv[2]??1000),raw=generate({persons:4,locations:5,events:n,evidence:1,propositions:1,broad:true},7341,'star');raw.events.forEach((e:any,i:number)=>{e.time={kind:'interval',start:0,end:10};e.locationId=`location:x${i%5}`;});const t=parseCaseTruth(raw);global.gc?.();const before=process.memoryUsage(),cpu=process.cpuUsage(),start=performance.now();const report=validateCaseSemantics(t);console.log(JSON.stringify({n,findings:report.findings.length,wall_ms:performance.now()-start,cpu:process.cpuUsage(cpu),before,after:process.memoryUsage(),resourceUsage:process.resourceUsage(),source:'MEASURED PRODUCTION single cold validation adversarial input'}));
