import fs from 'node:fs';
import {performance} from 'node:perf_hooks';
import assert from 'node:assert/strict';
import {fixture,sizes} from './generator.ts';
import {ConclusionClaimSchema} from '../baseline/src/domain/case-solution.ts';
import {hashCaseTruth} from '../baseline/src/domain/case-truth.identity.ts';
import {hashCaseSolution} from '../baseline/src/domain/case-solution.identity.ts';
import * as M from './models.ts';
const prior=process.env.RESUME?JSON.parse(fs.readFileSync('results/supplemental.json','utf8')):{rows:[],checks:[]};const rows:any[]=prior.rows,checks:any[]=prior.checks;let sink:any;
function bench(op:string,size:any,fn:()=>any,notes=''){if(rows.some(r=>r.op===op&&JSON.stringify(r.size)===JSON.stringify(size)))return;global.gc?.();for(let i=0;i<2;i++)sink=fn();const samples=[];for(let i=0;i<5;i++){const c=process.cpuUsage(),t=performance.now();sink=fn();const cpu=process.cpuUsage(c);samples.push({wall_ms:performance.now()-t,cpu_ms:(cpu.user+cpu.system)/1000});}const ms=samples.map(s=>s.wall_ms).sort((a,b)=>a-b);rows.push({source:'MEASURED SCRATCH',op,size,median_ms:ms[2],min_ms:ms[0],max_ms:ms.at(-1),samples,notes,warmups:2,repeats:5,iterations:1});fs.writeFileSync('results/supplemental.json',JSON.stringify({rows,checks},null,2));console.log(op,JSON.stringify(size),ms[2].toFixed(2));}
function evaluation(t:any,s:any,c:any,bound?:any){if(!bound&&s.truthHash!==hashCaseTruth(t))throw Error('binding');const parsed=ConclusionClaimSchema.parse(c);const e=bound?bound.events.get(parsed.eventId):t.events.find((e:any)=>e.id===parsed.eventId);if(!e)throw Error('reference');if('personId' in parsed&&!t.persons.some((p:any)=>p.id===parsed.personId))throw Error('person');if('causeEventId' in parsed&&!t.events.some((e:any)=>e.id===parsed.causeEventId))throw Error('cause');return M.resolve(parsed,s,t,bound);}
function core(t:any,s:any,lits:any[],bound?:any){if(!bound)hashCaseTruth(t);const byKey=new Map(lits.map((l:any)=>[M.key(l.claim),l.value]));for(const l of lits){const status=evaluation(t,s,l.claim,bound);if(status!=='undetermined'&&status!==l.value)return false;}for(const r of s.requiredConclusions){const claim=s.conclusions.find((c:any)=>c.id===r.conclusionId).claim;if(!byKey.has(M.key(claim))||byKey.get(M.key(claim))!==r.value)return false;}return true;}
function exactness(t:any,s:any,lits:any[],bound?:any){if(!bound){hashCaseTruth(t);hashCaseSolution(s);}if(!core(t,s,lits,bound))return false;for(const l of lits)if(evaluation(t,s,l.claim,bound)!==l.value)return false;return true;}
for(const n of [1,5,10,50,100,500]){
 const f=fixture({persons:12,locations:15,events:n,evidence:n}),lits=f.solution.conclusions.map(c=>({claim:c.claim,value:true}));
 bench('draft-core.rehash-per-literal',{claims:n,events:n},()=>core(f.truth,f.solution,lits),'Faithful per-literal binding/hash pattern of MYST-0002 §5.1 + §7; cost model, not conformance implementation');
 bench('draft-challenge.rehash-per-literal',{claims:n,events:n},()=>exactness(f.truth,f.solution,lits),n>256?'OUTSIDE draft scope cap 256':'Two evaluator passes, matching core + exactness');
 const bound=M.solutionIndex(f.truth,f.solution);const h=hashCaseTruth(f.truth);assert.equal(h,f.solution.truthHash);const a=exactness(f.truth,f.solution,lits),b=exactness(f.truth,f.solution,lits,bound);assert.equal(a,b);checks.push({name:`bound-evaluator-${n}`,pass:true});
 bench('draft-challenge.bound-working-experiment',{claims:n,events:n},()=>exactness(f.truth,f.solution,lits,bound),'Scratch counterexperiment only; would require preserving/revising normative binding API, no unchecked production shortcut');
}
for(const n of [10,100,1000,10000]){
 // Full dense DAG with approximately n edges, not n nodes and fan-in 10.
 const nodes=Math.floor((1+Math.sqrt(1+8*n))/2),edges=[];for(let i=1;i<nodes;i++)for(let j=0;j<i;j++)edges.push({allOf:[0,j],to:i,license:0});const g={roots:[0],edges};
 bench('proof.full-dense-closure-naive',{requestedEdges:n,edges:edges.length,nodes},()=>M.closureNaive(g));bench('proof.full-dense-closure-queue',{requestedEdges:n,edges:edges.length,nodes},()=>M.closureQueue(g));assert.deepEqual([...M.closureNaive(g)].sort((a,b)=>a-b),[...M.closureQueue(g)].sort((a,b)=>a-b));
}
for(const n of [10,100,1000,10000]){
 const obs=M.replay(M.events(n)).observations,keys=obs.map((o:any)=>o.id),needle=keys.at(-1),set=new Set(keys);
 bench('knowledge.dedup-array-full-batch',n,()=>{const out:any[]=[];for(const o of obs)if(!out.some(x=>x.id===o.id))out.push(o);return out;});
 bench('knowledge.dedup-set-full-batch',n,()=>{const seen=new Set(),out=[];for(const o of obs)if(!seen.has(o.id)){seen.add(o.id);out.push(o);}return out;});
 bench('knowledge.provenance-check',n,()=>obs.every((o:any)=>Number.isSafeInteger(o.provenance.eventIndex)&&o.provenance.eventIndex>=0&&o.provenance.packageHash==='a'.repeat(64)));
}
for(const [name,c] of Object.entries(sizes)){
 const f=fixture(c),known=M.entitiesOf(f.truth),access=M.accessEntries(c.evidence,c.locations),presentation=M.presentationInput(f.truth),qs=Array.from({length:c.questions},(_,i)=>({id:`question:x${i}`,mentions:[known[i%known.length]]})),graph=M.proofGraph(Math.min(128,c.events));
 for(const [profile,v] of [['accessHash',access],['presentationHash',presentation],['NPCSnapshotHash',{awareness:known,attitudes:f.truth.propositions}],['interrogationHash',qs],['proofProfileHash',graph],['packageIdentity',{truth:hashCaseTruth(f.truth),solution:hashCaseSolution(f.solution),access:M.digest('access',access),presentation:M.digest('presentation',presentation),interrogation:M.digest('interrogation',qs),proof:M.digest('proof',graph)}]])bench('component.hash',{name,profile},()=>M.digest(String(profile),v));
}
for(const n of [10,100,1000,10000,50000]){const es=M.events(n),payload=M.save(es);bench('save.canonical-event-validation',n,()=>{for(let i=0;i<es.length;i++){const e=es[i];if(!['investigate','interrogate','accuse'].includes(e.type)||e.sequence!==i||!/^pr1_[0-9a-z]{16}$/.test(e.target))throw Error('event');}return es.length;});}
console.log(`DONE ${rows.length}`);
