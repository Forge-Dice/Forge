"""Measure existing case's scratch host, not production session. Source executed only locally."""
import importlib.util,pathlib,time,json,statistics,hashlib
root=pathlib.Path('../inputs/DIE-LEERE-VITRINE-CASE-PACK').resolve()
# Cut only before top-level scenario runner; all original host functions are unchanged.
source=(root/'simulate.py').read_text();prefix=source[:source.index('\nscenarios=[]')]
ns={'__file__':str(root/'simulate.py')};exec(compile(prefix,str(root/'simulate.py'),'exec'),ns)
trace=[ns['Q']('max',1)]*95+ns['witness'] # 100 accepted actions, includes repeated question
def replay():
 s=ns['fresh']()
 for cmd in trace:assert ns['step'](s,cmd)['success']
 return ns['public_state'](s)
state=replay();assert state==replay()
def measured(name,fn):
 for _ in range(3):fn()
 samples=[]
 for _ in range(9):
  start=time.perf_counter();cpu=time.process_time()
  for _ in range(50):fn()
  samples.append({'wall_ms':(time.perf_counter()-start)*1000/50,'cpu_ms':(time.process_time()-cpu)*1000/50})
 return {'source':'MEASURED SCRATCH existing vitrine Python host','op':name,'median_ms':statistics.median(x['wall_ms'] for x in samples),'samples':samples}
def save_load():
 v={'schemaVersion':1,'packageHash':ns['packagehash'],'commands':trace};data=ns['stable'](v);v=json.loads(data);assert v['packageHash']==ns['packagehash'];s=ns['fresh']()
 for cmd in v['commands']:assert ns['step'](s,cmd)['success']
 return ns['public_state'](s)
rows=[measured('actual-vitrine-host.replay100',replay),measured('actual-vitrine-host.save-load100',save_load),measured('actual-vitrine-host.proof',lambda:ns['proof']({'evidence:d04','evidence:d05'}))]
pathlib.Path('results/vitrine-host.json').write_text(json.dumps({'rows':rows,'stateHash':hashlib.sha256(ns['stable'](state).encode()).hexdigest(),'eventCount':len(trace),'note':'Original provisional host/save profile; no V1 checksum or current PlayerRef compatibility claimed.'},indent=2));print('DONE vitrine host')
