// Deterministic schema-valid instruments, never playable cases or production authority.
import { parseCaseTruth } from '../baseline/src/domain/case-truth.ts';
import { hashCaseTruth } from '../baseline/src/domain/case-truth.identity.ts';
import { parseCaseSolution } from '../baseline/src/domain/case-solution.ts';
import { hashCaseSolution } from '../baseline/src/domain/case-solution.identity.ts';
export const sizes = {
 TINY:{persons:4,locations:5,events:8,evidence:8,questions:20},
 SMALL:{persons:6,locations:8,events:15,evidence:15,questions:40},
 MEDIUM:{persons:12,locations:15,events:40,evidence:40,questions:100},
 LARGE:{persons:25,locations:30,events:100,evidence:100,questions:250},
 STRESS:{persons:50,locations:60,events:250,evidence:250,questions:500},
};
export function rng(seed=7341){let s=seed>>>0;return ()=>{s=(Math.imul(1664525,s)+1013904223)>>>0;return s/4294967296;};}
export function generate(c:any, seed=7341, shape='sparse'){
 const random=rng(seed), p=c.persons,l=c.locations,n=c.events,it=c.items??Math.max(4,p),ev=c.evidence??n,pr=c.propositions??n*2;
 const entities=(kind:string,count:number)=>Array.from({length:count},(_,i)=>({id:`${kind}:x${i}`,name:`${kind} ${i} Ä雪🕵`}));
 const persons=entities('person',p),locations=entities('location',l),items=entities('item',it);
 const events=Array.from({length:n},(_,i)=>{
  let causes:number[]=[];
  if(shape==='chain'||shape==='near-cycle'||shape==='cycle')causes=i?[i-1]:[];
  if(shape==='star')causes=i?[0]:[];
  if(shape==='components')causes=i%10?[i-1]:[];
  if(shape==='sparse')causes=i&&random()<.7?[Math.floor(random()*i)]:[];
  if(shape==='dense')causes=Array.from({length:i},(_,j)=>j);
  if(shape==='cycle'&&i===0&&n>1)causes=[n-1];
  return {id:`event:x${i}`,description:`Ereignis ${i}`,time:i%2?{kind:'instant',at:i*10}:{kind:'interval',start:i*10,end:i*10+5},locationId:`location:x${i%l}`,participantIds:(c.broad?persons:[persons[i%p]]).map(x=>x.id),itemIds:[`item:x${i%it}`],causedByEventIds:causes.map(j=>`event:x${j}`)};
 });
 const propositions=Array.from({length:pr},(_,i)=>{
  const e=events[i%n],pi=Math.floor(i/n)%p;
  const claim=i%3===0?{kind:'personAt',personId:`person:x${i%p}`,locationId:e.locationId,at:n*10+i+1}:i%3===1?{kind:'eventHasParticipant',eventId:e.id,personId:`person:x${pi}`}:{kind:'eventHasItem',eventId:e.id,itemId:`item:x${Math.floor(i/n)%it}`};
  return {id:`proposition:x${i}`,claim,truth:claim.kind==='personAt'?false:claim.kind==='eventHasParticipant'?e.participantIds.includes(claim.personId):e.itemIds.includes(claim.itemId)};
 });
 const truthInput={schemaVersion:1,caseId:`case:scale-${seed}`,revision:1,title:'Synthetischer Messfall',timeline:{unit:'second',originLabel:'Start'},persons,locations,items,
  relationships:Array.from({length:Math.max(1,p-1)},(_,i)=>({id:`relationship:x${i}`,fromPersonId:`person:x${i%p}`,toPersonId:`person:x${(i+1)%p}`,kind:'kennt',time:{kind:'interval',start:0,end:n*10+1}})),events,
  motives:Array.from({length:p},(_,i)=>({id:`motive:x${i}`,personId:`person:x${i}`,eventIds:[`event:x${i%n}`],description:'Motiv'})),propositions,
  evidence:Array.from({length:ev},(_,i)=>({id:`evidence:x${i}`,description:'Hinweis',source:{kind:'event',id:`event:x${i%n}`},links:[{propositionId:`proposition:x${i%pr}`,direction:'supports'}]})),
  secrets:Array.from({length:Math.max(1,Math.floor(p/2))},(_,i)=>({id:`secret:x${i}`,propositionIds:[`proposition:x${i%pr}`]})),
  redHerrings:Array.from({length:Math.max(1,Math.floor(ev/4))},(_,i)=>({id:`red-herring:x${i}`,evidenceIds:[`evidence:x${i%ev}`],misleadingPropositionId:`proposition:x${i%pr}`}))};
 return truthInput;
}
export function solutionInput(t:any, assignments=1, conclusionKinds=1){
 const resolutions=t.events.map((e:any,i:number)=>({eventId:e.id,targets:[{kind:'item',id:t.items[i%t.items.length].id}],responsibility:{completeness:'complete',assignments:t.persons.slice(0,assignments).map((p:any)=>({personId:p.id,roles:['direct_actor','planner','facilitator']}))},intent:'intended',mechanism:'ordinary',causesComplete:true}));
 const conclusions=t.events.flatMap((e:any,i:number)=>{
 const cs:any[]=[{id:`conclusion:x${i}`,claim:{kind:'personResponsibleForEvent',eventId:e.id,personId:t.persons[0].id}}];
 if(conclusionKinds>1){cs.push({id:`conclusion:role${i}`,claim:{kind:'personRoleForEvent',eventId:e.id,personId:t.persons[0].id,role:'direct_actor'}},{id:`conclusion:intent${i}`,claim:{kind:'eventIntent',eventId:e.id,value:'intended'}},{id:`conclusion:mechanism${i}`,claim:{kind:'eventMechanism',eventId:e.id,value:'ordinary'}});for(const cause of e.causedByEventIds)cs.push({id:`conclusion:c${i}-${cause.slice(7)}`,claim:{kind:'eventCausedEvent',eventId:e.id,causeEventId:cause}});}
 return cs;});
 return {schemaVersion:1,caseId:t.caseId,revision:1,truthHash:hashCaseTruth(t),resolutions,conclusions,requiredConclusions:conclusions.map((x:any)=>({conclusionId:x.id,value:true}))};
}
export function npcInput(t:any,s:any,aw=10,att=10,index=0){
 const refs=[...t.persons.map((x:any)=>({kind:'person',id:x.id})),...t.locations.map((x:any)=>({kind:'location',id:x.id})),...t.items.map((x:any)=>({kind:'item',id:x.id})),...t.events.map((x:any)=>({kind:'event',id:x.id})),...t.evidence.map((x:any)=>({kind:'evidence',id:x.id}))];
 const seen=new Set();const attitudes=t.propositions.filter((x:any)=>{const k=JSON.stringify(Object.entries(x.claim).sort());if(seen.has(k))return false;seen.add(k);return true;}).slice(0,att).map((x:any,i:number)=>({subject:{kind:'proposition',id:x.id},stance:i%3===0?{kind:'uncertain',leaning:null}:i%3===1?{kind:'belief',value:!x.truth}:{kind:'knowledge',value:x.truth},acquiredAt:0,provenance:{kind:'prior_knowledge'}}));
 return {schemaVersion:1,caseId:t.caseId,truthHash:hashCaseTruth(t),solutionHash:s?hashCaseSolution(s):null,npcId:t.persons[index%t.persons.length].id,revision:1,asOf:t.events.length*10+100,awareness:refs.slice(0,aw).map(subject=>({subject,acquiredAt:0,provenance:{kind:'prior_knowledge'}})),attitudes};
}
export function fixture(c:any,seed=7341,shape='sparse'){const input=generate(c,seed,shape),truth=parseCaseTruth(input),si=solutionInput(truth),solution=parseCaseSolution(si,truth);return {input,truth,si,solution};}
export function counts(v:any){let objects=0,arrays=0,strings=0,chars=0;function walk(x:any){if(typeof x==='string'){strings++;chars+=x.length;}else if(x&&typeof x==='object'){if(Array.isArray(x))arrays++;else objects++;for(const c of Object.values(x))walk(c);}}walk(v);return {objects,arrays,strings,chars,bytes:Buffer.byteLength(JSON.stringify(v))};}
