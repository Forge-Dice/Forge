from certify import *
# Execute only original host definitions; no original experiment or source writes.
source=PACK.parent/'simulate.py';ns={'__file__':str(source)}
exec(compile(source.read_text().split('scenarios=[]')[0],str(source),'exec'),ns)
seqs=json.loads((OUT/'sequences.json').read_text());count=0;errors=[]
model=Model()
for row in seqs:
 s=model.fresh();old=ns['fresh']()
 for pos,a in enumerate(row['commands']):
  if a[0]=='accuse':
   cmd=ns['A'](a[1],[e.split(':')[1] for e in a[2]])
   if s['solved']:ok=False
   else:
    ok=set(a[2])<=s['found']
    if ok and a[1]=='lina' and len(closure(release_roots(set(a[2])))[1])==1:s['solved']=True
  else:
   cmd=ns['S'](a[1].split(':')[1]) if a[0]=='search' else ns['R'](a[1].split(':')[1]) if a[0]=='read' else ns['Q'](H['questionText'][a[1]]['npc'].split(':')[1],int(a[1].split('q')[-1]))
   ok,_=model.step(s,a)
  out=ns['step'](old,cmd);count+=1
  if (ok!=out['success'] or s['known']!=old['known'] or s['found']!=old['found'] or s['solved']!=(old['phase']=='solved')):errors.append([row['id'],pos])
assert not errors,errors[:10]
# Public witnesses from the original actual scratch release path.
for name,order in [('primary',ns['witness']),('independent',[ns['Q']('oskar',14),ns['R']('terminal'),ns['S']('galerie'),ns['Q']('oskar',12),ns['S']('hof'),ns['Q']('nora',8),ns['R']('kamera')])]:
 state=ns['fresh']();trace=[{'initial':ns['public_initial']()}]
 for cmd in order+[ns['A']()]:trace.append({'command':cmd,'result':ns['step'](state,cmd),'playerKnowledge':ns['public_state'](state)})
 dump(name+'-PUBLIC-witness.json',trace)
dump('differential.json',{'comparisons':count,'sequences':len(seqs),'mismatches':len(errors),'checked':['action success','known entities','discovered evidence','phase'],'notChecked':['NPC object identity bridge','MYST-0004 byte compatibility','production replay adapter']})
print('Differential comparisons',count,'mismatches',len(errors))
