from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parent.parent
(R/'lab/README.txt').write_text('''DIE LEERE VITRINE — FORMAL SOLVABILITY CERTIFICATION EVIDENCE
PRIVATE AUTHOR PACKAGE: contains spoilers, Truth, Solution and Proof Profile.
Do not give this archive to blind testers.

Verdict for current assembled contract chain: NOT CERTIFIED.
Bounded existing case model: PASS. See report for precise scope and blockers.

Main: 3d7545d843883418348004e68717399a64da7a7d; independently rechecked unchanged.
All canonical operations were GET reads. No repository/GitHub mutations.

Reproduce from archive root (Python 3 standard library; Node 22+):
  node --experimental-strip-types lab/current-resolver-probe.ts
  python3 lab/certify.py
  python3 lab/additional_checks.py
  python3 lab/differential.py
  python3 lab/render_report.py

The Node probe imports unmodified identity and semantics modules and extracts
exact private resolver source. It does NOT claim to run Zod parsing.
Python probes are disposable reference models, not production implementations.
The broader 531441-accusation loop may take several minutes on slower machines.

Original sources are preserved under inputs/ and current-main/.
The isolated model reads explicit release data, never Evidence.links as proof.
The original 144 simulations are historical inputs only, not this run's coverage.
Current 1200 sequences include an explicit recovery suffix, not simulated humans.
The independent 192-state quotient establishes no softlock under monotone gates.

Required repairs are candidate artifacts in lab/results/*REPAIR-CANDIDATE.json.
The standalone proof profile preserves the original bound bytes and release hash.
No new canonical Source/PlayerRef/Session contract is invented.

SOURCE-SHA256.json identifies source bytes. SHA256SUMS.json hashes archive members
except itself. These checksums provide integrity comparison, not authentication.
''')
files=[]
for folder in ['lab','current-main']:
 files.extend(p for p in (R/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ['.png','.cjs'])
files.extend(p for p in (R/'inputs').iterdir() if p.is_file() and p.suffix in ['.md','.html','.zip'])
files.extend(p for p in (R/'inputs/unpacked/DIE-LEERE-VITRINE-CASE-PACK').rglob('*') if p.is_file() and '__pycache__' not in p.parts)
files.extend(p for p in (R/'deliverables').iterdir() if p.suffix in ['.html','.json'])
# convenience root source manifest
members={str(p.relative_to(R)):p.read_bytes() for p in files}
members['README.txt']=(R/'lab/README.txt').read_bytes();members['SOURCE-SHA256.json']=(R/'lab/SOURCE-SHA256.json').read_bytes()
sums={n:hashlib.sha256(b).hexdigest() for n,b in sorted(members.items())}
members['SHA256SUMS.json']=(json.dumps(sums,indent=2)+'\n').encode()
p=R/'deliverables/DIE-LEERE-VITRINE-CERT-EVIDENCE.zip'
with zipfile.ZipFile(p,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(members.items()):z.writestr(n,b)
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 for n,h in sums.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
print(json.dumps({'members':len(members),'zipBytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
