from certify import *
# Reproduction against exact current code status probe.
curr=json.loads((OUT/'current-code-probe.json').read_text());assert curr['statuses']=={c:status(CONS[c]['claim']) for c in CID}
assert curr['truthHash']==S['truthHash']==P['bindings']['truthHash'];assert curr['solutionHash']==P['bindings']['solutionHash']
manifest=load('release-manifest.PRIVATE.design.json')
assert sha(('case-vitrine-release-manifest-v1\n'+stable(manifest)).encode())==P['bindings']['releaseHash']
assert manifest['proofMeaning']=={k:P[k] for k in ['observations','nodes','edges']}
# Every source record reproduced as a draft-shaped presentation entry: no links read.
entries=[]
for eid,x in H['presentation'].items():
 claims=[copy.deepcopy(PROPS[pid]['claim']) for pid in x['observed']]
 mentions=sorted({v for c in claims for v in refs(c)})
 entries.append({'evidenceId':eid,'text':x['text'],'mentions':[{'kind':v.split(':')[0],'id':v} for v in mentions], 'reports':[{'claim':c,'stance':'affirms','source':{'kind':'observation'}} for c in claims]})
presentation={'schemaVersion':1,'caseId':T['caseId'],'truthHash':S['truthHash'],'entries':entries}
dump('presentation.MYST-0004.REPAIR-CANDIDATE.json',presentation)
# Four authored factivity certificate entries only, exact match to licensed records.
certs=[]
for o in P['observations']:
 if o['kind']=='OBSERVED':
  certs.append({'observationId':o['id'],'evidenceId':o['source']['evidenceId'],'report':{'claim':PROPS[o['literal']['propositionId']]['claim'],'stance':'affirms','source':{'kind':'observation'}},'publicLicense':'rule:certified-sources','literal':o['literal']})
dump('factivity-bridge.REPAIR-CANDIDATE.json',{'status':'LAB ADAPTER PROPOSAL, NOT accepted Session or MYST-0004 API','presentationBytesSha256':sha((OUT/'presentation.MYST-0004.REPAIR-CANDIDATE.json').read_bytes()),'certificates':certs})
def bridge(found,pres=presentation,licenses={'rule:certified-sources'}):
 return {c['observationId'] for c in certs if c['evidenceId'] in found and c['publicLicense'] in licenses and any(e['evidenceId']==c['evidenceId'] and c['report'] in e['reports'] for e in pres['entries'])}
assert bridge(set())==set()
full={e['id'] for e in T['evidence']};assert len(bridge(full))==4
changed=copy.deepcopy(presentation)
for e in changed['entries']:
 for r in e['reports']:r['source']={'kind':'testimony','personId':'person:oskar'}
assert bridge(full,changed)==set();assert bridge(full,licenses=set())==set()
# NPC reports cannot match Evidence certificates; false NPC stance mutations preserve proof.
assert not any(c['evidenceId'].startswith('person:') for c in certs)
# Discovery without actual release does not match either.
assert bridge(full,{'entries':[]})==set()
dump('bridge-checks.json',{'positiveAuthorizedObservations':4,'noDiscovery':0,'discoveredButUnreleased':0,'testimonyPromotion':0,'withoutPublicLicense':0,'status':'PASS locally; production replay adapter UNKNOWN'})
# All 20 questions and all 8 evidence releases are reached in full closure; no hidden e08.
s=Model().exhaust();assert len(s['asked'])==20 and len(s['found'])==8
# Graph in explicit machine-readable edge list. Each edge is typed; suspicious inference is not proof.
graph=[]
def edge(a,b,k):graph.append({'from':a,'to':b,'kind':k})
for eid,a in H['access'].items():edge(a['target'],eid,'discovered_by');edge(eid,'release:'+eid,'released_by')
for e in entries:
 for m in e['mentions']:edge('release:'+e['evidenceId'],m['id'],'released_by')
 for i,r in enumerate(e['reports']):edge('release:'+e['evidenceId'],'report:'+e['evidenceId']+':'+str(i),'reported_by')
for q in qs:
 n=H['questionText'][q]['npc'].split(':')[1];r=next(r for r in I[n]['rules'] if r['questionId']==q);o=response(n,r)
 for m in qs[q]['mentions']:edge(m['id'],q,'ask_requires_all')
 edge('person:'+n,q,'ask_requires_all');edge(q,'npc-report:'+q,'reported_by')
 if 'claim' in o:
  for v in refs(o['claim']):edge('npc-report:'+q,v,'released_by')
for c in certs:edge('release:'+c['evidenceId'],c['observationId'],'certified_by_explicit_profile')
for e in P['edges']:
 for n in e['allOf']:edge(n,e['to'],'proves according to authored proof profile')
for o in P['nodes']:
 if o['kind']=='observation':edge(o['observationId'],o['id'],'released_by')
edge('report:evidence:d01:0','hypothesis:max','supports_author_inference')
edge('npc-report:question:q12','hypothesis:max','supports_author_inference')
edge('observed:max','npc-report:question:q12','contradicts')
for p in ['max','nora','oskar']:edge('literal:'+p,'hypothesis:'+p,'eliminates')
edge('report:evidence:d06:0','hypothesis:lina','supports_author_inference')
edge('report:evidence:d07:0','hypothesis:lina','supports_author_inference')
# Explicit content edges do not assert canonical truth.
for e in entries:
 for i,r in enumerate(e['reports']):
  claim_id='claim:'+sha(stable(r['claim']).encode())[:16]
  edge('report:'+e['evidenceId']+':'+str(i),claim_id,'reports_content_not_truth')
for q in qs:
 n=H['questionText'][q]['npc'].split(':')[1];r=next(r for r in I[n]['rules'] if r['questionId']==q);o=response(n,r)
 if 'claim' in o:edge('npc-report:'+q,'claim:'+sha(stable(o['claim']).encode())[:16],'reports_content_not_truth')
for c in CID:edge('literal:'+c.split('-')[-1],'required:'+c,'proves according to authored proof profile')
for v in itertools.product([False,True],repeat=4):
 hid='hypothesis-vector:'+''.join(str(int(b)) for b in v)
 for i,person in enumerate(['max','lina','nora','oskar']):
  target=person=='lina'
  if v[i]!=target:edge('literal:'+person,hid,'eliminates')
nodeids=sorted({e[k] for e in graph for k in ['from','to']})
claimdefs={ 'claim:'+sha(stable(c).encode())[:16]:c for c in [p['claim'] for p in T['propositions']]+[c['claim'] for c in S['conclusions']]}
dump('information-graph.json',{'edges':graph,'nodes':[{'id':n,'kind':n.split(':')[0],**({'claim':claimdefs[n]} if n in claimdefs else {})} for n in nodeids],'nodeIds':nodeids,'note':'ask_requires_all and proof bodies are AND; discovery alternatives are OR; supports_author_inference carries zero formal proof weight'})
# Full host receipts and joint general-accusation+receipt matrix (the latter is a test harness only).
claims=[CONS[c]['claim'] for c in CID];gold=[False,True,False,False];grid=[];joint=0;jointSolved=0
for mask in range(256):
 cited={e['id'] for i,e in enumerate(T['evidence']) if mask>>i&1};proof=len(closure(release_roots(cited))[1])==1
 for n in N:
  solved=n=='lina' and proof;grid.append({'actor':n,'citationMask':mask,'verdict':'solved' if solved else 'not_solved','expected':solved})
 for vals in itertools.product([None,False,True],repeat=4):
  core,exact=verdict(vals,claims);accepted=exact and proof
  expect=list(vals)==gold and {'evidence:d04','evidence:d05'}<=cited
  assert accepted==expect;joint+=1;jointSolved+=accepted
assert joint==20736 and jointSolved==64
dump('host-1024.json',grid);dump('joint-20736-summary.json',{'cases':joint,'solved':jointSolved,'falseAccepts':0,'falseRejects':0,'note':'joint harness, not an extra public command accepted by original host'})
# Information fraction = k of eight evidence cards, arbitrary subsets (not all independently reachable).
metric=[]
rows=json.loads((OUT/'minimal-sets.json').read_text())['evidenceSubsets']
for k in [0,2,4,6,8]:
 rr=[x for x in rows if len(x['found'])==k];v=[len(x['viableSingleActors']) for x in rr]
 metric.append({'evidenceCount':k,'fraction':k/8,'subsets':len(rr),'singleActorMin':min(v),'singleActorMax':max(v),'singleActorMean':sum(v)/len(v),'fullyProvenSubsets':sum(x['proof'] for x in rr)})
dump('fairness-metrics.json',metric)
# Actual semantic checker sensitivity rerun mutations that were refined after first execution.
h=copy.deepcopy(H);h['access']['evidence:d03']={'kind':'examine_item','target':'item:kamera'}
mut=json.loads((OUT/'mutations.json').read_text());mut[3]={'id':4,'mutation':'Move D03 behind camera it must unlock: circular access','detected':True,'expectedFailure':True,'result':check_profile(Model(host=h))};assert mut[3]['result']['status']=='fail';dump('mutations.json',mut)
print(stable({'joint':joint,'graphEdges':len(graph),'allQuestionsReached':len(s['asked']),'allEvidenceReached':len(s['found']),'metrics':metric,'bridges':len(certs)}))
