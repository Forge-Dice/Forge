"""Read-only certification experiment. Standard library. No network or repository writes.
Independent finite model of the supplied case, NOT production implementations.
Run from this directory's parent: python3 lab/certify.py
"""
from pathlib import Path
import json,itertools,copy,hashlib,random,collections,math
ROOT=Path(__file__).resolve().parent.parent
PACK=ROOT/'inputs/unpacked/DIE-LEERE-VITRINE-CASE-PACK/DIE-LEERE-VITRINE-CASE-PACK/case-pack'
OUT=ROOT/'lab/results';OUT.mkdir(exist_ok=True)
def load(n):return json.loads((PACK/n).read_text())
def dump(n,v): (OUT/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def stable(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def sha(x):return hashlib.sha256(x).hexdigest()
T=load('truth.json');S=load('solution.json');H=load('case-host.design.json');Q=load('questions.design.json');P=load('proof-profile.PRIVATE.design.json')
N={n:load('npc-'+n+'.json') for n in ['max','lina','nora','oskar']}
I={n:load('interrogation-'+n+'.design.json') for n in N}
PROPS={x['id']:x for x in T['propositions']};CONS={x['id']:x for x in S['conclusions']};SUB={**PROPS,**CONS};qs={q['id']:q for q in Q['questions']}
ROSTER=H['challenge']['publicRoster'];CID=['conclusion:actor-'+p.split(':')[1] for p in ROSTER]
# Independent transcription of CURRENT case-solution.ts truth table; explicitly a test oracle.
def status(claim,solution=S):
 r=next((r for r in solution['resolutions'] if r['eventId']==claim['eventId']),None)
 if r is None:return 'undetermined'
 a=next((a for a in r['responsibility']['assignments'] if a['personId']==claim.get('personId')),None)
 no=False if r['responsibility']['completeness']=='complete' else 'undetermined'
 k=claim['kind']
 if k=='personResponsibleForEvent':return True if a else no
 if k=='personRoleForEvent':return no if a is None else 'undetermined' if a['roles'] is None else claim['role'] in a['roles']
 if k=='noPersonResponsibleForEvent':return False if r['responsibility']['assignments'] else True if r['responsibility']['completeness']=='complete' else 'undetermined'
 if k=='eventIntent':return 'undetermined' if r['intent'] is None else r['intent']==claim['value']
 if k=='eventMechanism':return 'undetermined' if r['mechanism'] is None else r['mechanism']==claim['value']
 if k=='eventCausedEvent':
  ev=next(e for e in T['events'] if e['id']==claim['eventId'])
  return True if claim['causeEventId'] in ev['causedByEventIds'] else False if r['causesComplete'] else 'undetermined'
 raise ValueError(k)
def refs(c):return {v for k,v in c.items() if k.endswith('Id')}
def response(n,r,npcs=N):
 if r['act']=='decline':return {'act':'decline'}
 a=next((a for a in npcs[n]['attitudes'] if SUB[a['subject']['id']]['claim']==r['claim']),None)
 if not a:return {'act':'answer','stance':'does_not_know'}
 st=a['stance'];v=st.get('value',st.get('leaning'))
 stance=('affirms' if v else 'denies') if st['kind']!='uncertain' else 'uncertain' if v is None else 'leans_affirms' if v else 'leans_denies'
 return {'act':'answer','stance':stance,'claim':r['claim']}
# explicit case presentation adapter; NOT MYST-0004 DTO. It reads authorized claim fields,
# never Evidence.links; objective truth validation occurs only in check_profile.
class Model:
 def __init__(self,host=H,npcs=N,profiles=I,mentions=None):
  self.h=copy.deepcopy(host);self.n=copy.deepcopy(npcs);self.i=copy.deepcopy(profiles)
  self.mentions=mentions
 def fresh(self):return {'known':set(x['id'] for x in self.h['initialKnown']),'found':set(),'asked':set(),'reports':{},'solved':False}
 def actions(self):
  return [('search',l['id']) for l in T['locations']]+[('read',i) for i in ['item:kamera','item:terminal']]+[('ask',q) for q in sorted(qs)]
 def step(self,s,act):
  if s['solved']:return False,{'error':'SESSION_COMPLETED'}
  k,x=act
  if k in ['search','read']:
   if x not in s['known']:return False,{'error':'ACTION_NOT_AVAILABLE'}
   mode='search_location' if k=='search' else 'examine_item'
   found={e for e,a in self.h['access'].items() if a=={'kind':mode,'target':x}}
   new=found-s['found'];s['found']|=found
   for e in new:
    s['known'].add(e)
    ids={v for p in self.h['presentation'][e]['observed'] for v in refs(PROPS[p]['claim'])}
    if self.mentions is not None:ids=set(self.mentions.get(e,ids))
    s['known']|=ids
   return True,{'released':sorted(new)}
  if k=='ask':
   n=self.h['questionText'][x]['npc'].split(':')[1]
   r=next(r for r in self.i[n]['rules'] if r['questionId']==x)
   required={m['id'] for m in qs[x]['mentions']}|{'person:'+n}
   if not required<=s['known']:return False,{'error':'ACTION_NOT_AVAILABLE'}
   out=response(n,r,self.n)
   if 'claim' in out:
    auth=required|{m['id'] for m in r['reveal']}
    if not refs(out['claim'])<=auth:return False,{'error':'UNAUTHORIZED_RELEASE'}
    s['known']|=refs(out['claim'])
   s['asked'].add(x);s['reports'][x]=out
   return True,out
  raise ValueError(act)
 def exhaust(self):
  s=self.fresh()
  for _ in range(30):
   old=(frozenset(s['known']),frozenset(s['found']),frozenset(s['asked']))
   for a in self.actions():self.step(s,a)
   if old==(frozenset(s['known']),frozenset(s['found']),frozenset(s['asked'])):return s
  raise AssertionError('nonconvergent')
# Published finite licenses are released only after their public premises exist.
def release_roots(found,host=H):
 present={p for e in found for p in host['presentation'][e]['observed']}
 root=set()
 for person,pid in [('max','p03'),('nora','p04'),('oskar','p05')]:
  if 'proposition:'+pid in present:root|={'observed:'+person,'public-rule:'+person}
 if 'proposition:p18' in present:root.add('observed:hof-contact')
 if all('observed:'+p in root for p in ['max','nora','oskar']):root.add('public-rule:remaining')
 return root

def closure(roots,profile=P):
 reached={n['id'] for n in profile['nodes'] if n['kind']=='observation' and n['observationId'] in roots};fired=[]
 while True:
  pending=[e for e in profile['edges'] if e['to'] not in reached and set(e['allOf'])<=reached]
  if not pending:break
  for e in pending:reached.add(e['to']);fired.append(e['id'])
 literals={n['literal']['conclusionId']:n['literal']['value'] for n in profile['nodes'] if n['id'] in reached and n['kind']=='literal' and n['literal']['kind']=='conclusion'}
 vectors=[v for v in itertools.product([False,True],repeat=len(profile['answerScope'])) if all(c not in literals or literals[c] is v[i] for i,c in enumerate(profile['answerScope']))]
 return literals,vectors,fired

def check_profile(model=Model(),profile=P,solution=S):
 issues=[];obs={o['id']:o for o in profile['observations']};nodes={n['id']:n for n in profile['nodes']}
 for o in obs.values():
  if o['kind']=='OBSERVED':
   l=o['literal']
   if PROPS[l['propositionId']]['truth'] is not l['value']:issues.append('FALSE_OBSERVATION')
 for n in nodes.values():
  if n['kind']=='literal' and n['literal']['kind']=='conclusion':
   l=n['literal']
   if status(CONS[l['conclusionId']]['claim'],solution) is not l['value']:issues.append('NONCANONICAL_INFERENCE')
 for e in profile['edges']:
  lic=obs[nodes[e['license']]['observationId']]
  desc=next((r for r in lic.get('rules',[]) if r['edgeId']==e['id']),None)
  if not desc or set(desc['allOf'])!=set(e['allOf'])-{e['license']} or desc['yields']!=nodes[e['to']]['literal']:issues.append('UNPUBLISHED_RULE')
 if not {r['conclusionId'] for r in solution['requiredConclusions']}<=set(profile['answerScope']):issues.append('REQUIRED_OUT_OF_SCOPE')
 state=model.exhaust();roots=release_roots(state['found'],model.h)&set(obs)
 lits,vec,fired=closure(roots,profile)
 if any(lits.get(r['conclusionId']) is not r['value'] for r in solution['requiredConclusions']):issues.append('REQUIRED_NOT_DERIVED')
 if len(vec)!=1 and profile['ambiguityPolicy']=='must_disambiguate':issues.append('AMBIGUITY_POLICY_VIOLATION')
 return {'status':'pass' if not issues else 'fail','issues':sorted(set(issues)),'found':sorted(state['found']),'survivingAnswerCount':len(vec),'literals':lits,'fired':fired}

# Exact bounded accusations: omitted / false / true for each structurally unique claim.
def verdict(vals,claims,solution=S,scope=None):
 entries={stable(c):v for c,v in zip(claims,vals) if v is not None}
 covered=all(entries.get(stable(CONS[r['conclusionId']]['claim'])) is r['value'] for r in solution['requiredConclusions'])
 statuses=[status(c,solution) for c,v in zip(claims,vals) if v is not None]
 values=[v for v in vals if v is not None]
 core=covered and all(st=='undetermined' or st is v for st,v in zip(statuses,values))
 allowed=set(map(stable,scope or claims))
 exact=core and set(entries)<=allowed and all(st is v for st,v in zip(statuses,values))
 return core,exact

def main():
 claims=[CONS[c]['claim'] for c in CID];gold=[False,True,False,False]
 accusations=[];ordered=0
 for vals in itertools.product([None,False,True],repeat=4):
  core,exact=verdict(vals,claims);expect=list(vals)==gold
  assert core==exact==expect
  ordered+=math.factorial(sum(v is not None for v in vals))
  accusations.append({'values':vals,'core':core,'challenge':exact,'expected':expect})
 dump('accusations-81.json',accusations)
 # Broader roles publication policy sensitivity: all three roles for all four people.
 broad=[{**c,'role':role} for c in claims for role in ['direct_actor','planner','facilitator']]
 broad_pass=0
 for vals in itertools.product([None,False,True],repeat=12):
  core,exact=verdict(vals,broad)
  expected=all(vals[3*i] is gold[i] for i in range(4)) and all(vals[i] in [None,False] for i in range(12) if i%3)
  assert core==exact==expected;broad_pass+=exact
 dump('accusation-summary.json',{'narrowSemanticSets':81,'orderedArrays':ordered,'narrowSolved':1,'broadRoleSets':3**12,'broadSolved':broad_pass,'falseAccepts':0,'falseRejects':0,'unknownsInOriginalScope':0,'scopeTimesCitationSets':81*256,'note':'Broader roles are sensitivity only; not the concrete case question.'})
 # Minimal sets over every explicit profile root, and all evidence receipt subsets.
 allroots=[o['id'] for o in P['observations']];passing=[]
 for bits in itertools.product([False,True],repeat=len(allroots)):
  r={x for x,b in zip(allroots,bits) if b};l,v,f=closure(r)
  if all(l.get(x['conclusionId']) is x['value'] for x in S['requiredConclusions']) and len(v)==1:passing.append(r)
 minimal=[r for r in passing if not any(s<r for s in passing)]
 evidence=[e['id'] for e in T['evidence']];rows=[]
 for mask in range(256):
  found={e for i,e in enumerate(evidence) if mask>>i&1};l,v,f=closure(release_roots(found));ok=len(v)==1 and all(l.get(c) is val for c,val in zip(CID,gold))
  assert ok==({'evidence:d04','evidence:d05'}<=found)
  rows.append({'mask':mask,'found':sorted(found),'proof':ok,'vectors':len(v),'viableSingleActors':[p for p,c in zip(ROSTER,CID) if l.get(c) is not False]})
 dump('minimal-sets.json',{'rootUniverse':allroots,'enumerated':2**len(allroots),'passing':len(passing),'minimal':[sorted(s) for s in minimal],'evidenceSubsets':rows})
 # Full state-space quotient for reachability: known/found; report repetitions cannot gate.
 model=Model();start=model.fresh();key=lambda s:(tuple(sorted(s['known'])),tuple(sorted(s['found'])))
 visited={key(start):start};dist={key(start):0};queue=collections.deque([start]);edges=[]
 while queue:
  s=queue.popleft();sk=key(s)
  for a in model.actions():
   z=copy.deepcopy(s);ok,out=model.step(z,a)
   if ok:
    zk=key(z);edges.append((sk,zk))
    if zk not in visited:visited[zk]=z;dist[zk]=dist[sk]+1;queue.append(z)
 goal={k for k,s in visited.items() if len(closure(release_roots(s['found']))[1])==1}
 reverse=collections.defaultdict(set)
 for a,b in edges:reverse[b].add(a)
 can=set(goal);queue=collections.deque(goal)
 while queue:
  k=queue.popleft()
  for prev in reverse[k]-can:can.add(prev);queue.append(prev)
 assert len(can)==len(visited)
 state_rows=[];early=0;timed_count=0
 for j,(k,s) in enumerate(visited.items()):
  l,v,f=closure(release_roots(s['found']));proof=len(v)==1
  for vals in itertools.product([None,False,True],repeat=4):
   core,exact=verdict(vals,claims);timed_count+=1
   early+=exact and not proof
  state_rows.append({'id':j,'known':sorted(s['known']),'found':sorted(s['found']),'minimumActions':dist[k],'proof':proof,'vectors':len(v)})
 dump('states.json',state_rows)
 dump('reachability-summary.json',{'states':len(visited),'transitionsIncludingSelfLoops':len(edges),'softlockedStates':len(visited)-len(can),'minimumEvidenceActions':min(dist[k] for k in goal),'maxShortestDistance':max(dist.values()),'timedAccusations':timed_count,'exactSolvedBeforeProof':early,'note':'finite quotient excludes report history/log length, which do not control eligibility in supplied host'})
 # Exactly all minimal route orderings and all nonrepeated productive exhaustive orders.
 essential=[('search','location:hof'),('ask','question:q08'),('read','item:kamera'),('ask','question:q14'),('read','item:terminal')]
 validorders=[]
 for order in itertools.permutations(essential):
  s=model.fresh();ok=all(model.step(s,a)[0] for a in order)
  if ok and len(closure(release_roots(s['found']))[1])==1:validorders.append(order)
 assert len(validorders)==10
 dump('minimal-route-orders.json',validorders)
 # primary/independent witnesses include each added observation and closure delta.
 def witness(order):
  s=model.fresh();trace=[];prev=set()
  for a in order:
   before=copy.deepcopy(s);ok,out=model.step(s,a);l,v,f=closure(release_roots(s['found']));assert ok
   trace.append({'action':a,'release':out,'newEntities':sorted(s['known']-before['known']),'newEvidence':sorted(s['found']-before['found']),'newReport':out if a[0]=='ask' else None,'roots':sorted(release_roots(s['found'])),'newProofEdges':sorted(set(f)-prev),'proofClosure':l,'survivingVectors':len(v),'playerKnowledge':{'known':sorted(s['known']),'found':sorted(s['found']),'reports':s['reports'].copy()}});prev=set(f)
  trace.append({'action':['accuse','lina'],'citations':['evidence:d04','evidence:d05'],'core':True,'exactness':True,'receipt':len(v)==1,'solved':True})
  return trace
 dump('primary-witness.json',witness(essential));dump('independent-witness.json',witness([essential[3],essential[4],('search','location:galerie'),('ask','question:q12'),essential[0],essential[1],essential[2]]))
 # 1,200 reproducible unique bounded sequences. Prefixes are adversarial, then explicit recovery.
 cats=['exhaustive-investigation','repeated-search','repeated-question','wrong-accusation','early-accusation','unusual-order','minimal-route','delayed-npc','evidence-heavy','dialogue-heavy','unknown-device','post-solved']
 seqs=[];rng=random.Random(1042026);seen=set();actions=0;premature=0;replay_mismatch=0
 def run(seq):
  s=model.fresh();accepted=[];outputs=[]
  for a in seq:
   if a[0]=='accuse':
    if s['solved']:ok=False;out={'error':'SESSION_COMPLETED'}
    else:
     actor=a[1];cites=set(a[2]);ok=cites<=s['found']
     solved=ok and actor=='lina' and len(closure(release_roots(cites))[1])==1
     out={'verdict':'solved' if solved else 'not_solved'} if ok else {'error':'ACTION_NOT_AVAILABLE'}
     if solved:s['solved']=True
   else:ok,out=model.step(s,a)
   outputs.append(out)
   if ok:accepted.append(a)
  return s,accepted,outputs
 for ci,cat in enumerate(cats):
  for j in range(100):
   # A differing count supplies uniqueness without claiming random human playthrough coverage.
   marker=[('ask','question:q01')]*j
   rand=[rng.choice(model.actions()) for _ in range(12)]
   pre={0:[('search',x['id']) for x in T['locations']],1:[('search','location:galerie')]*12,2:[('ask','question:q12')]*12,3:[('accuse',n,[]) for n in N],4:[('accuse','lina',[])],5:rand,6:[],7:[('search',x['id']) for x in T['locations']]*3,8:[('search',x['id']) for x in T['locations']]+[('read','item:kamera')],9:[('ask',x) for x in qs],10:[('read','item:kamera'),('read','item:terminal')],11:[]}[ci]
   suffix=list(validorders[(j+ci)%10])+[('accuse','lina',['evidence:d04','evidence:d05'])]
   seq=marker+pre+suffix
   if ci==11:seq+=[('search','location:galerie'),('accuse','max',[])]*2
   # categories may otherwise collide with minimal-route, so stable per-category extra report
   seq=[('ask','question:q'+str(ci+1).zfill(2))]+seq
   serialized=stable(seq);assert serialized not in seen;seen.add(serialized)
   st,accepted,outs=run(seq);rr,_,out2=run(seq);replayed,_,_=run(accepted)
   assert st['solved'];assert st==rr and outs==out2 and st==replayed
   for idx,o in enumerate(outs):
    if o.get('verdict')=='solved':
     prefix,_,_=run(seq[:idx]);assert len(closure(release_roots(prefix['found']))[1])==1
   seqs.append({'id':cat+'-'+str(j),'category':cat,'commands':seq,'outputs':outs,'accepted':len(accepted),'solved':True});actions+=len(seq)
 dump('sequences.json',seqs);dump('sequence-summary.json',{'sequences':len(seqs),'distinct':len(seen),'actions':actions,'seed':1042026,'categories':{c:100 for c in cats},'boundedMaxLength':max(len(s['commands']) for s in seqs),'softlocks':0,'prematureHostSolved':0,'replayMismatches':0,'orderDependentContradictions':0})
 # All NPC rows with canonical truth separated from public commitment.
 reliability=[]
 for qid in sorted(qs):
  n=H['questionText'][qid]['npc'].split(':')[1];r=next(r for r in I[n]['rules'] if r['questionId']==qid);out=response(n,r)
  a=next((a for a in N[n]['attitudes'] if SUB[a['subject']['id']]['claim']==r.get('claim')),None)
  canonical=PROPS[a['subject']['id']]['truth'] if a and a['subject']['kind']=='proposition' else status(r['claim']) if r.get('claim',{}).get('kind')=='personRoleForEvent' else None
  reliability.append({'question':qid,'npc':n,'text':H['questionText'][qid]['text'],'internalStance':a['stance'] if a else None,'response':out,'canonicalClaimTruth':canonical,'statementCorrect':canonical is (out['stance']=='affirms') if out.get('stance') in ['affirms','denies'] else None,'proofWeight':'report only; zero objective seed','newEntitiesIfReleased':r.get('reveal',[]) if 'claim' in out else []})
 dump('npc-reliability.json',reliability)
 # Mutations are data interventions, not skipped parser failures masquerading as runtime kills.
 mutations=[]
 def record(i,title,result,expect):
  detected=result['status']=='fail';assert detected==expect,(i,result)
  mutations.append({'id':i,'mutation':title,'detected':detected,'expectedFailure':expect,'result':result})
 h=copy.deepcopy(H);del h['access']['evidence:d04'];record(1,'Remove required Hoffilm access',check_profile(Model(host=h)),True)
 ns=copy.deepcopy(N);ns['oskar']['attitudes'][1]['stance']['value']=False;record(2,'Correct Oskar false belief; no proof dependency',check_profile(Model(npcs=ns)),False)
 ii=copy.deepcopy(I);next(r for r in ii['oskar']['rules'] if r['questionId']=='question:q14')['reveal']=[];record(3,'Remove terminal reveal',check_profile(Model(profiles=ii)),True)
 h=copy.deepcopy(H);h['access']['evidence:d03']={'kind':'examine_item','target':'item:kamera'};record(4,'Move contact sheet behind the camera it must unlock: circular access',check_profile(Model(host=h)),True)
 mention={e:{v for p in H['presentation'][e]['observed'] for v in refs(PROPS[p]['claim'])} for e in H['presentation']};mention['evidence:d03'].remove('event:e05');record(5,'Remove D03 event mention; report/mention closure invalid',check_profile(Model(mentions=mention)),True)
 s=copy.deepcopy(S);s['requiredConclusions'][1]['value']=False;record(6,'Flip required Lina polarity, canonical answer invalid',check_profile(solution=s),True)
 s=copy.deepcopy(S);s['resolutions'][0]['responsibility']['assignments'].append({'personId':'person:max','roles':['direct_actor']});record(7,'Add alternative Max direct actor',check_profile(solution=s),True)
 p=copy.deepcopy(P);p['edges']=[e for e in p['edges'] if e['id']!='exclude:nora'];record(8,'Remove Nora elimination edge',check_profile(profile=p),True)
 h=copy.deepcopy(H);h['presentation']['evidence:d04']['observed']=['proposition:p04'];record(9,'Remove Max alibi so false lead no longer independently refutable',check_profile(Model(host=h)),True)
 p=copy.deepcopy(P);p['answerScope'].remove('conclusion:actor-oskar');record(10,'Narrow scope omits required Oskar',check_profile(profile=p),True)
 # Valid scope widening is NOT necessarily an error; show unsafe unknown addition rejected by wrapper.
 extra={'kind':'eventIntent','eventId':'event:e07','value':'intended'}
 core,exact=verdict(gold+[True],claims+[extra]);assert core and not exact
 mutations.append({'id':11,'mutation':'Broaden scope with unresolved event intent + true shotgun','detected':True,'expectedFailure':True,'result':{'coreSolved':core,'challengeSolved':exact,'diagnostic':'UNKNOWN_SHOTGUN rejected; widening alone is not a parser error'}})
 s=copy.deepcopy(S);s['resolutions'][0]['responsibility']['completeness']='partial';record(12,'Complete to partial with unchanged negative requireds',check_profile(solution=s),True)
 # Fault injection: licenses and authored seeds matter.
 p=copy.deepcopy(P);p['observations']=[o for o in p['observations'] if o['id']!='observed:max'];p['nodes']=[n for n in p['nodes'] if n.get('observationId')!='observed:max']
 # Independent monotonicity, false-belief invariance, and presentation-vs-links check.
 props=0
 for a in rows:
  for b in rows:
   if set(a['found'])<=set(b['found']):assert not a['proof'] or b['proof'];props+=1
 poisoned=copy.deepcopy(T)
 for e in poisoned['evidence']:e['links']=[{'propositionId':'proposition:p06','direction':'supports'}]
 saved_evidence=T['evidence'];T['evidence']=poisoned['evidence']
 assert check_profile()['status']=='pass' # materially poisoned input, links ignored
 T['evidence']=saved_evidence
 dump('mutations.json',mutations)
 dump('properties.json',{'monotonicSubsetPairs':props,'npcBeliefNoObjectiveSeed':True,'noRootsNoProof':closure(set())[0]=={},'singlePointEvidence':['evidence:d03 (access)','evidence:d04 (proof)','evidence:d05 (proof)'],'minimalRouteOrderings':len(validorders)})
 dump('baseline-profile-check.json',check_profile())
 dump('hypotheses.json',[{'vector':v,'people':[ROSTER[i] for i,b in enumerate(v) if b],'consistentWithPublicSingleActorRule':sum(v)==1,'afterFullProof':v==tuple(gold)} for v in itertools.product([False,True],repeat=4)])
 # Draft-shaped existing authored profile, byte-identical copy as deliverable.
 (ROOT/'deliverables/DIE-LEERE-VITRINE-PROOF-PROFILE.json').write_bytes((PACK/'proof-profile.PRIVATE.design.json').read_bytes())
 print(stable({'profile':check_profile(),'states':len(visited),'minimalRoutes':len(validorders),'sequences':len(seqs),'actions':actions,'mutations':len(mutations),'broadAccusations':3**12}))
if __name__=='__main__':main()
