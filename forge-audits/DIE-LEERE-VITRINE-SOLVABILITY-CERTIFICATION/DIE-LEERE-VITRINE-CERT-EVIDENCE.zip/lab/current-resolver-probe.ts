import {readFileSync,writeFileSync} from "node:fs";
import {hashCaseTruth} from "../current-main/src/domain/case-truth.identity.ts";
import {hashCaseSolution} from "../current-main/src/domain/case-solution.identity.ts";
import {validateCaseSemantics} from "../current-main/src/domain/case-semantics.ts";
function resolveConclusion(claim: ConclusionClaim, resolution: EventResolution, event: TruthEvent): Status {
  const { completeness, assignments } = resolution.responsibility;
  const openOrFalse: Status = completeness === "complete" ? false : "undetermined";

  switch (claim.kind) {
    case "personResponsibleForEvent":
      return assignments.some((a) => a.personId === claim.personId) ? true : openOrFalse;
    case "personRoleForEvent": {
      const assignment = assignments.find((a) => a.personId === claim.personId);
      if (assignment === undefined) return openOrFalse;
      if (assignment.roles === null) return "undetermined";
      // A known role list is closed for this assignment, even if the responsibility list is partial.
      return assignment.roles.includes(claim.role);
    }
    case "noPersonResponsibleForEvent":
      if (assignments.length > 0) return false;
      return completeness === "complete" ? true : "undetermined";
    case "eventCausedEvent":
      // Direct edges only; no transitive causation.
      if (event.causedByEventIds.includes(claim.causeEventId)) return true;
      return resolution.causesComplete ? false : "undetermined";
    case "eventIntent":
      return resolution.intent === null ? "undetermined" : resolution.intent === claim.value;
    case "eventMechanism":
      return resolution.mechanism === null ? "undetermined" : resolution.mechanism === claim.value;
  }
}

const base="inputs/unpacked/DIE-LEERE-VITRINE-CASE-PACK/DIE-LEERE-VITRINE-CASE-PACK/case-pack/";
const t=JSON.parse(readFileSync(base+"truth.json","utf8"));
const s=JSON.parse(readFileSync(base+"solution.json","utf8"));
const statuses=Object.fromEntries(s.conclusions.map(c=>[c.id,resolveConclusion(c.claim,s.resolutions[0],t.events.find(e=>e.id===c.claim.eventId))]));
const result={note:"Exact current private resolver body extracted verbatim; raw fixture input, NOT a Zod parse. Identity functions and semantic validator imported unchanged.",truthHash:hashCaseTruth(t),solutionHash:hashCaseSolution(s),semanticFindings:validateCaseSemantics(t),statuses};
writeFileSync("lab/results/current-code-probe.json",JSON.stringify(result,null,2));console.log(result);
