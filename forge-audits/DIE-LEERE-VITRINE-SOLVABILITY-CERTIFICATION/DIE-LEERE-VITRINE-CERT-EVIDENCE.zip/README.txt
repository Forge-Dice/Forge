DIE LEERE VITRINE — FORMAL SOLVABILITY CERTIFICATION EVIDENCE
PRIVATE AUTHOR PACKAGE: contains spoilers, Truth, Solution and Proof Profile.
Do not give this archive to blind testers.

Verdict for current assembled contract chain: NOT CERTIFIED.
Bounded existing case model: PASS. See report for precise scope and blockers.

Main: 3d7545d843883418348004e68717399a64da7a7d; independently rechecked unchanged.
All canonical operations were GET reads. No repository/GitHub mutations.

Reproduce from archive root (Python 3 standard library; Node 22+):
  node --experimental-strip-types lab/current-resolver-probe.ts
  python3 lab/certify.py
  python3 lab/additional_checks.py
  python3 lab/differential.py
  python3 lab/render_report.py

The Node probe imports unmodified identity and semantics modules and extracts
exact private resolver source. It does NOT claim to run Zod parsing.
Python probes are disposable reference models, not production implementations.
The broader 531441-accusation loop may take several minutes on slower machines.

Original sources are preserved under inputs/ and current-main/.
The isolated model reads explicit release data, never Evidence.links as proof.
The original 144 simulations are historical inputs only, not this run's coverage.
Current 1200 sequences include an explicit recovery suffix, not simulated humans.
The independent 192-state quotient establishes no softlock under monotone gates.

Required repairs are candidate artifacts in lab/results/*REPAIR-CANDIDATE.json.
The standalone proof profile preserves the original bound bytes and release hash.
No new canonical Source/PlayerRef/Session contract is invented.

SOURCE-SHA256.json identifies source bytes. SHA256SUMS.json hashes archive members
except itself. These checksums provide integrity comparison, not authentication.
