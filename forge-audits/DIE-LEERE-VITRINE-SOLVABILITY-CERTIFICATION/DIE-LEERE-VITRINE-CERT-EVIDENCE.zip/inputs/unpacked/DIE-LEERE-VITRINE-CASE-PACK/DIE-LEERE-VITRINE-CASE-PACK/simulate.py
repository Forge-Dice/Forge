"""Disposable proposed host. NOT an implemented repository game or production PlayerRef protocol."""
import json,hashlib,itertools,pathlib,copy
ROOT=pathlib.Path(__file__).resolve().parent; PACK=ROOT/'case-pack'; OUT=ROOT/'evidence'
def load(name):return json.loads((PACK/name).read_text())
def stable(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
truth=load('truth.json');solution=load('solution.json');host=load('case-host.design.json');catalogue=load('questions.design.json')
npcs={n:load('npc-'+n+'.json') for n in ['max','lina','nora','oskar']};profiles={n:load('interrogation-'+n+'.design.json') for n in npcs}
oracle=json.loads((OUT/'current-parser-validation.json').read_text())['oracle']
packagehash=hashlib.sha256(stable(dict(profile='case-lab-package-v1',truth=truth,solution=solution,host=host,catalogue=catalogue,npcs=npcs,profiles=profiles,proofProfile=load('proof-profile.PRIVATE.design.json'),releaseManifest=load('release-manifest.PRIVATE.design.json'))).encode()).hexdigest()
alphabet='0123456789abcdefghjkmnpqrstvwxyz'
entities={}
for kind,coll in [('person','persons'),('location','locations'),('item','items'),('event','events'),('evidence','evidence')]:
 for e in truth[coll]:entities[e['id']]=kind
def ref(cid,pkg=packagehash):
 data=('case-scratch-playerref-v1\n'+pkg+'\n'+host['saltHex']+'\n'+entities[cid]+'\n'+cid).encode()
 n=int.from_bytes(hashlib.sha256(data).digest()[:10],'big');chars=''
 for _ in range(16):chars=alphabet[n&31]+chars;n>>=5
 return 'pr1_'+chars
refs={cid:ref(cid) for cid in entities}; reverse={r:cid for cid,r in refs.items()};assert len(reverse)==len(refs)
propmap={p['id']:p for p in truth['propositions']}
def claimrefs(c):return [v for k,v in c.items() if k in ['personId','locationId','itemId','eventId','causeEventId']]
def translate(c):return {({'personId':'person','locationId':'location','itemId':'item','eventId':'event','causeEventId':'causeEvent'}.get(k,k)):refs[v] if k.endswith('Id') else v for k,v in c.items()}
def proof(found):
 # Only released certified observations seed the public, case-bound rules. NPC reports do not.
 seeds=set(x for d in found for x in host['presentation'][d]['observed']); facts={};trace=[]
 for pid in sorted(seeds):
  p=propmap[pid];c=p['claim']
  if c['kind']=='personAt' and c['at']==host['challenge']['crimeTime'] and c['locationId']!=host['challenge']['crimeLocation']:
   person=c['personId'];facts[person]=False;trace.append(dict(rule='rule:manual-presence',premises=[pid],person=person,value=False))
 survivors=[p for p in host['challenge']['publicRoster'] if facts.get(p) is not False]
 if len(survivors)==1:
  facts[survivors[0]]=True;trace.append(dict(rule='rule:closed-roster',premises=sorted(p for p,v in facts.items() if v is False),person=survivors[0],value=True))
 vectors=list(itertools.product([False,True],repeat=4));roster=host['challenge']['publicRoster']
 vectors=[v for v in vectors if all(p not in facts or v[i]==facts[p] for i,p in enumerate(roster))]
 return dict(facts=facts,trace=trace,survivingVectors=vectors,pass_=len(facts)==4 and len(vectors)==1)
def fresh():return dict(known=set(x['id'] for x in host['initialKnown']),found=set(),reports=[],log=[],phase='running')
def available(state,r,kind=None):
 if not isinstance(r,str):return None
 cid=reverse.get(r);return cid if cid in state['known'] and (kind is None or entities[cid]==kind) else None
def bad():return dict(success=False,code='ACTION_NOT_AVAILABLE')
def card(state,d):
 payload=host['presentation'][d];obs=[];mentions=set()
 for pid in payload['observed']:
  p=propmap[pid];assert p['truth'] # certificate checked by source parser validator; never infer from links
  mentions.update(claimrefs(p['claim']));obs.append(dict(type='observed',statement=translate(p['claim']),value=True))
 state['known'].update(mentions);state['known'].add(d)
 return dict(ref=refs[d],title=payload['title'],text=payload['text'],observations=obs,mentions=[dict(kind=entities[x],ref=refs[x]) for x in sorted(mentions,key=lambda x:refs[x])])
def step(state,cmd):
 if state['phase']=='solved':return dict(success=False,code='SESSION_COMPLETED')
 if not isinstance(cmd,dict):return bad()
 typ=cmd.get('type');out=None
 if typ in ['search','read_record']:
  if set(cmd)!={'type','target'}:return bad()
  cid=available(state,cmd['target'],'location' if typ=='search' else 'item')
  if not cid or typ=='read_record' and cid not in ['item:kamera','item:terminal']:return bad()
  mode='search_location' if typ=='search' else 'examine_item'
  allfound=sorted(d for d,path in host['access'].items() if path==dict(kind=mode,target=cid))
  new=[d for d in allfound if d not in state['found']]
  cards=[card(state,d) for d in new];state['found'].update(allfound)
  out=dict(success=True,evidence=cards)
 elif typ=='ask':
  if set(cmd)!={'type','npc','questionId'}:return bad()
  cid=available(state,cmd['npc'],'person');n=cid.split(':')[1] if cid else ''
  rule=next((r for r in profiles.get(n,{}).get('rules',[]) if r['questionId']==cmd['questionId']),None)
  q=next((q for q in catalogue['questions'] if q['id']==cmd['questionId']),None)
  if not rule or not q or any(x['id'] not in state['known'] for x in q['mentions']):return bad()
  observation=dict(schemaVersion=1,npc=refs[cid],questionId=cmd['questionId'],act=rule['act'])
  if rule['act']=='answer':
   attitudes=npcs[n]['attitudes'];subjects={p['id']:p['claim'] for p in truth['propositions']};subjects.update({c['id']:c['claim'] for c in solution['conclusions']})
   attitude=next((a for a in attitudes if subjects[a['subject']['id']]==rule['claim']),None)
   if not attitude:observation['stance']='does_not_know'
   else:
    stance=attitude['stance'];v=stance.get('value',stance.get('leaning'))
    observation['stance']=('affirms' if v else 'denies') if stance['kind'] in ['knowledge','belief'] else ('uncertain' if v is None else 'leans_affirms' if v else 'leans_denies')
    authorized={x['id'] for x in q['mentions']+rule['reveal']}|{cid}
    if not set(claimrefs(rule['claim']))<=authorized:raise ValueError('unauthorized claim release')
    observation['statement']=translate(rule['claim']);m=set(claimrefs(rule['claim']));state['known'].update(m)
    observation['mentions']=[dict(kind=entities[x],ref=refs[x]) for x in sorted(m,key=lambda x:refs[x])]
  state['reports'].append(dict(type='reported',observation=observation));out=dict(success=True,observation=observation)
 elif typ=='accuse':
  if set(cmd)!={'type','actor','evidenceRefs'}:return bad()
  actor=available(state,cmd['actor'],'person');er=cmd['evidenceRefs']
  if not actor or actor not in host['challenge']['publicRoster'] or not isinstance(er,list) or not all(isinstance(x,str) for x in er) or len(er)>8 or len(set(er))!=len(er):return bad()
  cited=[available(state,r,'evidence') for r in er]
  if any(x is None or x not in state['found'] for x in cited):return bad()
  submitted={'conclusion:actor-'+p.split(':')[1]:p==actor for p in host['challenge']['publicRoster']}
  key_ok=all(oracle[c]==v for c,v in submitted.items())
  # Proposed challenge proof receipt, above the unchanged neutral Core Verdict design.
  receipt=proof(cited)
  evidence_ok=receipt['pass_'] and all(receipt['facts'].get(p)==(p==actor) for p in host['challenge']['publicRoster'])
  solved=key_ok and evidence_ok
  if solved:state['phase']='solved'
  out=dict(success=True,verdict='solved' if solved else 'not_solved')
 else:return bad()
 state['log'].append(copy.deepcopy(cmd));return out
def public_initial():
 return dict(title='Die leere Vitrine',time='18:08:00',brief='Die Goldmedaille Morgenstern fehlt. Der authentifizierte Sensor setzt die eigenhändige Entnahme auf 18:04:00 in der Galerie. Prüfe die vier verbliebenen Personen und belege deine Entscheidung mit unabhängigen Nachweisen.',suspects=[dict(ref=refs[p['id']],name=p['name'],role=host['personRoles'][p['id']]) for p in truth['persons']],locations=[dict(ref=refs[l['id']],name=l['name']) for l in truth['locations']],rules=host['publicRules'],question='Wer entnahm die Medaille eigenhändig?',answerOptions=[refs[p] for p in host['challenge']['publicRoster']],entities=public_state(fresh())['entities'],phase='running')
def public_state(s):return dict(phase=s['phase'],known=sorted(refs[x] for x in s['known']),entities=[dict(kind=entities[x],ref=refs[x],label=host['entityLabels'][x]) for x in sorted(s['known'],key=lambda x:refs[x])],discoveredEvidence=sorted(refs[x] for x in s['found']),reports=s['reports'])
def S(l):return dict(type='search',target=refs['location:'+l])
def R(i):return dict(type='read_record',target=refs['item:'+i])
def Q(n,i):return dict(type='ask',npc=refs['person:'+n],questionId='question:q'+str(i).zfill(2))
def A(n='lina',ds=('d04','d05')):return dict(type='accuse',actor=refs['person:'+n],evidenceRefs=[refs['evidence:'+d] for d in ds])
witness=[S('hof'),Q('nora',8),R('kamera'),Q('oskar',14),R('terminal')]
scenarios=[]
for j in range(12):
 # All categories are constructed, not random sampling; repeated prefixes distinguish lengths.
 pre=[Q('max',1)]*(j%4)+[S(['hof','foyer','werkstatt'][j%3])]
 cases={
 'normal':pre+[S('galerie'),Q('oskar',12),Q('max',2),*witness,A()],
 'exhaustive':[S(x) for x in list(itertools.permutations(['galerie','hof','archiv','werkstatt','foyer']))[j]]+[Q(n,i) for i in range(1,21) for n in [host['questionText']['question:q'+str(i).zfill(2)]['npc'].split(':')[1]]]+[R('kamera'),R('terminal'),A('lina',tuple('d'+str(k).zfill(2) for k in range(1,9)))],
 'wrong-order':pre+[R('kamera'),R('terminal'),A('max',()),Q('oskar',14),R('terminal'),A('lina',('d05',)),S('hof'),Q('nora',8),R('kamera'),A()],
 'repeated-search':pre+[S('galerie')]*(j+2)+witness+[R('kamera')]*3+[A()],
 'repeated-questions':pre+[Q('oskar',12)]*(j+2)+witness+[Q('nora',8)]*3+[A()],
 'accusation-spam':pre+[A(n,()) for _ in range(j+1) for n in npcs]+witness+[A(n) for n in ['max','nora','oskar']]+[A()],
 'minimal-information':[Q('max',2)]*j+([Q('oskar',14),R('terminal'),S('hof'),Q('nora',8),R('kamera')] if j%2 else witness)+[A()],
 'contradictory-reports':pre+[Q('oskar',12),Q('nora',9),Q('max',2),Q('nora',10),Q('lina',17)]+witness+[A()],
 'stale-refs':pre+[dict(type='read_record',target=ref('item:kamera',hashlib.sha256(str(j).encode()).hexdigest())),dict(type='ask',npc=ref('person:lina','0'*64),questionId='question:q16')]+witness+[A()],
 'inaccessible-refs':pre+[R('terminal'),R('kamera'),R('medaille'),dict(type='read_record',target=refs['person:max'])]+witness+[A()],
 'citation-attack':pre+witness+[A('lina',()),A('lina',('d04',)),A('lina',('d05',)),A('max',('d04','d05')),A('lina',('d04','d04')),dict(type='accuse',actor=refs['person:lina'],evidenceRefs=[refs['evidence:d04'],refs['evidence:d05']],extras=['everyone'])]+[A()],
 'post-solved':pre+witness+[A()]+[S('galerie'),Q('oskar',12),A('max')] *(j+1)
 }
 for category,commands in cases.items():scenarios.append(dict(id=category+'-'+str(j+1).zfill(2),category=category,commands=commands))
assert len({stable(x['commands']) for x in scenarios})==len(scenarios)
forbidden=['person:','location:','item:','event:','proposition:','conclusion:','evidence:','"knowledge"','"belief"','"provenance"','"acquiredAt"','"index"','"requiredConclusions"','"truthHash"','"solutionHash"']
def leakcheck(x):
 s=stable(x)
 for token in forbidden:assert token not in s,('leak',token)
leakcheck(public_initial())
results=[];actions=0;invalid=0;verdicts={};story=[]
for fixture in scenarios:
 state=fresh();outputs=[]
 for command in fixture['commands']:
  out=step(state,command);leakcheck(out);outputs.append(out);actions+=1
  if not out['success']:invalid+=1
  if 'verdict' in out:verdicts[out['verdict']]=verdicts.get(out['verdict'],0)+1
 assert state['phase']=='solved',fixture['id']
 again=fresh();second=[step(again,c) for c in fixture['commands']]
 assert stable(outputs)==stable(second) and public_state(state)==public_state(again)
 replay=fresh()
 for c in state['log']:assert step(replay,c)['success']
 assert public_state(state)==public_state(replay),('replay',fixture['id'])
 results.append(dict(id=fixture['id'],category=fixture['category'],actions=len(outputs),accepted=len(state['log']),solved=True,deterministic=True,replayEqual=True,discovered=len(state['found'])))
# Golden visible progression: false accusation -> missing citation -> substantiated answer.
commands=[S('galerie'),Q('oskar',12),A('max',('d01','d02')),Q('max',2),Q('nora',6),S('hof'),Q('nora',8),R('kamera'),A('oskar',('d04',)),Q('oskar',14),R('terminal'),A()]
state=fresh()
for c in commands:story.append(dict(action=c,result=step(state,c),publicState=public_state(state)))
leakcheck(story)
# Validate authored proof consequences against the CURRENT authoritative parser oracle.
completeproof=proof(['evidence:d04','evidence:d05'])
assert all(completeproof['facts'][p]==oracle['conclusion:actor-'+p.split(':')[1]] for p in host['challenge']['publicRoster'])
# Full finite answer/citation experiment; no shotgun claim route exists.
state=fresh()
for c in [*[S(l) for l in ['galerie','hof','archiv','werkstatt','foyer']],*witness]:step(state,c)
accusations=[]
all_e=['evidence:d'+str(k).zfill(2) for k in range(1,9)]
for actor in npcs:
 for mask in range(256):
  cited=[e for i,e in enumerate(all_e) if mask&(1<<i)];tmp=copy.deepcopy(state)
  o=step(tmp,dict(type='accuse',actor=refs['person:'+actor],evidenceRefs=[refs[e] for e in cited]));expected=actor=='lina' and 'evidence:d04' in cited and 'evidence:d05' in cited
  assert o==dict(success=True,verdict='solved' if expected else 'not_solved')
  accusations.append(dict(actor=actor,citationMask=mask,solved=o['verdict']=='solved',expected=expected))
proofmatrix=[]
for mask in range(256):
 found=[e for i,e in enumerate(all_e) if mask&(1<<i)];p=proof(found)
 assert p['pass_']==('evidence:d04' in found and 'evidence:d05' in found)
 proofmatrix.append(dict(mask=mask,pass_=p['pass_'],survivingAnswerVectors=len(p['survivingVectors'])))
# Fresh-state reports alone, decline, uncertainty and early true fact cannot prove guilt.
reportstate=fresh()
for i in range(1,21): step(reportstate,Q(host['questionText']['question:q'+str(i).zfill(2)]['npc'].split(':')[1],i))
assert not proof(reportstate['found'])['pass_'];assert reportstate['found']==set()
assert len([r for r in reportstate['reports'] if r['observation']['act']=='decline'])==2
assert len([r for r in reportstate['reports'] if r['observation'].get('stance')=='does_not_know'])==3
assert len([r for r in reportstate['reports'] if r['observation'].get('stance')=='uncertain'])==1
summary=dict(status='CASE-SPECIFIC PROPOSAL — experimentally checked disposable model, NOT repository runtime',packageHash=packagehash,scenarios=len(scenarios),distinctScenarios=len({stable(x['commands']) for x in scenarios}),actions=actions,invalidOrPostSolved=invalid,verdicts=verdicts,determinismMismatches=0,replayMismatches=0,publicPayloadLeakFailures=0,scenarioFailures=0,proofSubsets=256,proofPassingSubsets=sum(x['pass_'] for x in proofmatrix),accusations=len(accusations),accusationsSolved=sum(x['solved'] for x in accusations),wrongActorSolved=0,insufficientProofSolved=0,npcQuestions=20,declines=2,unknownResponses=3,uncertainResponses=1,knownFalseBeliefReports=1,commonWitnessActions=5,winningAccusationAction=1)
for name,value in [('simulation-summary.json',summary),('playthrough-results.json',results),('golden-player-trace.json',story),('accusation-grid.json',accusations),('proof-subsets.json',proofmatrix)]: (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
(PACK/'public-initial.json').write_text(json.dumps(public_initial(),ensure_ascii=False,indent=2)+'\n')
(PACK/'acceptance-scenarios.json').write_text(json.dumps(scenarios,ensure_ascii=False,indent=2)+'\n')
(PACK/'package-manifest.design.json').write_text(json.dumps(dict(profile='case-lab-package-v1',packageHash=packagehash,sourceMain=host['sourceMain'],playerRefProfile='case-scratch-playerref-v1 — provisional; NOT claimed compatible with MYST-0001',publicRules='case-bound manual presence + closed finite roster',savedData=['schemaVersion','packageHash','commands'],derivedOnly=['known','discoveredEvidence','reports','proofClosure','phase'],authenticity='none'),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False))
