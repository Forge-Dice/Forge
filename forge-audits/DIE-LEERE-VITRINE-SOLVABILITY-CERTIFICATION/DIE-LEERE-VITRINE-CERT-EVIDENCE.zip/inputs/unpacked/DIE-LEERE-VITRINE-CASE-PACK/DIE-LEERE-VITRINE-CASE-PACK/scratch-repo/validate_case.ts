import fs from 'node:fs';
import {parseCaseTruth} from './src/domain/case-truth.ts';
import {hashCaseTruth} from './src/domain/case-truth.identity.ts';
import {validateCaseSemantics} from './src/domain/case-semantics.ts';
import {parseCaseSolution} from './src/domain/case-solution.ts';
import {hashCaseSolution} from './src/domain/case-solution.identity.ts';
import {parseNpcKnowledge} from './src/domain/npc-knowledge.ts';
import {projectNpcKnowledge} from './src/domain/npc-knowledge.projection.ts';
const root=new URL('../',import.meta.url);
const read=(name:string)=>JSON.parse(fs.readFileSync(new URL('case-pack/'+name,root),'utf8'));
const write=(name:string,value:unknown)=>fs.writeFileSync(new URL('case-pack/'+name,root),JSON.stringify(value,null,2)+'\n');
const truth=parseCaseTruth(read('truth.json'));
const truthHash=hashCaseTruth(truth);
const sin=read('solution.input.json');sin.truthHash=truthHash;
const solution=parseCaseSolution(sin,truth); const solutionHash=hashCaseSolution(solution);
const semantic=validateCaseSemantics(truth);
if(semantic.findings.length)throw Error(JSON.stringify(semantic));
write('solution.json',solution);
const catalogue=read('questions.input.json');catalogue.truthHash=truthHash;
// Current domain has no catalogue parser: draft shape/binding checked only by this scratch validator.
const c14n=(x:any):string=>Array.isArray(x)?'['+x.map(c14n).sort().join(',')+']':x&&typeof x==='object'?'{'+Object.keys(x).sort().map(k=>JSON.stringify(k)+':'+c14n(x[k])).join(',')+'}':JSON.stringify(x);
const {createHash}=await import('node:crypto');
const catalogueHash=createHash('sha256').update('forge-interrogation-catalogue-c14n-v1\n'+c14n(catalogue)).digest('hex');
write('questions.design.json',catalogue);
const host=read('case-host.design.json');host.truthHash=truthHash;host.solutionHash=solutionHash;
const validation:any={status:'EXPERIMENTALLY VERIFIED',main:host.sourceMain,truthHash,solutionHash,semantic,counts:{persons:truth.persons.length,locations:truth.locations.length,events:truth.events.length,evidence:truth.evidence.length},npc:[],draftReleaseChecks:[],oracle:{}};
for(const name of ['max','lina','nora','oskar']){
 const nin=read('npc-'+name+'.input.json');nin.truthHash=truthHash;nin.solutionHash=solutionHash;
 const npc=parseNpcKnowledge(nin,truth,solution); const projection=projectNpcKnowledge(npc,truth,solution);
 if(!projection.success)throw Error('projection mismatch');
 if(/person:|event:|proposition:|conclusion:|evidence:/.test(JSON.stringify(projection.context)))throw Error('projection raw ID leak');
 const bad:any=structuredClone(npc);bad.truthHash='0'.repeat(64);
 if(projectNpcKnowledge(bad,truth,solution).success)throw Error('binding not checked');
 write('npc-'+name+'.json',npc);write('projection-'+name+'.PRIVATE.json',projection.context);
 validation.npc.push({name,attitudes:npc.attitudes.length,projectionSuccess:true,frozen:Object.isFrozen(projection.context),mismatchRejected:true});
 const profile=read('interrogation-'+name+'.input.json');profile.truthHash=truthHash;profile.catalogueHash=catalogueHash;
 for(const r of profile.rules){
  const q=catalogue.questions.find((x:any)=>x.id===r.questionId);if(!q)throw Error('missing question');
  if(r.act==='decline')continue;
  const refs=Object.entries(r.claim).flatMap(([k,id])=>({personId:'person',locationId:'location',itemId:'item',eventId:'event',causeEventId:'event'} as any)[k]?[{kind:({personId:'person',locationId:'location',itemId:'item',eventId:'event',causeEventId:'event'} as any)[k],id}]:[]);
  const key=(x:any)=>x.kind+'|'+x.id; const m=new Set([...q.mentions,{kind:'person',id:npc.npcId}].map(key));const rv=new Set(r.reveal.map(key));
  if(rv.size!==r.reveal.length || refs.some(x=>!m.has(key(x))&&!rv.has(key(x)))||r.reveal.some((x:any)=>m.has(key(x))||!refs.some(y=>key(y)===key(x))))throw Error('draft R1-R4 failure '+r.questionId);
  validation.draftReleaseChecks.push(r.questionId);
 }
 write('interrogation-'+name+'.design.json',profile);
}
// Black-box reuse of the existing authoritative parser, no duplicated resolver switch.
for(const c of solution.conclusions){
 const accepted=[];
 for(const value of [true,false]){
   try{parseCaseSolution({...sin,requiredConclusions:[{conclusionId:c.id,value}]},truth);accepted.push(value);}catch{}
 }
 validation.oracle[c.id]=accepted.length===1?accepted[0]:'undetermined';
}
host.catalogueHash=catalogueHash;
// Release factuality checks are explicit and separate from Evidence.links.
for(const [eid,r] of Object.entries(host.presentation) as [string,any][]){
 if(!truth.evidence.some(x=>x.id===eid))throw Error('foreign release');
 for(const id of r.observed)if(!truth.propositions.find(x=>x.id===id)?.truth)throw Error('false certified observation');
}
if(host.challenge.crimeTime!==truth.events.find(e=>e.id===host.challenge.eventId)!.time.at)throw Error('setup crime time');
write('case-host.design.json',host);
fs.writeFileSync(new URL('evidence/current-parser-validation.json',root),JSON.stringify(validation,null,2)+'\n');
console.log(JSON.stringify(validation));
