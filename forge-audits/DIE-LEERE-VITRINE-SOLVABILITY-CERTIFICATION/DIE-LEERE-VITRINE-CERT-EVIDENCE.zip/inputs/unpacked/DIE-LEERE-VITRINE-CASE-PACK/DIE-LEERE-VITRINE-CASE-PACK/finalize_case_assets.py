import pathlib,json
P=pathlib.Path(__file__).resolve().parent/'case-pack'
p=P/'case-host.design.json';h=json.loads(p.read_text())
if not any(r['id']=='rule:certified-sources' for r in h['publicRules']):h['publicRules'].append(dict(id='rule:certified-sources',text='Die als Beobachtung freigegebenen Bildnachweise sind in diesem Fall unverfälscht und mit dem Entnahmesensor synchronisiert. Zeugenaussagen können irren. Ein Besuch zu einer anderen Uhrzeit und eine Gesprächsverweigerung beweisen keine eigenhändige Entnahme.'))
h['entityLabels']={'person:max':'Max Brandt','person:lina':'Lina Kern','person:nora':'Nora Weiss','person:oskar':'Oskar Falk','location:galerie':'Galerie','location:hof':'Innenhof','location:archiv':'Archiv','location:werkstatt':'Werkstatt','location:foyer':'Foyer','item:medaille':'Goldmedaille „Morgenstern“','item:schluessel':'Vitrinenschlüssel','item:kamera':'Noras Kamera','item:terminal':'Archivterminal','item:kassette':'Transportkassette',**h['publicEventLabels'],**{eid:r['title'] for eid,r in h['presentation'].items()}}
# Exact MYST-0003 draft shape, no invented revision field.
entries=[]
for eid,a in h['access'].items():
    field='locationId' if a['kind']=='search_location' else 'itemId'
    entries.append(dict(evidenceId=eid,access=dict(kind='discoverable',paths=[{'kind':a['kind'],field:a['target']}])) )
(P/'evidence-access.design.json').write_text(json.dumps(dict(schemaVersion=1,caseId='case:leere-vitrine-v1',truthHash=h['truthHash'],entries=entries),ensure_ascii=False,indent=2)+'\n')
p.write_text(json.dumps(h,ensure_ascii=False,indent=2)+'\n')
