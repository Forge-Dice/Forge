import json, pathlib
ROOT=pathlib.Path(__file__).resolve().parent
PACK=ROOT/'case-pack'
def write(name,value): (PACK/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
people=[('max','Max Brandt','Historiker und Vertreter der ehemaligen Eigentümerfamilie'),('lina','Lina Kern','Restauratorin'),('nora','Nora Weiss','Museumsfotografin'),('oskar','Oskar Falk','Aufsicht und Schlüsselverwalter')]
locations=[('galerie','Galerie'),('hof','Innenhof'),('archiv','Archiv'),('werkstatt','Werkstatt'),('foyer','Foyer')]
items=[('medaille','Goldmedaille „Morgenstern“'),('schluessel','Vitrinenschlüssel'),('kamera','Noras Kamera'),('terminal','Archivterminal'),('kassette','Transportkassette')]
P=lambda s:'person:'+s
L=lambda s:'location:'+s
I=lambda s:'item:'+s
E=lambda s:'event:'+s
def event(n,description,time,location,persons,items): return dict(id=E(n),description=description,time=time,locationId=L(location),participantIds=list(map(P,persons)),itemIds=list(map(I,items)),causedByEventIds=[])
instant=lambda n:dict(kind='instant',at=n)
events=[event('e01','Alle vier bleiben nach der Schließung im Museum.',instant(0),'foyer',['max','lina','nora','oskar'],[]),event('e02','Max betrachtet die Medaille; Oskar beobachtet ihn. Max entnimmt sie nicht.',instant(120),'galerie',['max','oskar'],['medaille']),event('e03','Oskar übergibt Lina den Vitrinenschlüssel.',instant(180),'archiv',['oskar','lina'],['schluessel']),event('e04','Lina entnimmt die Medaille eigenhändig.',instant(240),'galerie',['lina'],['medaille','schluessel']),event('e05','Nora und Max sind im synchronisierten Hoffoto erfasst.',dict(kind='interval',start=220,end=280),'hof',['max','nora'],['kamera']),event('e06','Oskar arbeitet im Archiv, die Archivkamera erfasst ihn.',dict(kind='interval',start=220,end=280),'archiv',['oskar'],['terminal']),event('e07','Lina legt die Medaille in die Transportkassette; das öffentliche Bild zeigt nur den geschlossenen Deckel.',instant(300),'werkstatt',['lina'],['medaille','kassette']),event('e08','Nora entdeckt die leere Vitrine.',instant(360),'galerie',['nora'],[])]
props=[]
def prop(n,claim,value=True): props.append(dict(id='proposition:'+n,claim=claim,truth=value)); return n
def at(n,p,l,t,value=True): return prop(n,dict(kind='personAt',personId=P(p),locationId=L(l),at=t),value)
def part(n,e,p,value=True): return prop(n,dict(kind='eventHasParticipant',eventId=E(e),personId=P(p)),value)
def has(n,e,i,value=True): return prop(n,dict(kind='eventHasItem',eventId=E(e),itemId=I(i)),value)
at('p01','max','galerie',120); at('p02','max','galerie',240,False)
at('p03','max','hof',240); at('p04','nora','hof',240); at('p05','oskar','archiv',240); at('p06','lina','galerie',240)
part('p07','e03','lina');has('p08','e03','schluessel');has('p09','e06','terminal');has('p10','e05','kamera')
part('p11','e07','lina');has('p12','e04','medaille');has('p13','e07','medaille');part('p14','e04','max',False)
has('p15','e04','schluessel');has('p16','e07','kassette');part('p17','e03','oskar');part('p18','e05','nora')
at('p19','lina','archiv',180);at('p20','lina','werkstatt',300)
for n,p in enumerate(['max','lina','nora','oskar'],21): part('p'+str(n),'e01',p)
def evidence(n,desc,source,links): return dict(id='evidence:'+n,description=desc,source=dict(kind=source[0],id=source[1]),links=[dict(propositionId='proposition:'+p,direction='supports') for p in links])
es=[evidence('d01','Besucherstempel bestätigt Max um 18:02 in der Galerie. Keine Entnahmebehauptung.',('location',L('galerie')),['p01']),evidence('d02','Authentifizierter Entnahmesensor meldet 18:04:00; zeigt keine Identität.',('event',E('e04')),['p12']),evidence('d03','Kontaktbogen zeigt Nora beim Hoffototermin, aber keine Uhrzeit und keinen vollständigen Film.',('location',L('hof')),['p18']),evidence('d04','Vollständiger Kamerafilm zeigt Max und Nora um 18:04:00 im Hof.',('item',I('kamera')),['p03','p04']),evidence('d05','Archivkamera zeigt Oskar um 18:04:00 im Archiv.',('item',I('terminal')),['p05']),evidence('d06','Werkstattaufnahme zeigt Lina um 18:05 an einer geschlossenen Transportkassette. Inhalt nicht sichtbar.',('location',L('werkstatt')),['p11','p16','p20']),evidence('d07','Quittung bestätigt Oskar und Lina bei der Schlüsselübergabe um 18:03.',('location',L('archiv')),['p07','p08','p17','p19']),evidence('d08','Schließliste nennt genau die vier Personen, die im Museum verblieben.',('location',L('foyer')),['p21','p22','p23','p24'])]
truth=dict(schemaVersion=1,caseId='case:leere-vitrine-v1',revision=1,title='Die leere Vitrine',timeline=dict(unit='second',originLabel='18:00:00 am Schließabend'),persons=[dict(id=P(s),name=n) for s,n,_ in people],locations=[dict(id=L(s),name=n) for s,n in locations],items=[dict(id=I(s),name=n) for s,n in items],relationships=[],events=events,motives=[dict(id='motive:lina',personId=P('lina'),eventIds=[E('e04')],description='Lina will eine unerlaubte Reparatur vor der morgigen Leihgeberprüfung verbergen. Motive sind hier Erzählung, keine Proof-Prämisse.')],propositions=props,evidence=es,secrets=[dict(id='secret:medaille',propositionIds=['proposition:p06','proposition:p13','proposition:p15'])],redHerrings=[dict(id='red-herring:max',evidenceIds=['evidence:d01'],misleadingPropositionId='proposition:p02')])
conclusions=[dict(id='conclusion:actor-'+s,claim=dict(kind='personRoleForEvent',personId=P(s),eventId=E('e04'),role='direct_actor')) for s,_,_ in people]
solution=dict(schemaVersion=1,caseId=truth['caseId'],revision=1,truthHash='TO_BE_BOUND',resolutions=[dict(eventId=E('e04'),targets=[dict(kind='item',id=I('medaille'))],responsibility=dict(completeness='complete',assignments=[dict(personId=P('lina'),roles=['direct_actor'])]),intent='intended',mechanism='ordinary',causesComplete=True)],conclusions=conclusions,requiredConclusions=[dict(conclusionId=c['id'],value=c['id']=='conclusion:actor-lina') for c in conclusions])
byprop={p['id']:p for p in props}
def refs(claim):
    kinds={'personId':'person','locationId':'location','itemId':'item','eventId':'event','causeEventId':'event'}
    return [dict(kind=kinds[k],id=v) for k,v in claim.items() if k in kinds]
questions=[];profiles={s:[] for s,_,_ in people};presentation={};npcstates={s:[] for s,_,_ in people}
def q(n,npc,text,propid=None,stance=None,decline=False,reveal=(),mentions=None,conclusion=None):
    qid='question:q'+str(n).zfill(2)
    claim=(byprop['proposition:'+propid]['claim'] if propid else next(c['claim'] for c in conclusions if c['id']==conclusion)) if not decline else None
    rr=list(reveal); m=mentions if mentions is not None else ([dict(kind='person',id=P(npc))] if rr else refs(claim))
    questions.append(dict(id=qid,mentions=m));presentation[qid]=dict(npc=P(npc),text=text)
    rule=dict(questionId=qid,act='decline' if decline else 'answer')
    if not decline:rule.update(claim=claim,reveal=rr)
    profiles[npc].append(rule)
    if stance:
        subject=dict(kind='proposition' if propid else 'conclusion',id='proposition:'+propid if propid else conclusion)
        if not any(x['subject']==subject for x in npcstates[npc]): npcstates[npc].append(dict(subject=subject,stance=stance,acquiredAt=400,provenance=dict(kind='author_modeled_inference')))
knowledge=lambda b:dict(kind='knowledge',value=b)
belief=lambda b:dict(kind='belief',value=b)
uncertain=lambda b:dict(kind='uncertain',leaning=b)
q(1,'max','Waren Sie um 18:02 in der Galerie?','p01',knowledge(True))
q(2,'max','Waren Sie um 18:04 in der Galerie?','p02',knowledge(False))
q(3,'max','Waren Sie um 18:04 im Hof?','p03',knowledge(True))
q(4,'max','War Lina um 18:04 in der Galerie?','p06')
q(5,'max','Wo ist der vollständige Fotonachweis?','p10',reveal=refs(byprop['proposition:p10']['claim']))
q(6,'nora','War Max um 18:04 im Hof?','p03',knowledge(True))
q(7,'nora','Waren Sie um 18:04 im Hof?','p04',knowledge(True))
q(8,'nora','Kann ich den vollständigen Film dieses Hoffototermins sehen?','p10',knowledge(True),reveal=[dict(kind='item',id=I('kamera'))],mentions=[dict(kind='person',id=P('nora')),dict(kind='event',id=E('e05'))])
q(9,'nora','War Max um 18:04 in der Galerie?','p02',knowledge(False))
q(10,'nora','War Lina um 18:04 in der Galerie?','p06',uncertain(None))
q(11,'oskar','War Max um 18:02 in der Galerie?','p01',knowledge(True))
q(12,'oskar','War Max um 18:04 in der Galerie?','p02',belief(True))
q(13,'oskar','Waren Sie um 18:04 im Archiv?','p05',knowledge(True))
q(14,'oskar','Wo ist der unabhängige Archivnachweis?','p09',knowledge(True),reveal=refs(byprop['proposition:p09']['claim']))
q(15,'oskar','War Lina um 18:03 bei Ihnen im Archiv?','p19',knowledge(True))
q(16,'lina','Waren Sie um 18:04 in der Galerie?',decline=True,mentions=refs(byprop['proposition:p06']['claim']))
q(17,'lina','Hat Max die Medaille eigenhändig entnommen?',stance=belief(False),conclusion='conclusion:actor-max')
q(18,'lina','Waren Sie um 18:05 in der Werkstatt?','p20',knowledge(True))
q(19,'lina','War Nora um 18:04 im Hof?','p04')
q(20,'lina','Möchten Sie zur Entnahme Stellung nehmen?',decline=True,mentions=[dict(kind='person',id=P('lina')),dict(kind='event',id=E('e04'))])
# Lina's private knowledge remains unreleased by decline policy.
npcstates['lina'].append(dict(subject=dict(kind='proposition',id='proposition:p06'),stance=knowledge(True),acquiredAt=400,provenance=dict(kind='author_modeled_inference')))
acquisitions={'max':{'p01':('e02',120),'p02':('e05',240),'p03':('e05',240)},'nora':{'p03':('e05',240),'p04':('e05',240),'p02':('e05',240),'p10':('e05',240)},'oskar':{'p01':('e02',120),'p05':('e06',240),'p09':('e06',240),'p19':('e03',180)},'lina':{'p06':('e04',240),'p20':('e07',300)}}
for npc,attitudes in npcstates.items():
    for a in attitudes:
        pid=a['subject']['id'].split(':')[1]
        if a['subject']['kind']=='proposition' and pid in acquisitions[npc]:
            ev,t=acquisitions[npc][pid];a['acquiredAt']=t;a['provenance']=dict(kind='witnessed_event',eventId=E(ev))
baseknown=[dict(kind=k,id=v) for k,v in [('person',P(s)) for s,_,_ in people]+[('location',L(s)) for s,_ in locations]+[('item',I('medaille')),('event',E('e04'))]]
access={}
for d,kind,target in [('d01','search_location',L('galerie')),('d02','search_location',L('galerie')),('d03','search_location',L('hof')),('d04','examine_item',I('kamera')),('d05','examine_item',I('terminal')),('d06','search_location',L('werkstatt')),('d07','search_location',L('archiv')),('d08','search_location',L('foyer'))]:access['evidence:'+d]=dict(kind=kind,target=target)
publicevidence={}
certificates={'evidence:d01':['proposition:p01'],'evidence:d02':['proposition:p12'],'evidence:d03':['proposition:p18'],'evidence:d04':['proposition:p03','proposition:p04'],'evidence:d05':['proposition:p05'],'evidence:d06':['proposition:p11','proposition:p16','proposition:p20'],'evidence:d07':['proposition:p07','proposition:p08','proposition:p17','proposition:p19'],'evidence:d08':['proposition:p21','proposition:p22','proposition:p23','proposition:p24']}
for e in es:
    released=certificates[e['id']][:] # authored certificates, NEVER inferred from Evidence.links
    publicevidence[e['id']]=dict(title={'d01':'Besucherstempel','d02':'Entnahmeprotokoll','d03':'Kontaktbogen','d04':'Vollständiger Hoffilm','d05':'Archivaufnahme','d06':'Werkstattaufnahme','d07':'Schlüsselquittung','d08':'Schließliste'}[e['id'].split(':')[1]],text=e['description'],observed=released)
publicevidence['evidence:d03']['text']='Nora ist auf einem undatierten Kontaktbogen des Hoffototermins erkennbar. Frage sie nach dem vollständigen Fotonachweis.'
publicevidence['evidence:d01']['text']='Der Besucherstempel bestätigt: Max war um 18:02 in der Galerie. Über den Zeitpunkt 18:04 sagt der Stempel nichts.'
publicevidence['evidence:d06']['text']='Werkstattaufnahme, 18:05: Lina steht an einer geschlossenen Transportkassette. Ihr Inhalt ist nicht sichtbar.'
catalogue=dict(schemaVersion=1,caseId=truth['caseId'],truthHash='TO_BE_BOUND',revision=1,questions=questions)
write('truth.json',truth);write('solution.input.json',solution);write('questions.input.json',catalogue)
for s,_,_ in people:
    awareness={('person',P(s))}
    for rule in profiles[s]:
        if rule['act']=='answer': awareness.update((r['kind'],r['id']) for r in refs(rule['claim']))
    snap=dict(schemaVersion=1,caseId=truth['caseId'],truthHash='TO_BE_BOUND',solutionHash='TO_BE_BOUND',npcId=P(s),revision=1,asOf=480,awareness=[dict(subject=dict(kind=k,id=v),acquiredAt=400 if k=='event' else 0,provenance=dict(kind='author_modeled_inference' if k=='event' else 'prior_knowledge')) for k,v in sorted(awareness)],attitudes=npcstates[s])
    write('npc-'+s+'.input.json',snap)
    write('interrogation-'+s+'.input.json',dict(schemaVersion=1,caseId=truth['caseId'],truthHash='TO_BE_BOUND',catalogueHash='TO_BE_BOUND',npcId=P(s),revision=1,rules=profiles[s]))
write('case-host.design.json',dict(status='CASE-SPECIFIC PROPOSAL / DESIGN INPUT; NOT IMPLEMENTED ON MAIN',sourceMain='3d7545d843883418348004e68717399a64da7a7d',saltHex='00112233445566778899aabbccddeeff',proofPolicy=dict(profile='vitrine-proof-v1',rootMode='explicit-certified-evidence-observations-only',rules=['manual_presence_elsewhere_excludes_direct_actor','closed_four_person_single_direct_actor'],licensedInstanceRelease='only after public premises are actually released; never export private proof graph',engineVersion='scratch-v1'),redHerringDesign=dict(evidenceId='evidence:d01',trueObservation='proposition:p01',misleadingConclusion=dict(conclusionId='conclusion:actor-max',value=True),correctionEvidence='evidence:d04',status='CASE-SPECIFIC PROPOSAL; native RedHerring cannot reference ConclusionClaim'),initialKnown=baseknown,challenge=dict(eventId=E('e04'),crimeTime=240,crimeLocation=L('galerie'),publicRoster=[P(s) for s,_,_ in people],answerScope=[c['claim'] for c in conclusions],requireAllFour=True,requireReleasedProof=True,playerVerdicts=['solved','not_solved']),publicRules=[dict(id='rule:manual-presence',text='Die Medaille wurde um 18:04:00 in der Galerie von einer einzelnen Person eigenhändig entnommen. Wer nachweislich zu genau diesem Zeitpunkt an einem anderen Ort war, scheidet als direkter Entnehmer aus.'),dict(id='rule:closed-roster',text='Nur Max, Lina, Nora und Oskar kommen als direkte Entnehmer in Betracht. Es gab genau einen direkten Entnehmer. Sind drei ausgeschlossen, bleibt die vierte Person.')],access=access,presentation=publicevidence,questionText=presentation,publicEventLabels={E('e01'):'Schließrunde',E('e02'):'Galeriebesuch um 18:02',E('e03'):'Schlüsselübergabe um 18:03',E('e04'):'Entnahme um 18:04',E('e05'):'Hoffototermin',E('e06'):'Archivarbeit',E('e07'):'Werkstattaufnahme um 18:05',E('e08'):'Entdeckung der leeren Vitrine'},personRoles={P(s):role for s,_,role in people}))
