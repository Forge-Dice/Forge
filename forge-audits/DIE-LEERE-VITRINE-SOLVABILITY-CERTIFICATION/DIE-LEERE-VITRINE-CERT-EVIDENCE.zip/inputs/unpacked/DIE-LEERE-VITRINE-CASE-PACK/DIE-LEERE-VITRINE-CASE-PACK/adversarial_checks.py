import pathlib,json,copy,contextlib,io
ROOT=pathlib.Path(__file__).resolve().parent
source=(ROOT/'simulate.py').read_text().split('scenarios=[]')[0]
def environment(s):
 e={'__file__':str(ROOT/'simulate.py')};exec(compile(s,'scratch-mutant','exec'),e);return e
def checks(e):
 st=e['fresh']();assert e['step'](st,e['R']('kamera'))==e['bad']()
 st=e['fresh']();o=e['step'](st,e['Q']('oskar',12));assert o['observation']['stance']=='affirms'
 st=e['fresh']();o=e['step'](st,e['Q']('max',5));assert 'statement' not in o['observation'] and 'mentions' not in o['observation'];assert 'item:kamera' not in st['known']
 st=e['fresh']();assert e['step'](st,e['A']('lina',()))['verdict']=='not_solved'
 st=e['fresh']();e['step'](st,e['S']('werkstatt'));assert 'person:lina' not in e['proof'](st['found'])['facts']
 st=e['fresh']()
 for c in e['witness']:e['step'](st,c)
 assert e['step'](copy.deepcopy(st),e['A']('lina',()))['verdict']=='not_solved'
 assert e['step'](st,e['A']())['verdict']=='solved'
 before=copy.deepcopy(st);assert e['step'](st,e['Q']('oskar',12))==dict(success=False,code='SESSION_COMPLETED');assert st==before
 assert e['ref']('person:nora','0'*64)!=e['ref']('person:nora','1'*64)
 st=e['fresh']();o=e['step'](st,e['Q']('max',1));assert 'knowledge' not in json.dumps(o) and 'belief' not in json.dumps(o)
 return True
base=environment(source);assert checks(base)
mutants=[
 ('M1-known-authorization-removed',"cid in state['known'] and (kind is None or entities[cid]==kind)","cid in reverse.values() and (kind is None or entities[cid]==kind)"),
 ('M2-belief-distinguished',"('affirms' if v else 'denies') if stance['kind'] in ['knowledge','belief']", "('leans_affirms' if stance['kind']=='belief' else 'affirms' if v else 'denies') if stance['kind'] in ['knowledge','belief']"),
 ('M3-hidden-truth-roots',"seeds=set(x for d in found for x in host['presentation'][d]['observed'])","seeds=set(propmap)"),
 ('M4-time-check-removed',"and c['at']==host['challenge']['crimeTime'] ",""),
 ('M5-citations-ignored',"receipt=proof(cited)","receipt=proof(state['found'])"),
 ('M6-unknown-answer-reveals',"if not attitude:observation['stance']='does_not_know'","if not attitude:observation['stance']='does_not_know';observation['statement']=translate(rule['claim'])"),
 ('M7-post-solved-actions-accepted',"if state['phase']=='solved':return dict(success=False,code='SESSION_COMPLETED')","if False:return dict(success=False,code='SESSION_COMPLETED')"),
 ('M8-package-binding-removed',"+pkg+'\\n'+host['saltHex']","+'unbound'+'\\n'+host['saltHex']"),
 ('M9-private-stance-leak',"observation['statement']=translate(rule['claim']);m=set(claimrefs(rule['claim']))","observation['privateStance']=stance['kind'];observation['statement']=translate(rule['claim']);m=set(claimrefs(rule['claim']))")
]
results=[]
for name,old,new in mutants:
 assert source.count(old)==1,(name,source.count(old))
 try:checks(environment(source.replace(old,new)));killed=False
 except AssertionError:killed=True
 results.append(dict(mutant=name,killed=killed))
assert all(x['killed'] for x in results),results
progress=[]
for camera in range(3):
 for terminal in range(3):
  st=base['fresh']()
  if camera>=1:base['step'](st,base['S']('hof'));base['step'](st,base['Q']('nora',8))
  if camera==2:base['step'](st,base['R']('kamera'))
  if terminal>=1:base['step'](st,base['Q']('oskar',14))
  if terminal==2:base['step'](st,base['R']('terminal'))
  for c in base['witness']:base['step'](st,c)
  assert base['step'](st,base['A']())['verdict']=='solved'
  progress.append(dict(cameraState=camera,terminalState=terminal,completionPossible=True))
summary=dict(status='CASE-SPECIFIC PROPOSAL — disposable host mutation probes',mutants=results,killed=sum(x['killed'] for x in results),total=len(results),abstractProgressStates=progress,scope='Nine relevant device-awareness/discovery states; not exhaustive enumeration of all complete session histories.')
malformed=[None,True,42,[],{},dict(type='search',target=[]),dict(type='read_record',target={}),dict(type='ask',npc=[],questionId='question:q01'),dict(type='ask',npc=base['refs']['person:max'],questionId={}),dict(type='accuse',actor=base['refs']['person:lina'],evidenceRefs=[{}]),dict(type='accuse',actor=[],evidenceRefs=[]),dict(type='accuse',actor=base['refs']['person:lina'],evidenceRefs='x')]
for command in malformed:assert base['step'](base['fresh'](),command)==base['bad']()
summary['malformedJsonCommandsRejected']=len(malformed)
(ROOT/'evidence/adversarial-checks.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'mutantsKilled':summary['killed'],'mutantsTotal':summary['total'],'abstractProgressStates':len(progress)}))
