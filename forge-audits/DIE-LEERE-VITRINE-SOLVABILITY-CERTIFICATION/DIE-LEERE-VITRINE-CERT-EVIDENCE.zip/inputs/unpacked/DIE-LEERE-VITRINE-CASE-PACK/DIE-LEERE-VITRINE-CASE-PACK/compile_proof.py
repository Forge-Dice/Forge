"""Draft-only data profile plus independent finite forward-closure checks."""
import json,hashlib,itertools,pathlib
ROOT=pathlib.Path(__file__).resolve().parent;P=ROOT/'case-pack';O=ROOT/'evidence'
load=lambda name:json.loads((P/name).read_text())
host=load('case-host.design.json');solution=load('solution.json')
observations=[dict(id='observed:hof-contact',kind='OBSERVED',literal=dict(kind='proposition',propositionId='proposition:p18',value=True),source=dict(kind='evidence',evidenceId='evidence:d03'))];nodes=[dict(id='observation:hof-contact',kind='observation',observationId='observed:hof-contact')];edges=[]
for person,pid,d in [('max','p03','d04'),('nora','p04','d04'),('oskar','p05','d05')]:
 oid='observed:'+person; nid='observation:'+person;cid='conclusion:actor-'+person
 observations.append(dict(id=oid,kind='OBSERVED',literal=dict(kind='proposition',propositionId='proposition:'+pid,value=True),source=dict(kind='evidence',evidenceId='evidence:'+d)))
 nodes.append(dict(id=nid,kind='observation',observationId=oid))
 nodes.append(dict(id='literal:'+person,kind='literal',literal=dict(kind='conclusion',conclusionId=cid,value=False)))
 license='license:'+person;edge='exclude:'+person
 observations.append(dict(id='public-rule:'+person,kind='PUBLIC_RULE',rules=[dict(edgeId=edge,allOf=[nid],yields=dict(kind='conclusion',conclusionId=cid,value=False))]))
 nodes.append(dict(id=license,kind='observation',observationId='public-rule:'+person))
 edges.append(dict(id=edge,allOf=[nid,license],to='literal:'+person,license=license))
nodes.append(dict(id='literal:lina',kind='literal',literal=dict(kind='conclusion',conclusionId='conclusion:actor-lina',value=True)))
body=['literal:max','literal:nora','literal:oskar']
observations.append(dict(id='public-rule:remaining',kind='PUBLIC_RULE',rules=[dict(edgeId='remaining:lina',allOf=body,yields=dict(kind='conclusion',conclusionId='conclusion:actor-lina',value=True))]))
nodes.append(dict(id='license:remaining',kind='observation',observationId='public-rule:remaining'))
edges.append(dict(id='remaining:lina',allOf=body+['license:remaining'],to='literal:lina',license='license:remaining'))
profile=dict(schemaVersion=1,bindings=dict(caseId=solution['caseId'],truthHash=host['truthHash'],solutionHash=host['solutionHash'],releaseHash='TO_BE_BOUND'),answerScope=[c['id'] for c in solution['conclusions']],ambiguityPolicy='must_disambiguate',question=dict(kind='required_literals'),observations=observations,nodes=nodes,edges=edges,witnessStepIds=['search-hof','ask-nora-photo','read-camera','ask-oskar-record','read-terminal'])
actions={'search-hof':dict(type='search',locationId='location:hof'),'ask-nora-photo':dict(type='ask',npcId='person:nora',questionId='question:q08'),'read-camera':dict(type='read_record',itemId='item:kamera'),'ask-oskar-record':dict(type='ask',npcId='person:oskar',questionId='question:q14'),'read-terminal':dict(type='read_record',itemId='item:terminal')}
portinputs=dict(questionCatalogue=load('questions.design.json'),interrogationProfiles={n:load('interrogation-'+n+'.design.json') for n in ['max','lina','nora','oskar']},npcSnapshots={n:load('npc-'+n+'.json') for n in ['max','lina','nora','oskar']},evidenceAccessMap=load('evidence-access.design.json'),hostPortSourceHash=hashlib.sha256((ROOT/'simulate.py').read_text().split('scenarios=[]')[0].encode()).hexdigest())
manifest=dict(profile='case-vitrine-release-manifest-v1',host=host,portInputs=portinputs,proofMeaning=dict(observations=observations,nodes=nodes,edges=edges),actionCatalogue=actions,licensePort='Finite R1/R2 instances released only when their public premises become available; no Solution lookup for eligibility. Generic law cards are visible initially; PRIVATE graph is never player JSON.')
releasehash=hashlib.sha256(('case-vitrine-release-manifest-v1\n'+json.dumps(manifest,sort_keys=True,ensure_ascii=False,separators=(',',':'))).encode()).hexdigest()
profile['bindings']['releaseHash']=releasehash
(P/'proof-profile.PRIVATE.design.json').write_text(json.dumps(profile,ensure_ascii=False,indent=2)+'\n')
(P/'release-manifest.PRIVATE.design.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
# Only literal nodes reached through actual replay roots count; manifest expectations never seed roots.
def close(found):
 seeds=set()
 if 'evidence:d04' in found:seeds|={'observation:max','observation:nora','license:max','license:nora'}
 if 'evidence:d05' in found:seeds|={'observation:oskar','license:oskar'}
 # license for the final instance is eligible after all three public alibi observations, not from Solution.
 if {'evidence:d04','evidence:d05'}<=set(found):seeds.add('license:remaining')
 reached=set(seeds)
 while True:
  expanded=reached|{e['to'] for e in edges if set(e['allOf'])<=reached}
  if expanded==reached:break
  reached=expanded
 literals={n['literal']['conclusionId']:n['literal']['value'] for n in nodes if n['kind']=='literal' and n['id'] in reached}
 required=all(literals.get(x['conclusionId']) is x['value'] for x in solution['requiredConclusions'])
 vectors=[v for v in itertools.product([False,True],repeat=4) if all(cid not in literals or literals[cid]==v[i] for i,cid in enumerate(profile['answerScope']))]
 return required and len(vectors)==1,literals,len(vectors)
checks=[]
for mask in range(256):
 f=['evidence:d'+str(i+1).zfill(2) for i in range(8) if mask&(1<<i)]
 ok,lits,count=close(f);assert ok==('evidence:d04' in f and 'evidence:d05' in f)
 checks.append(dict(mask=mask,pass_=ok,survivors=count))
report=dict(status='CASE-SPECIFIC PROPOSAL — draft-shaped fixture; no production profile parser exists on main',profileNodes=len(nodes),profileEdges=len(edges),releaseHash=releasehash,finiteChecks=len(checks),passing=sum(x['pass_'] for x in checks),commonWitnessSteps=len(profile['witnessStepIds']),withNoEvidence=close([]),withCameraOnly=close(['evidence:d04']),withTerminalOnly=close(['evidence:d05']),withBoth=close(['evidence:d04','evidence:d05']))
(O/'draft-proof-profile-check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False))
