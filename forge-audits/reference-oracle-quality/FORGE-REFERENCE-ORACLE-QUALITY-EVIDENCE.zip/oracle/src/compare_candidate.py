#!/usr/bin/env python3
"""Compare candidate to frozen, contract-derived layer expectations.

Adapter accepts: --case /abs/input.json --repo /abs/repo (when applicable).
Its exit 0 means the adapter completed, not that the tested rule accepted input.
stdout is {"normativeOutcome": value, "diagnostics": optional}.
No reference output is ever consulted. All candidate code runs only in an
external environment explicitly authorized by the operator; this is no sandbox.
"""
import argparse, base64, json, subprocess, tempfile
from pathlib import Path

def diff_semantics(rows):
    def identity(x):
        return None if x is None else (x['pathBytesBase64'],x['mode'],x['kind'],x['oid'])
    projected=[]
    for row in rows:
        p=base64.b64decode(row['pathBytesBase64'],validate=True)
        flags=row['types']
        if len(flags)!=len(set(flags)) or any(f not in ('ADD','DELETE','MODIFY','MODE_CHANGE') for f in flags):raise ValueError('invalid delta')
        projected.append((p,tuple(sorted(flags)),identity(row['old']),identity(row['new'])))
    if len(set(x[0] for x in projected))!=len(projected):raise ValueError('duplicate delta path')
    return sorted(projected)

def equal(case,actual):
    expected=case['normativeOutcome']
    if case['layer']=='diff':return diff_semantics(expected)==diff_semantics(actual)
    # Python bool == int must NOT weaken the protocol.
    return type(expected) is type(actual) and expected==actual

def main():
    p=argparse.ArgumentParser();p.add_argument('--corpus',type=Path,default=Path(__file__).resolve().parent.parent/'corpus/high-confidence.json');p.add_argument('adapter',nargs=argparse.REMAINDER);a=p.parse_args()
    if a.adapter and a.adapter[0]=='--':a.adapter=a.adapter[1:]
    if not a.adapter:p.error('provide an adapter argv after --')
    corpus=json.loads(a.corpus.read_text());rows=[]
    with tempfile.TemporaryDirectory() as td:
        for n,case in enumerate(corpus['cases']):
            f=Path(td)/f'{n:03d}.json'
            # Candidate sees input/entry point only; no expected or observed values.
            f.write_text(json.dumps({k:case[k] for k in ('id','layer','input')}))
            argv=[*a.adapter,'--case',str(f)]
            if case.get('repository'):argv+=['--repo',str((a.corpus.parent/case['repository']).resolve())]
            try:
                r=subprocess.run(argv,capture_output=True,timeout=30)
                if r.returncode!=0:raise ValueError('adapter exit')
                if len(r.stdout)>2**20:raise ValueError('oversized adapter output')
                got=json.loads(r.stdout)
                rows.append(dict(id=case['id'],equal=equal(case,got['normativeOutcome'])))
            except (ValueError,KeyError,TypeError,subprocess.TimeoutExpired) as e:rows.append(dict(id=case['id'],equal=False,adapterError=type(e).__name__))
    out=dict(cases=len(rows),mismatches=sum(not x['equal'] for x in rows),results=rows)
    print(json.dumps(out));return int(out['mismatches']>0)
if __name__=='__main__':raise SystemExit(main())
