"""Independent tiny oracle: no imports from reference, fixtures or its parser.

Sorted merge of tree sequences; prefix trie; relational inventory comparison;
explicit decision table for execution witnesses. Only stdlib, no test framework.
profile='lab' models the overlap; profile='v01' checks current draft semantics.
"""
import base64, collections, re, unicodedata
LEAF=object()

def path(e):
    return base64.b64decode(e['pathBytesBase64'], validate=True)

def canonical_diff(before, after):
    left=sorted(before,key=path);right=sorted(after,key=path)
    if any(path(a)==path(b) for seq in (left,right) for a,b in zip(seq,seq[1:])):
        raise ValueError('duplicate raw path')
    i=j=0;result=[]
    while i<len(left) or j<len(right):
        old=left[i] if i<len(left) else None;new=right[j] if j<len(right) else None
        if new is None or old is not None and path(old)<path(new):
            p=path(old);new=None;flags=['DELETE'];i+=1
        elif old is None or path(new)<path(old):
            p=path(new);old=None;flags=['ADD'];j+=1
        else:
            p=path(old);flags=[];i+=1;j+=1
            if (old['oid'],old['kind'])!=(new['oid'],new['kind']):flags+=['MODIFY']
            if old['mode']!=new['mode']:flags+=['MODE_CHANGE']
        if flags:result.append({'pathBytesBase64':base64.b64encode(p).decode(),
            'path':p.decode('utf-8','backslashreplace'),'types':flags,'old':old,'new':new})
    return result

def safe(rows,profile='lab'):
    root={};raw_seen=set()
    for e in rows:
        p=path(e)
        if p in raw_seen:return False
        raw_seen.add(p)
        try:s=p.decode('utf-8')
        except UnicodeDecodeError:return False
        if not s or len(p)>255 or '\\' in s or any(ord(c)<32 or ord(c)==127 for c in s):return False
        if e['kind']!='blob' or e['mode'] not in ('100644','100755'):return False
        node=root
        for segment in s.split('/'):
            if segment in ('','.','..') or segment.casefold()=='.git':return False
            if segment.endswith(('.',' ')) or ':' in segment:return False
            stem=segment.split('.')[0].casefold()
            if stem in {'con','prn','aux','nul'}|{x+str(n) for x in ('com','lpt') for n in range(1,10)}:return False
            if profile=='v01' and (not re.fullmatch(r'[A-Za-z0-9._-]+',segment) or segment.startswith('-')):return False
            key=unicodedata.normalize('NFC',segment).casefold()
            if LEAF in node:return False
            if key in node:
                spelling,child=node[key]
                if spelling!=segment:return False
            else:child={};node[key]=(segment,child)
            node=child
        if node:return False
        node[LEAF]=True
    return True

def blocked_path(p,profile):
    components=p.split('/');leaf=components[-1].lower()
    protected=any(p==r or p.startswith(r+'/') for r in
        ('forge/contracts','forge/approvals','.github','verifier','node_modules'))
    protected|=leaf in {'package.json','package-lock.json','.npmrc','.gitattributes','.gitmodules','codeowners'}
    protected|=any(leaf.startswith(x+'.') for x in ('tsconfig','vitest','vite','eslint')) or leaf.startswith('.env')
    if profile=='v01':
        protected|=any(p.startswith(r+'/') for r in ('src/forge','tests','tools/forge_v01','forge/verifier'))
    return protected

def scope_ok(changes,metadata,policy,profile='lab'):
    allowed={(p,'ADD') for p in metadata['scope']['create']}|{(p,'MODIFY') for p in metadata['scope']['modify']}
    for row in changes:
        p=row['path'];types=row['types']
        if blocked_path(p,profile) or p in policy.get('frozenTests',[]):return False
        if profile=='lab' and p.startswith('forge/coordination/') and types in (['ADD'],['MODIFY']):continue
        if len(types)!=1 or (p,types[0]) not in allowed:return False
        if profile=='v01' and row['new']['mode']!='100644':return False
    return True

def inventory_ok(base,head):
    def relation(inv):
        if not isinstance(inv,dict) or inv.get('completed') is not True or inv.get('errors') or not inv.get('cases'):return None
        records=[]
        for c in inv['cases']:
            if not isinstance(c['ancestors'],list) or not all(isinstance(x,str) for x in [c['file'],c['project'],c['title'],*c['ancestors']]):return None
            if type(c['occurrence'])!=int or c['occurrence']<1 or c['status'] not in ('passed','failed','skipped','todo','pending'):return None
            records.append(((c['file'],c['project'],tuple(c['ancestors']),c['title']),c['occurrence'],c['status']))
        names=collections.defaultdict(list)
        for name,occ,status in records:names[name].append(occ)
        if any(v!=list(range(1,len(v)+1)) for v in names.values()):return None
        return {(name,occ):status for name,occ,status in records}
    a,b=relation(base),relation(head)
    return a is not None and b is not None and all(s=='passed' for s in [*a.values(),*b.values()]) and set(a)<=set(b) and set(base.get('files',[]))<=set(head.get('files',[]))

def classify(w):
    # Current draft semantics, not the weaker reference 'expected title' rule.
    if w['anchorCount']!=1 or not w.get('distinct',True):return 'NOT_APPLIED'
    if w.get('unmutatedExit')!=0 or w.get('timeout') or w.get('signal') or w.get('typecheckExit',0)!=0:return 'INFRA_FAILURE'
    inv=w.get('inventory',{})
    if not inv.get('completed') or inv.get('errors') or set(inv.get('files',[]))!=set(w['testFiles']) or not inv.get('cases'):return 'INFRA_FAILURE'
    def identity(c):return (c['file'],c['project'],tuple(c['ancestors']),c['title'],c['occurrence'])
    cases=inv['cases'];named={identity(c) for c in w['namedIdentities']};failed=[c for c in cases if c['status']=='failed']
    if not named<={identity(c) for c in cases} or not named<={identity(c) for c in w['baselineIdentities']}:return 'INFRA_FAILURE'
    if any(c['status'] not in ('passed','failed') for c in cases):return 'INFRA_FAILURE'
    if w['runExit']==0 and not failed:return 'SURVIVED'
    if w['runExit']==1 and failed and all(identity(c) in named and c.get('errors') and all(e['name']=='AssertionError' for e in c['errors']) for c in failed):return 'KILLED'
    return 'INFRA_FAILURE'
