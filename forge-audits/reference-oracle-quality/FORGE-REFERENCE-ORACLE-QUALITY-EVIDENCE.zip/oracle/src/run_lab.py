#!/usr/bin/env python3
import base64, collections, copy, hashlib, importlib.util, itertools, json, os, random, shutil, subprocess, sys, tempfile, time
from pathlib import Path
HERE=Path(__file__).resolve().parent;OUT=HERE.parent/'results';CORP=HERE.parent/'corpus'
ROOT=HERE.parent.parent/'reference';sys.path.insert(0,str(ROOT/'reference'))
import forge_ref as ref
import supervisor as sup
import tiny_model as tiny
OUT.mkdir(exist_ok=True);CORP.mkdir(exist_ok=True)

def write(name,data):
    (OUT/name).write_text(json.dumps(data,ensure_ascii=True,indent=2)+'\n')
def entry(p,mode='100644',oid='1'*40,kind='blob'):
    return dict(pathBytesBase64=base64.b64encode(p).decode(),path=p.decode('utf-8','backslashreplace'),mode=mode,oid=oid,kind=kind)
original=json.loads((ROOT/'results/differential/cases.json').read_text())['cases']
valid=next(c for c in original if c['id']=='060-legitimate')['input']
def fixture():return copy.deepcopy(valid)
def metadata(f):return json.loads(f['contract'][8:f['contract'].find('\n---\n')])
def inv():return copy.deepcopy(valid['verify']['baseline'])
def refresh(f):
    # The generator owns exact document bytes. Do NOT call reference parse/canonical/hash.
    f['policy']['contractHash']=hashlib.sha256(('forge-contract-v1\n'+f['contract']).encode()).hexdigest()
    p=f['policy'];binding=dict(repoId=p['repoId'],pr=f['metadata']['pr'],base=f['base'],head=f['head'],contractHash=p['contractHash'],verifierSha=p['verifierSha'],policyHash=hashlib.sha256(json.dumps(p,ensure_ascii=True,sort_keys=True,separators=(',',':')).encode()).hexdigest(),aiReportHash=p['aiReportHash'])
    f['verify']['attestation']['binding']=binding
def modify_contract(f,fn):
    m=metadata(f);fn(m);f['contract']='---json\n'+json.dumps(m,ensure_ascii=False,indent=2)+'\n---\n# Independent lab fixture\n';refresh(f)
checks=collections.Counter();failures=[];second=[];goldens=[]
def check(name,ok,detail=None):
    checks[name]+=1
    if not ok:failures.append(dict(property=name,iteration=checks[name],detail=detail))
def differential(name,a,b):
    second.append(dict(id=name,equal=a==b,reference=a,second=b,expectationProvenance='REFERENCE-DERIVED',useAsIndependentOracle=False,note='model agreement only; normative goldens separate'))

def provenance():
    rows=[]
    for c in original:
        db=ref.GitDB(ROOT/c['repository']);parents=db.readCommit(c['input']['head'])['parents']
        for action in ('gate','verify'):
            rows.append(dict(id=c['id'],action=action,outcomeProvenance='HAND-AUTHORED',
                generator='reference/lab.py:corpus -> assert_case',
                expected=c['expected'][action],diagnosticProvenance='HAND-AUTHORED LAB PRIORITY',
                changesProvenance='HAND-AUTHORED ALGORITHM',
                referenceDerivedInputs=['baseTree','headTree','ancestor check','policy.contractHash','policy attestation helpers'],
                independentOracle=False,classification='EXPLORATORY_FULL_FUNNEL',
                reasons=['lab profile differs from current draft','synthetic execution witness','shared fixture construction'],
                headParentCount=len(parents)))
    write('expectation-provenance.json',rows)
    (CORP/'exploratory-original.json').write_text(json.dumps({'cases':original,'provenance':rows},indent=2))
    # Compare independently structured mini-model on 4 overlapping core APIs.
    for c in original:
        f=c['input'];a,b=f['baseTree'],f['headTree'];m=metadata(f) if c['id'].split('-',1)[1]!='bad-contract' else None
        differential(c['id']+':diff',ref.diff(a,b),tiny.canonical_diff(a,b))
        differential(c['id']+':path',not ref.path_safety(a+b) if False else not ref.path_safety(b),tiny.safe(b))
        if m:differential(c['id']+':scope',not ref.scope_errors(ref.diff(a,b),m,f['policy']),tiny.scope_ok(tiny.canonical_diff(a,b),m,f['policy']))
        differential(c['id']+':inventory',ref.inventory_compare(f['verify']['baseline'],f['verify']['head'])['outcome']=='PASS',tiny.inventory_ok(f['verify']['baseline'],f['verify']['head']))

def golden(name,layer,args,expected,basis):
    # Only literal contract/property conclusions, not outputs computed by either model.
    case=dict(id=name,layer=layer,input=args,normativeOutcome=expected,expectationProvenance='CONTRACT-DERIVED',basis=basis,optionalDiagnostic=True)
    goldens.append(case)
    if layer=='path':
        a=not ref.path_safety(args['rows']);b=tiny.safe(args['rows'],'v01')
    elif layer=='scope':
        a=not ref.scope_errors(args['changes'],args['metadata'],args['policy']);b=tiny.scope_ok(args['changes'],args['metadata'],args['policy'],'v01')
    elif layer=='inventory':
        a=ref.inventory_compare(args['base'],args['head'])['outcome']=='PASS';b=tiny.inventory_ok(args['base'],args['head'])
    elif layer=='diff':
        a=ref.diff(args['base'],args['head']);b=tiny.canonical_diff(args['base'],args['head'])
    else:return
    case['observedReference']=a;case['observedSecond']=b

def golden_core():
    for p in [b'src/a.ts',b'src/-a.ts',b'src/a b.ts',b'src/a@b.ts','src/é.ts'.encode(),b'src/.git/a',b'AUX.txt',b'a..ts',b'a./x',b'../x',b'src/a.ts/../b.ts',b'a\\b',b'a:b',b'a\x7f',b'a\xff']:
        expected=p in [b'src/a.ts',b'a..ts']
        golden('path-'+base64.b64encode(p).decode(),'path',dict(rows=[entry(p)]),expected,'Implementation package §3 ASCII portable path grammar')
    for mode in ['100644','100755','120000','160000','100600']:
        golden('mode-'+mode,'path',dict(rows=[entry(b'a.ts',mode,kind='commit' if mode=='160000' else 'blob')]),mode in ['100644','100755'],'§3 allowed snapshot modes; unchanged executable BASE permitted')
    for a,b in [(b'A/x',b'a/y'),(b'a',b'a/b'),(b'A',b'a/b'),(b'x',b'x')]:
        golden('collision-'+str((a,b)),'path',dict(rows=[entry(a),entry(b)]),False,'§3 raw duplicate/case/prefix invariants')
    m=metadata(valid);policy=valid['policy']
    for p,typ,ok in [(b'src/clamp.ts','MODIFY',True),(b'src/clamp.ts','DELETE',False),(b'src/clamp.ts','MODE_CHANGE',False),(b'src/other.ts','MODIFY',False),(b'forge/coordination/CODEX.md','ADD',False),(b'vitest.config.mjs','ADD',False)]:
        old=entry(p);new=entry(p,oid='2'*40)
        c=dict(path=p.decode(),pathBytesBase64=base64.b64encode(p).decode(),types=[typ],old=None if typ=='ADD' else old,new=None if typ=='DELETE' else new)
        golden('scope-'+p.decode()+typ,'scope',dict(changes=[c],metadata=m,policy=policy),ok,'§4 exact scope, delete/mode prohibition; no coordination exception')
    for label in ['valid','delete','skip','todo','failed','replacement','module','partial','unknown','duplicate']:
        a=inv();b=copy.deepcopy(a)
        if label=='delete':b['cases'].pop()
        elif label in ['skip','todo','failed','unknown']:b['cases'][0]['status']={'skip':'skipped','unknown':'mystery'}.get(label,label)
        elif label=='replacement':b['cases'].pop();b['cases'][0]['title']='replacement'
        elif label=='module':b['files']=[]
        elif label=='partial':b['completed']=False
        elif label=='duplicate':b['cases'].append(copy.deepcopy(b['cases'][0]))
        golden('inventory-'+label,'inventory',dict(base=a,head=b),label=='valid','§7 baseline identities/modules must survive and pass; lab-wire 1-based occurrence adapter')
    a=[entry(b'a',oid='1'*40),entry(b'b',oid='2'*40)];b=[entry(b'a','100755',oid='3'*40),entry(b'c',oid='2'*40)]
    expected=[dict(pathBytesBase64='YQ==',path='a',types=['MODIFY','MODE_CHANGE'],old=a[0],new=b[0]),dict(pathBytesBase64='Yg==',path='b',types=['DELETE'],old=a[1],new=None),dict(pathBytesBase64='Yw==',path='c',types=['ADD'],old=None,new=b[1])]
    golden('diff-delete-add-and-content-mode','diff',dict(base=a,head=b),expected,'§3 canonical byte-identity diff; no rename inference')

def metamorphic():
    rng=random.Random(4072026)
    for i in range(500):
        a=[entry(f'src/f{j}.ts'.encode(),oid=f'{rng.getrandbits(160):040x}') for j in range(rng.randint(2,20))]
        b=copy.deepcopy(a);b[0]['oid']=f'{rng.getrandbits(160):040x}';d=ref.diff(a,b)
        shuffled=copy.deepcopy(b);rng.shuffle(shuffled)
        check('M01 tree enumeration permutation',d==ref.diff(list(reversed(a)),shuffled))
        extra=entry(f'src/unchanged{i}.ts'.encode());check('M02 unchanged leaf insertion',d==ref.diff(a+[extra],b+[extra]))
        check('M03 identical trees are empty',ref.diff(a,a)==[])
        reverse=ref.diff(b,a);check('M04 diff inversion',all(x['old']==y['new'] and x['new']==y['old'] for x,y in zip(d,reverse)))
        rename=copy.deepcopy(a);rename[0]=entry(f'src/z{i}.ts'.encode(),oid=a[0]['oid'])
        check('M05 rename equals delete plus add',ref.diff(a,rename)==tiny.canonical_diff(a,rename))
        modes=copy.deepcopy(a);modes[0]['mode']='100755';modes[0]['oid']='e'*40
        check('M06 mode plus content both preserved',ref.diff(a,modes)[0]['types']==['MODIFY','MODE_CHANGE'])
        decorated=ref.diff(a,[dict(e,path='spoof') for e in b])
        check('M07 diagnostic label cannot change raw delta',[(x['pathBytesBase64'],x['types'],x['old']['oid'],x['new']['oid']) for x in decorated]==[(x['pathBytesBase64'],x['types'],x['old']['oid'],x['new']['oid']) for x in d])
        check('M08 display cannot change scope identity',[x['path'] for x in ref.diff(a,[dict(e,path='spoof') for e in b])]==[x['path'] for x in d])
        f=fixture();g=ref.gate(f);f['headTree'].append(entry(f'outside{i}'.encode()))
        check('M09 out-of-scope addition cannot improve',g['outcome']=='PASS' and ref.gate(f)['outcome']=='FAIL')
        f=fixture();del f['headTree'][1];check('M10 deleting frozen test cannot improve',ref.gate(f)['outcome']=='FAIL')
        a_inv=inv();b_inv=copy.deepcopy(a_inv);b_inv['cases'].pop(rng.randrange(3))
        check('M11 baseline identity deletion cannot improve',ref.inventory_compare(a_inv,b_inv)['outcome']=='FAIL')
        new=copy.deepcopy(a_inv['cases'][0]);new['title']=str(i);b_inv['cases'].append(new)
        check('M12 extra test cannot compensate loss',ref.inventory_compare(a_inv,b_inv)['outcome']=='FAIL')
        a_inv=inv();b_inv=copy.deepcopy(a_inv);rng.shuffle(b_inv['cases']);check('M13 unique inventory permutation',ref.inventory_compare(a_inv,b_inv)['outcome']=='PASS')
        b_inv['cases'][0]['status']=rng.choice(['skipped','todo','failed']);check('M14 status degradation cannot improve',ref.inventory_compare(a_inv,b_inv)['outcome']=='FAIL')
        b_inv=inv();b_inv['cases'].append(copy.deepcopy(b_inv['cases'][0]));check('M15 duplicate identity never repairs',ref.inventory_compare(a_inv,b_inv)['outcome']=='FAIL')
        f=fixture();f['metadata']['currentHead']='d'*40;before=ref.gate(f);f['metadata']['unrelated']=rng.randrange(100000)
        check('M16 unrelated metadata cannot refresh head',before['outcome']=='FAIL' and ref.gate(f)['outcome']=='FAIL')
        f=fixture();f['verify']['attestation']['commitId']='d'*40;f['verify']['attestation']['extra']=str(i);check('M17 unrelated review metadata cannot refresh attestation',ref.verify(f)['outcome']=='FAIL')
        f=fixture();f['verify']['mutants'][0]['classification']='SURVIVED';before=ref.verify(f);f['verify']['checks'].append(dict(name='extra',command='data',exit=0))
        check('M18 surviving mutant cannot be rescued',before['outcome']=='FAIL' and ref.verify(f)['outcome']=='FAIL')
        paths=[entry(f'A{i}/x'.encode()),entry(f'a{i}/y'.encode())];rng.shuffle(paths);check('M19 case collision permutation',bool(ref.path_safety(paths)))
        paths=[entry(f'src/a{i}'.encode())];check('M20 unsafe mode degradation',not ref.path_safety(paths) and bool(ref.path_safety([dict(paths[0],mode='120000')])))
        f=fixture();f['headTree'].append(entry(f'vitest.config.{i}.mjs'.encode()));check('M21 protected config cannot be allowlisted',bool(ref.scope_errors(ref.diff(f['baseTree'],f['headTree']),dict(scope=dict(create=[f'vitest.config.{i}.mjs'],modify=['src/clamp.ts'])),f['policy'])))
        f=fixture();old=ref.gate(f);rng.shuffle(f['headTree']);rng.shuffle(f['baseTree']);check('M22 gate verdict tree permutation',ref.gate(f)['outcome']==old['outcome'])
        differential(f'generated-{i}:diff',d,tiny.canonical_diff(a,b))
        differential(f'generated-{i}:paths',not ref.path_safety(b),tiny.safe(b))
        differential(f'generated-{i}:inventory',ref.inventory_compare(a_inv,b_inv)['outcome']=='PASS',tiny.inventory_ok(a_inv,b_inv))
    write('metamorphic.json',dict(seed=4072026,counts=dict(checks),checks=sum(checks.values()),failures=failures))

def git_properties():
    source=ROOT/'repos/060.git';case=next(c for c in original if c['id']=='060-legitimate');f=case['input']
    records=[]
    with tempfile.TemporaryDirectory() as td:
        repo=Path(td)/'db.git';shutil.copytree(source,repo);db=ref.GitDB(repo)
        before=ref.diff(db.collectTree(f['base']),db.collectTree(f['head']))
        for i in range(50):
            junk=db.git('hash-object','-w','--stdin',data=f'garbage-{i}'.encode()).decode().strip()
            after=ref.diff(db.collectTree(f['base']),db.collectTree(f['head']))
            check('M23 unreachable ODB garbage invariant',before==after)
            old=f['headTree'][0]['oid'];db.git('update-ref','refs/replace/'+old,junk)
            after=ref.diff(db.collectTree(f['base']),db.collectTree(f['head']))
            check('M24 disabled replacement preserves raw diff',before==after)
            try:db.audit();audit=False
            except ref.RefError as e:audit=e.code=='REPO_UNSAFE'
            records.append(dict(iteration=i,diffUnchanged=before==after,fullGateLayoutRejects=audit))
            db.git('update-ref','-d','refs/replace/'+old)
    write('git-metamorphic.json',records)
    write('metamorphic.json',dict(seed=4072026,counts=dict(checks),checks=sum(checks.values()),failures=failures))

def run_record(classification='kill'):
    cases=copy.deepcopy(inv()['cases'])
    for c in cases:c['ancestors']=[];c['errors']=[]
    if classification=='kill':cases[0]['status']='failed';cases[0]['errors']=[dict(name='AssertionError')]
    return dict(exit=1 if classification=='kill' else 0,timeout=False,inventory=dict(completed=True,errors=[],files=['tests/clamp.test.ts'],cases=cases))
def run_supervisor(module,run,source=b'abc',anchor='b'):
    calls=[]
    def stub(*args,**kw):
        calls.append(1);return run_record('survived') if len(calls)==1 else copy.deepcopy(run)
    old=module.run_inventory;module.run_inventory=stub
    try:
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'src';p.mkdir();(p/'clamp.ts').write_bytes(source)
            result=module.mutation(td,'unused',dict(id='m',file='src/clamp.ts',anchor=anchor,replacement='d',testFiles=['tests/clamp.test.ts'],expectedFailureTitle='negative',timeout=1),Path(td)/'out.json')
            assert (p/'clamp.ts').read_bytes()==source
            return result['classification']
    finally:module.run_inventory=old

def mutation_witnesses():
    records=[]
    for label in ['kill','survived','timeout','compiler','exit2','signal','wrong-failed-title','mixed-error','missing-named','partial','skip','wrong-identity-same-title','overlapping-anchor']:
        run=run_record('survived' if label=='survived' else 'kill')
        if label=='timeout':run['timeout']=True
        elif label=='compiler':run['inventory']['errors']=[dict(name='CompilerError')]
        elif label=='exit2':run['exit']=2
        elif label=='signal':run['exit']=-9
        elif label=='wrong-failed-title':run['inventory']['cases'][1]['status']='failed';run['inventory']['cases'][1]['errors']=[dict(name='Error')]
        elif label=='mixed-error':run['inventory']['cases'][0]['errors'].append(dict(name='TypeError'))
        elif label=='missing-named':run['inventory']['cases'][0]['title']='other'
        elif label=='partial':run['inventory']['completed']=False
        elif label=='skip':run['inventory']['cases'][1]['status']='skipped'
        elif label=='wrong-identity-same-title':run['inventory']['cases'][0]['ancestors']=['another suite']
        baseline=run_record('survived')['inventory']['cases']
        w=dict(anchorCount=2 if label=='overlapping-anchor' else 1,distinct=True,unmutatedExit=0,runExit=run['exit'],timeout=run['timeout'],testFiles=['tests/clamp.test.ts'],namedIdentities=[baseline[0]],baselineIdentities=baseline,inventory=run['inventory'])
        expected='KILLED' if label=='kill' else 'SURVIVED' if label=='survived' else 'NOT_APPLIED' if label=='overlapping-anchor' else 'INFRA_FAILURE'
        a=run_supervisor(sup,run,source=b'ababa',anchor='aba') if label=='overlapping-anchor' else run_supervisor(sup,run)
        b=tiny.classify(w)
        records.append(dict(id=label,input=w,run=run,normativeOutcome=expected,reference=a,second=b,referenceConforms=a==expected,secondConforms=b==expected,expectationProvenance='CONTRACT-DERIVED',basis='Implementation package §8 exact exit 1; no infrastructure or unnamed failure'))
        goldens.append(dict(id='mutation-'+label,layer='mutation',input=w,normativeOutcome=expected,expectationProvenance='CONTRACT-DERIVED',basis='§8 mutation classification',observedReference=a,observedSecond=b))
    write('mutation-classification.json',records);return records

def mutated(source,anchor,replacement,name):
    assert source.count(anchor)==1,(name,source.count(anchor))
    m=type(ref)(name);m.__file__=str(ROOT/'reference'/('supervisor.py' if 'timeout' in name else 'forge_ref.py'))
    code=source.replace(anchor,replacement);exec(compile(code,m.__file__,'exec'),m.__dict__)
    return m,dict(beforeHash=hashlib.sha256(source.encode()).hexdigest(),afterHash=hashlib.sha256(code.encode()).hexdigest(),anchor=anchor,replacement=replacement)

def mutation_reference(records):
    src=(ROOT/'reference/forge_ref.py').read_text();super_src=(ROOT/'reference/supervisor.py').read_text();result=[]
    def test(name,anchor,replacement,observe,expected,source=src):
        m,evidence=mutated(source,anchor,replacement,name);actual=observe(m)
        result.append(dict(id=name,expected=expected,observedMutant=actual,killed=actual!=expected,**evidence))
    symlink=[entry(b'src/link','120000')]
    test('allow-symlink',"e['mode'] not in ('100644','100755')","e['mode'] not in ('100644','100755','120000')",lambda m:not m.path_safety(symlink),False)
    a=[entry(b'src/clamp.ts')];b=[entry(b'src/new.ts')]
    test('trust-rename',"if flags:out.append({'pathBytesBase64'", "if flags and not (flags==['DELETE'] and any(x['oid']==old['oid'] for x in bb.values())):out.append({'pathBytesBase64'",lambda m:[x['types'] for x in m.diff(a,b)],[['DELETE'],['ADD']])
    a_inv=inv();b_inv=copy.deepcopy(a_inv);b_inv['cases'].pop()
    test('ignore-deleted-test',"if k not in bb:errors.append(('BASELINE_TEST_LOST',canonical(k)))","if k not in bb:continue",lambda m:m.inventory_compare(a_inv,b_inv)['outcome'],'FAIL')
    timeout=next(r['run'] for r in records if r['id']=='timeout')
    test('timeout-as-killed',"if run['timeout'] or not inv['completed']", "if run['timeout']:return result|{'classification':'KILLED'}\n        if not inv['completed']",lambda m:run_supervisor(m,timeout),'INFRA_FAILURE',super_src)
    f=fixture();f['metadata']['currentHead']='d'*40
    test('ignore-stale-head',"if meta.get('currentHead')!=head:","if False:",lambda m:m.gate(f)['outcome'],'FAIL')
    row=dict(path='src/CLAMP.ts',pathBytesBase64=base64.b64encode(b'src/CLAMP.ts').decode(),types=['MODIFY'],old=entry(b'src/CLAMP.ts'),new=entry(b'src/CLAMP.ts',oid='2'*40))
    test('incorrect-path-normalization',"p=c['path']\n        if protected(p)","p=c['path'].lower()\n        if protected(p)",lambda m:not m.scope_errors([row],metadata(valid),valid['policy']),False)
    # Broad config policy relaxation, not an equivalent mutant shielded by scope.
    row=dict(path='vitest.config.mjs',types=['ADD']);meta=dict(scope=dict(create=['vitest.config.mjs'],modify=[]))
    test('ignore-config-change',"return name in ('package.json','package-lock.json','.npmrc','.gitattributes','.gitmodules','codeowners') or bool(re.match(r'(tsconfig|vitest|vite|eslint)\\.',name)) or name.startswith('.env')","return name in ('package.json','package-lock.json','.npmrc','.gitattributes','.gitmodules','codeowners') or name.startswith('.env')",lambda m:not m.scope_errors([row],meta,{}),False)
    # There is no existing single-parent guard to remove. Mutate the only history
    # primitive to make the already-permitted second-parent behavior explicit.
    case=original[0];db=ref.GitDB(ROOT/case['repository']);h=case['input']['head'];base=case['input']['base'];parents=db.readCommit(h)['parents']
    assert len(parents)==2
    test('permit-second-parent',"pending.extend(self.readCommit(oid)['parents'])","parents=self.readCommit(oid)['parents']\n            if base in parents:return True\n            pending.extend(parents)",lambda m:m.gate(case['input'],m.GitDB(ROOT/case['repository']))['outcome'],'FAIL')
    result[-1]['baselineAlreadyViolatesNormative']=ref.gate(case['input'],db)['outcome']=='PASS'
    result[-1]['killed']=False;result[-1]['status']='PREEXISTING_DEFECT_EQUIVALENT_ON_WITNESS'
    # Original corpus kill detection independent of its exact codes.
    for r in result:
        if r['id'] in ['timeout-as-killed','permit-second-parent']:
            r['originalCorpusOutcomeKills']=0;continue
        m,_=mutated(src,r['anchor'],r['replacement'],r['id']+'-corpus');kills=[]
        for c in original:
            f=c['input'];g=m.gate(f);v=m.verify(f,g)
            if any(x['outcome']!=c['expected'][a]['outcome'] for a,x in [('gate',g),('verify',v)]):kills.append(c['id'])
        r['originalCorpusOutcomeKills']=len(kills);r['originalKillingCases']=kills
    write('reference-mutations.json',result)

def history_probes():
    cases=[]
    def git(repo,*args,data=None):
        p=subprocess.run(['git','--no-replace-objects','--git-dir='+str(repo),*args],input=data,capture_output=True,env=ref.clean_env());assert p.returncode==0,p.stderr;return p.stdout.strip().decode()
    with tempfile.TemporaryDirectory() as td:
        repo=Path(td)/'db.git';shutil.copytree(ROOT/'repos/060.git',repo);db=ref.GitDB(repo);f=fixture();base=f['base'];normal_head=f['head'];tree=db.readCommit(normal_head)['tree']
        def commit(tree,parents):
            raw=('tree '+tree+'\n'+''.join('parent '+x+'\n' for x in parents)+'author X <x@invalid> 1 +0000\ncommitter X <x@invalid> 1 +0000\n\nprobe\n').encode()
            return git(repo,'hash-object','-w','-t','commit','--stdin',data=raw)
        # independent raw tree augmentation uses mktree with existing regular entries
        bt=db.collectTree(base);root=db.readCommit(base)['tree'];root_bytes=db.obj(root,'tree')
        blob=git(repo,'hash-object','-w','--stdin',data=b'protected')
        evil_tree=git(repo,'hash-object','--literally','-w','-t','tree','--stdin',data=root_bytes+b'100644 vitest.config.mjs\0'+bytes.fromhex(blob))
        evil=commit(evil_tree,[base]);reverted=commit(tree,[evil]);merge=commit(tree,[normal_head,base]);empty=commit(root,[base])
        chain=base
        for i in range(129):chain=commit(tree,[chain])
        for name,h,expected,basis in [('second-parent',merge,'FAIL','§3 single parent above BASE'),('reverted-config',reverted,'FAIL','§4 every intermediate snapshot'),('empty-diff',empty,'FAIL','§3 nonempty net diff'),('base-equals-head',base,'FAIL','§3 new nonempty history'),('129-commits',chain,'FAIL','§3 max 128 commits'),('linear',commit(tree,[base]),'PASS','§3 new linear change')]:
            x=copy.deepcopy(f);x['head']=h;x['metadata']['currentHead']=h;refresh(x);x['verify']['attestation']['commitId']=h
            got=ref.gate(x,db)
            cases.append(dict(id=name,expected=expected,reference=got['outcome'],code=got['code'],basis=basis,head=h))
        # Persist local git bytes as reusable static regression fixtures.
        dest=CORP/'history-probes.git'
        for c in cases:
            x=copy.deepcopy(f);x['head']=c['head'];x['metadata']['currentHead']=c['head'];refresh(x);x['verify']['attestation']['commitId']=c['head']
            goldens.append(dict(id='history-'+c['id'],layer='history-and-intermediate-scope',repository='history-probes.git',input=dict(base=base,head=c['head'],metadata=metadata(x),policy=x['policy']),normativeOutcome=c['expected'],expectationProvenance='CONTRACT-DERIVED',basis=c['basis'],observedReference=c['reference']))
        # BASE itself can contain a historical merge; do not reject it by checking
        # every ancestor indefinitely. Positive witness guards against reject-all.
        merged_base=commit(root,[base,normal_head]);one=commit(tree,[merged_base])
        goldens.append(dict(id='history-historical-base-merge',layer='history-and-intermediate-scope',repository='history-probes.git',input=dict(base=merged_base,head=one,metadata=metadata(f),policy=f['policy']),normativeOutcome='PASS',expectationProvenance='CONTRACT-DERIVED',basis='§3 BASE may have multiple parents; stop exactly at BASE',observedReference='PASS' if db.ancestor(merged_base,one) else 'FAIL'))
        if dest.exists():shutil.rmtree(dest)
        shutil.copytree(repo,dest)
    write('history-probes.json',cases)

def pairwise():
    # Tag original cases by independent input facts, not scenario names.
    coverage=[];tested=[]
    originals=[]
    for c in original:
        f=c['input'];db=ref.GitDB(ROOT/c['repository']);parents=db.readCommit(f['head'])['parents']
        badpath=not tiny.safe([dict(x,mode='100644',kind='blob') for x in f['headTree']]);mode=any(x['mode'] not in ('100644','100755') for x in f['headTree'])
        config=any(tiny.blocked_path(x['path'],'lab') for x in tiny.canonical_diff(f['baseTree'],f['headTree']))
        test=not tiny.inventory_ok(f['verify']['baseline'],f['verify']['head'])
        policy=f['policy'];at=f['verify'].get('attestation',{})
        binding=dict(repoId=policy['repoId'],pr=f['metadata']['pr'],base=f['base'],head=f['head'],contractHash=policy['contractHash'],verifierSha=policy['verifierSha'],policyHash=hashlib.sha256(json.dumps(policy,ensure_ascii=True,sort_keys=True,separators=(',',':')).encode()).hexdigest(),aiReportHash=policy['aiReportHash'])
        review_ok=at.get('binding')==binding and at.get('userId')==policy['ownerId'] and at.get('commitId')==f['head'] and at.get('revoked') is False and at.get('state')=='COMMENTED' and at.get('result')=='PASS'
        originals.append(dict(id=c['id'],history='root' if not parents else 'merge' if len(parents)>1 else 'linear',path='unsafe' if badpath else 'safe',mode='unsafe' if mode else 'regular',test='bad' if test else 'good',config='changed' if config else 'clean',head='stale' if f['metadata']['currentHead']!=f['head'] else 'fresh',review='good' if review_ok else 'bad'))
    axes=[('history','path',['linear','merge','root'],['safe','unsafe']),('path','mode',['safe','unsafe'],['regular','unsafe']),('test','config',['good','bad'],['clean','changed']),('review','head',['good','bad'],['fresh','stale'])]
    for x,y,xs,ys in axes:
        for xv,yv in itertools.product(xs,ys):
            hits=[c['id'] for c in originals if c[x]==xv and c[y]==yv]
            coverage.append(dict(axis=x+' × '+y,left=xv,right=yv,existingCases=hits,missing=not hits))
    with tempfile.TemporaryDirectory() as td:
        repo=Path(td)/'db.git';shutil.copytree(ROOT/'repos/060.git',repo);db=ref.GitDB(repo);base=valid['base'];tree=db.readCommit(valid['head'])['tree']
        def object(kind,data):return db.git('hash-object','--literally','-w','-t',kind,'--stdin',data=data).decode().strip()
        blob=object('blob',b'x');child=object('tree',b'100644 escape\0'+bytes.fromhex(blob));bad_tree=object('tree',b'40000 ..\0'+bytes.fromhex(child)+db.obj(tree,'tree'))
        for h,p in itertools.product(['linear','merge','root'],['safe','unsafe']):
            parents=[base] if h=='linear' else [valid['head'],base] if h=='merge' else []
            raw=('tree '+(tree if p=='safe' else bad_tree)+'\n'+''.join('parent '+x+'\n' for x in parents)+'author X <x@invalid> 1 +0000\ncommitter X <x@invalid> 1 +0000\n\npairwise\n').encode();head=object('commit',raw)
            f=fixture();f['head']=head;f['metadata']['currentHead']=head;refresh(f);f['verify']['attestation']['commitId']=head
            got=ref.gate(f,db)['outcome'];tested.append(dict(axis='history × path',left=h,right=p,mode='actual raw Git commits/trees',expected='PASS' if h=='linear' and p=='safe' else 'FAIL',reference=got,head=head,base=base))
        dest=CORP/'pairwise-history.git'
        if dest.exists():shutil.rmtree(dest)
        shutil.copytree(repo,dest)
    for p,m in itertools.product(['safe','unsafe'],['regular','unsafe']):
        rows=[entry(b'valid.ts' if p=='safe' else b'../escape','100644' if m=='regular' else '120000')]
        ok=not ref.path_safety(rows);tested.append(dict(axis='path × mode',left=p,right=m,expected=p=='safe' and m=='regular',reference=ok))
    for t,c in itertools.product(['good','bad'],['clean','changed']):
        f=fixture()
        if t=='bad':f['verify']['head']['cases'].pop()
        if c=='changed':f['headTree'].append(entry(b'vitest.config.mjs'))
        tested.append(dict(axis='test × config',left=t,right=c,expected='PASS' if t=='good' and c=='clean' else 'FAIL',reference=ref.verify(f)['outcome']))
    for r,h in itertools.product(['good','bad'],['fresh','stale']):
        f=fixture()
        if r=='bad':f['verify']['attestation']['commitId']='d'*40
        if h=='stale':f['metadata']['currentHead']='d'*40
        tested.append(dict(axis='review × head',left=r,right=h,expected='PASS' if r=='good' and h=='fresh' else 'FAIL',reference=ref.verify(f)['outcome']))
    for applied,exec_out in itertools.product(['unique','missing','duplicate'],['kill','survived','timeout','compiler','signal']):
        run=run_record('survived' if exec_out=='survived' else 'kill')
        if exec_out=='timeout':run['timeout']=True
        if exec_out=='compiler':run['inventory']['errors']=[dict(name='CompilerError')]
        if exec_out=='signal':run['exit']=-9
        baseline=run_record('survived')['inventory']['cases']
        w=dict(anchorCount={'unique':1,'missing':0,'duplicate':2}[applied],distinct=True,unmutatedExit=0,runExit=run['exit'],timeout=run['timeout'],testFiles=['tests/clamp.test.ts'],namedIdentities=[baseline[0]],baselineIdentities=baseline,inventory=run['inventory'])
        expected='NOT_APPLIED' if applied!='unique' else {'kill':'KILLED','survived':'SURVIVED'}.get(exec_out,'INFRA_FAILURE')
        # Run actual supervisor with unique/nonunique patch anchors, no source execution.
        calls=[]
        def stub(*a,**kw):calls.append(1);return run_record('survived') if len(calls)==1 else run
        old=sup.run_inventory;sup.run_inventory=stub
        try:
            with tempfile.TemporaryDirectory() as td:
                Path(td,'f.ts').write_text({'unique':'abc','missing':'xxx','duplicate':'abbc'}[applied])
                actual=sup.mutation(td,'unused',dict(id='m',file='f.ts',anchor='b',replacement='d',testFiles=['tests/clamp.test.ts'],expectedFailureTitle='negative'),Path(td,'out'))['classification']
        finally:sup.run_inventory=old
        tested.append(dict(axis='mutant × execution outcome',left=applied,right=exec_out,expected=expected,reference=actual,second=tiny.classify(w)))
        coverage.append(dict(axis='mutant × execution outcome',left=applied,right=exec_out,existingCases=[],missing=True,scope='original 300 differential comparisons; real runtime evidence separate'))
    write('pairwise.json',dict(originalTags=originals,coverage=coverage,probes=tested,missingCells=sum(x['missing'] for x in coverage)))

def finish():
    write('second-model.json',dict(comparisons=len(second),mismatches=sum(not x['equal'] for x in second),rows=second))
    properties=[dict(id=name,expectationProvenance='PROPERTY-DERIVED',generator='src/run_lab.py:metamorphic/git_properties',seed=4072026,checks=count,relationOnly=True) for name,count in checks.items()]
    (CORP/'high-confidence.json').write_text(json.dumps(dict(schema='forge-oracle-quality-v1',wireProfile='layer-isolated; inventory adapter maps 1-based lab occurrences to 0-based normative occurrences',cases=goldens,metamorphicProperties=properties),indent=2)+'\n')
    write('golden-conformance.json',dict(cases=len(goldens),referenceViolations=[g['id'] for g in goldens if g.get('observedReference')!=g['normativeOutcome']],secondViolations=[g['id'] for g in goldens if 'observedSecond' in g and g['observedSecond']!=g['normativeOutcome']]))
    print(json.dumps(dict(metamorphicChecks=sum(checks.values()),metamorphicFailures=len(failures),secondComparisons=len(second),secondMismatches=sum(not x['equal'] for x in second),goldens=len(goldens))))

if __name__=='__main__':
    provenance();golden_core();metamorphic();git_properties();records=mutation_witnesses();mutation_reference(records);history_probes();pairwise();finish()
