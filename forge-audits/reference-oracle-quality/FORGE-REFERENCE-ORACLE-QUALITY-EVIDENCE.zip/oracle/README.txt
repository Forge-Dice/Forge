FORGE REFERENCE ORACLE QUALITY LAB — 2026-10-04

Decision: NO-GO for the unchanged reference as a normative Codex oracle.
The new frozen high-confidence corpus is a selected-layer regression oracle,
not a complete Stage-2 or production certificate.

Package layout:
  oracle/src/tiny_model.py          independent tiny model, no reference imports
  oracle/src/run_lab.py             experiment runner and provenance generation
  oracle/src/compare_candidate.py   expected-vs-candidate comparison adapter
  oracle/corpus/high-confidence.json  contract-derived layer cases
  oracle/corpus/exploratory-original.json  150 original cases, 300 provenance rows
  oracle/corpus/*-history.git       raw Git static fixtures; never check out
  oracle/results/*                 complete results, mismatches, mutation patches
  reference/                       unmodified original evidence package
  inputs/                          exact normative/design-source snapshots

Reproduce the audit from the package root (stdlib Python + Git):
  python3 oracle/src/run_lab.py
  python3 reference/reference/differential.py reference
The source-executing npm/Vitest experiments are NOT rerun by these commands.
The supervisor probes stub run_inventory with deterministic trusted witness
records; actual reference mutation/classification code executes, but no
candidate JavaScript, compiler or test suite is run. The distinction is recorded.

Candidate comparison:
  python3 oracle/src/compare_candidate.py -- python3 /absolute/adapter.py
Run only in an independently provisioned disposable isolated environment.
This comparator is a local lab driver, not an execution sandbox. Future adapter
must route each layer to the candidate's real core rule, not a copied model.
Expected/observed data are stripped from per-case input given to the adapter.
The adapter returns JSON {"normativeOutcome": value}, optional diagnostics.
Adapter exit 0 denotes successful evaluation, independent of policy rejection.

Layer contracts:
  path: input.rows -> bool, valid snapshot paths/modes; unchanged 100755 allowed
  scope: input.changes/metadata/policy -> bool, exact selected source scope
  inventory: input.base/head -> bool; lab wire occurrence 1 must map to 0 in
             normative wire, project forge-ref-trusted maps to forge-v01;
             preserve strings and structured identity; completion true required
  diff: input.base/head -> canonical raw identity deltas. Compare raw paths,
        object kinds, modes, object IDs and type flags. Display labels ignored.
  mutation: input witness -> KILLED|SURVIVED|INFRA_FAILURE|NOT_APPLIED;
            full named structured identity, baseline passed identity, exact
            exit and infrastructure facts; anchorCount is a PREVALIDATED fact
  history-and-intermediate-scope: input.base/head + repository -> PASS|FAIL;
            raw new single-parent chain <=128, stop at BASE, every snapshot
            obeys metadata scope/policy protections, nonempty final diff

Anchor counting is additionally tested against actual supervisor byte patching
in run_lab.py (overlap ababa/aba). A candidate classifying prevalidated witness
facts correctly does not prove its real patch/collector pipeline produced them.
Similarly layer path acceptance is not filesystem materialization security.

Diagnostics are optional. Lab PRIORITY and labels are not production failure
codes. Normative ordered phases in the current draft remain separate contract
tests. No arbitrary outcome mapping or expected-output regeneration is allowed.

Known limits: only the five selected tiny-model APIs, seven history regressions,
sampled properties and witness-driven semantics. No authenticated GitHub review
lookup; no container, readonly mount, resource, network or receipt provenance
certificate. No blanket GO for Codex or Forge. Original 150 repository repeats
cover only 60 scenario names; 300 CLI comparisons are a self-replay.
