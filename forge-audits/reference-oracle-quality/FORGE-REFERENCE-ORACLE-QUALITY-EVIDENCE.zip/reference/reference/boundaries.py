#!/usr/bin/env python3
import copy,json,random,shutil,sys
from pathlib import Path
from lab import newdb,commit,blob,basic,save,WORK,ROOT
from forge_ref import *
def run():
    cases=[]
    vectors=[('invalid-utf8',[entry(b'a\xff')]),('c0',[entry(b'a\x01')]),('del',[entry(b'a\x7f')]),('newline',[entry(b'a\nb')]),('tab',[entry(b'a\tb')]),('cr',[entry(b'a\rb')]),('dot',[entry(b'./x')]),('dotdot',[entry(b'../x')]),('git',[entry(b'.GIT/x')]),('case',[entry(b'A.ts'),entry(b'a.ts')]),('directory-case',[entry(b'A/x'),entry(b'a/y')]),('normalization',[entry('é/x'.encode()),entry('e\u0301/y'.encode())]),('prefix',[entry(b'a'),entry(b'a/b')]),('windows',[entry(b'CON.txt')]),('trailing-dot',[entry(b'x.')]),('trailing-space',[entry(b'x ')]),('ads',[entry(b'x:s')]),('symlink',[entry(b'link','120000')]),('gitlink',[entry(b'link','160000','commit')]),('unknown-mode',[entry(b'x','100600')]),('backslash',[entry(b'a\\b')]),('valid-unicode',[entry('中文.ts'.encode())]),('normal',[entry(b'safe.ts')]),('executable',[entry(b'tool','100755')])]
    for name,rows in vectors:
        result=path_safety(rows);expected=name not in ('valid-unicode','normal','executable');assert bool(result)==expected,name;cases.append({'name':name,'input':rows,'reject':expected,'diagnostics':result})
    # True malicious Git object: file and directory with same component, never materialized.
    db=newdb(WORK/'prefix-object.git');leaf=blob(db,b'a');sub=bytes.fromhex(blob(db,b'b'))
    child=db.git('hash-object','--literally','-w','-t','tree','--stdin',data=b'100644 b\0'+sub).decode().strip()
    tree=db.git('hash-object','--literally','-w','-t','tree','--stdin',data=b'100644 a\0'+bytes.fromhex(leaf)+b'40000 a\0'+bytes.fromhex(child)).decode().strip()
    commitraw=f'tree {tree}\nauthor Lab <lab@example.invalid> 1700000000 +0000\ncommitter Lab <lab@example.invalid> 1700000000 +0000\n\nprefix\n'.encode();head=db.git('hash-object','-w','-t','commit','--stdin',data=commitraw).decode().strip()
    dest=WORK/'prefix-export'
    try:materialize(db,head,dest);raise AssertionError('materialized')
    except RefError as e:cases.append({'name':'raw-file-directory-collision','code':e.code,'materialized':dest.exists()});assert not dest.exists()
    db2=newdb(WORK/'case-object.git');head2=commit(db2,{b'A/x':('100644','blob',b'a'),b'a/y':('100644','blob',b'b')});dest2=WORK/'case-export'
    try:materialize(db2,head2,dest2);raise AssertionError('materialized')
    except RefError as e:cases.append({'name':'raw-case-directory-collision','code':e.code,'materialized':dest2.exists()});assert not dest2.exists()
    # Inventory tampering: duplicate identities, unknown status, invalid occurrence, incomplete/error report.
    from lab import mini_inventory
    b=mini_inventory()
    for name,fn in [('duplicate',lambda h:h['cases'].append(copy.deepcopy(h['cases'][0]))),('status',lambda h:h['cases'][0].update(status='green')),('occurrence',lambda h:h['cases'][0].update(occurrence=2)),('incomplete',lambda h:h.update(completed=False)),('collection-error',lambda h:h.update(errors=['error'])),('empty',lambda h:h.update(cases=[]))]:
        h=copy.deepcopy(b);fn(h);r=inventory_compare(b,h);assert r['code']=='INVENTORY_INVALID';cases.append({'name':'inventory-'+name,'result':r})
    # Regression for the totality error discovered during construction.
    f=basic();f['policy']='malformed';r=gate(f);assert r['code']=='INPUT_INVALID';cases.append({'name':'gate-policy-string-regression','result':r})
    save('boundaries.json',cases);print('boundaries',len(cases))
if __name__=='__main__':run()
