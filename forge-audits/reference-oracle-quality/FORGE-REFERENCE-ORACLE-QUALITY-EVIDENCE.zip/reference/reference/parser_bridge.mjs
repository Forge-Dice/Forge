// Actual main parser is used ONLY as a comparison oracle, not by the independent gate.
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
const [trustedRoot, inputsPath]=process.argv.slice(2);
const {parseContractDocument}=await import(pathToFileURL(resolve(trustedRoot,'src/forge/contract-document.ts')).href);
const hash=s=>createHash('sha256').update(s,'utf8').digest('hex');
const inputs=JSON.parse(readFileSync(inputsPath,'utf8'));
console.log(JSON.stringify(inputs.map(x=>{const r=parseContractDocument(x,hash);return r.ok?{ok:true,metadata:r.document.metadata,hash:r.document.ref.contentHash}:{ok:false,codes:r.issues.map(x=>x.code)};})));
