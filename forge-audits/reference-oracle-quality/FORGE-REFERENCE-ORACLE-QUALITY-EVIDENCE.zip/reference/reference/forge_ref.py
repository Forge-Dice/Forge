#!/usr/bin/env python3
"""Independent, stdlib-only behavioral lab; never a production authority."""
import argparse, base64, collections, hashlib, json, os, re, shutil, signal, subprocess, sys, tempfile, time, unicodedata
from pathlib import Path

VERSION = 'forge-ref/1'
NODE = shutil.which('node') or '/usr/bin/node'
CANONICAL_ORIGIN = 'https://github.com/Forge-Dice/Forge.git'
# Trusted operator transport settings are ONLY passed to fetch, never to PR execution.
TRANSPORT_ENV = {k:os.environ[k] for k in ('HTTPS_PROXY','HTTP_PROXY','ALL_PROXY','NO_PROXY','https_proxy','http_proxy','all_proxy','no_proxy') if k in os.environ}
SHA = re.compile(r'^[0-9a-f]{40}$')
JS_WHITESPACE = set('\t\n\v\f\r \u00a0\u1680\u2028\u2029\u202f\u205f\u3000\ufeff') | set(chr(c) for c in range(0x2000,0x200b))
PRIORITY = ['INPUT_INVALID','REPO_UNSAFE','GIT_OBJECT_INVALID','METADATA_INVALID','STALE_BASE','STALE_HEAD','HISTORY_INVALID','CONTRACT_INVALID','CONTRACT_BINDING','PATH_UNSAFE','LIMIT_EXCEEDED','PROTECTED_PATH','TEST_FROZEN','SCOPE_VIOLATION','CHECK_UNSUPPORTED','INVENTORY_INVALID','BASELINE_TEST_LOST','TEST_NOT_PASSED','CHECK_FAILED','MUTANT_NOT_APPLIED','MUTANT_INFRA_FAILURE','MUTANT_SURVIVED','ATTESTATION_INVALID']
class RefError(Exception):
    def __init__(self, code, detail=''): self.code, self.detail = code, str(detail)
def digest(x): return hashlib.sha256(x).hexdigest()
def canonical(x): return json.dumps(x, ensure_ascii=True, separators=(',', ':'), sort_keys=True)
def outcome(errors):
    errors = sorted(set((c,str(d)) for c,d in errors), key=lambda x:(PRIORITY.index(x[0]) if x[0] in PRIORITY else len(PRIORITY), x[0],x[1]))
    return {'outcome':'FAIL','code':errors[0][0],'diagnostics':[{'code':c,'subject':d} for c,d in errors]} if errors else {'outcome':'PASS','code':None,'diagnostics':[]}
def clean_env():
    # No inherited Git/NODE_OPTIONS/npm/credentials/runner env. PATH pins host binaries only in this lab.
    return {'PATH':str(Path(NODE).parent)+':'+os.defpath+':/usr/local/bin','LC_ALL':'C.UTF-8','LANG':'C.UTF-8','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_SYSTEM':'/dev/null','GIT_CONFIG_GLOBAL':'/dev/null','GIT_NO_REPLACE_OBJECTS':'1','GIT_NO_LAZY_FETCH':'1','GIT_TERMINAL_PROMPT':'0','GIT_ATTR_NOSYSTEM':'1','CI':'true'}
def command(argv, cwd=None, timeout=30, env=None, data=None):
    p=subprocess.Popen(argv,cwd=cwd,env=env or clean_env(),stdin=subprocess.PIPE if data is not None else subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
    try: out,err=p.communicate(data,timeout=timeout); timed=False
    except subprocess.TimeoutExpired:
        os.killpg(p.pid,signal.SIGKILL);out,err=p.communicate();timed=True
    return {'exit':p.returncode,'stdout':out,'stderr':err,'timeout':timed}

class GitDB:
    def __init__(self, path): self.path=Path(path).resolve()
    def git(self,*args,data=None,timeout=30,transport=False):
        env=clean_env() | (TRANSPORT_ENV if transport else {})
        r=command(['git','--no-replace-objects','--git-dir='+str(self.path),'-c','core.hooksPath=/dev/null','-c','credential.helper=','-c','protocol.ext.allow=never',*args],timeout=timeout,data=data,env=env)
        if r['exit']!=0 or r['timeout']: raise RefError('GIT_OBJECT_INVALID',r['stderr'].decode('utf-8','replace')[:400])
        return r['stdout']
    def audit(self):
        bad=[]
        for p in ['objects/info/alternates','objects/info/http-alternates','info/grafts','shallow']:
            if (self.path/p).exists():bad.append(p)
        if list((self.path/'objects/pack').glob('*.promisor')):bad.append('promisor pack')
        cfg=self.git('config','--local','--list','--null')
        allowed={'core.repositoryformatversion','core.filemode','core.bare','remote.origin.url','remote.origin.fetch'}
        for item in cfg.split(b'\0'):
            if item and item.split(b'\n',1)[0].decode('ascii','replace').lower() not in allowed:bad.append('config:'+item.split(b'\n',1)[0].decode('ascii','replace'))
        if self.git('for-each-ref','--format=%(refname)','refs/replace').strip():bad.append('replace ref')
        if bad:raise RefError('REPO_UNSAFE',','.join(bad))
    def obj(self,oid,kind):
        if not SHA.fullmatch(oid):raise RefError('INPUT_INVALID','object id')
        if self.git('cat-file','-t',oid).strip()!=kind.encode():raise RefError('GIT_OBJECT_INVALID','object type')
        size=int(self.git('cat-file','-s',oid))
        if size>32*1024*1024:raise RefError('LIMIT_EXCEEDED','object bytes')
        return self.git('cat-file',kind,oid)
    def readCommit(self,oid):
        raw=self.obj(oid,'commit');headers=raw.split(b'\n\n',1)[0].split(b'\n')
        trees=[v[5:].decode('ascii') for v in headers if v.startswith(b'tree ')]
        parents=[v[7:].decode('ascii') for v in headers if v.startswith(b'parent ')]
        if len(trees)!=1 or not all(SHA.fullmatch(x) for x in trees+parents):raise RefError('GIT_OBJECT_INVALID','commit headers')
        return {'oid':oid,'tree':trees[0],'parents':parents}
    def readTree(self,oid):
        # Decode actual raw tree objects rather than quoted ls-tree output.
        raw=self.obj(oid,'tree');rows=[];i=0
        while i<len(raw):
            space=raw.find(b' ',i);nul=raw.find(b'\0',space+1)
            if space<0 or nul<0 or nul+21>len(raw):raise RefError('GIT_OBJECT_INVALID','tree encoding')
            mode=raw[i:space].decode('ascii');name=raw[space+1:nul];obj=raw[nul+1:nul+21].hex();i=nul+21
            if not name or b'/' in name:raise RefError('GIT_OBJECT_INVALID','tree component')
            mode=mode.zfill(6);kind='tree' if mode=='040000' else 'commit' if mode=='160000' else 'blob'
            rows.append((name,mode,kind,obj))
        if len({x[0] for x in rows})!=len(rows):raise RefError('GIT_OBJECT_INVALID','duplicate entry')
        return rows
    def collectTree(self,commit):
        root=self.readCommit(commit)['tree'];rows=[];stack=[(b'',root,0)];cache={}
        while stack:
            prefix,oid,depth=stack.pop()
            if depth>64:raise RefError('LIMIT_EXCEEDED','tree depth')
            if oid not in cache:cache[oid]=self.readTree(oid)
            for name,mode,kind,obj in cache[oid]:
                p=prefix+name
                if kind=='tree':stack.append((p+b'/',obj,depth+1))
                else: rows.append(entry(p,mode,kind,obj))
                if len(rows)+len(stack)>200000:raise RefError('LIMIT_EXCEEDED','tree entries')
        return sorted(rows,key=lambda e:rawpath(e))
    def ancestor(self,base,head):
        # Graph traversal, no graft/shallow interpretation; bounded history.
        pending=[head];seen=set()
        while pending:
            oid=pending.pop()
            if oid==base:return True
            if oid in seen:continue
            seen.add(oid)
            if len(seen)>100000:raise RefError('LIMIT_EXCEEDED','history')
            pending.extend(self.readCommit(oid)['parents'])
        return False

def acquire(dest,origin,refs):
    """origin is supervisor-owned; no URL or ref is derived from PR text."""
    dest=Path(dest).resolve()
    if dest.exists():raise RefError('INPUT_INVALID','acquisition target exists')
    if not (origin==CANONICAL_ORIGIN or origin.startswith('/') or origin.startswith('file:///')):raise RefError('INPUT_INVALID','origin is not fixed canonical or local lab')
    for ref,expected in refs:
        if not re.fullmatch(r'refs/(heads/main|pull/[1-9][0-9]*/head)',ref) or not SHA.fullmatch(expected):raise RefError('INPUT_INVALID','ref/sha')
    with tempfile.TemporaryDirectory() as template:
        r=command(['git','init','--bare','--template='+template,str(dest)])
        if r['exit']:raise RefError('REPO_UNSAFE','init')
    db=GitDB(dest);db.git('remote','add','origin',origin)
    for idx,(ref,expected) in enumerate(refs):
        local=f'refs/forge/pin-{idx}'
        db.git('-c','fetch.fsckObjects=true','-c','transfer.fsckObjects=true','fetch','--no-tags','--no-recurse-submodules','origin',f'{ref}:{local}',timeout=120,transport=True)
        actual=db.git('rev-parse','--verify',local).decode().strip()
        if actual!=expected:raise RefError('STALE_HEAD',ref)
    db.audit();return db

def entry(path,mode='100644',kind='blob',oid='0'*40):
    return {'pathBytesBase64':base64.b64encode(path).decode(),'path':path.decode('utf-8','backslashreplace'),'mode':mode,'kind':kind,'oid':oid}
def rawpath(e):return base64.b64decode(e['pathBytesBase64'],validate=True)
def tree_map(rows):
    d={rawpath(e):e for e in rows}
    if len(d)!=len(rows):raise RefError('GIT_OBJECT_INVALID','duplicate raw path')
    return d
def diff(a,b):
    aa,bb=tree_map(a),tree_map(b);out=[]
    for p in sorted(aa.keys()|bb.keys()):
        old,new=aa.get(p),bb.get(p);flags=[]
        if old is None:flags=['ADD']
        elif new is None:flags=['DELETE']
        else:
            if old['oid']!=new['oid'] or old['kind']!=new['kind']:flags.append('MODIFY')
            if old['mode']!=new['mode']:flags.append('MODE_CHANGE')
        if flags:out.append({'pathBytesBase64':base64.b64encode(p).decode(),'path':p.decode('utf-8','backslashreplace'),'types':flags,'old':old,'new':new})
    return out

def path_safety(rows):
    errors=[];raw_seen=set();fold={};norm={};paths=set()
    for e in rows:
        p=rawpath(e);label=base64.b64encode(p).decode()
        if p in raw_seen:errors.append(('PATH_UNSAFE','duplicate:'+label))
        raw_seen.add(p)
        try:s=p.decode('utf-8','strict')
        except UnicodeDecodeError:errors.append(('PATH_UNSAFE','utf8:'+label));continue
        parts=s.split('/');paths.add(s)
        if not s or s.startswith('/') or '\\' in s or len(p)>255 or any(ord(c)<32 or ord(c)==127 for c in s):errors.append(('PATH_UNSAFE','syntax:'+label))
        for c in parts:
            if c in ('','.','..') or c.casefold()=='.git' or c.endswith(('.',' ')) or ':' in c or re.match(r'^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)',c,re.I):errors.append(('PATH_UNSAFE','component:'+label))
        # Include directory prefixes: A/x and a/y also collide on portable filesystems.
        for i in range(1,len(parts)+1):
            sub='/'.join(parts[:i])
            for mapping,key in [(fold,unicodedata.normalize('NFC',sub).casefold()),(norm,unicodedata.normalize('NFC',sub))]:
                if key in mapping and mapping[key]!=sub:errors.append(('PATH_UNSAFE','collision:'+label))
                mapping[key]=sub
        if e['mode'] not in ('100644','100755') or e['kind']!='blob':errors.append(('PATH_UNSAFE','mode:'+label))
    for s in paths:
        for i,c in enumerate(s.split('/')):
            if i and '/'.join(s.split('/')[:i]) in paths:errors.append(('PATH_UNSAFE','prefix:'+s))
    return errors

def parse_contract(text):
    if not isinstance(text,str):raise RefError('CONTRACT_INVALID','NOT_TEXT')
    if any(0xd800<=ord(c)<=0xdfff for c in text):raise RefError('CONTRACT_INVALID','NOT_WELL_FORMED_UNICODE')
    if text.startswith('\ufeff'):raise RefError('CONTRACT_INVALID','BOM')
    if '\r' in text:raise RefError('CONTRACT_INVALID','CARRIAGE_RETURN')
    if not text.startswith('---json\n'):raise RefError('CONTRACT_INVALID','FRONTMATTER_MISSING')
    close=text.find('\n---\n',7)
    if close<0:raise RefError('CONTRACT_INVALID','FRONTMATTER_UNTERMINATED')
    src=text[8:close]
    try:m=json.loads(src)
    except (ValueError,RecursionError):raise RefError('CONTRACT_INVALID','FRONTMATTER_JSON')
    if json.dumps(m,ensure_ascii=False,indent=2,separators=(',', ': '))!=src:raise RefError('CONTRACT_INVALID','FRONTMATTER_NOT_CANONICAL')
    def fail():raise RefError('CONTRACT_INVALID','METADATA_SCHEMA')
    keys={'forgeContractFormat','taskId','contractVersion','baseCommit','dependencies','scope','requiredChecks','mutationSmoke'}
    if not isinstance(m,dict) or set(m)!=keys:fail()
    def task(s):return isinstance(s,str) and len(s)<=64 and re.fullmatch(r'[A-Z][A-Z0-9]*(-[A-Z0-9]+)+',s)
    def path(s):return isinstance(s,str) and len(s)<=255 and re.fullmatch(r'[A-Za-z0-9._-]+(/[A-Za-z0-9._-]+)*',s) and all(x not in ('.','..') for x in s.split('/'))
    if type(m['forgeContractFormat'])!=int or m['forgeContractFormat']!=1 or not task(m['taskId']) or type(m['contractVersion'])!=int or not 1<=m['contractVersion']<=9007199254740991 or not isinstance(m['baseCommit'],str) or not SHA.fullmatch(m['baseCommit']):fail()
    if m['mutationSmoke'] not in ('none','optional','required'):fail()
    if not isinstance(m['dependencies'],list):fail()
    seen=set()
    for d in m['dependencies']:
        if not isinstance(d,dict) or set(d)!={'taskId','acceptedCommit'} or not task(d['taskId']) or d['taskId']==m['taskId'] or d['taskId'] in seen or not (d['acceptedCommit'] is None or isinstance(d['acceptedCommit'],str) and SHA.fullmatch(d['acceptedCommit'])):fail()
        seen.add(d['taskId'])
    s=m['scope'];seen=set()
    if not isinstance(s,dict) or set(s)!={'create','modify'}:fail()
    for k in ('create','modify'):
        if not isinstance(s[k],list):fail()
        for p in s[k]:
            if not path(p) or p in seen or p==f"forge/contracts/{m['taskId']}.md":fail()
            seen.add(p)
    checks=m['requiredChecks'];seen=set()
    if not isinstance(checks,list) or not checks:fail()
    for c in checks:
        if not isinstance(c,dict) or set(c)!={'name','command'} or not isinstance(c['name'],str) or not re.fullmatch(r'[a-z][a-z0-9-]{0,31}',c['name']) or c['name'] in seen or not isinstance(c['command'],str) or not any(ch not in JS_WHITESPACE for ch in c['command']):fail()
        seen.add(c['name'])
    return {'metadata':m,'contentHash':digest(('forge-contract-v1\n'+text).encode())}

def protected(p):
    roots=('forge/contracts','forge/approvals','.github','verifier','node_modules')
    if any(p==r or p.startswith(r+'/') for r in roots):return True
    name=p.rsplit('/',1)[-1].lower()
    return name in ('package.json','package-lock.json','.npmrc','.gitattributes','.gitmodules','codeowners') or bool(re.match(r'(tsconfig|vitest|vite|eslint)\.',name)) or name.startswith('.env')

def scope_errors(changes,m,policy):
    errors=[];frozen=set(policy.get('frozenTests',[]));create=set(m['scope']['create']);modify=set(m['scope']['modify'])
    for c in changes:
        p=c['path']
        if protected(p):errors.append(('PROTECTED_PATH',p))
        if p in frozen:errors.append(('TEST_FROZEN',p))
        if c['types']==['ADD']:allowed=p in create
        elif 'DELETE' in c['types']:allowed=False
        else:allowed=p in modify and 'MODE_CHANGE' not in c['types']
        # Core coordination exemption retained for safe ADD/MODIFY, never DELETE/mode.
        if p.startswith('forge/coordination/') and c['types'] in (['ADD'],['MODIFY']):allowed=True
        if not allowed:errors.append(('SCOPE_VIOLATION',p))
    return errors

def gate(fixture,db=None):
    errors=[]
    try:
        if not isinstance(fixture,dict):raise RefError('INPUT_INVALID','manifest')
        base,head=fixture['base'],fixture['head'];meta=fixture['metadata'];policy=fixture['policy']
        if not SHA.fullmatch(base) or not SHA.fullmatch(head):raise RefError('INPUT_INVALID','sha')
        if db:
            db.audit();a=db.collectTree(base);b=db.collectTree(head);ancestor=db.ancestor(base,head)
        else:a=fixture['baseTree'];b=fixture['headTree'];ancestor=fixture['ancestor']
        changes=diff(a,b)
        if meta.get('repoId')!=policy.get('repoId') or meta.get('headRepoId')!=policy.get('repoId') or meta.get('authorId')!=policy.get('developerId') or meta.get('state')!='open' or meta.get('event')!='pull_request_target' or type(meta.get('pr'))!=int or meta['pr']<=0 or not re.fullmatch(r'forge/run/codex/[A-Za-z0-9_-]+(?:/[A-Za-z0-9_-]+)*',meta.get('branch','')):errors.append(('METADATA_INVALID','repo/actor/ref/event'))
        if meta.get('main')!=base or policy.get('verifierSha')!=base:errors.append(('STALE_BASE','main/verifier'))
        if meta.get('currentHead')!=head:errors.append(('STALE_HEAD','head'))
        if not ancestor:errors.append(('HISTORY_INVALID','base not ancestor'))
        contract=parse_contract(fixture['contract']);m=contract['metadata']
        if m['baseCommit']!=base or policy.get('contractHash')!=contract['contentHash'] or policy.get('taskId')!=m['taskId'] or policy.get('version')!=m['contractVersion']:errors.append(('CONTRACT_BINDING','base/hash/task/version'))
        if m['dependencies']:
            for d in m['dependencies']:
                accepted=policy.get('acceptedDependencies',{}).get(d['taskId'])
                if not accepted or accepted!=d['acceptedCommit'] or not db or not db.ancestor(accepted,base):errors.append(('CONTRACT_BINDING','dependency:'+d['taskId']))
        errors.extend(path_safety(a));errors.extend(path_safety(b))
        limits=policy['limits']
        if set(limits)!={'files','changedFiles','blobBytes','totalBytes'} or any(type(v)!=int or v<1 for v in limits.values()):raise RefError('INPUT_INVALID','limits')
        reads=policy.get('reads',[])
        if not isinstance(reads,list) or len(reads)!=len(set(reads)) or any(p not in {e['path'] for e in a} for p in reads):errors.append(('CONTRACT_BINDING','auxiliary read context'))
        mutants=policy['mutants']
        if not isinstance(mutants,list) or any(not isinstance(x,dict) or not isinstance(x.get('id'),str) or not re.fullmatch(r'[a-z][a-z0-9-]{0,63}',x['id']) for x in mutants) or len({x['id'] for x in mutants})!=len(mutants):errors.append(('CONTRACT_BINDING','auxiliary mutant list'))
        if len(b)>limits['files'] or len(changes)>limits['changedFiles']:errors.append(('LIMIT_EXCEEDED','files/changes'))
        if db:
            sizes={e['oid']:int(db.git('cat-file','-s',e['oid'])) for e in b if e['kind']=='blob'}
            if sum(sizes[e['oid']] for e in b if e['kind']=='blob')>limits['totalBytes'] or any(v>limits['blobBytes'] for v in sizes.values()):errors.append(('LIMIT_EXCEEDED','blob bytes'))
        errors.extend(scope_errors(changes,m,policy))
        mappings=policy['checkCommands']
        for c in m['requiredChecks']:
            if mappings.get(c['name'])!=c['command']:errors.append(('CHECK_UNSUPPORTED',c['name']))
        result=outcome(errors);result['changes']=changes;return result
    except RefError as e:errors.append((e.code,e.detail))
    except (KeyError,TypeError,ValueError,AttributeError,OverflowError,RecursionError,OSError) as e:errors.append(('INPUT_INVALID',type(e).__name__))
    result=outcome(errors)
    if 'changes' in locals():result['changes']=changes
    return result

def inventory_key(c):return (c['file'],c['project'],tuple(c['ancestors']),c['title'],c['occurrence'])
def inventory_compare(base,head):
    errors=[]
    try:
        def checked(inv):
            if not isinstance(inv,dict) or not inv.get('completed') or inv.get('errors') or not inv.get('cases'):raise RefError('INVENTORY_INVALID','completion/errors/empty')
            out={};next_occ=collections.Counter()
            for c in inv['cases']:
                if not isinstance(c['ancestors'],list) or not all(isinstance(s,str) for s in [c['file'],c['project'],c['title'],*c['ancestors']]) or c['status'] not in ('passed','failed','skipped','todo','pending'):raise RefError('INVENTORY_INVALID','case')
                k=inventory_key(c);name=k[:-1];next_occ[name]+=1
                if k in out or type(c['occurrence'])!=int or c['occurrence']!=next_occ[name]:raise RefError('INVENTORY_INVALID','occurrence')
                out[k]=c
            return out
        aa,bb=checked(base),checked(head)
        for k,c in aa.items():
            if c['status']!='passed':errors.append(('INVENTORY_INVALID','baseline nonpassing'))
            if k not in bb:errors.append(('BASELINE_TEST_LOST',canonical(k)))
            elif bb[k]['status']!='passed':errors.append(('TEST_NOT_PASSED',canonical(k)))
        for k,c in bb.items():
            if c['status']!='passed':errors.append(('TEST_NOT_PASSED',canonical(k)))
        if set(base.get('files',[]))-set(head.get('files',[])):errors.append(('BASELINE_TEST_LOST','module'))
    except RefError as e:errors.append((e.code,e.detail))
    except (KeyError,TypeError,ValueError):errors.append(('INVENTORY_INVALID','shape'))
    return outcome(errors)

def verify(fixture,gate_result=None):
    try:
        g=gate_result or gate(fixture)
        if g['outcome']!='PASS':return {'outcome':'FAIL','code':g['code'],'diagnostics':g['diagnostics'],'execution':'NOT_STARTED'}
        errors=[];v=fixture['verify'];errors.extend((x['code'],x['subject']) for x in inventory_compare(v['baseline'],v['head'])['diagnostics'])
        m=parse_contract(fixture['contract'])['metadata']
        for spec in m['requiredChecks']:
            matches=[c for c in v['checks'] if c.get('name')==spec['name']]
            if len(matches)!=1 or matches[0].get('command')!=spec['command'] or matches[0].get('exit')!=0:errors.append(('CHECK_FAILED',spec['name']))
        names=[c.get('name') for c in v['checks']]
        if len(names)!=len(set(names)):errors.append(('CHECK_FAILED','duplicates'))
        required=fixture['policy']['mutants']
        if m['mutationSmoke']=='required' and not required:errors.append(('MUTANT_NOT_APPLIED','required set empty'))
        seen=set()
        for mut in required:
            results=[r for r in v['mutants'] if r.get('id')==mut['id']]
            if mut['id'] in seen or len(results)!=1:errors.append(('MUTANT_NOT_APPLIED',mut['id']));continue
            seen.add(mut['id']);r=results[0];code={'SURVIVED':'MUTANT_SURVIVED','NOT_APPLIED':'MUTANT_NOT_APPLIED','INFRA_FAILURE':'MUTANT_INFRA_FAILURE'}.get(r.get('classification'))
            if code:errors.append((code,mut['id']))
            elif r.get('classification')!='KILLED':errors.append(('MUTANT_INFRA_FAILURE',mut['id']))
        binding={'repoId':fixture['policy']['repoId'],'pr':fixture['metadata']['pr'],'base':fixture['base'],'head':fixture['head'],'contractHash':fixture['policy']['contractHash'],'verifierSha':fixture['policy']['verifierSha'],'policyHash':digest(canonical(fixture['policy']).encode()),'aiReportHash':fixture['policy']['aiReportHash']}
        at=v.get('attestation',{})
        if at.get('userId')!=fixture['policy']['ownerId'] or at.get('binding')!=binding or at.get('revoked') is not False or at.get('result')!='PASS' or at.get('commitId')!=fixture['head'] or at.get('state')!='COMMENTED' or v.get('runAttempt',0)<2 or v.get('triggeringActorId')!=fixture['policy']['ownerId']:errors.append(('ATTESTATION_INVALID','owner/head/binding/recheck'))
        return outcome(errors)
    except (RefError,KeyError,TypeError,ValueError,RecursionError) as e:return outcome([('INPUT_INVALID',type(e).__name__)])

def materialize(db,commit,dest):
    rows=db.collectTree(commit);errors=path_safety(rows)
    if errors:raise RefError('PATH_UNSAFE',errors[0])
    target=Path(dest)
    if target.exists():raise RefError('INPUT_INVALID','materialization destination exists')
    # Every leaf is validated before the first filesystem mutation.
    target.mkdir(mode=0o700)
    for e in rows:
        path=target/e['path'];path.parent.mkdir(parents=True,exist_ok=True)
        fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
        with os.fdopen(fd,'wb') as f:f.write(db.obj(e['oid'],'blob'))
    return rows

def main():
    ap=argparse.ArgumentParser();ap.add_argument('action',choices=['gate','verify','diff','inventory','acquire']);ap.add_argument('--manifest');ap.add_argument('--repo');ap.add_argument('--base');ap.add_argument('--head');ap.add_argument('--origin');ap.add_argument('--ref',action='append',default=[]);ap.add_argument('--destination');ap.add_argument('--baseline');ap.add_argument('--candidate');args=ap.parse_args()
    try:
        db=GitDB(args.repo) if args.repo else None
        if args.action=='acquire':db=acquire(args.destination,args.origin,[tuple(v.split('=',1)) for v in args.ref]);r={'outcome':'PASS','repo':str(db.path)}
        elif args.action=='diff':db.audit();r={'outcome':'PASS','changes':diff(db.collectTree(args.base),db.collectTree(args.head))}
        elif args.action=='inventory':r=inventory_compare(json.load(open(args.baseline)),json.load(open(args.candidate)))
        else:
            f=json.load(open(args.manifest));g=gate(f,db);r=g if args.action=='gate' else verify(f,g)
    except RefError as e:r=outcome([(e.code,e.detail)])
    except Exception as e:r=outcome([('INPUT_INVALID',type(e).__name__)])
    print(canonical(r));return 0 if r['outcome']=='PASS' else 1
if __name__=='__main__':sys.exit(main())
