"""Host laboratory supervisor; explicitly NOT an execution sandbox."""
import json, os, shutil, tempfile, time
from pathlib import Path
from forge_ref import command, clean_env, digest, inventory_compare

HERE=Path(__file__).resolve().parent
def run_inventory(root,toolchain,out,filters=(),timeout=120):
    out=Path(out).resolve();out.parent.mkdir(parents=True,exist_ok=True)
    r=command(['node',str(HERE/'run_inventory.mjs'),str(Path(root).resolve()),str(Path(toolchain).resolve()),str(out),*filters],cwd=root,timeout=timeout)
    Path(str(out)+'.log').write_bytes(r['stdout']+r['stderr'])
    inv=json.loads(out.read_text()) if out.exists() else {'completed':False,'errors':[{'message':'no report'}],'cases':[],'files':[]}
    return {'exit':r['exit'],'timeout':r['timeout'],'inventory':inv,'isolation':'EXECUTION_ISOLATION_NOT_TESTED'}
def typecheck(root,toolchain,trusted_config,timeout=120):
    # Copy trusted config to a fresh external directory; candidate tsconfig is not consulted.
    root=Path(root).resolve();toolchain=Path(toolchain).resolve()
    config=json.loads(Path(trusted_config).read_text());config['include']=[str(root/'src'),str(root/'tests')]
    config['compilerOptions']['typeRoots']=[str(toolchain/'node_modules/@types')]
    with tempfile.TemporaryDirectory() as td:
        c=Path(td)/'tsconfig.json';c.write_text(json.dumps(config))
        r=command(['node',str(toolchain/'node_modules/typescript/bin/tsc'),'--project',str(c),'--noEmit'],cwd=root,timeout=timeout)
    return {'exit':r['exit'],'timeout':r['timeout'],'stdout':r['stdout'].decode('utf-8','replace'),'stderr':r['stderr'].decode('utf-8','replace'),'isolation':'EXECUTION_ISOLATION_NOT_TESTED'}
def mutation(root,toolchain,spec,out):
    root=Path(root);path=root/spec['file']
    result={'id':spec['id'],'classification':'INFRA_FAILURE','isolation':'EXECUTION_ISOLATION_NOT_TESTED'}
    try:
        before=path.read_bytes();anchor=spec['anchor'].encode();replacement=spec['replacement'].encode();count=before.count(anchor)
        result.update(beforeHash=digest(before),anchorCount=count)
        if count!=1 or anchor==replacement:return result|{'classification':'NOT_APPLIED'}
        baseline=run_inventory(root,toolchain,str(out)+'.unmutated.json',spec['testFiles'],timeout=spec.get('timeout',30))
        bi=baseline['inventory'];result['unmutatedExit']=baseline['exit']
        if baseline['exit']!=0 or baseline['timeout'] or not bi['completed'] or bi['errors'] or set(bi['files'])!=set(spec['testFiles']) or not bi['cases'] or any(c['status']!='passed' for c in bi['cases']):return result
        after=before.replace(anchor,replacement);result['afterHash']=digest(after)
        path.write_bytes(after)
        if path.read_bytes()!=after or digest(before)==digest(after):return result|{'classification':'NOT_APPLIED'}
        run=run_inventory(root,toolchain,out,spec['testFiles'],timeout=spec.get('timeout',30));inv=run['inventory'];result['runExit']=run['exit'];result['timeout']=run['timeout'];result['inventory']=inv
        expected=set(spec['testFiles']);actual=set(inv['files'])
        if run['timeout'] or not inv['completed'] or inv['errors'] or actual!=expected or not inv['cases']:return result
        failed=[c for c in inv['cases'] if c['status']=='failed'];wanted=spec['expectedFailureTitle']
        kills=[c for c in failed if c['title']==wanted and any(e.get('name')=='AssertionError' for e in c['errors'])]
        result['failedTitles']=[c['title'] for c in failed]
        if run['exit']!=0 and kills and all(c['status'] in ('passed','failed') for c in inv['cases']):result['classification']='KILLED'
        elif run['exit']==0 and all(c['status']=='passed' for c in inv['cases']):result['classification']='SURVIVED'
        return result
    except (OSError,ValueError,KeyError) as e:return result|{'error':type(e).__name__}
    finally:
        if 'before' in locals():path.write_bytes(before)
