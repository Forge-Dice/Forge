#!/usr/bin/env python3
"""Black-box adapter: compare external semantics, not helper implementations.
Usage: python3 reference/differential.py ROOT_TO_PACKAGE [-- COMMAND ...]
COMMAND must accept: gate|verify --repo PATH --manifest PATH; stdout is JSON.
"""
import json, subprocess, sys, tempfile
from pathlib import Path
root=Path(sys.argv[1]).resolve()
cmd=sys.argv[3:] if len(sys.argv)>2 and sys.argv[2]=='--' else [sys.executable,str(root/'reference/forge_ref.py')]
corpus=json.loads((root/'results/differential/cases.json').read_text())
results=[]
with tempfile.TemporaryDirectory() as td:
 for case in corpus['cases']:
  mf=Path(td)/(case['id']+'.json');mf.write_text(json.dumps(case['input']))
  rep=root/case['repository']
  if not rep.exists():rep=root/'lab-work/adversarial'/Path(case['repository']).name
  for action in ('gate','verify'):
   r=subprocess.run([*cmd,action,'--repo',str(rep),'--manifest',str(mf)],capture_output=True,timeout=60)
   try:got=json.loads(r.stdout);expected=case['expected'][action];same=got['outcome']==expected['outcome'] and got['code']==expected['code']
   except (ValueError,KeyError,TypeError):got={'invalidOutput':True};same=False
   if action=='gate' and 'changes' in got:same=same and got['changes']==case['expected']['changes']
   same=same and r.returncode==(0 if case['expected'][action]['outcome']=='PASS' else 1)
   results.append({'id':case['id'],'action':action,'equal':same,'exit':r.returncode,'gotCode':got.get('code')})
out={'comparisons':len(results),'mismatches':sum(not r['equal'] for r in results),'results':results}
print(json.dumps(out));sys.exit(0 if out['mismatches']==0 else 1)
