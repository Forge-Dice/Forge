// Supervisor-owned programmatic Vitest configuration: no candidate config loading.
import { writeFileSync } from 'node:fs';
import { resolve, relative } from 'node:path';
import { pathToFileURL } from 'node:url';
const [rootArg, toolchainArg, outputArg, ...filters] = process.argv.slice(2);
const root = resolve(rootArg), toolchain = resolve(toolchainArg);
const { startVitest } = await import(pathToFileURL(resolve(toolchain,'node_modules/vitest/dist/node.js')).href);
const brief = e => ({ name:e.name??'', message:String(e.message??''), actual:e.actual, expected:e.expected });
let wrote = false;
const reporter = {
  onTestRunEnd(modules, errors, reason) {
    const cases=[], files=[], collectionErrors=[];
    const counts=new Map();
    for (const mod of [...modules].sort((a,b)=>a.moduleId<b.moduleId?-1:1)) {
      const file=relative(root,mod.moduleId).split('\\').join('/');files.push(file);
      collectionErrors.push(...mod.errors().map(brief));
      for(const suite of mod.children.allSuites()) collectionErrors.push(...suite.errors().map(brief));
      for(const test of mod.children.allTests()) {
        const ancestors=[]; let parent=test.parent;
        while(parent.type==='suite') { ancestors.unshift(parent.name); parent=parent.parent; }
        const project=test.project.name??'';
        const key=JSON.stringify([file,project,ancestors,test.name]);const occurrence=(counts.get(key)??0)+1;counts.set(key,occurrence);
        const result=test.result();
        const status=test.options.mode==='todo'?'todo':result.state;
        cases.push({file,project,ancestors,title:test.name,occurrence,status,errors:(result.errors??[]).map(brief)});
      }
    }
    const allErrors=[...errors.map(brief),...collectionErrors];
    writeFileSync(outputArg,JSON.stringify({schema:'forge-ref-inventory-v1',completed:reason==='passed'||reason==='failed',reason,files,cases,errors:allErrors},null,2));wrote=true;
  }
};
try {
 const ctx=await startVitest('test',filters,{root,config:false,watch:false,include:['tests/**/*.test.ts'],exclude:['**/node_modules/**'],allowOnly:false,passWithNoTests:false,maxWorkers:2,testTimeout:20000,reporters:[reporter],name:'forge-ref-trusted',environment:'node',retry:0,bail:0,update:false},{configFile:false});
 if(!ctx || !wrote) process.exitCode=2;
 if(ctx) await ctx.close();
} catch(e) {
 writeFileSync(outputArg,JSON.stringify({completed:false,files:[],cases:[],errors:[brief(e)]}));process.exitCode=2;
}
