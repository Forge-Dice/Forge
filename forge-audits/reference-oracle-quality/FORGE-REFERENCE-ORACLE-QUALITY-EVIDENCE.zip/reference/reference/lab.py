#!/usr/bin/env python3
"""Reproducible fixtures with hand-authored expectations; no production helpers."""
import base64, collections, copy, json, os, random, shutil, statistics, sys, tempfile, time
from pathlib import Path
from forge_ref import *
from supervisor import run_inventory,typecheck,mutation
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'results';OUT.mkdir(exist_ok=True)
WORK=ROOT/'lab-work';WORK.mkdir(exist_ok=True)
def save(name,data):
    p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,ensure_ascii=True,indent=2));return p
def newdb(path):
    path=Path(path)
    if path.exists():shutil.rmtree(path)
    with tempfile.TemporaryDirectory() as td:
        r=command(['git','init','--bare','--template='+td,str(path)])
        assert r['exit']==0,r
    return GitDB(path)
def blob(db,data):return db.git('hash-object','-w','--stdin',data=data).decode().strip()
def make_tree(db,files):
    # files maps raw byte paths to (mode,kind,bytes or referenced oid).
    nested={};blob_cache={}
    for p,v in files.items():
        parts=p.split(b'/');cur=nested
        for c in parts[:-1]:cur=cur.setdefault(c,{})
        cur[parts[-1]]=v
    def build(d):
        raw=b''
        for name,v in sorted(d.items(),key=lambda x:x[0]+(b'/' if isinstance(x[1],dict) else b'')):
            if isinstance(v,dict):mode,oid='40000',build(v)
            else:
                mode,kind,data=v
                if kind=='commit':oid=data
                else:
                    if data not in blob_cache:blob_cache[data]=blob(db,data)
                    oid=blob_cache[data]
            raw+=mode.encode()+b' '+name+b'\0'+bytes.fromhex(oid)
        return db.git('hash-object','--literally','-w','-t','tree','--stdin',data=raw).decode().strip()
    return build(nested)
def commit(db,files,parents=(),message='fixture'):
    tree=make_tree(db,files)
    raw=('tree '+tree+'\n'+''.join('parent '+p+'\n' for p in parents)+'author Lab <lab@example.invalid> 1700000000 +0000\ncommitter Lab <lab@example.invalid> 1700000000 +0000\n\n'+message+'\n').encode()
    return db.git('hash-object','-w','-t','commit','--stdin',data=raw).decode().strip()
def contract(base,modify=('src/clamp.ts',),create=(),smoke='required'):
    m={'forgeContractFormat':1,'taskId':'REF-DRILL-0001','contractVersion':1,'baseCommit':base,'dependencies':[],'scope':{'create':list(create),'modify':list(modify)},'requiredChecks':[{'name':'typecheck','command':'npm run typecheck'},{'name':'test','command':'npm test'}],'mutationSmoke':smoke}
    return '---json\n'+json.dumps(m,indent=2,ensure_ascii=False)+'\n---\n# Local reference drill\n'
def mini_inventory():
    return {'completed':True,'errors':[],'files':['tests/clamp.test.ts'],'cases':[{'file':'tests/clamp.test.ts','project':'forge-ref-trusted','ancestors':['clamp'],'title':s,'occurrence':1,'status':'passed'} for s in ['negative','zero','positive']]}
def bind_attestation(f):
    p=f['policy'];binding={'repoId':p['repoId'],'pr':f['metadata']['pr'],'base':f['base'],'head':f['head'],'contractHash':p['contractHash'],'verifierSha':p['verifierSha'],'policyHash':digest(canonical(p).encode()),'aiReportHash':p['aiReportHash']}
    f['verify']['attestation']={'userId':p['ownerId'],'binding':binding,'commitId':f['head'],'state':'COMMENTED','revoked':False,'result':'PASS'}
def manifest(base,head,at,bt):
    text=contract(base)
    f={'schema':'forge-ref-case-v1','base':base,'head':head,'baseTree':at,'headTree':bt,'ancestor':True,'contract':text,'metadata':{'repoId':1401864629,'headRepoId':1401864629,'authorId':337272506,'pr':1,'state':'open','event':'pull_request_target','branch':'forge/run/codex/REF-DRILL-0001','main':base,'currentHead':head},'policy':{'profile':'reference-v0.1-lab','repoId':1401864629,'developerId':337272506,'ownerId':315180734,'verifierSha':base,'taskId':'REF-DRILL-0001','version':1,'contractHash':parse_contract(text)['contentHash'],'aiReportHash':'a'*64,'frozenTests':['tests/clamp.test.ts'],'limits':{'files':20000,'changedFiles':20,'blobBytes':1048576,'totalBytes':16777216},'checkCommands':{'typecheck':'npm run typecheck','test':'npm test'},'reads':['src/clamp.ts'],'mutants':[{'id':'negative-return'}]},'verify':{'baseline':mini_inventory(),'head':mini_inventory(),'checks':[{'name':'typecheck','command':'npm run typecheck','exit':0},{'name':'test','command':'npm test','exit':0}],'mutants':[{'id':'negative-return','classification':'KILLED'}],'runAttempt':2,'triggeringActorId':315180734}}
    bind_attestation(f);return f
def basic():
    a=[entry(b'src/clamp.ts',oid='1'*40),entry(b'tests/clamp.test.ts',oid='2'*40),entry(b'src/other.ts',oid='3'*40)]
    b=copy.deepcopy(a);b[0]['oid']='4'*40
    return manifest('b'*40,'c'*40,a,b)
def assert_case(name,f,expected_gate,expected_verify,db=None):
    g=gate(f,db);v=verify(f,g);actual=(g['code'],v['code'])
    expected=(expected_gate,expected_verify)
    assert actual==expected,(name,expected,actual,g,v)
    # Expectations are explicitly set by the scenario author, not copied from g/v.
    assert g.get('changes',[])==f.get('expectedChanges',[]),(name,'diff oracle mismatch')
    return {'id':name,'input':f,'expected':{'changes':f.get('expectedChanges',[]),'gate':{'outcome':'FAIL' if expected_gate else 'PASS','code':expected_gate},'verify':{'outcome':'FAIL' if expected_verify else 'PASS','code':expected_verify}},'observed':{'gate':g,'verify':v}}

def expected_changes(oldfiles,newfiles):
    # Independent fixture oracle from authored raw file data, not readTree/diff output.
    def describe(p,v):
        mode,kind,data=v
        oid=data if kind=='commit' else __import__('hashlib').sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
        return {'pathBytesBase64':base64.b64encode(p).decode(),'path':p.decode('utf-8','backslashreplace'),'mode':mode.zfill(6),'kind':kind,'oid':oid}
    out=[]
    for p in sorted(set(oldfiles)|set(newfiles)):
        old=describe(p,oldfiles[p]) if p in oldfiles else None;new=describe(p,newfiles[p]) if p in newfiles else None
        flags=['ADD'] if old is None else ['DELETE'] if new is None else (['MODIFY'] if old['oid']!=new['oid'] or old['kind']!=new['kind'] else [])+(['MODE_CHANGE'] if old['mode']!=new['mode'] else [])
        if flags:out.append({'pathBytesBase64':base64.b64encode(p).decode(),'path':p.decode('utf-8','backslashreplace'),'types':flags,'old':old,'new':new})
    return out

def corpus():
    base_files={b'src/clamp.ts':('100644','blob',b'export const clamp=(n:number)=>{ if(n<0)return 0; return n; };\n'),b'tests/clamp.test.ts':('100644','blob',b'import {it,expect} from "vitest"; import {clamp} from "../src/clamp.ts";\nit("negative",()=>expect(clamp(-1)).toBe(0));\nit("zero",()=>expect(clamp(0)).toBe(0));\nit("positive",()=>expect(clamp(2)).toBe(2));\n'),b'src/other.ts':('100644','blob',b'export const other=1;\n'),b'package.json':('100644','blob',b'{"type":"module"}\n')}
    scenarios=['legitimate','scope','deleted-test','skipped-test','config','protected','extra','survived','stale','invalid-utf8','control','del','dot','dotdot','git','case','unicode-normalization','prefix-case','windows','trailing-dot','trailing-space','colon','symlink','gitlink','unknown-mode','binary','empty','rename','case-rename','mode-only','content-mode','bad-contract','version','base-binding','task-binding','foreign-repo','foreign-author','branch','closed','event','stale-base','history','limit','missing-check','wrong-command','duplicate-check','missing-mutant','infra-mutant','revoked','wrong-owner','initial-run','wrong-trigger','wrong-report','todo','new-tests','duplicate-title','parameterized','config-shrink','removed-plus-added','no-attestation']
    cases=[];rawdiff=[]
    for idx in range(150):
        scenario=scenarios[idx%len(scenarios)];db=newdb(WORK/f'adversarial/{idx:03d}.git')
        older=commit(db,{b'ancestral.txt':('100644','blob',str(idx).encode())},message=f'root-{idx}') if idx%3==0 else None
        base=commit(db,base_files,[older] if older else [],message=f'base-{idx}')
        files=copy.deepcopy(base_files);files[b'src/clamp.ts']=('100644','blob',b'export const clamp=(n:number)=>n<0?0:n;\n');eg=ev=None
        if scenario=='scope':files[b'src/other.ts']=('100644','blob',b'changed');eg=ev='SCOPE_VIOLATION'
        elif scenario=='deleted-test':del files[b'tests/clamp.test.ts'];eg=ev='TEST_FROZEN'
        elif scenario=='skipped-test':files[b'tests/clamp.test.ts']=('100644','blob',b'test.skip');eg=ev='TEST_FROZEN'
        elif scenario=='config':files[b'vitest.config.mjs']=('100644','blob',b'export default {};');eg=ev='PROTECTED_PATH'
        elif scenario=='protected':files[b'.github/workflows/evil.yml']=('100644','blob',b'name: evil');eg=ev='PROTECTED_PATH'
        elif scenario=='extra':files[b'notes.txt']=('100644','blob',b'notes');eg=ev='SCOPE_VIOLATION'
        elif scenario in ['invalid-utf8','control','del','dot','dotdot','git','windows','trailing-dot','trailing-space','colon']:
            path={'invalid-utf8':b'bad\xff','control':b'a\n\t','del':b'a\x7f','dot':b'./x','dotdot':b'../x','git':b'.git/config','windows':b'AUX.txt','trailing-dot':b'name.','trailing-space':b'name ','colon':b'name:stream'}[scenario]
            files[path]=('100644','blob',b'x');eg=ev='PATH_UNSAFE'
        elif scenario=='case':files[b'A.ts']=('100644','blob',b'a');files[b'a.ts']=('100644','blob',b'b');eg=ev='PATH_UNSAFE'
        elif scenario=='unicode-normalization':files['é.ts'.encode()]=('100644','blob',b'a');files['e\u0301.ts'.encode()]=('100644','blob',b'b');eg=ev='PATH_UNSAFE'
        elif scenario=='prefix-case':files[b'A/x']=('100644','blob',b'a');files[b'a/y']=('100644','blob',b'b');eg=ev='PATH_UNSAFE'
        elif scenario in ('symlink','gitlink','unknown-mode'):
            mode,kind,data={'symlink':('120000','blob',b'/tmp/marker'),'gitlink':('160000','commit',base),'unknown-mode':('100600','blob',b'x')}[scenario];files[b'src/link']=(mode,kind,data);eg=ev='PATH_UNSAFE'
        elif scenario in ('binary','empty'):
            files[b'data.bin']=('100644','blob',b'\x00\xff' if scenario=='binary' else b'');eg=ev='SCOPE_VIOLATION'
        elif scenario in ('rename','case-rename'):
            files[b'src/Clamp.ts' if scenario=='case-rename' else b'src/new.ts']=files.pop(b'src/clamp.ts');eg=ev='SCOPE_VIOLATION'
        elif scenario in ('mode-only','content-mode'):
            files[b'src/clamp.ts']=('100755','blob',base_files[b'src/clamp.ts'][2] if scenario=='mode-only' else b'new');eg=ev='SCOPE_VIOLATION'
        head=commit(db,files,[] if scenario=='history' else [base],message=f'head-{idx}')
        if idx%5==0 and scenario!='history':head=commit(db,files,[head,base],message=f'merge-{idx}')
        db.git('update-ref','refs/heads/main',base);db.git('update-ref','refs/pull/1/head',head)
        at,bt=db.collectTree(base),db.collectTree(head);f=manifest(base,head,at,bt);f['expectedChanges']=expected_changes(base_files,files)
        changes=diff(at,bt)
        # Independent external diff projection cross-check: git --raw, no rename heuristics.
        raw=db.git('diff-tree','--no-commit-id','--raw','-r','-z','--no-renames','--no-ext-diff','--no-textconv',base,head).split(b'\0')
        projected=[]
        for j in range(0,len(raw)-1,2):
            if not raw[j]:continue
            h=raw[j].split();status=h[-1].decode();flags=['ADD'] if status=='A' else ['DELETE'] if status=='D' else ([] if h[2]==h[3] else ['MODIFY'])+([] if h[0][1:]==h[1] else ['MODE_CHANGE'])
            projected.append((base64.b64encode(raw[j+1]).decode(),flags))
        own=[(c['pathBytesBase64'],c['types']) for c in changes]
        assert projected==own,(scenario,projected,own)
        rawdiff.append({'case':idx,'equal':True})
        if scenario=='survived':f['verify']['mutants'][0]['classification']='SURVIVED';ev='MUTANT_SURVIVED'
        elif scenario=='stale':f['metadata']['currentHead']='d'*40;eg=ev='STALE_HEAD'
        elif scenario=='bad-contract':f['contract']='---yaml\n';eg=ev='CONTRACT_INVALID'
        elif scenario=='version':f['policy']['version']=2;eg=ev='CONTRACT_BINDING'
        elif scenario=='base-binding':f['contract']=contract('d'*40);eg=ev='CONTRACT_BINDING'
        elif scenario=='task-binding':f['policy']['taskId']='OTHER-0001';eg=ev='CONTRACT_BINDING'
        elif scenario in ('foreign-repo','foreign-author','branch','closed','event'):
            key,value={'foreign-repo':('headRepoId',9),'foreign-author':('authorId',9),'branch':('branch','forge/run/codexevil/task'),'closed':('state','closed'),'event':('event','push')}[scenario];f['metadata'][key]=value;eg=ev='METADATA_INVALID'
        elif scenario=='stale-base':f['metadata']['main']='d'*40;eg=ev='STALE_BASE'
        elif scenario=='history':f['ancestor']=False;eg=ev='HISTORY_INVALID'
        elif scenario=='limit':f['policy']['limits']['files']=1;eg=ev='LIMIT_EXCEEDED'
        elif scenario=='missing-check':f['verify']['checks'].pop();ev='CHECK_FAILED'
        elif scenario=='wrong-command':f['verify']['checks'][0]['command']='true';ev='CHECK_FAILED'
        elif scenario=='duplicate-check':f['verify']['checks'].append(copy.deepcopy(f['verify']['checks'][0]));ev='CHECK_FAILED'
        elif scenario=='missing-mutant':f['verify']['mutants']=[];ev='MUTANT_NOT_APPLIED'
        elif scenario=='infra-mutant':f['verify']['mutants'][0]['classification']='INFRA_FAILURE';ev='MUTANT_INFRA_FAILURE'
        elif scenario=='revoked':f['verify']['attestation']['revoked']=True;ev='ATTESTATION_INVALID'
        elif scenario=='wrong-owner':f['verify']['attestation']['userId']=9;ev='ATTESTATION_INVALID'
        elif scenario=='initial-run':f['verify']['runAttempt']=1;ev='ATTESTATION_INVALID'
        elif scenario=='wrong-trigger':f['verify']['triggeringActorId']=9;ev='ATTESTATION_INVALID'
        elif scenario=='wrong-report':f['verify']['attestation']['binding']['aiReportHash']='f'*64;ev='ATTESTATION_INVALID'
        elif scenario=='todo':f['verify']['head']['cases'][0]['status']='todo';ev='TEST_NOT_PASSED'
        elif scenario in ('new-tests','duplicate-title','parameterized'):
            c=copy.deepcopy(f['verify']['head']['cases'][0]);c['title']='extra' if scenario!='duplicate-title' else c['title'];c['occurrence']=2 if scenario=='duplicate-title' else 1;f['verify']['head']['cases'].append(c)
        elif scenario in ('config-shrink','removed-plus-added'):
            f['verify']['head']['cases'].pop(0);ev='BASELINE_TEST_LOST'
            if scenario=='removed-plus-added':c=copy.deepcopy(f['verify']['head']['cases'][0]);c['title']='replacement';f['verify']['head']['cases'].append(c)
        elif scenario=='no-attestation':f['verify'].pop('attestation');ev='ATTESTATION_INVALID'
        # Limit mutation intentionally invalidates binding too; gate priority remains authoritative.
        record=assert_case(f'{idx:03d}-{scenario}',f,eg,ev,db);record['repository']=f'repos/{idx:03d}.git';record['externalDiffCrossCheck']=True
        cases.append(record)
        if idx%25==0:print('corpus',idx,flush=True)
    save('differential/cases.json',{'schema':'forge-differential-corpus-v1','referenceProfile':'reference-v0.1-lab','cases':cases})
    save('adversarial.json',{'repositories':len(cases),'crashes':0,'expectationMismatches':0,'rawGitDiffComparisons':rawdiff,'outcomes':dict(collections.Counter(r['observed']['gate']['outcome'] for r in cases))})
    return cases

def properties():
    rng=random.Random(20261004);counts=collections.Counter();errors=[]
    def check(name,value):
        counts[name]+=1
        if not value:errors.append({'name':name,'iteration':counts[name]})
    for i in range(600):
        a=[entry(f'src/f{j:04d}.ts'.encode(),oid=f'{rng.getrandbits(160):040x}') for j in range(rng.randrange(1,40))];b=copy.deepcopy(a)
        b[rng.randrange(len(b))]['oid']=f'{rng.getrandbits(160):040x}'
        d=diff(a,b);check('diff deterministic',d==diff(a,b));rng.shuffle(a);rng.shuffle(b);check('reorder independent',d==diff(a,b))
        x=copy.deepcopy(a[0]);x['pathBytesBase64']=base64.b64encode(f'src/renamed-{i}'.encode()).decode();x['path']=f'src/renamed-{i}'
        renamed=diff(a,[x]+a[1:]);check('rename never MODIFY',[c['types'] for c in renamed]==[['DELETE'],['ADD']] or [c['types'] for c in renamed]==[['ADD'],['DELETE']])
        f=basic();before=gate(f);f['headTree'].append(entry(f'forbidden-{i}'.encode()));after=gate(f);check('out-of-scope never improves',before['outcome']=='PASS' and after['outcome']=='FAIL')
        f=basic();f['verify']['head']['cases'].pop(rng.randrange(3));v=verify(f);check('delete baseline never improves',v['code']=='BASELINE_TEST_LOST');f['verify']['head']['cases'].append({'file':'new.ts','project':'x','ancestors':[],'title':str(i),'occurrence':1,'status':'passed'});check('addition cannot compensate deletion',verify(f)['code']=='BASELINE_TEST_LOST')
        f=basic();f['verify']['mutants'][0]['classification']='SURVIVED';check('surviving mutant never PASS',verify(f)['code']=='MUTANT_SURVIVED')
        f=basic();f['metadata']['currentHead']=f'{rng.getrandbits(160):040x}';check('stale head never current',gate(f)['code']=='STALE_HEAD')
        coll=[entry(f'P{i}/a'.encode()),entry(f'p{i}/b'.encode())];check('collision rejected before materialization',bool(path_safety(coll)))
        f=basic();f['headTree'][0]['mode']=rng.choice(['100600','120000','160000','100664','000000']);check('unknown mode never accepted',gate(f)['code']=='PATH_UNSAFE')
    # Failure priority under independent metadata/scope/order permutations.
    for i in range(200):
        f=basic();f['metadata']['currentHead']='d'*40;f['headTree'].append(entry(b'forbidden'));rng.shuffle(f['headTree']);check('failure priority stable',gate(f)['code']=='STALE_HEAD')
    # Totality for bounded malformed JSON-like inputs.
    atoms=[None,False,1,'x',[],{},['x'],{'x':1}]
    for i in range(200):
        f=basic();f[rng.choice(['contract','metadata','policy','baseTree','headTree'])]=rng.choice(atoms)
        check('malformed input defined result',gate(f)['outcome'] in ('PASS','FAIL'))
    save('properties.json',{'seed':20261004,'checks':sum(counts.values()),'counts':dict(counts),'failures':errors});assert not errors,errors
    print('properties',sum(counts.values()),flush=True)

def performance():
    results=[]
    for n in [100,1000,10000]:
        db=newdb(WORK/f'perf-{n}.git');files={f'd{j//100:03d}/f{j:05d}.ts'.encode():('100644','blob',b'baseline') for j in range(n)}
        # Build raw trees with shared blob caching to measure collection rather than fixture subprocess cost.
        base=commit(db,files);files[list(files)[-1]]=('100644','blob',b'head');head=commit(db,files,[base]);samples=[]
        for run in range(3):
            t=time.perf_counter();a=db.collectTree(base);b=db.collectTree(head);t1=time.perf_counter();d=diff(a,b);t2=time.perf_counter();p=path_safety(b);t3=time.perf_counter();m={'scope':{'modify':[d[0]['path']],'create':[]}};s=scope_errors(d,m,{});t4=time.perf_counter();assert not p and not s
            samples.append({'collectionMs':(t1-t)*1000,'diffMs':(t2-t1)*1000,'pathMs':(t3-t2)*1000,'scopeMs':(t4-t3)*1000})
        # Also scope n changed files, not only single-change sparse diff.
        dense=diff([],b);m={'scope':{'create':[e['path'] for e in b],'modify':[]}}
        t=time.perf_counter();scope_errors(dense,m,{});dense_ms=(time.perf_counter()-t)*1000
        results.append({'files':n,'samples':samples,'median':{k:statistics.median(s[k] for s in samples) for k in samples[0]},'denseScopeMs':dense_ms})
        print('perf',n,flush=True)
    save('performance.json',results)

def parser_checks():
    texts=[p.read_text() for p in sorted((ROOT/'upstream/forge/contracts').glob('*.md'))];labels=[p.name for p in sorted((ROOT/'upstream/forge/contracts').glob('*.md'))]
    c=contract('b'*40)
    probes=[c,'\ufeff'+c,c.replace('\n','\r\n'),c.replace('---json','---yaml'),c.replace('\n---\n',''),c.replace('  "forgeContractFormat"',' "forgeContractFormat"'),c.replace('"contractVersion": 1','"contractVersion": 0'),c.replace('"contractVersion": 1','"contractVersion": 9007199254740992'),c.replace('"mutationSmoke": "required"','"mutationSmoke": "future"'),c.replace('"dependencies": []','"dependencies": [],\n  "reads": []')]
    texts+=probes;labels += [f'probe-{i}' for i in range(len(probes))]
    # Canonical Format-1 schema mutations; actual parser run in a single trusted process.
    for i in range(100):
        m=json.loads(c.split('\n---\n')[0][8:]);k=['taskId','contractVersion','baseCommit','scope','requiredChecks','mutationSmoke','dependencies'][i%7]
        m[k]=[None,False,0,'',{},[],['x']][i%7];texts.append('---json\n'+json.dumps(m,indent=2)+'\n---\nbody');labels.append(f'schema-{i}')
    rng=random.Random(811);
    for i in range(500):
        m=json.loads(c.split('\n---\n')[0][8:]);m['contractVersion']=i+1;m['taskId']=f'REF-PARSER-{i}';m['scope']['create']=[f'tests/new-{i}.test.ts'];m['scope']['modify']=[f'src/file-{j}.ts' for j in range(rng.randrange(1,12))];m['mutationSmoke']=rng.choice(['none','optional','required'])
        if i%4==0:m['dependencies']=[{'taskId':f'OTHER-{i}','acceptedCommit':None if i%8 else 'e'*40}]
        if i%5==0:m['requiredChecks'][0]['command']=rng.choice(['\u0085','\u00a0','\ufeff','\u200b','npm test\u2028'])
        text='---json\n'+json.dumps(m,ensure_ascii=False,indent=2)+'\n---\nbody';texts.append(text);labels.append(f'generated-{i}')
    save('parser-inputs.json',texts);r=command(['node',str(ROOT/'reference/parser_bridge.mjs'),str(ROOT/'upstream'),str(OUT/'parser-inputs.json')]);assert r['exit']==0,r['stderr'];actual=json.loads(r['stdout']);rows=[]
    for label,text,oracle in zip(labels,texts,actual):
        try:ref=parse_contract(text);mine={'ok':True,'metadata':ref['metadata'],'hash':ref['contentHash']}
        except RefError as e:mine={'ok':False,'code':e.detail}
        equal=mine['ok']==oracle['ok'] and (not mine['ok'] or mine['metadata']==oracle['metadata'] and mine['hash']==oracle['hash'])
        assert equal,(label,mine,oracle);rows.append({'label':label,'independent':mine,'actualParser':oracle,'equal':equal})
    save('parser-differential.json',rows);print('parser',len(rows),flush=True)

def copy_source(dest):
    dest=Path(dest)
    if dest.exists():shutil.rmtree(dest)
    shutil.copytree(ROOT/'upstream',dest,ignore=shutil.ignore_patterns('.git','node_modules'))
    os.symlink(str(ROOT/'upstream/node_modules'),dest/'node_modules',target_is_directory=True)
    return dest
def inventory_experiments():
    baseline=json.load(open(OUT/'baseline.json'));rows=[]
    path='tests/forge/identity.test.ts';original=(ROOT/'upstream'/path).read_text()
    for name in ['delete','test-skip','describe-skip','todo','new','duplicate','parameterized','config-shrink']:
        root=copy_source(WORK/f'inventory-{name}');p=root/path
        if name=='delete':p.unlink()
        elif name=='test-skip':p.write_text(original.replace('it(', 'it.skip(',1))
        elif name=='describe-skip':p.write_text(original.replace('describe(', 'describe.skip(',1))
        elif name=='todo':p.write_text(original+'\nit.todo("new todo");\n')
        elif name=='new':p.write_text(original+'\nit("extra",()=>expect(1).toBe(1));\n')
        elif name=='duplicate':p.write_text(original+'\nit("duplicate",()=>expect(1).toBe(1));\nit("duplicate",()=>expect(1).toBe(1));\n')
        elif name=='parameterized':p.write_text(original+'\nit.each([1,2,3])("parameter %s",n=>expect(n).toBeGreaterThan(0));\n')
        elif name=='config-shrink':(root/'vitest.config.mjs').write_text('import {writeFileSync} from "node:fs";writeFileSync("CONFIG_EXECUTED", "bad");export default {test:{include:["tests/forge/identity.test.ts"]}};\n')
        r=run_inventory(root,ROOT/'upstream',OUT/f'inventories/{name}.json');compare=inventory_compare(baseline,r['inventory']);expected='FAIL' if name in ('delete','test-skip','describe-skip','todo') else 'PASS';assert compare['outcome']==expected,(name,compare)
        row={'name':name,'exit':r['exit'],'cases':len(r['inventory']['cases']),'statuses':dict(collections.Counter(c['status'] for c in r['inventory']['cases'])),'comparison':compare,'candidateConfigExecuted':(root/'CONFIG_EXECUTED').exists()};assert not row['candidateConfigExecuted'];rows.append(row);print('inventory',name,row['cases'],compare['code'],flush=True)
    # Direct evidence of a genuinely shrunken discovered config: safe fixture emits marker.
    root=WORK/'inventory-config-shrink';r=command(['node',str(ROOT/'upstream/node_modules/vitest/vitest.mjs'),'run','--reporter=json','--outputFile='+str(OUT/'unsafe-discovery.json')],cwd=root,timeout=120)
    x=json.load(open(OUT/'unsafe-discovery.json'));rows.append({'name':'unsafe-config-auto-discovery-control','exit':r['exit'],'tests':x['numTotalTests'],'candidateConfigExecuted':(root/'CONFIG_EXECUTED').exists(),'classification':'CONTROL_ONLY_NOT_TRUSTED_EXECUTION'})
    # A config-shrink head report fixture loses identities even if all selected tests passed.
    shrunk=copy.deepcopy(baseline);shrunk['cases']=[c for c in baseline['cases'] if c['file']==path];shrunk['files']=[path];rows.append({'name':'config-shrink-inventory-comparison','comparison':inventory_compare(baseline,shrunk)})
    save('inventory-experiments.json',rows)

def mutation_experiments():
    root=copy_source(WORK/'clamp');(root/'src').mkdir(exist_ok=True);(root/'tests').mkdir(exist_ok=True)
    # Dedicated deterministic drill: no large repository suite needed for these named mutations.
    (root/'src/clamp.ts').write_text('export function clampAtZero(n: number): number { return n < 0 ? 0 : n; }\n')
    (root/'tests/clamp.test.ts').write_text('import {it,expect} from "vitest"; import {clampAtZero} from "../src/clamp.ts";\nit("negative",()=>expect(clampAtZero(-1)).toBe(0));\nit("zero",()=>expect(clampAtZero(0)).toBe(0));\nit("positive",()=>expect(clampAtZero(2)).toBe(2));\n')
    basic={'file':'src/clamp.ts','anchor':'return n < 0 ? 0 : n;','testFiles':['tests/clamp.test.ts'],'expectedFailureTitle':'negative'}
    configs=[('real-kill','return n;','KILLED'),('survived','if(n < 0) return 0; return n;','SURVIVED'),('compiler-crash','return ( @@@;','INFRA_FAILURE'),('timeout','while(true) {}','INFRA_FAILURE')]
    results=[]
    for name,replacement,expected in configs:
        spec=basic|{'id':name,'replacement':replacement,'timeout':2 if name=='timeout' else 30};r=mutation(root,ROOT/'upstream',spec,OUT/f'mutants/{name}.json');assert r['classification']==expected,(name,r);results.append(r);print('mutant',name,r['classification'],flush=True)
    for name,change in [('missing-anchor',{'anchor':'no such anchor'}),('duplicate-anchor',{}),('wrong-test-file',{'testFiles':['tests/missing.test.ts']})]:
        if name=='duplicate-anchor':p=root/'src/clamp.ts';old=p.read_text();p.write_text(old+'// return n < 0 ? 0 : n;\n')
        spec=basic|{'id':name,'replacement':'return n;',**change};r=mutation(root,ROOT/'upstream',spec,OUT/f'mutants/{name}.json');expected='NOT_APPLIED' if name!='wrong-test-file' else 'INFRA_FAILURE';assert r['classification']==expected,(name,r);results.append(r)
        if name=='duplicate-anchor':p.write_text(old)
    # Trusted tsc still detects errors even with a candidate config excluding all source.
    (root/'tsconfig.json').write_text('{"include":["no-source-here"]}');p=root/'src/clamp.ts';old=p.read_text();p.write_text(old+'const bad: number = "string";\n');t=typecheck(root,ROOT/'upstream',ROOT/'upstream/tsconfig.json');assert t['exit']!=0;p.write_text(old);save('trusted-tsc-config-shrink.json',t)
    save('mutations.json',results)
    return results

def acquisition_tests():
    root=newdb(WORK/'acquire-origin.git');base=commit(root,{b'safe.txt':('100644','blob',b'base')});head=commit(root,{b'safe.txt':('100644','blob',b'head')},[base]);root.git('update-ref','refs/heads/main',base);root.git('update-ref','refs/pull/1/head',head)
    marker=WORK/'HOOK_EXECUTED';hook=root.path/'hooks/post-update';hook.parent.mkdir();hook.write_text('#!/bin/sh\ntouch '+str(marker)+'\n');hook.chmod(0o755)
    root.git('config','diff.external','touch '+str(marker));root.git('config','core.hooksPath',str(root.path/'hooks'))
    fresh=WORK/'acquired.git'
    if fresh.exists():shutil.rmtree(fresh)
    # Inject hostile caller settings; child gets a newly built environment.
    prev={k:os.environ.get(k) for k in ['GIT_CONFIG_COUNT','GIT_CONFIG_KEY_0','GIT_CONFIG_VALUE_0','GIT_ALTERNATE_OBJECT_DIRECTORIES','NODE_OPTIONS']}
    os.environ.update(GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='diff.external',GIT_CONFIG_VALUE_0='touch '+str(marker),GIT_ALTERNATE_OBJECT_DIRECTORIES='/tmp/not-trusted',NODE_OPTIONS='--invalid-forge-ref-option')
    try:db=acquire(fresh,str(root.path),[('refs/heads/main',base),('refs/pull/1/head',head)])
    finally:
        for k,v in prev.items():
            if v is None:os.environ.pop(k,None)
            else:os.environ[k]=v
    assert db.readCommit(head)['parents']==[base] and not marker.exists();rows=[{'case':'isolated-exact-fetch','outcome':'PASS','markerExecuted':False}]
    for name,path,content in [('alternates','objects/info/alternates',str(root.path/'objects')),('grafts','info/grafts',head+' '+base),('shallow','shallow',head),('promisor','objects/pack/pack-test.promisor','')]:
        p=db.path/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(content)
        try:db.audit();raise AssertionError(name)
        except RefError as e:rows.append({'case':name,'code':e.code});assert e.code=='REPO_UNSAFE'
        p.unlink()
    db.git('update-ref','refs/replace/'+head,base)
    assert db.readCommit(head)['tree']!=db.readCommit(base)['tree']
    try:db.audit();raise AssertionError('replacement')
    except RefError as e:rows.append({'case':'replacement','code':e.code,'replacementInterpretation':False})
    db.git('update-ref','-d','refs/replace/'+head)
    db.git('config','include.path','/tmp/untrusted')
    try:db.audit();raise AssertionError('config')
    except RefError as e:rows.append({'case':'config include','code':e.code})
    db.git('config','--unset','include.path')
    # Fetched wrong expected pin always fails.
    wrong=WORK/'wrong-pin.git'
    if wrong.exists():shutil.rmtree(wrong)
    try:acquire(wrong,str(root.path),[('refs/heads/main',head)]);raise AssertionError('pin')
    except RefError as e:rows.append({'case':'wrong pin','code':e.code});assert e.code=='STALE_HEAD'
    save('git-acquisition.json',rows);print('acquisition',len(rows),flush=True)

def d_drill():
    cases=json.load(open(OUT/'differential/cases.json'))['cases'];lookup={r['id'].split('-',1)[1]:r for r in cases};rows=[]
    for label,scenario in [('D1','legitimate'),('D2','scope'),('D3','deleted-test'),('D4','skipped-test'),('D5','config'),('D6','protected'),('D7','extra'),('D8','survived'),('D9','stale')]:
        record=copy.deepcopy(lookup[scenario]);rows.append({'drill':label,'scenario':scenario,'gate':record['expected']['gate'],'verify':record['expected']['verify'],'metadataOnly':label=='D9'})
    f=basic();f['verify'].pop('attestation');assert verify(f)['code']=='ATTESTATION_INVALID';rows[0]['beforeAttestation']='ATTESTATION_INVALID'
    f=basic();f['verify']['attestation']['commitId']='d'*40;assert verify(f)['code']=='ATTESTATION_INVALID';rows[-1]['staleReviewCode']='ATTESTATION_INVALID'
    save('D1-D9.json',rows)
if __name__=='__main__':
    actions={'corpus':corpus,'properties':properties,'performance':performance,'parser':parser_checks,'inventory':inventory_experiments,'mutants':mutation_experiments,'acquisition':acquisition_tests,'drill':d_drill}
    for name in sys.argv[1:] or actions:actions[name]()
