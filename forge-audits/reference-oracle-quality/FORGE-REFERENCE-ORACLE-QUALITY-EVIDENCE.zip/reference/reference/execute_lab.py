#!/usr/bin/env python3
"""Executable local supervisor. Requires explicit --unsafe-local-lab; no sandbox claim."""
import argparse, copy, json, os, sys, tempfile
from pathlib import Path
from forge_ref import GitDB,gate,materialize,verify,canonical,outcome
from supervisor import run_inventory,typecheck,mutation

def execute(f,db,toolchain,trusted_config,out):
    g=gate(f,db)
    if g['outcome']!='PASS':return {'gate':g,'verify':verify(f,g),'isolation':'EXECUTION_ISOLATION_NOT_TESTED'}
    out=Path(out).resolve();out.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='forge-ref-execution-') as td:
        base,head=Path(td)/'base',Path(td)/'head'
        materialize(db,f['base'],base);materialize(db,f['head'],head)
        # Symlinking trusted dependencies here is a laboratory convenience, not a protected mount.
        for root in (base,head):os.symlink(str(Path(toolchain).resolve()/'node_modules'),root/'node_modules',target_is_directory=True)
        br=run_inventory(base,toolchain,out/'baseline.json');hr=run_inventory(head,toolchain,out/'head.json');tc=typecheck(head,toolchain,trusted_config)
        vf=copy.deepcopy(f);vf['verify']['baseline']=br['inventory'];vf['verify']['head']=hr['inventory'];vf['verify']['checks']=[{'name':'typecheck','command':'npm run typecheck','exit':tc['exit']},{'name':'test','command':'npm test','exit':hr['exit']}]
        mutants=[]
        for spec in f['policy']['mutants']:mutants.append(mutation(head,toolchain,spec,out/(spec['id']+'.json')))
        vf['verify']['mutants']=mutants
        v=verify(vf,g)
        if br['exit']!=0 or br['timeout'] or hr['timeout']:v=outcome([('CHECK_FAILED','baseline/timeout')])
        return {'gate':g,'verify':v,'baselineExit':br['exit'],'headExit':hr['exit'],'typecheck':tc,'mutants':mutants,'isolation':'EXECUTION_ISOLATION_NOT_TESTED','productionAuthority':False}
def main():
    p=argparse.ArgumentParser();p.add_argument('--unsafe-local-lab',action='store_true');p.add_argument('--manifest',required=True);p.add_argument('--repo',required=True);p.add_argument('--toolchain',required=True);p.add_argument('--trusted-config',required=True);p.add_argument('--out',required=True);a=p.parse_args()
    if not a.unsafe_local_lab:r=outcome([('EXECUTION_ISOLATION_NOT_TESTED','Docker unavailable; explicit local lab switch required')])
    else:
        try:r=execute(json.load(open(a.manifest)),GitDB(a.repo),a.toolchain,a.trusted_config,a.out)
        except Exception as e:r=outcome([('INPUT_INVALID',type(e).__name__)])
    print(canonical(r));return 0 if r.get('verify',r)['outcome']=='PASS' else 1
if __name__=='__main__':sys.exit(main())
