# Forge Verifier Reference Laboratory

Independent behavioral reference; no production authority. Canonical repository was accessed read-only. Pinned main: `3d7545d843883418348004e68717399a64da7a7d`.

Python 3.12 and Git 2.51.1 are used for the gate, raw object reader, fixtures and properties. Node 24.19.0 executes the existing TypeScript 7.0.2 / Vitest 5.0.3 / Zod 4.6.5 toolchain. No additional runtime dependency is introduced. Python was selected for raw byte paths and independent JSON/Unicode/object modeling; the actual main parser is a separate comparison oracle, never imported into the gate.

## Contents

- `reference/forge_ref.py`: CLI, bare acquisition, raw commit/tree reader, deterministic diff, path validator, Format-1 parser, gate, inventory comparator and verify evaluator.
- `reference/execute_lab.py`, `supervisor.py`, `run_inventory.mjs`: explicit local execution supervisor, direct trusted TypeScript and Vitest invocation, real runtime inventory and mutation runner.
- `reference/parser_bridge.mjs`: actual pinned main parser comparison.
- `reference/lab.py`, `boundaries.py`: authored adversarial fixture generator, properties, boundaries, experiments and benchmarks.
- `reference/differential.py`: black-box comparison adapter.
- `repos/`: 150 actual bare fixture repositories with deterministic commits and raw dangerous tree objects. Do not check them out or execute their contents.
- `results/differential/cases.json`: portable inputs, base/head identities and authored expected external outcomes and changes.
- `results/`: raw inventories, mutation reports, benchmarks, property results, D1–D9, acquisition and CLI differential results.
- `upstream/`: exact main source snapshot without `.git` or dependencies, for reproducibility of the actual parser and 1,087-test baseline. It is an input snapshot, not a modified canonical repository.
- `inputs/`: original Bootstrap Report and extracted text; historical design input.
- `FORGE-VERIFIER-REFERENCE-REPORT.html`: complete 18-section report.
- `MANIFEST-SHA256.json`: package file integrity manifest. This is not an approval or authenticity signature.

## Run without executing fixture source

From the extracted package directory:

```bash
python3 reference/differential.py . > blackbox-results.json
python3 reference/lab.py properties
python3 reference/boundaries.py
```

The default differential adapter runs the reference CLI, twice per case (gate and verify). To compare a future implementation, supply an argv adapter that accepts the documented external CLI interface:

```bash
python3 reference/differential.py . -- python3 /absolute/path/production_adapter.py
```

The adapter receives `gate|verify --repo PATH --manifest PATH`. It must emit one JSON object on stdout with `outcome: PASS|FAIL`, `code: string|null`, and optional `changes` for gate. Exit is 0 for PASS and 1 for FAIL. If changes are emitted they must equal the expected canonical changes. The future implementation can map native failure codes to this explicit **reference profile**. No claim is made that these new lab codes are already canonical Forge-Core codes.

The independent authored diff oracle computes Git blob identities directly from fixture file bytes. Expected gate/verify codes are set by the scenario author and asserted, not copied from reference outcomes. The corpus additionally cross-checks diff projections against Git's raw `--no-renames` comparison. Timing, diagnostics, caches, private data structures and traversal order are not expected behavior.

`verify` in the differential corpus evaluates supplied **trusted lab witness fixtures**. Most corpus runtime inventories/check results/mutation classifications are synthetic scenario inputs. They are NOT claims that all 150 arbitrary head sources were executed. Runtime collector/mutation behavior is separately tested with real runs and D1/D8 end-to-end execution. Future adapters should consume the same witness fixtures for this behavioral comparison; test the real production execution and report provenance independently.

## Inspect one case through the CLI

Extract one `input` into a manifest using a JSON tool, then:

```bash
python3 reference/forge_ref.py gate --repo repos/000.git --manifest case.json
python3 reference/forge_ref.py verify --repo repos/000.git --manifest case.json
python3 reference/forge_ref.py diff --repo repos/000.git --base BASE_SHA --head HEAD_SHA
python3 reference/forge_ref.py inventory --baseline results/baseline.json --candidate results/inventories/delete.json
```

Replace the full SHA placeholders with the identities from `cases.json`. `diff` uses raw byte path identity (Base64 in JSON), preserves mode/object kind/ID, sorts paths bytewise and never detects renames. Rename is DELETE+ADD. Content+mode change has two flags.

## Reproduce source-executing experiments

**EXECUTION_ISOLATION_NOT_TESTED. Docker was unavailable.** These are controlled, harmless local lab inputs, not a sandbox. Run only in a disposable environment you explicitly allow to execute the included test code. The supervisor requires `--unsafe-local-lab` for CLI execution. There are no read-only mounts, network block, cgroup memory/PID/CPU limits or protection from malicious JavaScript. A timeout process group and environment allowlist do not supply those guarantees.

Install only the pinned upstream input lockfile:

```bash
cd upstream
npm ci --ignore-scripts --no-audit --no-fund
cd ..
python3 -c 'import sys; sys.path.insert(0,"reference"); from supervisor import run_inventory,typecheck; run_inventory("upstream","upstream","results/baseline.json"); print(typecheck("upstream","upstream","upstream/tsconfig.json"))'
python3 reference/lab.py parser inventory mutants
```

The inventory runner uses the installed trusted Vitest API and supervisor-owned options (`config:false`, `configFile:false`, full include, no `.only`, no empty-suite pass, fixed name, no retries). No candidate npm script is executed. The TypeScript driver uses direct `node <trusted>/typescript/bin/tsc --project <external trusted config> --noEmit`; absolute include paths cover candidate src/tests. The original required-check command strings remain evidence identities, not shell commands executed from contract text.

Baseline/head source materialization happens only after complete path validation, into fresh private targets with O_EXCL/O_NOFOLLOW. Executable bits are preserved as tree facts and not automatically run. Dependencies are symlinked to the trusted installation for this local lab and are NOT a protected mount.

Actual D1 end-to-end:

```bash
python3 reference/execute_lab.py --unsafe-local-lab --manifest results/D1-execution-manifest.json --repo repos/000.git --toolchain upstream --trusted-config upstream/tsconfig.json --out results/D1-rerun
```

D1 uses real three-case Clamp tests, direct typecheck, a proven negative-return mutation and a local owner metadata attestation. The owner record is a fixture, not an authenticated GitHub approval.

## Regenerate repositories and performance evidence

```bash
python3 reference/lab.py acquisition corpus drill properties performance
```

The generator writes disposable repositories to `lab-work/adversarial`; the adapter automatically falls back to that location when `repos` is absent. Rebuilding replaces only generator-owned paths. Existing shipped `repos` remain unchanged; to test a regenerated corpus, use a fresh package/work folder or relocate the newly generated repositories to a separate differential package.

Acquisition accepts only fixed canonical HTTPS origin `https://github.com/Forge-Dice/Forge.git` or explicit absolute/file local laboratory origins. Only exact `refs/heads/main` and `refs/pull/<integer>/head` refs are accepted. Full 40-character expected SHAs are compared after fetch. A fresh bare ODB, empty template, config/hook isolation, no tags/submodules and fsck are used. Operator proxy variables are passed only to fetch for this managed network; they are removed from test execution. No credential helpers or authorization headers are added. Metadata audit rejects replacements, alternates/http-alternates, grafts, shallow, promisor and unexpected local config keys/includes.

The direct `--repo` option is a **local lab object reader**; it is not authorization to trust an arbitrary externally supplied `.git` directory in production. A real supervisor must own acquisition, storage and policy/contract inputs. Transport/resource and executable-toolchain trust remain outside this reference model.

## Contract and policy boundaries

Only today's Format 1 is supported: task, version, baseCommit, dependencies, exact create/modify scope, requiredChecks and mutationSmoke. `reads`, `limits` and concrete `mutants` do not exist in that metadata schema. They are explicitly separated auxiliary policy fixtures; unknown Format-2-style contract fields reject. Core coordination ADD/MODIFY exception is retained, but deletes/mode changes never receive that exception. Protected paths and frozen baseline test blobs override any scope allowlist.

The auxiliary policy is operator-owned and bound to the local owner attestation by its digest. Reads are checked as available baseline context, not enforced filesystem access. Mutant IDs are checked and required classifications fail closed. In execution each patch must match once, have distinct before/after bytes, pass its unmutated named tests, and produce the expected assertion failure. Timeout, collection/compiler error, wrong selection or broken infrastructure is never a kill. Equivalent surviving audit mutations are deliberately failures for this drill profile.

Failure priority is the ordered `PRIORITY` list exported in `results/failure-priority.json`; secondary subjects sort deterministically. It is a lab external protocol, not an invented replacement for the existing Core evaluator's sorted failure list. GitHub native check association, rulesets, Actions policy, actor lookup, latest review resolution/revocation and atomic merge semantics have not been proved by metadata fixtures.

Counts and timings describe this pinned snapshot and host only. The baseline count is collected, never used as the acceptance threshold. Scientific confidence, universal semantic correctness, complete parser equivalence and production security are not asserted. See the report for correlated-failure risks and independent Claude/Grok review targets.
